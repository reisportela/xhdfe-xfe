#!/usr/bin/env bash
set -euo pipefail

SCRIPT_DIR="$(cd -- "$(dirname -- "${BASH_SOURCE[0]}")" && pwd)"
REPO_ROOT="$(cd -- "${SCRIPT_DIR}/../.." && pwd)"

STATA_BIN="${STATA_BIN:-stata-mp}"
if ! command -v "${STATA_BIN}" >/dev/null 2>&1; then
  if command -v stata-se >/dev/null 2>&1; then
    STATA_BIN="stata-se"
  elif command -v stata >/dev/null 2>&1; then
    STATA_BIN="stata"
  else
    echo "Error: Stata executable not found. Set STATA_BIN=/path/to/stata." >&2
    exit 127
  fi
fi

if [[ "${XHDFE_BUILD_STATA_PLUGIN:-0}" == "1" ]]; then
  (
    cd "${REPO_ROOT}/stata"
    # shellcheck disable=SC2086
    bash tools/build-plugin.sh ${XHDFE_STATA_BUILD_ARGS:-}
    # shellcheck disable=SC2086
    bash tools/build-xfepout-plugin.sh ${XHDFE_STATA_BUILD_ARGS:-}
  )
fi

export XHDFE_REPO_ROOT="${REPO_ROOT}"
export XHDFE_STATA_TEST_DIR="${SCRIPT_DIR}"
export XHDFE_STATA_ADOPATH="${XHDFE_STATA_ADOPATH:-${REPO_ROOT}/stata}"

OUT_DIR="${XHDFE_STATA_TEST_OUTPUT:-${SCRIPT_DIR}/output}"
mkdir -p "${OUT_DIR}"

(
  cd "${OUT_DIR}"
  "${STATA_BIN}" -b do "${SCRIPT_DIR}/testall.do"
)

LOG_FILE="${OUT_DIR}/testall.log"
if ! grep -q "XHDFE STATA CERTIFICATION TESTS COMPLETED SUCCESSFULLY" "${LOG_FILE}"; then
  echo "Stata certification failed. Last log lines:" >&2
  tail -n 80 "${LOG_FILE}" >&2
  exit 1
fi

# Human-facing Gelbach output is a public contract: keep the integrated
# coefficient/block layout and audible diagnostics from silently reverting to
# separate raw matrix dumps or generic "see r(notes)" messages.
gelbach_markers=(
  "Gelbach decomposition of coefficient movement"
  "Movement = base coefficient - full coefficient"
  "Coefficient: x1"
  "Covariate blocks"
  "Absorbed fixed effects"
  "All fixed effects (subtotal)"
  "Total movement"
  "Result status"
  "FE mobility components (connected_worker connected_firm)"
  "Selected FE pair: connected; connected mode require"
  "connected(require) failed"
  "connected(require) requires exactly two FE dimensions"
  "FE X1-row split: normalization_dependent"
  "per-FE-dimension X1-row contributions are normalization-dependent"
  "per-FE-dimension X1-row contributions are not connectivity-certified"
  "0 (imposed)"
  "Summation check (max absolute residual)"
  "Interpretation: specification accounting, not causal mediation."
  "Reported focal coefficient(s):"
  "Shares: signed fraction of total movement"
  "Share inference: delta method using the joint component covariance."
  "Share inference: full delta method using Var(b_base) and Cov(delta,b_base)."
  "near-FE-collinear focal"
  "few clusters (G < 30)"
  "shares and confidence intervals are undefined and returned missing"
  "observed x2 group 1 is severely ill-conditioned"
  "absorbed-target inference is not certified for this VCE"
)
for marker in "${gelbach_markers[@]}"; do
  if ! grep -Fq "${marker}" "${LOG_FILE}"; then
    echo "Stata certification failed: missing Gelbach output marker: ${marker}" >&2
    exit 1
  fi
done
if grep -Fq "Gelbach inferential diagnostic; see r(notes)" "${LOG_FILE}"; then
  echo "Stata certification failed: Gelbach warning regressed to a generic r(notes) pointer" >&2
  exit 1
fi
if grep -Fq "Contributions (delta):" "${LOG_FILE}"; then
  echo "Stata certification failed: Gelbach display regressed to separate raw matrix dumps" >&2
  exit 1
fi

(
  cd "${OUT_DIR}"
  "${STATA_BIN}" -q -b do "${SCRIPT_DIR}/xhdfegelbach_bootstrap_smoke.do"
)
BOOTSTRAP_LOG="${OUT_DIR}/xhdfegelbach_bootstrap_smoke.log"
if ! grep -Fq "XHDFEGELBACH_BOOTSTRAP_SMOKE_PASS" "${BOOTSTRAP_LOG}"; then
  echo "Stata Gelbach bootstrap/reporting certification failed. Last log lines:" >&2
  tail -n 100 "${BOOTSTRAP_LOG}" >&2
  exit 1
fi

echo "Stata certification log: ${LOG_FILE}"
echo "Stata Gelbach bootstrap log: ${BOOTSTRAP_LOG}"

(
  cd "${OUT_DIR}"
  "${STATA_BIN}" -q -b do "${SCRIPT_DIR}/version_contract.do" cpu
)
if ! grep -Fxq "VERSION_CONTRACT_PASS cpu" "${OUT_DIR}/version_contract.log"; then
  echo "Stata stored/displayed version contract failed" >&2
  tail -n 80 "${OUT_DIR}/version_contract.log" >&2
  exit 1
fi

(
  cd "${OUT_DIR}"
  "${STATA_BIN}" -q -b do "${SCRIPT_DIR}/saturated_statistics_contract.do" cpu
)
if ! grep -Fxq "SATURATED_STATISTICS_CONTRACT_PASS cpu" "${OUT_DIR}/saturated_statistics_contract.log"; then
  tail -n 80 "${OUT_DIR}/saturated_statistics_contract.log" >&2
  exit 1
fi

(
  cd "${OUT_DIR}"
  "${STATA_BIN}" -q -b do "${SCRIPT_DIR}/absorb_interaction_contract.do" cpu
)
if ! grep -Fxq "ABSORB_INTERACTION_CONTRACT_PASS cpu" "${OUT_DIR}/absorb_interaction_contract.log"; then
  echo "Stata categorical absorb interaction contract failed" >&2
  tail -n 80 "${OUT_DIR}/absorb_interaction_contract.log" >&2
  exit 1
fi

(
  cd "${OUT_DIR}"
  "${STATA_BIN}" -q -b do "${SCRIPT_DIR}/cluster_interaction_contract.do" cpu
)
if ! grep -Fxq "CLUSTER_INTERACTION_CONTRACT_PASS cpu" "${OUT_DIR}/cluster_interaction_contract.log"; then
  echo "Stata categorical cluster/xfepout interaction contract failed" >&2
  tail -n 80 "${OUT_DIR}/cluster_interaction_contract.log" >&2
  exit 1
fi

(
  cd "${OUT_DIR}"
  "${STATA_BIN}" -q -b do "${SCRIPT_DIR}/group_interaction_contract.do" cpu
)
if ! grep -Fxq "GROUP_INTERACTION_CONTRACT_PASS cpu" "${OUT_DIR}/group_interaction_contract.log"; then
  tail -n 80 "${OUT_DIR}/group_interaction_contract.log" >&2
  exit 1
fi

(
  cd "${OUT_DIR}"
  "${STATA_BIN}" -q -b do "${SCRIPT_DIR}/iv_firststage_contract.do" cpu
)
FIRSTSTAGE_LOG="${OUT_DIR}/iv_firststage_contract.log"
if ! grep -Fxq "IV_FIRSTSTAGE_CONTRACT_PASS cpu" "${FIRSTSTAGE_LOG}"; then
  echo "Stata IV first-stage diagnostics failed. Last log lines:" >&2
  tail -n 80 "${FIRSTSTAGE_LOG}" >&2
  exit 1
fi
echo "Stata IV first-stage log: ${FIRSTSTAGE_LOG}"

(
  cd "${OUT_DIR}"
  "${STATA_BIN}" -q -b do "${SCRIPT_DIR}/../analytic_precision/iv_repeated_control_contract.do" cpu
)
IV_OVERLAP_LOG="${OUT_DIR}/iv_repeated_control_contract.log"
if ! grep -Fxq "IV_REPEATED_CONTROL_CONTRACT_PASS cpu" "${IV_OVERLAP_LOG}"; then
  echo "Stata IV repeated-control contract failed. Last log lines:" >&2
  tail -n 80 "${IV_OVERLAP_LOG}" >&2
  exit 1
fi
echo "Stata IV repeated-control log: ${IV_OVERLAP_LOG}"

(
  cd "${OUT_DIR}"
  "${STATA_BIN}" -q -b do "${SCRIPT_DIR}/../analytic_precision/iv_proportional_instrument_contract.do" cpu
)
IV_PROPORTIONAL_LOG="${OUT_DIR}/iv_proportional_instrument_contract.log"
if ! grep -Fxq "IV_PROPORTIONAL_INSTRUMENT_CONTRACT_PASS cpu" "${IV_PROPORTIONAL_LOG}"; then
  echo "Stata IV proportional-instrument contract failed. Last log lines:" >&2
  tail -n 80 "${IV_PROPORTIONAL_LOG}" >&2
  exit 1
fi
echo "Stata IV proportional-instrument log: ${IV_PROPORTIONAL_LOG}"

(
  cd "${OUT_DIR}"
  "${STATA_BIN}" -q -b do "${SCRIPT_DIR}/iv_firststage_alias_contract.do" cpu
)
ALIAS_LOG="${OUT_DIR}/iv_firststage_alias_contract.log"
if ! grep -Fxq "IV_FIRSTSTAGE_ALIAS_CONTRACT_PASS cpu" "${ALIAS_LOG}"; then
  tail -n 80 "${ALIAS_LOG}" >&2
  exit 1
fi

(
  cd "${OUT_DIR}"
  "${STATA_BIN}" -q -b do "${SCRIPT_DIR}/cg_near_redundant_contract.do" cpu 1
)
CG_LOG="${OUT_DIR}/cg_near_redundant_contract.log"
if ! grep -Fxq "CG_NEAR_REDUNDANT_CONTRACT_PASS cpu" "${CG_LOG}"; then
  tail -n 80 "${CG_LOG}" >&2
  exit 1
fi

DK_OUTPUT="${OUT_DIR}/dk_iv_$(date -u +%Y%m%dT%H%M%SZ)_$$"
python3 -B "${SCRIPT_DIR}/../analytic_precision/dkraay_iv_influence_contract.py" \
  --extended --backend cpu --package "${XHDFE_STATA_ADOPATH}" --output "${DK_OUTPUT}"

cuda04_backends=(cpu)
if [[ "${XHDFE_TEST_CUDA:-0}" == "1" ]]; then
  cuda04_backends+=(cuda)
fi
for backend in "${cuda04_backends[@]}"; do
  contract_dir="${OUT_DIR}/cuda04_${backend}"
  mkdir -p "${contract_dir}"
  (
    cd "${contract_dir}"
    "${STATA_BIN}" -q -b do "${SCRIPT_DIR}/cuda_ordinary_weak_graph_contract.do" "${backend}"
  )
  if ! grep -Fxq "CUDA_ORDINARY_WEAK_GRAPH_PASS ${backend}" "${contract_dir}/cuda_ordinary_weak_graph_contract.log"; then
    tail -n 60 "${contract_dir}/cuda_ordinary_weak_graph_contract.log" >&2
    exit 1
  fi
done
if [[ "${XHDFE_TEST_CUDA:-0}" == "1" ]]; then
  (
    cd "${OUT_DIR}"
    "${STATA_BIN}" -q -b do "${SCRIPT_DIR}/cg_cold_restart_floor.do"
  )
  if ! grep -Fxq "CG_COLD_FLOOR_PASS" "${OUT_DIR}/cg_cold_restart_floor.log"; then
    tail -n 60 "${OUT_DIR}/cg_cold_restart_floor.log" >&2
    exit 1
  fi
fi
