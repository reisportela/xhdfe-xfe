"""Falsification tests for the offline corresponding-source custody tools."""

from __future__ import annotations

import argparse
import copy
import hashlib
import json
from pathlib import Path
import shutil
import subprocess
import tempfile
import unittest
from unittest import mock
import zipfile

from tools import build_corresponding_source_bundle as builder
from tools import record_linux_release_provenance as linux_provenance
from tools import validate_corresponding_source_bundle as validator


REPO_ROOT = Path(__file__).resolve().parents[1]


class CorrespondingSourceBundleTests(unittest.TestCase):
    def test_source_rpm_identity_uses_sourcepackage_not_arch(self) -> None:
        with tempfile.TemporaryDirectory() as temporary:
            source_rpm = Path(temporary) / "gcc-8.5.0-28.el8_10.alma.1.src.rpm"
            source_rpm.write_bytes(b"synthetic source rpm")
            genuine = subprocess.CompletedProcess(
                args=[],
                returncode=0,
                stdout=(
                    "gcc\t0\t8.5.0\t28.el8_10.alma.1\tx86_64\t1\tabsent\n"
                ),
                stderr="warning: Header RSA/SHA256 Signature, key ID: NOKEY\n",
            )
            with mock.patch.object(linux_provenance, "_run", return_value=genuine):
                info = linux_provenance._source_rpm_info(source_rpm)
            self.assertEqual(info["rpm_name"], "gcc")
            self.assertEqual(info["arch"], "x86_64")
            self.assertEqual(info["file_kind"], "src")
            self.assertEqual(info["nevra"], "gcc-8.5.0-28.el8_10.alma.1.x86_64")

            binary_header = subprocess.CompletedProcess(
                args=[],
                returncode=0,
                stdout=(
                    "libgomp\t0\t8.5.0\t28.el8_10.alma.1\tx86_64\t0\tpresent\n"
                ),
                stderr="",
            )
            with (
                mock.patch.object(
                    linux_provenance, "_run", return_value=binary_header
                ),
                self.assertRaisesRegex(
                    linux_provenance.ProvenanceError, "not a valid source RPM"
                ),
            ):
                linux_provenance._source_rpm_info(source_rpm)

            inconsistent_source = subprocess.CompletedProcess(
                args=[],
                returncode=0,
                stdout=(
                    "gcc\t0\t8.5.0\t28.el8_10.alma.1\tx86_64\t1\tpresent\n"
                ),
                stderr="",
            )
            with (
                mock.patch.object(
                    linux_provenance, "_run", return_value=inconsistent_source
                ),
                self.assertRaisesRegex(
                    linux_provenance.ProvenanceError, "not a valid source RPM"
                ),
            ):
                linux_provenance._source_rpm_info(source_rpm)

            wrong_header = subprocess.CompletedProcess(
                args=[],
                returncode=0,
                stdout="gcc\t0\t8.5.1\t1.el8\tx86_64\t1\tabsent\n",
                stderr="",
            )
            with (
                mock.patch.object(
                    linux_provenance, "_run", return_value=wrong_header
                ),
                self.assertRaisesRegex(
                    linux_provenance.ProvenanceError, "header/filename mismatch"
                ),
            ):
                linux_provenance._source_rpm_info(source_rpm)

            malformed_epoch = subprocess.CompletedProcess(
                args=[],
                returncode=0,
                stdout=(
                    "gcc\t(none)\t8.5.0\t28.el8_10.alma.1\tx86_64\t1\tabsent\n"
                ),
                stderr="",
            )
            with (
                mock.patch.object(
                    linux_provenance, "_run", return_value=malformed_epoch
                ),
                self.assertRaisesRegex(
                    linux_provenance.ProvenanceError, "not a valid source RPM"
                ),
            ):
                linux_provenance._source_rpm_info(source_rpm)

            repeated = subprocess.CompletedProcess(
                args=[],
                returncode=0,
                stdout=genuine.stdout * 2,
                stderr="",
            )
            with (
                mock.patch.object(linux_provenance, "_run", return_value=repeated),
                self.assertRaisesRegex(
                    linux_provenance.ProvenanceError, "not a valid source RPM"
                ),
            ):
                linux_provenance._source_rpm_info(source_rpm)

            nosrc_rpm = Path(temporary) / "restricted-1.0-2.nosrc.rpm"
            nosrc_rpm.write_bytes(b"synthetic no-source rpm")
            nosrc = subprocess.CompletedProcess(
                args=[],
                returncode=0,
                stdout="restricted\t0\t1.0\t2\tnoarch\t1\tabsent\n",
                stderr="",
            )
            with mock.patch.object(linux_provenance, "_run", return_value=nosrc):
                info = linux_provenance._source_rpm_info(nosrc_rpm)
            self.assertEqual(info["file_kind"], "nosrc")

    def test_proprietary_rpm_may_omit_source_rpm_but_libgomp_may_not(self) -> None:
        with tempfile.TemporaryDirectory() as temporary:
            binary = Path(temporary) / "libdevice.10.bc"
            binary.write_bytes(b"synthetic libdevice")
            rpm_query = subprocess.CompletedProcess(
                args=[],
                returncode=0,
                stdout="cuda-nvcc-12-6\t0\t12.6.85\t1\tx86_64\t",
                stderr="",
            )
            with mock.patch.object(linux_provenance, "_run", return_value=rpm_query):
                with self.assertRaisesRegex(
                    linux_provenance.ProvenanceError, "no source RPM metadata"
                ):
                    linux_provenance._rpm_info_for_path(
                        binary,
                        allow_missing_source_rpm=False,
                        allow_multiple_owners=False,
                    )
                info = linux_provenance._rpm_info_for_path(
                    binary,
                    allow_missing_source_rpm=True,
                    allow_multiple_owners=False,
                )
                self.assertEqual(info["nevra"], "cuda-nvcc-12-6-12.6.85-1.x86_64")
                self.assertIsNone(info["source_rpm"])

            source_query = subprocess.CompletedProcess(
                args=[],
                returncode=0,
                stdout=(
                    "libgomp\t0\t13.2.1\t6.el8\tx86_64\t"
                    "gcc-toolset-13-gcc-13.2.1-6.el8.src.rpm"
                ),
                stderr="",
            )
            with mock.patch.object(linux_provenance, "_run", return_value=source_query):
                info = linux_provenance._rpm_info_for_path(
                    binary,
                    allow_missing_source_rpm=False,
                    allow_multiple_owners=False,
                )
                self.assertEqual(
                    info["source_rpm"],
                    "gcc-toolset-13-gcc-13.2.1-6.el8.src.rpm",
                )

            malformed = subprocess.CompletedProcess(
                args=[],
                returncode=0,
                stdout="cuda-nvcc-12-6\t\t12.6.85\t1\tx86_64\t(none)",
                stderr="",
            )
            with (
                mock.patch.object(linux_provenance, "_run", return_value=malformed),
                self.assertRaisesRegex(
                    linux_provenance.ProvenanceError, "incomplete RPM ownership"
                ),
            ):
                linux_provenance._rpm_info_for_path(
                    binary,
                    allow_missing_source_rpm=True,
                    allow_multiple_owners=False,
                )

            coowned = subprocess.CompletedProcess(
                args=[],
                returncode=0,
                stdout=(
                    "cuda-nvvm-12-6\t0\t12.6.85\t1\tx86_64\t"
                    "cuda-nvcc-12-6-12.6.85-1.src.rpm\n"
                    "cuda-nvcc-12-6\t0\t12.6.85\t1\tx86_64\t"
                    "cuda-nvcc-12-6-12.6.85-1.src.rpm\n"
                ),
                stderr="",
            )
            with mock.patch.object(linux_provenance, "_run", return_value=coowned):
                info = linux_provenance._rpm_info_for_path(
                    binary,
                    allow_missing_source_rpm=False,
                    allow_multiple_owners=True,
                )
                self.assertEqual(info["name"], "cuda-nvcc-12-6")
                self.assertEqual(
                    [owner["name"] for owner in info["coowners"]],
                    ["cuda-nvvm-12-6"],
                )
                with self.assertRaisesRegex(
                    linux_provenance.ProvenanceError,
                    "multiple RPM owners are not permitted",
                ):
                    linux_provenance._rpm_info_for_path(
                        binary,
                        allow_missing_source_rpm=False,
                        allow_multiple_owners=False,
                    )

            duplicated = subprocess.CompletedProcess(
                args=[],
                returncode=0,
                stdout=coowned.stdout.splitlines(keepends=True)[0] * 2,
                stderr="",
            )
            with mock.patch.object(linux_provenance, "_run", return_value=duplicated):
                with self.assertRaisesRegex(
                    linux_provenance.ProvenanceError,
                    "duplicate or conflicting RPM ownership metadata",
                ):
                    linux_provenance._rpm_info_for_path(
                        binary,
                        allow_missing_source_rpm=False,
                        allow_multiple_owners=True,
                    )

            conflicting = subprocess.CompletedProcess(
                args=[],
                returncode=0,
                stdout=(
                    coowned.stdout.splitlines(keepends=True)[0]
                    + coowned.stdout.splitlines(keepends=True)[0].replace(
                        "cuda-nvcc-12-6-12.6.85-1.src.rpm",
                        "contradictory-source.src.rpm",
                    )
                ),
                stderr="",
            )
            with mock.patch.object(linux_provenance, "_run", return_value=conflicting):
                with self.assertRaisesRegex(
                    linux_provenance.ProvenanceError,
                    "duplicate or conflicting RPM ownership metadata",
                ):
                    linux_provenance._rpm_info_for_path(
                        binary,
                        allow_missing_source_rpm=False,
                        allow_multiple_owners=True,
                    )

    def test_cuda_eula_is_an_explicit_hash_pinned_input(self) -> None:
        with tempfile.TemporaryDirectory() as temporary:
            eula = Path(temporary) / "NVIDIA-CUDA-12.6-EULA.pdf"
            payload = b"synthetic pinned CUDA EULA"
            eula.write_bytes(payload)
            digest = hashlib.sha256(payload).hexdigest()
            with mock.patch.object(linux_provenance, "_CUDA_EULA_SHA256", digest):
                self.assertEqual(
                    linux_provenance._validated_cuda_eula(eula),
                    eula.resolve(),
                )
                eula.write_bytes(payload + b" tampered")
                with self.assertRaisesRegex(
                    linux_provenance.ProvenanceError, "EULA hash mismatch"
                ):
                    linux_provenance._validated_cuda_eula(eula)

        self.assertEqual(
            linux_provenance._CUDA_EULA_SHA256,
            "7c2dc636ad47cf67a0efb97d9c11246efcc471ac9d11eb8efceae3bfd56d8649",
        )
        manylinux_path = REPO_ROOT / "ci" / "build_linux_release_manylinux.sh"
        if manylinux_path.is_file():
            manylinux = manylinux_path.read_text(encoding="utf-8")
            self.assertIn('CUDA_EULA_INPUT="${XHDFE_CUDA_EULA:?', manylinux)
            self.assertIn('--toolkit-eula "$CUDA_EULA_INPUT"', manylinux)

    def _file(self, root: Path, name: str, data: bytes) -> Path:
        path = root / name
        path.parent.mkdir(parents=True, exist_ok=True)
        path.write_bytes(data)
        return path

    def _inputs(self, root: Path, *, contains_cuda: bool = False) -> argparse.Namespace:
        component_paths = {}
        for object_id in sorted(builder.REQUIRED_COMPONENTS):
            component_paths[object_id] = self._file(
                root, f"inputs/{object_id}.src", f"source:{object_id}\n".encode()
            )
        provider_paths = {}
        for object_id in sorted(builder.REQUIRED_PROVIDERS):
            if object_id in builder.DEBIAN_SOURCE_PROVIDERS:
                provider_dir = root / "providers" / object_id
                payload = self._file(
                    provider_dir,
                    f"{object_id}.orig.tar.xz",
                    f"provider:{object_id}\n".encode(),
                )
                digest = hashlib.sha256(payload.read_bytes()).hexdigest()
                self._file(
                    provider_dir,
                    f"{object_id}.dsc",
                    (
                        "Format: 3.0 (quilt)\n"
                        "Checksums-Sha256:\n"
                        f" {digest} {payload.stat().st_size} {payload.name}\n"
                        "Files:\n"
                    ).encode(),
                )
                provider_paths[object_id] = provider_dir
            else:
                provider_paths[object_id] = self._file(
                    root,
                    f"providers/{object_id}.src",
                    f"provider:{object_id}\n".encode(),
                )

        components = [f"{name}={path}" for name, path in component_paths.items()]
        providers = [f"{name}={path}" for name, path in provider_paths.items()]
        runtimes = []
        runtime_providers = []
        provider_binaries = []
        metadata = [
            "gcc.version=13.2.0",
            "gcc.upstream_url=https://example.invalid/gcc-13.2.0",
            "mingw-w64.version=11.0.1",
            "mingw-w64.upstream_url=https://example.invalid/mingw-w64-11.0.1",
            "dlfcn-win32.version=1.4.1",
            "dlfcn-win32.upstream_url=https://example.invalid/dlfcn-win32-1.4.1",
            "winlibs-recipes.commit=0123456789abcdef",
            "winlibs-recipes.upstream_url=https://example.invalid/winlibs-recipes",
            "winlibs-tools.commit=fedcba9876543210",
            "winlibs-tools.upstream_url=https://example.invalid/winlibs-tools",
            "ubuntu-mingw-gcc.source_package=gcc-mingw-w64",
            "ubuntu-mingw-gcc.source_version=13.2.0-test",
            "ubuntu-mingw-gcc.upstream_url=https://example.invalid/ubuntu-gcc-source",
            "ubuntu-mingw-w64.source_package=mingw-w64",
            "ubuntu-mingw-w64.source_version=11.0.1-test",
            "ubuntu-mingw-w64.upstream_url=https://example.invalid/ubuntu-mingw-source",
            "manylinux-libgomp.nevra=libgomp-test.x86_64",
            "manylinux-libgomp.sourcerpm=gcc-test.src.rpm",
            "manylinux-libgomp.provider_path=/opt/test/libgomp.so.1",
            "manylinux-libgomp.upstream_url=https://example.invalid/manylinux-source-rpm",
        ]
        for runtime_id, provider_id in sorted(builder.RUNTIME_PROVIDERS.items()):
            data = f"runtime:{runtime_id}\n".encode()
            packaged = self._file(root, f"runtime/{runtime_id}.bin", data)
            provider = self._file(root, f"provider-bin/{runtime_id}.bin", data)
            runtimes.append(f"{runtime_id}={packaged}")
            runtime_providers.append(f"{runtime_id}={provider_id}")
            provider_binaries.append(f"{runtime_id}={provider}")
            metadata.append(f"{runtime_id}.release_path=release/{packaged.name}")
            metadata.append(f"{runtime_id}.provider_path=/toolchain/{runtime_id}.bin")

        return argparse.Namespace(
            output=str(root / "corresponding-source.zip"),
            version="2.24.0.20260815",
            component=components,
            provider_source=providers,
            runtime_binary=runtimes,
            runtime_provider=runtime_providers,
            provider_binary=provider_binaries,
            metadata=metadata,
            contains_cuda=contains_cuda,
            license_dir=str(REPO_ROOT / "third_party" / "licenses"),
            force=False,
        )

    def _stata_runtime_ledgers(self, root: Path) -> tuple[Path, Path, Path]:
        runtime_dir = root / "stata-runtimes"
        runtime_dir.mkdir()
        claims = {
            "libgcc_s_seh-1.dll": "GCC-13.2.0-COPYING.RUNTIME",
            "libgomp-1.dll": "GCC-13.2.0-COPYING.RUNTIME",
            "libstdc++-6.dll": "GCC-13.2.0-COPYING.RUNTIME",
            "libwinpthread-1.dll": "mingw-w64-11.0.1-winpthreads-COPYING",
        }
        entries = []
        for name, license_file in claims.items():
            payload = f"test runtime {name}\n".encode()
            (runtime_dir / name).write_bytes(payload)
            entries.append(
                {
                    "name": name,
                    "sha256": hashlib.sha256(payload).hexdigest(),
                    "size": len(payload),
                    "source_path": f"/usr/test/{name}",
                    "runtime_package": "test-runtime:amd64",
                    "runtime_version": "1-test",
                    "source_package": "test-source",
                    "source_version": "1-test",
                    "built_using": "",
                    "license_file": license_file,
                }
            )
        provider_ledger = root / "windows-stata-provider-ledger.json"
        provider_ledger.write_text(
            json.dumps(
                {
                    "schema_version": 1,
                    "artifact": "xhdfe-xfe-stata-windows-cpu",
                    "compiler": {
                        "target": "x86_64-w64-mingw32",
                        "version": "13.2.0",
                    },
                    "entries": sorted(entries, key=lambda item: item["name"].lower()),
                },
                indent=2,
                sort_keys=True,
            )
            + "\n",
            encoding="utf-8",
        )
        closure_ledger = root / "windows-stata-runtime-ledger.json"
        closure_ledger.write_text(
            json.dumps(
                {
                    "format": "xhdfe-windows-runtime-closure-v1",
                    "roots": [
                        {
                            "architecture": "pei-x86-64",
                            "dependencies": sorted(claims),
                            "member": "xhdfe.plugin",
                            "member_sha256": "0" * 64,
                            "size": 1,
                        }
                    ],
                    "runtimes": [
                        {
                            "architecture": "pei-x86-64",
                            "dependencies": [],
                            "license": "test",
                            "member": entry["name"],
                            "member_sha256": entry["sha256"],
                            "resolution_method": "test",
                            "size": entry["size"],
                            "source_path": entry["source_path"],
                            "source_sha256": entry["sha256"],
                        }
                        for entry in entries
                    ],
                },
                indent=2,
                sort_keys=True,
            )
            + "\n",
            encoding="utf-8",
        )
        return runtime_dir, provider_ledger, closure_ledger

    def _stage_windows_site(
        self,
        root: Path,
        runtime_dir: Path,
        provider_ledger: Path,
        closure_ledger: Path,
        site_name: str,
    ) -> subprocess.CompletedProcess[str]:
        xhdfe_plugin = self._file(root, "plugins/xhdfe.plugin", b"xhdfe PE fixture\n")
        xfe_plugin = self._file(root, "plugins/xfepout.plugin", b"xfepout PE fixture\n")
        return subprocess.run(
            [
                "bash",
                str(REPO_ROOT / "tools" / "stage_stata_netinstall_site.sh"),
                str(root / site_name),
                "--windows-xhdfe",
                str(xhdfe_plugin),
                "--windows-xfepout",
                str(xfe_plugin),
                "--windows-runtime-dir",
                str(runtime_dir),
                "--windows-runtime-provider-ledger",
                str(provider_ledger),
                "--windows-runtime-closure-ledger",
                str(closure_ledger),
            ],
            cwd=REPO_ROOT,
            text=True,
            capture_output=True,
        )

    def _rewrite_provenance(
        self, source: Path, destination: Path, transform
    ) -> None:
        with zipfile.ZipFile(source) as archive:
            payloads = {info.filename: archive.read(info.filename) for info in archive.infolist()}
        root = next(iter(payloads)).split("/", 1)[0]
        provenance_name = f"{root}/PROVENANCE.json"
        provenance = json.loads(payloads[provenance_name])
        transform(provenance)
        payloads[provenance_name] = (
            json.dumps(provenance, indent=2, sort_keys=True) + "\n"
        ).encode()
        manifest_name = f"{root}/MANIFEST.sha256"
        payloads[manifest_name] = "".join(
            f"{hashlib.sha256(data).hexdigest()}  {name[len(root) + 1:]}\n"
            for name, data in sorted(payloads.items())
            if name != manifest_name
        ).encode()
        with zipfile.ZipFile(destination, "w") as archive:
            for name, data in sorted(payloads.items()):
                archive.writestr(name, data)

    def test_roundtrip_closes_every_required_mapping(self) -> None:
        with tempfile.TemporaryDirectory() as temporary:
            args = self._inputs(Path(temporary))
            builder.build_archive(args)
            provenance = validator.validate(Path(args.output))
            self.assertEqual(
                set(builder.RUNTIME_PROVIDERS),
                {entry["id"] for entry in provenance["runtime_binaries"]},
            )

    def test_release_workflow_maps_current_stata_runtime_closure(self) -> None:
        self.assertEqual(builder.RUNTIME_PROVIDERS, validator.RUNTIME_PROVIDERS)
        self.assertEqual(
            {
                runtime_id: provider
                for runtime_id, provider in builder.RUNTIME_PROVIDERS.items()
                if runtime_id.startswith("windows-stata-")
            },
            {
                "windows-stata-libgcc": "ubuntu-mingw-gcc",
                "windows-stata-libgomp": "ubuntu-mingw-gcc",
                "windows-stata-libwinpthread": "ubuntu-mingw-w64",
            },
        )
        workflow_path = REPO_ROOT / ".github" / "workflows" / "release.yml"
        if not workflow_path.is_file():
            return
        workflow = workflow_path.read_text(encoding="utf-8")
        for fragment in (
            'test "${#STATA_RUNTIME_DLLS[@]}" -eq 0',
            '--windows-stata-static-ledger dl/windows-stata-provider-ledger.json',
            'tools/validate_python_release_artifacts.py --system-only',
            'needs: [build-linux, build-windows-python, build-macos, test-windows-stata]',
            "receipt['plugin_sha256'] == record['sha256']",
        ):
            self.assertIn(fragment, workflow)

    def test_archive_is_deterministic_across_staging_paths(self) -> None:
        with tempfile.TemporaryDirectory() as first, tempfile.TemporaryDirectory() as second:
            first_args = self._inputs(Path(first))
            second_args = self._inputs(Path(second))
            builder.build_archive(first_args)
            builder.build_archive(second_args)
            self.assertEqual(
                hashlib.sha256(Path(first_args.output).read_bytes()).hexdigest(),
                hashlib.sha256(Path(second_args.output).read_bytes()).hexdigest(),
            )

    def test_missing_source_fails_closed(self) -> None:
        with tempfile.TemporaryDirectory() as temporary:
            args = self._inputs(Path(temporary))
            args.component = [
                value for value in args.component if not value.startswith("gcc=")
            ]
            with self.assertRaisesRegex(ValueError, "missing source components: gcc"):
                builder.build_archive(args)

    def test_debian_provider_dsc_closure_rejects_missing_payload(self) -> None:
        with tempfile.TemporaryDirectory() as temporary:
            root = Path(temporary)
            args = self._inputs(root)
            assignment = next(
                value
                for value in args.provider_source
                if value.startswith("ubuntu-mingw-w64=")
            )
            provider_dir = Path(assignment.split("=", 1)[1])
            dsc = next(provider_dir.glob("*.dsc"))
            dsc.write_text(
                dsc.read_text(encoding="utf-8").replace(
                    "Files:\n",
                    f" {'0' * 64} 269 missing-orig-signature.asc\nFiles:\n",
                ),
                encoding="utf-8",
            )
            with self.assertRaisesRegex(ValueError, "missing Debian source payload"):
                builder.build_archive(args)

    def test_validator_rejects_reclosed_archive_missing_dsc_payload(self) -> None:
        with tempfile.TemporaryDirectory() as temporary:
            root_path = Path(temporary)
            args = self._inputs(root_path)
            builder.build_archive(args)
            source = Path(args.output)
            tampered = root_path / "tampered-corresponding-source.zip"
            with zipfile.ZipFile(source) as archive:
                payloads = {
                    info.filename: archive.read(info.filename)
                    for info in archive.infolist()
                }
            archive_root = next(iter(payloads)).split("/", 1)[0]
            provenance_name = f"{archive_root}/PROVENANCE.json"
            provenance = json.loads(payloads[provenance_name])
            provider = next(
                entry
                for entry in provenance["provider_sources"]
                if entry["id"] == "ubuntu-mingw-w64"
            )
            dropped = next(
                record
                for record in provider["files"]
                if record["path"].endswith(".orig.tar.xz")
            )
            provider["files"].remove(dropped)
            provider["tree_sha256"] = builder.tree_sha256(provider["files"])
            payloads.pop(
                f"{archive_root}/{provider['bundle_path']}/{dropped['path']}"
            )
            payloads[provenance_name] = (
                json.dumps(provenance, indent=2, sort_keys=True) + "\n"
            ).encode()
            manifest_name = f"{archive_root}/MANIFEST.sha256"
            payloads[manifest_name] = "".join(
                f"{hashlib.sha256(data).hexdigest()}  "
                f"{name[len(archive_root) + 1:]}\n"
                for name, data in sorted(payloads.items())
                if name != manifest_name
            ).encode()
            with zipfile.ZipFile(tampered, "w") as archive:
                for name, data in sorted(payloads.items()):
                    archive.writestr(name, data)
            with self.assertRaisesRegex(ValueError, "missing Debian source payload"):
                validator.validate(tampered)

    def test_extra_runtime_requires_full_mapping_and_is_manifested(self) -> None:
        with tempfile.TemporaryDirectory() as temporary:
            root = Path(temporary)
            args = self._inputs(root)
            packaged = self._file(root, "runtime/extra-runtime.dll", b"extra runtime\n")
            provider = self._file(root, "provider-bin/extra-runtime.dll", b"extra runtime\n")
            args.runtime_binary.append(f"windows-python-extra={packaged}")
            args.provider_binary.append(f"windows-python-extra={provider}")
            args.metadata.extend(
                [
                    "windows-python-extra.release_path=wheel/xhdfe/extra-runtime.dll",
                    "windows-python-extra.provider_path=C:/toolchain/extra-runtime.dll",
                ]
            )
            with self.assertRaisesRegex(ValueError, "runtime-provider"):
                builder.build_archive(args)

            args.runtime_provider.append("windows-python-extra=gcc")
            builder.build_archive(args)
            provenance = validator.validate(Path(args.output))
            runtime_ids = {entry["id"] for entry in provenance["runtime_binaries"]}
            self.assertIn("windows-python-extra", runtime_ids)

    def test_missing_license_fails_closed(self) -> None:
        with tempfile.TemporaryDirectory() as temporary:
            args = self._inputs(Path(temporary))
            empty = Path(temporary) / "empty-licenses"
            empty.mkdir()
            args.license_dir = str(empty)
            with self.assertRaisesRegex(ValueError, "missing input"):
                builder.build_archive(args)

    def test_payload_hash_mutation_is_rejected(self) -> None:
        with tempfile.TemporaryDirectory() as temporary:
            root = Path(temporary)
            args = self._inputs(root)
            builder.build_archive(args)
            original = Path(args.output)
            mutated = root / "mutated.zip"
            with zipfile.ZipFile(original) as source, zipfile.ZipFile(mutated, "w") as target:
                for info in source.infolist():
                    data = source.read(info.filename)
                    if info.filename.endswith("/README.md"):
                        data += b"mutation\n"
                    target.writestr(info, data)
            with self.assertRaisesRegex(ValueError, "manifest hash mismatch"):
                validator.validate(mutated)

    def test_duplicate_runtime_id_is_rejected_beyond_manifest_hash(self) -> None:
        with tempfile.TemporaryDirectory() as temporary:
            root = Path(temporary)
            args = self._inputs(root)
            builder.build_archive(args)
            mutated = root / "duplicate-runtime.zip"

            def duplicate(provenance):
                provenance["runtime_binaries"].append(
                    copy.deepcopy(provenance["runtime_binaries"][0])
                )

            self._rewrite_provenance(Path(args.output), mutated, duplicate)
            with self.assertRaisesRegex(ValueError, "duplicate runtime evidence IDs"):
                validator.validate(mutated)

    def test_false_byte_identity_claim_is_rejected_beyond_manifest_hash(self) -> None:
        with tempfile.TemporaryDirectory() as temporary:
            root = Path(temporary)
            args = self._inputs(root)
            builder.build_archive(args)
            mutated = root / "false-byte-identity.zip"

            def contradict(provenance):
                runtime = provenance["runtime_binaries"][0]
                runtime["provider_binary_sha256"] = "0" * 64
                runtime["byte_identical_to_provider"] = True

            self._rewrite_provenance(Path(args.output), mutated, contradict)
            with self.assertRaisesRegex(ValueError, "claim contradicts recorded hashes"):
                validator.validate(mutated)

    def test_license_ledger_omission_is_rejected_beyond_manifest_hash(self) -> None:
        with tempfile.TemporaryDirectory() as temporary:
            root = Path(temporary)
            args = self._inputs(root)
            builder.build_archive(args)
            mutated = root / "missing-license-record.zip"

            def omit(provenance):
                provenance["license_files"] = provenance["license_files"][:-1]

            self._rewrite_provenance(Path(args.output), mutated, omit)
            with self.assertRaisesRegex(ValueError, "license ledger"):
                validator.validate(mutated)

    def test_unsafe_zip_member_is_rejected(self) -> None:
        with tempfile.TemporaryDirectory() as temporary:
            root = Path(temporary)
            args = self._inputs(root)
            builder.build_archive(args)
            unsafe = root / "unsafe.zip"
            shutil.copyfile(args.output, unsafe)
            with zipfile.ZipFile(unsafe, "a") as archive:
                archive.writestr("../escape", b"not extracted")
            with self.assertRaisesRegex(ValueError, "unsafe ZIP member path"):
                validator.validate(unsafe)

    def test_cuda_requires_and_validates_both_exact_license_inputs(self) -> None:
        with tempfile.TemporaryDirectory() as temporary:
            root = Path(temporary)
            license_dir = root / "licenses"
            license_dir.mkdir()
            for name in builder.LICENSE_HASHES:
                shutil.copyfile(REPO_ROOT / "third_party" / "licenses" / name, license_dir / name)

            fake_cuda = {
                "NVIDIA-CUDA-12.6-EULA.pdf": b"test CUDA EULA bytes\n",
                "NVIDIA-CCCL-2.5.0-LICENSE": b"test CCCL license bytes\n",
            }
            test_hashes = {
                name: hashlib.sha256(data).hexdigest()
                for name, data in fake_cuda.items()
            }
            (license_dir / "NVIDIA-CUDA-12.6-EULA.pdf").write_bytes(
                fake_cuda["NVIDIA-CUDA-12.6-EULA.pdf"]
            )

            args = self._inputs(root, contains_cuda=True)
            args.license_dir = str(license_dir)
            with mock.patch.dict(builder.CUDA_LICENSE_HASHES, test_hashes, clear=True):
                with self.assertRaisesRegex(ValueError, "missing input"):
                    builder.build_archive(args)

            (license_dir / "NVIDIA-CCCL-2.5.0-LICENSE").write_bytes(
                fake_cuda["NVIDIA-CCCL-2.5.0-LICENSE"]
            )
            with mock.patch.dict(builder.CUDA_LICENSE_HASHES, test_hashes, clear=True), \
                 mock.patch.object(builder.subprocess, "run"):
                builder.build_archive(args)
            with mock.patch.dict(validator.CUDA_LICENSE_HASHES, test_hashes, clear=True):
                provenance = validator.validate(Path(args.output))
            self.assertTrue(provenance["cuda"]["included"])
            self.assertEqual(
                provenance["cuda"]["redistributable_static_components"],
                ["libcudadevrt", "libcudart_static"],
            )

    def test_stata_stage_uses_complete_generic_runtime_ledger(self) -> None:
        with tempfile.TemporaryDirectory() as temporary:
            root = Path(temporary)
            runtime_dir, provider_ledger, closure_ledger = self._stata_runtime_ledgers(root)
            staged = self._stage_windows_site(
                root, runtime_dir, provider_ledger, closure_ledger, "site"
            )
            self.assertEqual(staged.returncode, 0, staged.stderr)
            site = root / "site"
            validated = subprocess.run(
                [
                    "bash",
                    str(REPO_ROOT / "tools" / "validate_stata_package_site.sh"),
                    str(site),
                ],
                cwd=REPO_ROOT,
                text=True,
                capture_output=True,
            )
            self.assertEqual(validated.returncode, 0, validated.stderr)
            package = (site / "xhdfe.pkg").read_text(encoding="utf-8")
            for runtime in sorted(path.name for path in runtime_dir.iterdir()):
                self.assertIn(f"G WIN64 {runtime} {runtime}\n", package)
            self.assertIn(
                "g WIN64 windows-stata-provider-ledger.json "
                "windows-stata-provider-ledger.json\n",
                package,
            )
            self.assertIn(
                "g WIN64 windows-stata-runtime-ledger.json "
                "windows-stata-runtime-ledger.json\n",
                package,
            )

            (site / "unledgered.dll").write_bytes(b"orphan\n")
            rejected = subprocess.run(
                [
                    "bash",
                    str(REPO_ROOT / "tools" / "validate_stata_package_site.sh"),
                    str(site),
                ],
                cwd=REPO_ROOT,
                text=True,
                capture_output=True,
            )
            self.assertNotEqual(rejected.returncode, 0)
            self.assertIn("runtime ledger/site DLL mismatch", rejected.stderr)

    def test_stata_stage_rejects_runtime_not_in_ledger(self) -> None:
        with tempfile.TemporaryDirectory() as temporary:
            root = Path(temporary)
            runtime_dir, provider_ledger, closure_ledger = self._stata_runtime_ledgers(root)
            (runtime_dir / "unledgered.dll").write_bytes(b"orphan\n")
            rejected = self._stage_windows_site(
                root,
                runtime_dir,
                provider_ledger,
                closure_ledger,
                "bad-site",
            )
            self.assertNotEqual(rejected.returncode, 0)
            self.assertIn("ledger/directory mismatch", rejected.stderr)

    def test_stata_stage_rejects_provider_closure_ledger_disagreement(self) -> None:
        with tempfile.TemporaryDirectory() as temporary:
            root = Path(temporary)
            runtime_dir, provider_ledger, closure_ledger = self._stata_runtime_ledgers(root)
            closure = json.loads(closure_ledger.read_text(encoding="utf-8"))
            closure["runtimes"][0]["member_sha256"] = "0" * 64
            closure_ledger.write_text(
                json.dumps(closure, indent=2, sort_keys=True) + "\n",
                encoding="utf-8",
            )
            rejected = self._stage_windows_site(
                root,
                runtime_dir,
                provider_ledger,
                closure_ledger,
                "bad-closure-site",
            )
            self.assertNotEqual(rejected.returncode, 0)
            self.assertIn("ledgers disagree", rejected.stderr)

    def test_static_windows_package_installs_entire_runtime_closure(self) -> None:
        with tempfile.TemporaryDirectory() as temporary:
            root = Path(temporary)
            runtime_dir, provider_ledger, closure_ledger = self._stata_runtime_ledgers(root)
            staged = self._stage_windows_site(
                root, runtime_dir, provider_ledger, closure_ledger, "static-site"
            )
            self.assertEqual(staged.returncode, 0, staged.stderr)
            site = root / "static-site"
            for cmd in ("xhdfe", "xfepout"):
                (site / f"{cmd}.win64.plugin").replace(site / f"{cmd}.plugin")
            runtime_names = sorted(path.name for path in runtime_dir.iterdir())
            additions = runtime_names + [
                "windows-stata-provider-ledger.json",
                "windows-stata-runtime-ledger.json",
            ]
            for pkg_name in ("xhdfe.pkg", "xfepout.pkg"):
                pkg = site / pkg_name
                lines = [
                    line
                    for line in pkg.read_text(encoding="utf-8").splitlines()
                    if not line.startswith(("g WIN64 ", "G WIN64 "))
                ]
                plugin_names = (
                    ("xhdfe.plugin", "xfepout.plugin")
                    if pkg_name == "xhdfe.pkg"
                    else ("xfepout.plugin",)
                )
                lines.extend(f"f {name}" for name in plugin_names)
                lines.extend(f"f {name}" for name in additions)
                pkg.write_text("\n".join(lines) + "\n", encoding="utf-8")

            validated = subprocess.run(
                [
                    "bash",
                    str(REPO_ROOT / "tools" / "validate_stata_package_site.sh"),
                    str(site),
                ],
                cwd=REPO_ROOT,
                text=True,
                capture_output=True,
            )
            self.assertEqual(validated.returncode, 0, validated.stderr)

            xfe_pkg = site / "xfepout.pkg"
            omitted = f"f {runtime_names[0]}\n"
            xfe_pkg.write_text(
                xfe_pkg.read_text(encoding="utf-8").replace(omitted, ""),
                encoding="utf-8",
            )
            rejected = subprocess.run(
                [
                    "bash",
                    str(REPO_ROOT / "tools" / "validate_stata_package_site.sh"),
                    str(site),
                ],
                cwd=REPO_ROOT,
                text=True,
                capture_output=True,
            )
            self.assertNotEqual(rejected.returncode, 0)
            self.assertIn("runtime DLL lacks one exact installable platform mapping", rejected.stderr)


if __name__ == "__main__":
    unittest.main()
