#include "stplugin.h"

#include <Eigen/Dense>

#include <algorithm>
#include <atomic>
#include <chrono>
#include <cerrno>
#include <cctype>
#include <cstdint>
#include <cmath>
#include <cstdlib>
#include <cstdio>
#include <cstring>
#include <deque>
#include <iostream>
#include <limits>
#include <memory>
#include <new>
#include <optional>
#include <sstream>
#include <stdexcept>
#include <string>
#include <unordered_map>
#include <utility>
#include <vector>

#ifdef _OPENMP
#include <omp.h>
#endif

#include "hdfe/akm_kss.hpp"
#include "hdfe/hdfe_regressor_v11.hpp"
#include "hdfe/ieee_bits.hpp"
#include "hdfe/parallel_work_observer.hpp"
#include "fe_absorption_cuda.hpp"
#include "xhdfe_stata_buildinfo.hpp"
#include "xhdfe_wide_id_rank.hpp"

// Parallel sort when libstdc++ parallel mode is available (GCC host compiler
// with OpenMP, as used by the plugin build); otherwise fall back to std::sort.
// The only use is the categorical dense-rank below, whose output is invariant
// to how the sort orders equal keys, so results are bit-for-bit unchanged.
#if defined(__GNUC__) && defined(_OPENMP) && __has_include(<parallel/algorithm>)
#include <parallel/algorithm>
#define XHDFE_HAS_GNU_PARALLEL_SORT 1
#define XHDFE_PARALLEL_SORT(first, last, cmp) __gnu_parallel::sort((first), (last), (cmp))
#else
#define XHDFE_PARALLEL_SORT(first, last, cmp) std::sort((first), (last), (cmp))
#endif

namespace {

using hdfe::AbsorptionMethod;
using hdfe::ConvergenceCriterion;
using hdfe::DofAdjustmentMethod;
using hdfe::FeRecoveryMethod;
using hdfe::FixefDofMethod;
using hdfe::HdfeOptions;
using hdfe::StandardErrorType;
using hdfe::StatsStyle;
using hdfe::ToleranceMode;
using hdfe::ClusterDofMethod;
using hdfe::detail::HeterogeneousSlopeTerm;
using hdfe::detail::ParallelWorkObserver;
using hdfe::v11::GroupAggregation;
using hdfe::v11::HdfeRegressorV11;
using hdfe::v11::ThreadingOptions;

constexpr double kGroupConstantTol = 1e-12;

[[noreturn]] void throw_with_prefix(const char* prefix, const std::string& msg);

// The plugin performs categorical dense-ranking before HdfeRegressorV11 is
// constructed.  Apply an explicit num_threads request to that preprocessing
// too, then restore Stata's caller ICV on every normal/exceptional exit.
class ScopedPluginThreadRequest {
public:
    explicit ScopedPluginThreadRequest(int requested) {
#ifdef _OPENMP
        if (requested <= 0) return;
        if (requested > 1 && omp_in_parallel()) {
            throw std::runtime_error(
                "xhdfe plugin: explicit num_threads > 1 cannot be guaranteed "
                "inside an active OpenMP region");
        }
        previous_dynamic_ = omp_get_dynamic();
        previous_threads_ = omp_get_max_threads();
        const int capacity = std::max(
            1, std::min(omp_get_num_procs(), omp_get_thread_limit()));
        omp_set_dynamic(0);
        omp_set_num_threads(std::max(1, std::min(requested, capacity)));
        active_ = true;
#else
        (void)requested;
#endif
    }

    ~ScopedPluginThreadRequest() {
#ifdef _OPENMP
        if (active_) {
            omp_set_num_threads(previous_threads_);
            omp_set_dynamic(previous_dynamic_);
        }
#endif
    }

    ScopedPluginThreadRequest(const ScopedPluginThreadRequest&) = delete;
    ScopedPluginThreadRequest& operator=(const ScopedPluginThreadRequest&) =
        delete;

private:
#ifdef _OPENMP
    bool active_ = false;
    int previous_dynamic_ = 0;
    int previous_threads_ = 1;
#endif
};

std::string to_lower(std::string s) {
    std::transform(s.begin(), s.end(), s.begin(), [](unsigned char c) {
        return static_cast<char>(std::tolower(c));
    });
    return s;
}

std::string normalize_gpu_backend(const std::string& raw) {
    const std::string name = to_lower(raw);
    if (name == "cpu" || name == "cuda" || name == "metal") {
        return name;
    }
    throw_with_prefix("xhdfe plugin: ", "invalid gpu_backend: " + raw);
}

hdfe::detail::GpuBackend parse_gpu_backend_override(
    const std::string& backend) {
    if (backend == "cuda") return hdfe::detail::GpuBackend::Cuda;
    if (backend == "metal") return hdfe::detail::GpuBackend::Metal;
    return hdfe::detail::GpuBackend::Cpu;
}

void set_env_value(const std::string& key, const std::string& value) {
#ifdef _WIN32
    if (_putenv_s(key.c_str(), value.c_str()) != 0) {
        throw_with_prefix("xhdfe plugin: ", "failed to set environment variable " + key);
    }
#else
    if (setenv(key.c_str(), value.c_str(), 1) != 0) {
        throw_with_prefix("xhdfe plugin: ", "failed to set environment variable " + key);
    }
#endif
}

void unset_env_value(const std::string& key) {
#ifdef _WIN32
    if (_putenv_s(key.c_str(), "") != 0) {
        throw_with_prefix("xhdfe plugin: ", "failed to unset environment variable " + key);
    }
#else
    if (unsetenv(key.c_str()) != 0) {
        throw_with_prefix("xhdfe plugin: ", "failed to unset environment variable " + key);
    }
#endif
}

struct ScopedEnvVar {
    std::string key;
    std::optional<std::string> previous;
    bool active = false;

    ScopedEnvVar() = default;
    ScopedEnvVar(const std::string& key_in, const std::string& value)
        : key(key_in) {
        const char* prev = std::getenv(key.c_str());
        if (prev) {
            previous = std::string(prev);
        }
        set_env_value(key, value);
        active = true;
    }

    ~ScopedEnvVar() noexcept {
        if (!active) {
            return;
        }
        try {
            if (previous.has_value()) {
                set_env_value(key, *previous);
            } else {
                unset_env_value(key);
            }
        } catch (...) {
            // Avoid throwing from destructor.
        }
    }
};

bool plugin_savefe_profile_enabled() {
    static int cached = -1;
    if (cached >= 0) {
        return cached == 1;
    }
    const char* raw = std::getenv("XHDFE_PROFILE_SAVEFE");
    if (!raw || *raw == '\0' || *raw == '0') {
        cached = 0;
        return false;
    }
    cached = 1;
    return true;
}

void plugin_savefe_profile_log(const std::string& msg) {
    if (!plugin_savefe_profile_enabled()) {
        return;
    }
    std::cerr << "savefe_profile " << msg << '\n';
}

class PluginSavefeTimer {
public:
    explicit PluginSavefeTimer(const char* label)
        : label_(label), enabled_(plugin_savefe_profile_enabled()) {
        if (enabled_) {
            start_ = std::chrono::steady_clock::now();
        }
    }

    ~PluginSavefeTimer() {
        if (!enabled_) {
            return;
        }
        const auto end = std::chrono::steady_clock::now();
        const std::chrono::duration<double, std::milli> elapsed = end - start_;
        std::cerr << "savefe_profile label=" << label_
                  << " ms=" << elapsed.count() << '\n';
    }

private:
    const char* label_;
    bool enabled_;
    std::chrono::steady_clock::time_point start_;
};

bool plugin_cpu_profile_enabled() {
    static int cached = -1;
    if (cached >= 0) {
        return cached == 1;
    }
    const char* raw = std::getenv("XHDFE_PROFILE_CPU");
    if (!raw || *raw == '\0' || *raw == '0') {
        cached = 0;
        return false;
    }
    cached = 1;
    return true;
}

void plugin_cpu_profile_log_elapsed(
    const char* label,
    const std::chrono::steady_clock::time_point& start) {
    if (!plugin_cpu_profile_enabled()) {
        return;
    }
    const auto end = std::chrono::steady_clock::now();
    const std::chrono::duration<double, std::milli> elapsed = end - start;
    std::cerr << "plugin_profile label=" << label << " ms=" << elapsed.count() << '\n';
}

void plugin_cpu_profile_log_elapsed(
    const std::string& label,
    const std::chrono::steady_clock::time_point& start) {
    plugin_cpu_profile_log_elapsed(label.c_str(), start);
}

// The stretches of a standard fit in stata_call() that no other label covers
// (package A, item A2, 22nov2026), so that the labels add up to plugin_total:
// each lap runs from the end of the previous one, or from restart(), to the
// call that names it, and the time spent printing a lap belongs to the next.
// With the profile off nothing is read and nothing is printed.
class PluginProfileLaps {
public:
    explicit PluginProfileLaps(const std::chrono::steady_clock::time_point& start)
        : on_(plugin_cpu_profile_enabled()), start_(start) {}

    void lap(const char* label) {
        if (!on_) {
            return;
        }
        const auto end = std::chrono::steady_clock::now();
        const std::chrono::duration<double, std::milli> elapsed = end - start_;
        std::cerr << "plugin_profile label=" << label << " ms=" << elapsed.count() << '\n';
        start_ = end;
    }

    void restart() {
        if (on_) {
            start_ = std::chrono::steady_clock::now();
        }
    }

private:
    bool on_;
    std::chrono::steady_clock::time_point start_;
};

// P7 (2.31.0): residuals() stores the fit's own within residuals, the state behind e(b), e(V) and e(rss)
// (the vector Python returns as residuals_ and R as residuals). Up to 2.30.1 the core re-absorbed y - Xb
// with the fit's tuned options and method (HdfeOptions::refine_stored_residuals): on CUDA that vector was
// less exact than the fit's own state (Fast and strict, MAP), and from 2.30.1 a Krylov fit sent it to the
// host LSMR (ready, Comparable CUDA: about two minutes). refine_stored_residuals still records the request,
// so every gate that reads it keeps its eligibility; stored_residuals_fit_state skips only the late
// re-absorption. Lean 2.31.0: a strict-residual fit keeps that re-absorption, as up to 2.30.1. Package B
// (17nov2026): the plugin asks for the fit's own residuals in every mode and the core decides for a
// strict-residual fit, from the record of the scope of its CUDA acceptance: inside it the fit's own residual
// (the one its acceptance measured), outside it (CPU strict, every excluded strict route) the re-absorption,
// as before. XHDFE_STATA_LEGACY_RESIDUAL_REFINE=1, read at every fit, restores that re-absorption, and only
// it, for A/B and regression tests.
bool legacy_stored_residual_refinement() {
    const char* raw = std::getenv("XHDFE_STATA_LEGACY_RESIDUAL_REFINE");
    return raw != nullptr && std::strcmp(raw, "1") == 0;
}

bool approx_equal(double a, double b) {
    const double scale = 1.0 + std::max(std::abs(a), std::abs(b));
    return std::abs(a - b) <= kGroupConstantTol * scale;
}

[[noreturn]] void throw_with_prefix(const char* prefix, const std::string& msg) {
    throw std::runtime_error(std::string(prefix) + msg);
}

struct ParsedArgs {
    std::unordered_map<std::string, std::string> kv;

    explicit ParsedArgs(int argc, char* argv[]) {
        kv.reserve(static_cast<std::size_t>(std::max(1, argc)));

        auto parse_item = [&](const std::string& item) {
            if (item.empty()) {
                return;
            }
            const std::size_t eq = item.find('=');
            if (eq == std::string::npos || eq == 0) {
                throw_with_prefix("xhdfe plugin: ", "invalid argument (expected key=value): " + item);
            }
            std::string key = item.substr(0, eq);
            std::string val = item.substr(eq + 1);
            kv.emplace(std::move(key), std::move(val));
        };

        auto parse_packed = [&](std::string packed) {
            if (packed.rfind("cfg=", 0) == 0) {
                packed.erase(0, 4);
            }
            std::string buf;
            buf.reserve(packed.size());
            for (char c : packed) {
                if (c == ';') {
                    parse_item(buf);
                    buf.clear();
                } else {
                    buf.push_back(c);
                }
            }
            parse_item(buf);
        };

        if (argc == 1) {
            const std::string only = argv[0] ? argv[0] : "";
            if (only.find(';') != std::string::npos || only.rfind("cfg=", 0) == 0) {
                parse_packed(only);
                return;
            }
        }

        for (int i = 0; i < argc; ++i) {
            const std::string item = argv[i] ? argv[i] : "";
            parse_item(item);
        }
    }

    bool has(const char* key) const { return kv.find(key) != kv.end(); }

    const std::string& get_required(const char* key) const {
        auto it = kv.find(key);
        if (it == kv.end()) {
            throw_with_prefix("xhdfe plugin: ", std::string("missing required argument: ") + key);
        }
        return it->second;
    }

    std::optional<std::string> get_optional(const char* key) const {
        auto it = kv.find(key);
        if (it == kv.end()) {
            return std::nullopt;
        }
        return it->second;
    }
};

bool parse_bool(const std::string& raw, const char* what) {
    const std::string s = to_lower(raw);
    if (s == "1" || s == "true" || s == "t" || s == "yes" || s == "y") {
        return true;
    }
    if (s == "0" || s == "false" || s == "f" || s == "no" || s == "n") {
        return false;
    }
    throw_with_prefix("xhdfe plugin: ", std::string("invalid boolean for ") + what + ": " + raw);
}

int parse_int(const std::string& raw, const char* what) {
    char* end = nullptr;
    errno = 0;
    const long v = std::strtol(raw.c_str(), &end, 10);
    if (errno != 0 || end == raw.c_str() || *end != '\0') {
        throw_with_prefix("xhdfe plugin: ", std::string("invalid integer for ") + what + ": " + raw);
    }
    if (v < std::numeric_limits<int>::min() || v > std::numeric_limits<int>::max()) {
        throw_with_prefix("xhdfe plugin: ", std::string("integer out of range for ") + what + ": " + raw);
    }
    return static_cast<int>(v);
}

double parse_double(const std::string& raw, const char* what) {
    char* end = nullptr;
    errno = 0;
    const double v = std::strtod(raw.c_str(), &end);
    if (errno != 0 || end == raw.c_str() || *end != '\0') {
        throw_with_prefix("xhdfe plugin: ", std::string("invalid numeric for ") + what + ": " + raw);
    }
    return v;
}

std::vector<int> parse_csv_ints_0based(const std::string& raw) {
    std::vector<int> out;
    std::string token;
    auto flush = [&]() {
        if (token.empty()) {
            return;
        }
        out.push_back(parse_int(token, "endogenous_idx"));
        token.clear();
    };
    for (char c : raw) {
        if (c == ',' || std::isspace(static_cast<unsigned char>(c))) {
            flush();
        } else {
            token.push_back(c);
        }
    }
    flush();
    std::sort(out.begin(), out.end());
    out.erase(std::unique(out.begin(), out.end()), out.end());
    return out;
}

std::vector<int> parse_csv_ints_ordered(const std::string& raw, const char* what) {
    std::vector<int> out;
    std::string token;
    auto flush = [&]() {
        if (token.empty()) {
            return;
        }
        out.push_back(parse_int(token, what));
        token.clear();
    };
    for (char c : raw) {
        if (c == ',' || std::isspace(static_cast<unsigned char>(c))) {
            flush();
        } else {
            token.push_back(c);
        }
    }
    flush();
    return out;
}

StandardErrorType parse_se_type(const std::string& raw) {
    const std::string name = to_lower(raw);
    if (name == "homoskedastic" || name == "classical" || name == "unadjusted" || name == "unadj" ||
        name == "ols") {
        return StandardErrorType::Homoskedastic;
    }
    if (name == "robust" || name == "hc1" || name == "heteroskedastic") {
        return StandardErrorType::Robust;
    }
    if (name == "cluster" || name == "clustered") {
        return StandardErrorType::Cluster;
    }
    throw_with_prefix("xhdfe plugin: ", "unknown se_type: " + raw);
}

AbsorptionMethod parse_absorption_method(const std::string& raw) {
    const std::string name = to_lower(raw);
    if (name == "auto") {
        return AbsorptionMethod::Auto;
    }
    if (name == "gs" || name == "gauss-seidel" || name == "gauss_seidel") {
        return AbsorptionMethod::GaussSeidel;
    }
    if (name == "sym" || name == "symmetric" || name == "symgs" || name == "symmetric-gauss-seidel" ||
        name == "symmetric_gauss_seidel") {
        return AbsorptionMethod::SymmetricGaussSeidel;
    }
    if (name == "jacobi") {
        return AbsorptionMethod::Jacobi;
    }
    if (name == "lsmr" || name == "plain-lsmr" || name == "plain_lsmr") {
        return AbsorptionMethod::Lsmr;
    }
    if (name == "mlsmr" || name == "modified-lsmr" || name == "modified_lsmr" ||
        name == "within" || name == "within-additive" || name == "within_additive") {
        return AbsorptionMethod::Mlsmr;
    }
    if (name == "auto-mlsmr" || name == "auto_mlsmr" ||
        name == "mlsmr-auto" || name == "mlsmr_auto") {
        return AbsorptionMethod::AutoMlsmr;
    }
    if (name == "reduced-pcg" || name == "reduced_pcg") {
        throw_with_prefix("xhdfe plugin: ",
                          "absorption method reduced-pcg is reported when the reduced-system tier "
                          "publishes a fit; it cannot be requested (use auto)");
    }
    if (name == "krylov-pcg" || name == "krylov_pcg") {
        throw_with_prefix("xhdfe plugin: ",
                          "absorption method krylov-pcg is reported when the Krylov-PCG route "
                          "is forced; it cannot be requested (use auto)");
    }
    throw_with_prefix("xhdfe plugin: ", "unknown absorption_method: " + raw);
}

ConvergenceCriterion parse_convergence_criterion(const std::string& raw) {
    const std::string name = to_lower(raw);
    if (name == "auto" || name.empty()) {
        return ConvergenceCriterion::Auto;
    }
    if (name == "normchange" || name == "norm" || name == "norm_change" ||
        name == "current" || name == "xhdfe") {
        return ConvergenceCriterion::NormChange;
    }
    if (name == "reghdfe" || name == "vector" || name == "vectors" ||
        name == "reghdfe-style" || name == "reghdfe_style") {
        return ConvergenceCriterion::Reghdfe;
    }
    if (name == "both") {
        return ConvergenceCriterion::Both;
    }
    throw_with_prefix("xhdfe plugin: ", "unknown convergence criterion: " + raw);
}

FeRecoveryMethod parse_fe_recovery_method(const std::string& raw) {
    const std::string name = to_lower(raw);
    if (name == "map" || name == "ap") {
        return FeRecoveryMethod::Map;
    }
    if (name == "hybrid" || name == "auto") {
        return FeRecoveryMethod::Hybrid;
    }
    throw_with_prefix("xhdfe plugin: ", "unknown fe_recovery_method: " + raw);
}

FixefDofMethod parse_fixef_method(const std::string& raw) {
    const std::string name = to_lower(raw);
    if (name == "full" || name == "true" || name == "yes") {
        return FixefDofMethod::Full;
    }
    if (name == "none" || name == "false" || name == "no") {
        return FixefDofMethod::None;
    }
    if (name == "nonnested" || name == "non-nested" || name == "non_nested") {
        return FixefDofMethod::Nonnested;
    }
    throw_with_prefix("xhdfe plugin: ", "unknown K.fixef: " + raw);
}

ClusterDofMethod parse_cluster_df(const std::string& raw) {
    const std::string name = to_lower(raw);
    if (name == "min") {
        return ClusterDofMethod::Min;
    }
    if (name == "conventional" || name == "conv") {
        return ClusterDofMethod::Conventional;
    }
    throw_with_prefix("xhdfe plugin: ", "unknown G.df: " + raw);
}

StatsStyle parse_stats_style(const std::string& raw) {
    const std::string name = to_lower(raw);
    if (name == "reghdfe" || name == "reghdfe-style" || name == "reghdfe_style") {
        return StatsStyle::Reghdfe;
    }
    if (name == "legacy" || name == "current" || name == "xhdfe") {
        return StatsStyle::Legacy;
    }
    throw_with_prefix("xhdfe plugin: ", "unknown statstyle: " + raw);
}

ToleranceMode parse_tolerance_mode(const std::string& raw) {
    const std::string name = to_lower(raw);
    if (name == "xhdfe-fast" || name == "xhdfe_fast" || name == "xhdfe" ||
        name == "fast" || name == "current") {
        return ToleranceMode::XhdfeFast;
    }
    if (name == "reghdfe-comparable" || name == "reghdfe_comparable" ||
        name == "reghdfe" || name == "comparable") {
        return ToleranceMode::ReghdfeComparable;
    }
    if (name == "strict-residual" || name == "strict_residual" ||
        name == "residual-certificate" || name == "residual_certificate" ||
        name == "strict") {
        return ToleranceMode::StrictResidual;
    }
    throw_with_prefix("xhdfe plugin: ", "unknown tolerance_mode: " + raw);
}

DofAdjustmentMethod parse_dof_method(const std::string& raw) {
    const std::string name = to_lower(raw);
    if (name == "exact") {
        return DofAdjustmentMethod::Exact;
    }
    if (name == "all") {
        return DofAdjustmentMethod::All;
    }
    if (name == "none") {
        return DofAdjustmentMethod::None;
    }
    if (name == "firstpair" || name == "first") {
        return DofAdjustmentMethod::FirstPair;
    }
    if (name == "pairwise" || name == "pair") {
        return DofAdjustmentMethod::Pairwise;
    }
    throw_with_prefix("xhdfe plugin: ", "unknown dof_method: " + raw);
}

struct ParsedDofAdjustments {
    DofAdjustmentMethod method = DofAdjustmentMethod::All;
    bool mobility_groups = true;
    bool adjust_clusters = true;
    bool adjust_continuous = true;
};

ParsedDofAdjustments parse_dofadjustments(std::optional<std::string> raw_opt) {
    ParsedDofAdjustments parsed;
    if (!raw_opt) {
        return parsed;
    }

    const bool token_free = std::all_of(
        raw_opt->begin(), raw_opt->end(), [](unsigned char c) {
            return c == ',' || std::isspace(c);
        });
    if (token_free) {
        return parsed;
    }

    // When the user explicitly supplies dofadjustments(...), mimic Stata/reghdfe behavior by
    // starting from a blank slate (only the listed items are enabled).
    parsed.method = DofAdjustmentMethod::All;
    parsed.mobility_groups = false;
    parsed.adjust_clusters = false;
    parsed.adjust_continuous = false;

    bool seen_all = false;
    bool seen_none = false;
    bool seen_firstpair = false;
    bool seen_pairwise = false;
    bool seen_clusters = false;
    bool seen_continuous = false;
    bool seen_exact = false;

    std::string raw = *raw_opt;
    std::replace(raw.begin(), raw.end(), ',', ' ');
    std::string token;
    auto flush = [&]() {
        if (token.empty()) {
            return;
        }
        const std::string tok = to_lower(token);
        token.clear();
        if (tok == "exact") {
            seen_exact = true;
            parsed.method = DofAdjustmentMethod::Exact;
            parsed.mobility_groups = true;
            return;
        }
        if (tok == "all") {
            seen_all = true;
            parsed.method = DofAdjustmentMethod::All;
            parsed.mobility_groups = true;
            parsed.adjust_clusters = true;
            parsed.adjust_continuous = true;
            return;
        }
        if (tok == "none") {
            seen_none = true;
            parsed.method = DofAdjustmentMethod::None;
            return;
        }
        if (tok == "firstpair" || tok == "first") {
            seen_firstpair = true;
            parsed.method = DofAdjustmentMethod::FirstPair;
            parsed.mobility_groups = true;
            return;
        }
        if (tok == "pairwise" || tok == "pair") {
            seen_pairwise = true;
            parsed.method = DofAdjustmentMethod::Pairwise;
            parsed.mobility_groups = true;
            return;
        }
        if (tok == "clusters" || tok == "cluster") {
            seen_clusters = true;
            parsed.adjust_clusters = true;
            return;
        }
        if (tok == "continuous" || tok == "cont") {
            seen_continuous = true;
            parsed.adjust_continuous = true;
            return;
        }
        throw_with_prefix("xhdfe plugin: ", "unknown dofadjustments token: " + tok);
    };
    for (char c : raw) {
        if (std::isspace(static_cast<unsigned char>(c))) {
            flush();
        } else {
            token.push_back(c);
        }
    }
    flush();
    const int token_classes = static_cast<int>(seen_all) + static_cast<int>(seen_none) +
                              static_cast<int>(seen_firstpair) + static_cast<int>(seen_pairwise) +
                              static_cast<int>(seen_clusters) + static_cast<int>(seen_continuous) +
                              static_cast<int>(seen_exact);
    if ((seen_all && token_classes > 1) || (seen_none && token_classes > 1) ||
        (seen_exact && token_classes > 1) ||
        (seen_firstpair && seen_pairwise)) {
        throw_with_prefix("xhdfe plugin: ", "mutually exclusive dofadjustments tokens");
    }
    return parsed;
}

GroupAggregation parse_aggregation(const std::string& raw) {
    const std::string name = to_lower(raw);
    if (name == "mean" || name == "average" || name == "avg") {
        return GroupAggregation::Mean;
    }
    if (name == "sum") {
        return GroupAggregation::Sum;
    }
    throw_with_prefix("xhdfe plugin: ", "unknown aggregation: " + raw);
}

void maybe_save_scalar(const std::optional<std::string>& name, double value) {
    if (!name || name->empty()) {
        return;
    }
    const ST_retcode rc = SF_scal_save(const_cast<char*>(name->c_str()), value);
    if (rc) {
        throw_with_prefix("xhdfe plugin: ", "failed to save scalar: " + *name);
    }
}

double stata_krylov_diagnostic(double value) {
    if (!hdfe::detail::ieee_finite(value) ||
        value == std::numeric_limits<double>::max()) {
        return SV_missval;
    }
    return value;
}

void maybe_save_gpu_diagnostics(const std::optional<std::string>& s_gpu_status_code,
                                const std::optional<std::string>& s_gpu_attempted,
                                const std::optional<std::string>& s_gpu_absorption_converged,
                                const std::optional<std::string>& s_gpu_absorption_iterations,
                                const HdfeRegressorV11& reg) {
    maybe_save_scalar(s_gpu_status_code, static_cast<double>(reg.gpu_status_code()));
    maybe_save_scalar(s_gpu_attempted, reg.gpu_attempted() ? 1.0 : 0.0);
    const double gpu_absorption_converged =
        reg.gpu_attempted() ? (reg.gpu_absorption_converged() ? 1.0 : 0.0) : SV_missval;
    const double gpu_absorption_iterations =
        reg.gpu_attempted() ? static_cast<double>(reg.gpu_absorption_iterations()) : SV_missval;
    maybe_save_scalar(s_gpu_absorption_converged,
                      gpu_absorption_converged);
    maybe_save_scalar(s_gpu_absorption_iterations,
                      gpu_absorption_iterations);
}

// The reduced-system tier's read-only diagnostics of the fit: status and
// discarded iterations in scalars (s_...), the reason in the caller's local
// named by m_reduced_pcg_reason.
void maybe_save_reduced_pcg(const std::optional<std::string>& s_status,
                            const std::optional<std::string>& m_reason,
                            const std::optional<std::string>& s_discarded,
                            const HdfeRegressorV11& reg) {
    maybe_save_scalar(s_status, static_cast<double>(reg.reduced_pcg_status()));
    maybe_save_scalar(s_discarded, static_cast<double>(reg.reduced_pcg_discarded_iterations()));
    if (m_reason && !m_reason->empty()) {
        const std::string local = "_" + *m_reason;
        if (SF_macro_save(const_cast<char*>(local.c_str()),
                          const_cast<char*>(reg.reduced_pcg_reason().c_str()))) {
            throw_with_prefix("xhdfe plugin: ", "failed to save macro: " + *m_reason);
        }
    }
}

void maybe_save_thread_diagnostics(
    const std::optional<std::string>& s_threads_used,
    const std::optional<std::string>& s_threads_requested,
    const std::optional<std::string>& s_threads_effective,
    const std::optional<std::string>& s_parallel_workers_active,
    const std::optional<std::string>& s_thread_capacity,
    const std::optional<std::string>& s_openmp_enabled,
    const std::optional<std::string>& s_thread_limit_code,
    const HdfeRegressorV11& reg,
    int plugin_threads_used,
    int plugin_workers_active) {
    // Include the observed plugin work in the command-wide maxima.
    maybe_save_scalar(s_threads_used,
                      static_cast<double>(std::max(reg.threads_used(), plugin_threads_used)));
    maybe_save_scalar(s_threads_requested,
                      static_cast<double>(reg.threads_requested()));
    maybe_save_scalar(s_threads_effective,
                      static_cast<double>(reg.threads_effective()));
    maybe_save_scalar(s_parallel_workers_active,
                      static_cast<double>(std::max(reg.parallel_workers_active(),
                                                   plugin_workers_active)));
    maybe_save_scalar(s_thread_capacity,
                      static_cast<double>(reg.thread_capacity()));
    maybe_save_scalar(s_openmp_enabled, reg.openmp_enabled() ? 1.0 : 0.0);
    maybe_save_scalar(s_thread_limit_code,
                      static_cast<double>(reg.thread_limit_code()));
}

double stata_value_or_missing(double value) {
    // The production plugin is compiled with -ffast-math. Under that contract
    // std::isfinite/NaN comparisons may be optimized on the assumption that
    // non-finite values do not exist, even though public diagnostic matrices
    // deliberately use NaN for unavailable cells. Inspect the IEEE-754
    // exponent bits instead so Python/R NaN becomes a genuine Stata missing
    // value without changing any finite number.
    std::uint64_t bits = 0;
    static_assert(sizeof(bits) == sizeof(value), "unexpected double width");
    std::memcpy(&bits, &value, sizeof(bits));
    constexpr std::uint64_t exponent_mask = UINT64_C(0x7ff0000000000000);
    return (bits & exponent_mask) == exponent_mask ? SV_missval : value;
}

void store_matrix(const std::string& mat, const Eigen::MatrixXd& m) {
    const int want_r = static_cast<int>(m.rows());
    const int want_c = static_cast<int>(m.cols());
    const int have_r = SF_row(const_cast<char*>(mat.c_str()));
    const int have_c = SF_col(const_cast<char*>(mat.c_str()));
    if (have_r != want_r || have_c != want_c) {
        throw_with_prefix(
            "xhdfe plugin: ",
            "matrix dimension mismatch for " + mat + " (have " + std::to_string(have_r) + "x" +
                std::to_string(have_c) + ", want " + std::to_string(want_r) + "x" +
                std::to_string(want_c) + ")");
    }

    for (int i = 0; i < want_r; ++i) {
        for (int j = 0; j < want_c; ++j) {
            const double val = stata_value_or_missing(m(i, j));
            const ST_retcode rc =
                SF_mat_store(const_cast<char*>(mat.c_str()), i + 1, j + 1, val);
            if (rc) {
                throw_with_prefix("xhdfe plugin: ", "failed to write matrix " + mat);
            }
        }
    }
}

void store_row_vector(const std::string& mat, const Eigen::VectorXd& v) {
    Eigen::MatrixXd m(1, v.size());
    m.row(0) = v.transpose();
    store_matrix(mat, m);
}

void maybe_store_cluster_diag(const std::optional<std::string>& name,
                              const hdfe::HdfeResults& res) {
    if (!name || name->empty()) {
        return;
    }
    const int want_rows = static_cast<int>(res.cluster_combo_counts.size());
    const int have_rows = SF_row(const_cast<char*>(name->c_str()));
    const int have_cols = SF_col(const_cast<char*>(name->c_str()));
    if (have_rows != want_rows || have_cols != 1) {
        throw_with_prefix("xhdfe plugin: ",
                          "cluster_diag has wrong dimensions (have " +
                              std::to_string(have_rows) + "x" + std::to_string(have_cols) +
                              ", want " + std::to_string(want_rows) + "x1)");
    }
    Eigen::MatrixXd out(want_rows, 1);
    for (int i = 0; i < want_rows; ++i) {
        out(i, 0) = static_cast<double>(res.cluster_combo_counts[static_cast<std::size_t>(i)]);
    }
    store_matrix(*name, out);
}

void maybe_store_dof_table(const std::optional<std::string>& name,
                           const hdfe::HdfeResults& res) {
    if (!name || name->empty()) {
        return;
    }
    const int rows = static_cast<int>(res.fe_num_levels.size());
    if (rows <= 0) {
        return;
    }
    // Optional columns used by the ado for heterogeneous-slope display:
    // 6 = distinct base FE levels; 7 = redundant base-intercept categories.
    const int have_rows = SF_row(const_cast<char*>(name->c_str()));
    const int have_cols = SF_col(const_cast<char*>(name->c_str()));
    if (have_rows != rows || (have_cols != 5 && have_cols != 6 && have_cols != 7)) {
        throw_with_prefix(
            "xhdfe plugin: ",
            "dof_table has wrong dimensions (have " + std::to_string(have_rows) + "x" +
                std::to_string(have_cols) + ", want " + std::to_string(rows) + "x5, x6, or x7)");
    }

    auto get_val = [&](const std::vector<int>& vec, int idx) -> double {
        if (idx < 0 || idx >= static_cast<int>(vec.size())) {
            return SV_missval;
        }
        return static_cast<double>(vec[static_cast<std::size_t>(idx)]);
    };

    for (int i = 0; i < rows; ++i) {
        const double col1 = get_val(res.fe_num_levels, i);
        const double col2 = get_val(res.fe_redundant, i);
        const double col3 = get_val(res.fe_num_coefs, i);
        const double col4 = get_val(res.fe_inexact, i);
        const double col5 = get_val(res.fe_nested, i);
        const ST_retcode rc1 =
            SF_mat_store(const_cast<char*>(name->c_str()), i + 1, 1, col1);
        const ST_retcode rc2 =
            SF_mat_store(const_cast<char*>(name->c_str()), i + 1, 2, col2);
        const ST_retcode rc3 =
            SF_mat_store(const_cast<char*>(name->c_str()), i + 1, 3, col3);
        const ST_retcode rc4 =
            SF_mat_store(const_cast<char*>(name->c_str()), i + 1, 4, col4);
        const ST_retcode rc5 =
            SF_mat_store(const_cast<char*>(name->c_str()), i + 1, 5, col5);
        ST_retcode rc6 = 0;
        ST_retcode rc7 = 0;
        if (have_cols >= 6) {
            rc6 = SF_mat_store(const_cast<char*>(name->c_str()), i + 1, 6,
                               get_val(res.fe_base_levels, i));
        }
        if (have_cols >= 7) {
            rc7 = SF_mat_store(const_cast<char*>(name->c_str()), i + 1, 7,
                               get_val(res.fe_base_redundant, i));
        }
        if (rc1 || rc2 || rc3 || rc4 || rc5 || rc6 || rc7) {
            throw_with_prefix("xhdfe plugin: ", "failed to write matrix dof_table");
        }
    }
}

int to_int_checked(double value, const char* what);

std::vector<int> read_matrix_vector_int(const std::string& name, const char* what) {
    const ST_double missval = SV_missval;
    const int rows = SF_row(const_cast<char*>(name.c_str()));
    const int cols = SF_col(const_cast<char*>(name.c_str()));
    if (rows <= 0 || cols != 1) {
        throw_with_prefix("xhdfe plugin: ",
                          std::string(what) + " has wrong dimensions (have " +
                              std::to_string(rows) + "x" + std::to_string(cols) + ")");
    }
    std::vector<int> out(static_cast<std::size_t>(rows), 0);
    for (int i = 0; i < rows; ++i) {
        double val = 0.0;
        const ST_retcode rc = SF_mat_el(const_cast<char*>(name.c_str()), i + 1, 1, &val);
        if (rc) {
            throw_with_prefix("xhdfe plugin: ",
                              std::string("failed to read ") + what + " matrix");
        }
        if (!std::isfinite(val) || !(val < missval)) {
            out[static_cast<std::size_t>(i)] = 0;
            continue;
        }
        out[static_cast<std::size_t>(i)] = to_int_checked(val, what);
    }
    return out;
}

void maybe_store_omit_reason(const std::optional<std::string>& name,
                             const hdfe::HdfeResults& res) {
    if (!name || name->empty()) {
        return;
    }
    const int rows = static_cast<int>(res.coefficients.size());
    if (rows <= 0) {
        return;
    }
    const int have_rows = SF_row(const_cast<char*>(name->c_str()));
    const int have_cols = SF_col(const_cast<char*>(name->c_str()));
    if (have_rows != rows || have_cols != 1) {
        throw_with_prefix("xhdfe plugin: ",
                          "omit_reason has wrong dimensions (have " +
                              std::to_string(have_rows) + "x" + std::to_string(have_cols) +
                              ", want " + std::to_string(rows) + "x1)");
    }
    Eigen::MatrixXd out(rows, 1);
    if (res.omitted_reason.empty()) {
        out.setZero();
    } else {
        if (static_cast<int>(res.omitted_reason.size()) != rows) {
            throw_with_prefix("xhdfe plugin: ", "omit_reason size mismatch");
        }
        for (int i = 0; i < rows; ++i) {
            out(i, 0) = static_cast<double>(res.omitted_reason[static_cast<std::size_t>(i)]);
        }
    }
    store_matrix(*name, out);
}

int to_int_checked(double value, const char* what) {
    const double rounded = std::round(value);
    if (!approx_equal(value, rounded)) {
        throw_with_prefix("xhdfe plugin: ", std::string("non-integer value in ") + what);
    }
    if (rounded < static_cast<double>(std::numeric_limits<int>::min()) ||
        rounded > static_cast<double>(std::numeric_limits<int>::max())) {
        throw_with_prefix("xhdfe plugin: ", std::string("integer out of range in ") + what);
    }
    return static_cast<int>(rounded);
}

struct ObservationMap {
    int in1 = 0;
    int n = 0;
    bool contiguous = false;
    std::vector<int> obs;

    int obs_no(int i) const {
        return contiguous ? in1 + i : obs[static_cast<std::size_t>(i)];
    }
};

ObservationMap selected_observations() {
    const int in1 = SF_in1();
    const int in2 = SF_in2();
    ObservationMap out;
    out.in1 = in1;
    if (in2 < in1) {
        return out;
    }
    out.contiguous = true;
    const int capacity = in2 - in1 + 1;
    for (int j = in1; j <= in2; ++j) {
        if (SF_ifobs(j)) {
            if (out.contiguous && j == in1 + out.n) {
                ++out.n;
                continue;
            }
            if (out.contiguous) {
                out.contiguous = false;
                out.obs.reserve(static_cast<std::size_t>(capacity));
                for (int k = 0; k < out.n; ++k) {
                    out.obs.push_back(in1 + k);
                }
            }
            out.obs.push_back(j);
            ++out.n;
        } else if (out.contiguous) {
            out.contiguous = false;
            out.obs.reserve(static_cast<std::size_t>(capacity));
            for (int k = 0; k < out.n; ++k) {
                out.obs.push_back(in1 + k);
            }
        }
    }
    if (out.contiguous) {
        out.obs.clear();
        out.obs.shrink_to_fit();
    }
    return out;
}

constexpr double kMaxExactIntegerId = 9007199254740992.0;  // 2^53

bool exact_int32_id(double value, int& out) {
    if (value < static_cast<double>(std::numeric_limits<int>::min()) ||
        value > static_cast<double>(std::numeric_limits<int>::max())) {
        return false;
    }
    const int candidate = static_cast<int>(value);
    if (static_cast<double>(candidate) != value) {
        return false;
    }
    out = candidate;
    return true;
}

// --- Fused input read -------------------------------------------------------
// Stata stores a dataset observation by observation. Reading one variable at a
// time walks the whole dataset once per variable; reading every variable of an
// observation before moving to the next walks it once. The accessor, the value
// checks and the destinations are those of the column readers in stata_call;
// only the order of the SF_vdata calls differs, so the inputs are identical.
//
// The pass never reports an error. On any anomaly (failed read, missing or
// non-finite value, invalid individual identifier) it returns false and the
// column readers run unchanged, so every message and the order in which
// problems are reported stay as they were. An identifier column holding a
// value outside exact int32 is left to its column reader, which owns the dense
// coding and its temporary storage. XHDFE_FUSED_READ=0 disables the pass.
bool fused_read_enabled() {
    static int cached = -1;
    if (cached >= 0) {
        return cached == 1;
    }
    const char* raw = std::getenv("XHDFE_FUSED_READ");
    cached = (raw && raw[0] == '0' && raw[1] == '\0') ? 0 : 1;
    return cached == 1;
}

struct FusedDoubleColumn {
    int var_idx;
    double* dest;
};

struct FusedIdColumn {
    int var_idx;
    int* dest;
    bool validate_individual;
    bool exact_int32;
};

bool read_columns_fused(const ObservationMap& obs,
                        const std::vector<FusedDoubleColumn>& doubles,
                        std::vector<FusedIdColumn>& ids) {
    const ST_double missval = SV_missval;
    const int n = obs.n;
    for (int i = 0; i < n; ++i) {
        const int obs_no = obs.obs_no(i);
        for (const FusedDoubleColumn& column : doubles) {
            ST_double z = 0.0;
            if (SF_vdata(column.var_idx, obs_no, &z) || !std::isfinite(z) || !(z < missval)) {
                return false;
            }
            column.dest[i] = z;
        }
        for (FusedIdColumn& column : ids) {
            if (!column.exact_int32) {
                continue;
            }
            ST_double z = 0.0;
            if (SF_vdata(column.var_idx, obs_no, &z) || !std::isfinite(z) || !(z < missval)) {
                return false;
            }
            if (column.validate_individual &&
                (z < 0.0 || std::trunc(z) != z || z > kMaxExactIntegerId)) {
                return false;
            }
            int id = 0;
            if (!exact_int32_id(z, id)) {
                column.exact_int32 = false;
                continue;
            }
            column.dest[i] = id;
        }
    }
    return true;
}

// --- Parallel input read ----------------------------------------------------
// The sample selection and the fused pass, split into row blocks that several
// threads read at once. StataCorp does not document that the plugin interface
// may be called from several threads, so this path runs only on a host where
// it was qualified empirically (parallel_read_host_qualified) or when
// XHDFE_PARALLEL_READ=1 forces it, which exists for qualification runs only;
// XHDFE_PARALLEL_READ=0 keeps the serial readers everywhere. Each switch below
// is read once per process.
//
// Inside a parallel region the only interface function any thread calls is the
// checked accessor SF_vdata: no display, no error, no macro or scalar access.
// A thread that meets a bad value records it and stops. The decision is taken
// after the region, on the calling thread: a failed selection is redone with
// SF_ifobs, and a failed read is discarded and redone by read_columns_fused,
// which in turn falls back to the column readers, so every message and the
// order of the messages stay those of the serial path.
constexpr int kParallelReadBlockRows = 16384;
constexpr int kParallelReadAutoMaxThreads = 16;
// A pass that reads fewer values than this (rows times variables) stays
// serial: the whole read then costs under 20 ms. XHDFE_PARALLEL_READ_MIN_VALUES
// replaces it; it is a test hook that lets the contract exercise the parallel
// reader on small data.
constexpr long long kParallelReadMinValues = 2000000;

// -1 when unset or neither 0 nor 1 (the host table decides), 0 off, 1 forced.
int parallel_read_switch() {
    static int cached = -2;
    if (cached != -2) {
        return cached;
    }
    const char* raw = std::getenv("XHDFE_PARALLEL_READ");
    cached = -1;
    if (raw && (raw[0] == '0' || raw[0] == '1') && raw[1] == '\0') {
        cached = raw[0] - '0';
    }
    return cached;
}

long long parallel_read_min_values() {
    static long long cached = -1;
    if (cached >= 0) {
        return cached;
    }
    cached = kParallelReadMinValues;
    const char* raw = std::getenv("XHDFE_PARALLEL_READ_MIN_VALUES");
    if (raw && *raw != '\0') {
        char* end = nullptr;
        errno = 0;
        const long long value = std::strtoll(raw, &end, 10);
        if (errno == 0 && *end == '\0' && value >= 0) {
            cached = value;
        }
    }
    return cached;
}

// The first touch of the pages the parallel read writes (package D, 23nov2026).
// On: the calling thread touches every destination page before the parallel
// pass, so the pages sit where the serial reader places them (2.34.2). Off: the
// readers touch the pages first. The built-in value, one place, read by the code
// and by the tests; changing it is a one-line edit here plus the documentation.
constexpr bool kParallelReadPretouchBuiltIn = true;

// The process value: XHDFE_PARALLEL_READ_PRETOUCH exactly 1 (on) or exactly 0
// (off), otherwise the built-in value. Read once per process. `source` receives
// 2 when the environment decided, 3 for the built-in value.
bool parallel_read_pretouch(int& source) {
    static int cached = -1;
    static int cached_source = 3;
    if (cached < 0) {
        const char* raw = std::getenv("XHDFE_PARALLEL_READ_PRETOUCH");
        if (raw && (raw[0] == '0' || raw[0] == '1') && raw[1] == '\0') {
            cached = raw[0] == '1' ? 1 : 0;
            cached_source = 2;
        } else {
            cached = kParallelReadPretouchBuiltIn ? 1 : 0;
            cached_source = 3;
        }
    }
    source = cached_source;
    return cached == 1;
}

// Hosts on which concurrent SF_vdata calls were qualified: every byte equal to
// the serial read in every comparison of prototypes/stata_read_direct. The
// table has one entry, the only one testable here: Linux x86-64, Stata 19 MP.
// The platform is the plugin's compile target; the rest are facts the ado
// passes from c(os), c(machine_type), c(edition_real) and c(stata_version)
// (19 and its point releases, StataNow 19.5 included). Anything missing or
// different keeps the serial readers.
bool parallel_read_host_qualified(const ParsedArgs& args) {
#if defined(__linux__) && defined(__x86_64__)
    const std::optional<std::string> os = args.get_optional("host_os");
    const std::optional<std::string> machine = args.get_optional("host_machine");
    const std::optional<std::string> edition = args.get_optional("host_edition");
    const std::optional<std::string> version = args.get_optional("host_stata_version");
    if (!os || !machine || !edition || !version) {
        return false;
    }
    const bool stata19 = *version == "19" || version->rfind("19.", 0) == 0;
    return *os == "Unix" && *machine == "PC (64-bit x86-64)" && *edition == "MP" && stata19;
#else
    (void)args;
    return false;
#endif
}

// Variables the fused pass reads: y, the regressors, each absorb() variable
// that is not a repeat of an earlier one (fe_dup_map), the slope variables, the
// weight, each cluster variable that is not one of the fixed effects
// (cluster_fe_map) and the instruments. A map that cannot be read counts every
// variable; the fused pass then does not run, and the stages report the map.
long long fused_read_variable_count(const ParsedArgs& args, int p, int nfe, int nslope,
                                    int nclust, bool has_weight, int ninst) {
    long long fe_read = nfe;
    long long cluster_read = nclust;
    try {
        const std::optional<std::string> dup_arg = args.get_optional("fe_dup_map");
        if (dup_arg && !dup_arg->empty()) {
            const std::vector<int> dup_map = parse_csv_ints_ordered(*dup_arg, "fe_dup_map");
            if (static_cast<int>(dup_map.size()) == nfe) {
                fe_read = std::count_if(dup_map.begin(), dup_map.end(),
                                        [](int dup) { return dup < 0; });
            }
        }
        const std::optional<std::string> cluster_arg = args.get_optional("cluster_fe_map");
        if (nclust > 0 && cluster_arg && !cluster_arg->empty()) {
            const std::vector<int> cluster_map =
                parse_csv_ints_ordered(*cluster_arg, "cluster_fe_map");
            if (static_cast<int>(cluster_map.size()) == nclust) {
                cluster_read = std::count_if(cluster_map.begin(), cluster_map.end(),
                                             [](int mapped) { return mapped < 0; });
            }
        }
    } catch (const std::exception&) {
        fe_read = nfe;
        cluster_read = nclust;
    }
    return 1LL + p + fe_read + nslope + (has_weight ? 1 : 0) + cluster_read + ninst;
}

// What one stata_call decides about the parallel read, then what happened.
struct ParallelReadPlan {
    bool allowed = false;  // every condition except the size and team of a pass
    const char* reason = "";
    int marker_var = 0;
    int requested_threads = 0;
    // A regressor built from the fit's own options and threading resolves the
    // team of each pass (see parallel_read_team).
    const HdfeRegressorV11* core = nullptr;
    int num_fes = 0;
    long long variables = 0;  // read by the fused pass
    long long min_values = kParallelReadMinValues;
    bool pretouch = true;
    int pretouch_source = 3;       // 1 the fit's request (read_pretouch), 2 the environment, 3 built-in
    bool select_parallel = false;  // the parallel selection ran, kept or not
    int select_team = 1;           // team observed in the selection; 1 when serial
    int select_workers = 0;        // threads of that team that scanned a block
    bool select_fallback = false;
    long long read_values = 0;
    long long read_blocks = 0;
    int read_core_threads = 0;  // the fit's team for the selected rows
    int read_team = 1;          // team observed in the read; 1 when serial
    int read_workers = 0;       // threads of that team that read a block
    bool read_used = false;
    bool read_fallback = false;
    // The team read of wide identifier columns (read_wide_id_on_team), kept or
    // discarded: the largest team observed and the most active workers of its
    // read, ordering and rank regions, over all the columns it took.
    bool wide_ran = false;
    int wide_team = 0;
    int wide_workers = 0;
};

long long& pretouch_stores();  // round 09, E.5 (defined with the touch helpers below)

ParallelReadPlan plan_parallel_read(const ParsedArgs& args, int marker_var,
                                    int requested_threads, int num_fes,
                                    long long variables) {
    ParallelReadPlan plan;
    pretouch_stores() = 0;  // round 09, E.5: the touches of this fit's reads from here
    plan.marker_var = marker_var;
    plan.requested_threads = requested_threads;
    plan.num_fes = num_fes;
    plan.variables = variables;
    plan.min_values = parallel_read_min_values();
    // Package D: the first touch, resolved once for the fused read and the read
    // of the wide identifiers: the fit's request (read_pretouch=on|off, passed
    // by the ado only when readpretouch() or the Stata global decided), else the
    // process value. It is not part of any numerical key.
    if (const std::optional<std::string> request = args.get_optional("read_pretouch")) {
        if (*request == "on") {
            plan.pretouch = true;
        } else if (*request == "off") {
            plan.pretouch = false;
        } else {
            throw_with_prefix("xhdfe plugin: ", "read_pretouch must be on or off");
        }
        plan.pretouch_source = 1;
    } else {
        plan.pretouch = parallel_read_pretouch(plan.pretouch_source);
    }
    const int forced = parallel_read_switch();
    const std::optional<std::string> alias = args.get_optional("alias_vars");
    if (!fused_read_enabled()) {
        plan.reason = "fused_read_off";
    } else if (forced == 0) {
        plan.reason = "switch_off";
    } else if (marker_var <= 0) {
        plan.reason = "no_marker";
    } else if (!alias) {
        plan.reason = "alias_unknown";
    } else if (*alias != "0") {
        // An alias variable (fralias) resolves through another frame.
        plan.reason = "alias_variables";
    } else if (forced != 1 && !parallel_read_host_qualified(args)) {
        plan.reason = "host_not_qualified";
    } else {
#ifdef _OPENMP
        plan.allowed = true;
        plan.reason = forced == 1 ? "switch_on" : "qualified_host";
#else
        plan.reason = "openmp_unavailable";
#endif
    }
    return plan;
}

// Team for a pass over `rows` rows in `blocks` blocks; 1 keeps the pass serial.
// The fit's regressor resolves the team for those rows, so every threading
// switch governs the read as it governs the fit (numthreads(), defaultthreads(),
// maxthreads(), minparallelrows(), targetrowsperthread(), the OpenMP default,
// the capacity clamp and an active OpenMP region); numthreads(1) therefore
// keeps the serial reader. The pass then uses at most one thread per block, and
// at most 16 in automatic mode. A resolution that throws keeps the pass serial;
// the fit reports the problem where it does today. `core_threads` receives the
// resolved team (0 when none was resolved).
int parallel_read_team(const ParallelReadPlan& plan, long long rows, long long blocks,
                       int& core_threads) {
    core_threads = 0;
    if (!plan.allowed || plan.core == nullptr || rows < 1 || blocks < 1 ||
        rows > std::numeric_limits<int>::max()) {
        return 1;
    }
    try {
        core_threads = plan.core->resolved_thread_count(static_cast<int>(rows), plan.num_fes);
    } catch (const std::exception&) {
        core_threads = 0;
        return 1;
    }
    long long team = std::min<long long>(core_threads, blocks);
    if (plan.requested_threads <= 0) {
        team = std::min<long long>(team, kParallelReadAutoMaxThreads);
    }
    return static_cast<int>(std::max<long long>(1, team));
}

// Package D (round 09, E.5): the stores the calling thread made to touch the
// destination pages of this fit's parallel reads, counted by the two touch
// helpers themselves (reset when the read is planned) and printed in the
// profile lines read_parallel_mode and wide_id_read (XHDFE_PROFILE_CPU=1), so
// that a test sees the touch, not only the policy (e(read_pretouch)).
long long& pretouch_stores() {
    static thread_local long long stores = 0;
    return stores;
}

// One store per 4 KiB page, and one in the last element.
template <class T>
void touch_destination_pages(T* data, int count) {
    if (count <= 0) {
        return;
    }
    constexpr std::size_t kStride = 4096 / sizeof(T);
    volatile T* const p = data;
    for (std::size_t k = 0; k < static_cast<std::size_t>(count); k += kStride) {
        p[k] = T();
    }
    p[static_cast<std::size_t>(count) - 1] = T();
    // The stores above, added once after the loop (round 11: the loop does no
    // work of its own beyond the stores of 2.34.2).
    pretouch_stores() += static_cast<long long>((static_cast<std::size_t>(count) + kStride - 1) / kStride) + 1;
}

// Sample selection from the marker read as data over SF_in1()..SF_in2(): count
// the selected rows of each block, prefix sums, then fill. A row is selected
// when its marker is not zero, which is what `if marker` evaluates, so a
// missing marker counts as selected (a defensive rule: the ado's marker is
// never missing). The map equals the one selected_observations() builds,
// `contiguous` included (true only when every row of the range is selected).
// False when a read fails; the caller then uses selected_observations().
// `workers_active` receives the number of threads that scanned at least one
// block of the range.
bool selected_by_marker_parallel(int marker_var, int threads, ObservationMap& out,
                                 int& team_observed, int& workers_active) {
    const int in1 = SF_in1();
    const int in2 = SF_in2();
    out = ObservationMap{};
    out.in1 = in1;
    team_observed = 1;
    workers_active = 0;
    if (in2 < in1) {
        return true;
    }
    const long long total = static_cast<long long>(in2) - in1 + 1;
    const long long blocks = (total + kParallelReadBlockRows - 1) / kParallelReadBlockRows;
    std::vector<long long> counts(static_cast<std::size_t>(blocks), 0);
    std::atomic<int> failed{0};
    std::atomic<int> active{0};
    int team = 1;
#ifdef _OPENMP
#pragma omp parallel num_threads(threads)
#else
    (void)threads;
#endif
    {
#ifdef _OPENMP
#pragma omp single
        team = omp_get_num_threads();
#endif
        int blocks_scanned = 0;
#ifdef _OPENMP
#pragma omp for schedule(static)
#endif
        for (long long b = 0; b < blocks; ++b) {
            if (failed.load(std::memory_order_relaxed)) {
                continue;
            }
            ++blocks_scanned;
            const long long lo = b * kParallelReadBlockRows;
            const long long hi = std::min(total, lo + kParallelReadBlockRows);
            long long count = 0;
            for (long long r = lo; r < hi; ++r) {
                ST_double z = 0.0;
                if (SF_vdata(marker_var, in1 + static_cast<int>(r), &z)) {
                    failed.store(1, std::memory_order_relaxed);
                    break;
                }
                count += z != 0.0 ? 1 : 0;
            }
            counts[static_cast<std::size_t>(b)] = count;
        }
        if (blocks_scanned > 0) {
            active.fetch_add(1, std::memory_order_relaxed);
        }
    }
    team_observed = team;
    workers_active = active.load();
    if (failed.load()) {
        return false;
    }
    std::vector<long long> offset(static_cast<std::size_t>(blocks) + 1, 0);
    for (long long b = 0; b < blocks; ++b) {
        offset[static_cast<std::size_t>(b) + 1] =
            offset[static_cast<std::size_t>(b)] + counts[static_cast<std::size_t>(b)];
    }
    const long long selected = offset[static_cast<std::size_t>(blocks)];
    out.n = static_cast<int>(selected);
    if (selected == total) {
        out.contiguous = true;
        return true;
    }
    if (selected == 0) {
        return true;
    }
    out.obs.resize(static_cast<std::size_t>(selected));
#ifdef _OPENMP
#pragma omp parallel for schedule(static) num_threads(threads)
#endif
    for (long long b = 0; b < blocks; ++b) {
        if (failed.load(std::memory_order_relaxed)) {
            continue;
        }
        const long long lo = b * kParallelReadBlockRows;
        const long long hi = std::min(total, lo + kParallelReadBlockRows);
        long long cursor = offset[static_cast<std::size_t>(b)];
        const long long end = offset[static_cast<std::size_t>(b) + 1];
        for (long long r = lo; r < hi; ++r) {
            ST_double z = 0.0;
            if (SF_vdata(marker_var, in1 + static_cast<int>(r), &z)) {
                failed.store(1, std::memory_order_relaxed);
                break;
            }
            if (z != 0.0) {
                if (cursor == end) {
                    // The marker changed between the passes: never write
                    // into the slots of another block.
                    failed.store(1, std::memory_order_relaxed);
                    break;
                }
                out.obs[static_cast<std::size_t>(cursor++)] = in1 + static_cast<int>(r);
            }
        }
        if (cursor != end) {
            failed.store(1, std::memory_order_relaxed);
        }
    }
    return !failed.load();
}

// The fused pass in blocks of kParallelReadBlockRows rows, schedule(static):
// each thread reads every variable of its rows into the final destinations
// (disjoint writes), with the value checks of read_columns_fused. An
// identifier column holding a value outside exact int32 is flagged and, as in
// the serial pass, left to its column reader. The flags reach `ids` only when
// the whole pass succeeds, so a failed pass leaves `ids` as it found it.
// `workers_active` receives the number of threads that read at least one block.
bool read_columns_fused_parallel(const ObservationMap& obs,
                                 const std::vector<FusedDoubleColumn>& doubles,
                                 std::vector<FusedIdColumn>& ids, int threads, bool pretouch,
                                 int& team_observed, int& workers_active) {
    const ST_double missval = SV_missval;
    const int n = obs.n;
    const long long blocks =
        (static_cast<long long>(n) + kParallelReadBlockRows - 1) / kParallelReadBlockRows;
    const std::size_t nd = doubles.size();
    const std::size_t ni = ids.size();
    if (pretouch) {
        for (const FusedDoubleColumn& column : doubles) {
            touch_destination_pages(column.dest, n);
        }
        for (const FusedIdColumn& column : ids) {
            touch_destination_pages(column.dest, n);
        }
    }
    std::vector<std::atomic<int>> wide(ni);
    for (std::atomic<int>& flag : wide) {
        flag.store(0, std::memory_order_relaxed);
    }
    std::atomic<int> anomaly{0};
    std::atomic<int> active{0};
    int team = 1;
#ifdef _OPENMP
#pragma omp parallel num_threads(threads)
#else
    (void)threads;
#endif
    {
#ifdef _OPENMP
#pragma omp single
        team = omp_get_num_threads();
#endif
        int blocks_read = 0;
#ifdef _OPENMP
#pragma omp for schedule(static)
#endif
        for (long long b = 0; b < blocks; ++b) {
            if (anomaly.load(std::memory_order_relaxed)) {
                continue;
            }
            ++blocks_read;
            const int lo = static_cast<int>(b * kParallelReadBlockRows);
            const int hi = static_cast<int>(
                std::min<long long>(n, static_cast<long long>(lo) + kParallelReadBlockRows));
            bool bad = false;
            for (int i = lo; i < hi && !bad; ++i) {
                const int obs_no = obs.obs_no(i);
                for (std::size_t j = 0; j < nd; ++j) {
                    ST_double z = 0.0;
                    if (SF_vdata(doubles[j].var_idx, obs_no, &z) || !std::isfinite(z) ||
                        !(z < missval)) {
                        bad = true;
                        break;
                    }
                    doubles[j].dest[i] = z;
                }
                for (std::size_t k = 0; k < ni && !bad; ++k) {
                    const FusedIdColumn& column = ids[k];
                    ST_double z = 0.0;
                    if (SF_vdata(column.var_idx, obs_no, &z) || !std::isfinite(z) ||
                        !(z < missval)) {
                        bad = true;
                        break;
                    }
                    if (column.validate_individual &&
                        (z < 0.0 || std::trunc(z) != z || z > kMaxExactIntegerId)) {
                        bad = true;
                        break;
                    }
                    int id = 0;
                    if (exact_int32_id(z, id)) {
                        column.dest[i] = id;
                    } else if (!wide[k].load(std::memory_order_relaxed)) {
                        wide[k].store(1, std::memory_order_relaxed);
                    }
                }
            }
            if (bad) {
                anomaly.store(1, std::memory_order_relaxed);
            }
        }
        if (blocks_read > 0) {
            active.fetch_add(1, std::memory_order_relaxed);
        }
    }
    team_observed = team;
    workers_active = active.load();
    if (anomaly.load()) {
        return false;
    }
    for (std::size_t k = 0; k < ni; ++k) {
        if (wide[k].load()) {
            ids[k].exact_int32 = false;
        }
    }
    return true;
}

// Sample selection for stata_call: the marker read in parallel when the plan
// allows it and the range times the variables the fused pass reads reaches the
// threshold (so that selection and read normally switch together), otherwise
// (or when that read fails) SF_ifobs as before.
ObservationMap select_observations_for_read(ParallelReadPlan& plan) {
    if (plan.allowed) {
        const long long range_rows =
            std::max(0LL, static_cast<long long>(SF_in2()) - SF_in1() + 1);
        const long long blocks =
            (range_rows + kParallelReadBlockRows - 1) / kParallelReadBlockRows;
        int core_threads = 0;
        const int team = parallel_read_team(plan, range_rows, blocks, core_threads);
        if (team > 1 && range_rows * plan.variables >= plan.min_values) {
            ObservationMap selected;
            int observed = 1;
            int workers = 0;
            bool done = false;
            try {
                done = selected_by_marker_parallel(plan.marker_var, team, selected, observed,
                                                   workers);
            } catch (const std::exception&) {
                done = false;
            }
            plan.select_parallel = true;
            plan.select_team = observed;
            plan.select_workers = workers;
            if (done) {
                return selected;
            }
            plan.select_fallback = true;
        }
    }
    return selected_observations();
}

// The parallel read of the fused stage when the plan allows it and the read
// has enough values. True only when it completed; otherwise the caller runs
// read_columns_fused as before.
bool read_inputs_parallel(ParallelReadPlan& plan, const ObservationMap& obs,
                          const std::vector<FusedDoubleColumn>& doubles,
                          std::vector<FusedIdColumn>& ids) {
    if (!plan.allowed) {
        return false;
    }
    const long long rows = obs.n;
    plan.read_values = rows * static_cast<long long>(doubles.size() + ids.size());
    plan.read_blocks = (rows + kParallelReadBlockRows - 1) / kParallelReadBlockRows;
    const int team = parallel_read_team(plan, rows, plan.read_blocks, plan.read_core_threads);
    if (team <= 1 || plan.read_values < plan.min_values) {
        return false;
    }
    int observed = 1;
    int workers = 0;
    bool done = false;
    try {
        done = read_columns_fused_parallel(obs, doubles, ids, team, plan.pretouch, observed,
                                           workers);
    } catch (const std::exception&) {
        done = false;
    }
    plan.read_team = observed;
    plan.read_workers = workers;
    plan.read_used = done;
    plan.read_fallback = !done;
    return done;
}

// The team and the workers the parallel input read reports to e(threads_used)
// and e(parallel_workers_active): the largest of the parallel passes that ran,
// the selection over the whole range and the read of the selected rows, kept
// or discarded; 0 when both were serial.
int parallel_read_threads_used(const ParallelReadPlan& plan) {
    int used = plan.select_parallel ? plan.select_team : 0;
    if (plan.read_used || plan.read_fallback) {
        used = std::max(used, plan.read_team);
    }
    if (plan.wide_ran) {
        used = std::max(used, plan.wide_team);
    }
    return used;
}

int parallel_read_workers_active(const ParallelReadPlan& plan) {
    int active = plan.select_parallel ? plan.select_workers : 0;
    if (plan.read_used || plan.read_fallback) {
        active = std::max(active, plan.read_workers);
    }
    if (plan.wide_ran) {
        active = std::max(active, plan.wide_workers);
    }
    return active;
}

// --- Wide identifier read (phase 3 of the Stata-path plan) ------------------
// A wide identifier column (a value outside exact int32) left by the fused
// pass to its column reader is read again, after a successful PARALLEL fused
// pass only, on the same team: blocks of kParallelReadBlockRows positions of
// the final sample map, schedule(static), straight into (value, row) pairs,
// with the checks of the fused pass. A worker never reports: it marks an
// anomaly and stops reading. After the region, an anomaly (or any exception
// on the way) discards everything and the column reader of today runs where
// it runs today, so every message and its order stay those of today. On
// success the pairs are sorted as today and ranked on the team
// (xhdfe_wide_id::rank_sorted), giving the codes of the column reader.
// XHDFE_WIDE_ID_READ=0, read once per process, keeps the column reader.
bool wide_id_read_enabled() {
    static int cached = -1;
    if (cached >= 0) {
        return cached == 1;
    }
    const char* raw = std::getenv("XHDFE_WIDE_ID_READ");
    cached = (raw && raw[0] == '0' && raw[1] == '\0') ? 0 : 1;
    return cached == 1;
}

// Test hook, read once per process: XHDFE_TEST_WIDE_ID_READ_ANOMALY=k (k >= 0)
// makes the worker of block k (the last block when k is beyond it) mark an
// anomaly after writing that block's pairs, so that a partly written buffer is
// discarded. -1 when unset or not a nonnegative integer.
long long wide_id_read_test_anomaly_block() {
    static long long cached = -2;
    if (cached != -2) {
        return cached;
    }
    cached = -1;
    const char* raw = std::getenv("XHDFE_TEST_WIDE_ID_READ_ANOMALY");
    if (raw && *raw != '\0') {
        char* end = nullptr;
        errno = 0;
        const long long value = std::strtoll(raw, &end, 10);
        if (errno == 0 && *end == '\0' && value >= 0) {
            cached = value;
        }
    }
    return cached;
}

// One store per 4 KiB page of a byte range, and one in its last byte.
void touch_destination_bytes(void* data, std::size_t bytes) {
    if (bytes == 0) {
        return;
    }
    volatile unsigned char* const p = static_cast<unsigned char*>(data);
    for (std::size_t k = 0; k < bytes; k += 4096) {
        p[k] = 0;
    }
    p[bytes - 1] = 0;
    pretouch_stores() += static_cast<long long>((bytes + 4095) / 4096) + 1;  // the stores above, added once
}

// True when pairs[0..n) are already in ascending order of value, which is what
// a dataset sorted by the column gives: each of `blocks` fixed blocks compares
// every pair with the one before it, the first with the previous block's last.
bool pairs_ascending_on_team(const xhdfe_wide_id::Pair* pairs, int n, long long blocks,
                             int threads, ParallelWorkObserver& observer) {
    if (n <= 1) {
        return true;
    }
    std::atomic<int> descent{0};
    observer.begin_region(threads);
#ifdef _OPENMP
#pragma omp parallel for schedule(static) num_threads(threads)
#else
    (void)threads;
#endif
    for (long long b = 0; b < blocks; ++b) {
        if (descent.load(std::memory_order_relaxed)) {
            continue;
        }
        const long long lo = std::max(1LL, b * kParallelReadBlockRows);
        const long long hi = std::min<long long>(n, (b + 1) * kParallelReadBlockRows);
        observer.observe_work();
        for (long long j = lo; j < hi; ++j) {
            if (pairs[j].value < pairs[j - 1].value) {
                descent.store(1, std::memory_order_relaxed);
                break;
            }
        }
    }
    observer.end_region();
    return descent.load() == 0;
}

void sort_wide_id_pairs(xhdfe_wide_id::Pair* first, int n, const ParallelReadPlan& plan,
                        int& sort_team, int& sort_workers) {
    const auto less = [](const xhdfe_wide_id::Pair& a, const xhdfe_wide_id::Pair& b) {
        return a.value < b.value;
    };
#if defined(XHDFE_HAS_GNU_PARALLEL_SORT) && defined(HDFE_USE_OPENMP)
    // GNU sort can use the ambient team, which can be wider than the input
    // read in automatic mode. Observe only when this can raise a maximum.
    const int capacity = std::min({n, omp_get_max_threads(), omp_get_thread_limit()});
    if (!omp_in_parallel() && capacity > 1 &&
        capacity > std::min(parallel_read_threads_used(plan), parallel_read_workers_active(plan))) {
        ParallelWorkObserver observer;
        observer.begin_region(capacity);
        static std::atomic<std::uint64_t> sort_epoch{0};
        const std::uint64_t epoch = sort_epoch.fetch_add(1, std::memory_order_relaxed) + 1;
        const auto observed_less = [&](const xhdfe_wide_id::Pair& a, const xhdfe_wide_id::Pair& b) {
            static thread_local std::uint64_t last_epoch = 0;
            if (last_epoch != epoch) {
                last_epoch = epoch;
                observer.observe_work();
            }
            return less(a, b);
        };
        XHDFE_PARALLEL_SORT(first, first + n, observed_less);
        observer.end_region();
        sort_team = observer.max_team_size();
        sort_workers = observer.active_workers();
        return;
    }
#else
    (void)plan;
    (void)sort_team;
    (void)sort_workers;
#endif
    XHDFE_PARALLEL_SORT(first, first + n, less);
}

// The read region: pairs[i] = (value of row obs.obs_no(i), i). False on any
// anomaly; the caller then discards the buffer.
bool read_wide_id_pairs_parallel(const ObservationMap& obs, int var_idx,
                                 bool validate_individual, int threads,
                                 xhdfe_wide_id::Pair* pairs, int& team_observed,
                                 int& workers_active) {
    const ST_double missval = SV_missval;
    const int n = obs.n;
    const long long blocks =
        (static_cast<long long>(n) + kParallelReadBlockRows - 1) / kParallelReadBlockRows;
    const long long inject_at = wide_id_read_test_anomaly_block();
    const long long inject_block =
        inject_at < 0 ? -1 : std::min<long long>(inject_at, blocks - 1);
    std::atomic<int> anomaly{0};
    std::atomic<int> active{0};
    int team = 1;
#ifdef _OPENMP
#pragma omp parallel num_threads(threads)
#else
    (void)threads;
#endif
    {
#ifdef _OPENMP
#pragma omp single
        team = omp_get_num_threads();
#endif
        int blocks_read = 0;
#ifdef _OPENMP
#pragma omp for schedule(static)
#endif
        for (long long b = 0; b < blocks; ++b) {
            if (anomaly.load(std::memory_order_relaxed)) {
                continue;
            }
            ++blocks_read;
            const int lo = static_cast<int>(b * kParallelReadBlockRows);
            const int hi = static_cast<int>(
                std::min<long long>(n, static_cast<long long>(lo) + kParallelReadBlockRows));
            bool bad = false;
            for (int i = lo; i < hi; ++i) {
                ST_double z = 0.0;
                if (SF_vdata(var_idx, obs.obs_no(i), &z) || !std::isfinite(z) || !(z < missval)) {
                    bad = true;
                    break;
                }
                if (validate_individual &&
                    (z < 0.0 || std::trunc(z) != z || z > kMaxExactIntegerId)) {
                    bad = true;
                    break;
                }
                pairs[i].value = z;
                pairs[i].row = i;
            }
            if (b == inject_block) {
                bad = true;
            }
            if (bad) {
                anomaly.store(1, std::memory_order_relaxed);
            }
        }
        if (blocks_read > 0) {
            active.fetch_add(1, std::memory_order_relaxed);
        }
    }
    team_observed = team;
    workers_active = active.load();
    return !anomaly.load();
}

// For a column the fused pass left to its column reader (wide): its codes on
// the team, true, or false with `codes` to be discarded and the column reader
// to run. `parallel_pass_done`: read_inputs_parallel itself succeeded (a
// success of the serial fused pass does not qualify). Never throws.
bool read_wide_id_on_team(ParallelReadPlan& plan, bool parallel_pass_done,
                          const ObservationMap& obs, int var_idx, bool validate_individual,
                          const char* what, Eigen::VectorXi& codes) {
    const char* reason = "done";
    bool ok = false;
    int team = 1;
    int read_team = 0;
    int read_workers = 0;
    int order_team = 0;
    int order_workers = 0;
    int sort_team = 0;
    int sort_workers = 0;
    xhdfe_wide_id::RankResult ranked;
    const int n = obs.n;
    const long long blocks =
        (static_cast<long long>(n) + kParallelReadBlockRows - 1) / kParallelReadBlockRows;
    if (!parallel_pass_done) {
        reason = "serial_first_pass";
    } else if (!wide_id_read_enabled()) {
        reason = "switch_off";
    } else {
        int core_threads = 0;
        team = parallel_read_team(plan, n, blocks, core_threads);
        if (team <= 1 || n < 1) {
            reason = "serial_team";
        } else {
            try {
                // Everything is allocated before the regions, so nothing
                // inside them allocates or throws.
                std::unique_ptr<xhdfe_wide_id::Pair[]> pairs(
                    new xhdfe_wide_id::Pair[static_cast<std::size_t>(n)]);
                codes.resize(n);
                if (plan.pretouch) {
                    touch_destination_bytes(pairs.get(),
                                            static_cast<std::size_t>(n) * sizeof(xhdfe_wide_id::Pair));
                    touch_destination_pages(codes.data(), n);
                }
                const auto read_t0 = std::chrono::steady_clock::now();
                const bool read_ok = read_wide_id_pairs_parallel(
                    obs, var_idx, validate_individual, team, pairs.get(), read_team, read_workers);
                plan.wide_ran = true;
                plan.wide_team = std::max(plan.wide_team, read_team);
                plan.wide_workers = std::max(plan.wide_workers, read_workers);
                plugin_cpu_profile_log_elapsed(std::string("read_") + what + "_wide_team", read_t0);
                if (!read_ok) {
                    reason = wide_id_read_test_anomaly_block() >= 0 ? "test_anomaly" : "anomaly";
                } else {
                    const auto code_t0 = std::chrono::steady_clock::now();
                    xhdfe_wide_id::Pair* const first = pairs.get();
                    // A column read in ascending order is ranked as read: the
                    // codes depend only on the values (rank_sorted), so the sort
                    // would not change one.
                    ParallelWorkObserver order_observer;
                    const bool ascending = pairs_ascending_on_team(first, n, blocks, team,
                                                                   order_observer);
                    order_team = order_observer.max_team_size();
                    order_workers = order_observer.active_workers();
                    plan.wide_team = std::max(plan.wide_team, order_team);
                    plan.wide_workers = std::max(plan.wide_workers, order_workers);
                    if (!ascending) {
                        sort_wide_id_pairs(first, n, plan, sort_team, sort_workers);
                        plan.wide_team = std::max(plan.wide_team, sort_team);
                        plan.wide_workers = std::max(plan.wide_workers, sort_workers);
                    }
                    ranked = xhdfe_wide_id::rank_sorted(first, n, codes.data(), blocks, team);
                    plan.wide_team = std::max(plan.wide_team, ranked.team);
                    plan.wide_workers = std::max(plan.wide_workers, ranked.workers);
                    plugin_cpu_profile_log_elapsed(std::string("code_") + what + "_dense_team", code_t0);
                    if (ranked.distinct >= 1) {
                        ok = true;
                    } else {
                        reason = "empty";
                    }
                }
            } catch (...) {
                reason = "exception";
                ok = false;
            }
        }
    }
    if (!ok) {
        codes = Eigen::VectorXi();
    }
    if (plugin_cpu_profile_enabled()) {
        std::cerr << "plugin_profile label=wide_id_read what=" << what << " var=" << var_idx
                  << " path=" << (ok ? "team" : "column_reader") << " reason=" << reason
                  << " team=" << read_team << " workers=" << read_workers
                  << " order_team=" << order_team << " order_workers=" << order_workers
                  << " sort_team=" << sort_team << " sort_workers=" << sort_workers
                  << " rank_team=" << (ok ? ranked.team : 0)
                  << " rank_workers=" << (ok ? ranked.workers : 0) << " rows=" << n
                  << " distinct=" << (ok ? ranked.distinct : 0)
                  << " pretouch_stores=" << pretouch_stores() << '\n';
    }
    return ok;
}

void log_parallel_read_mode(const ParallelReadPlan& plan) {
    std::cerr << "plugin_profile label=read_parallel_mode allowed=" << (plan.allowed ? 1 : 0)
              << " reason=" << plan.reason << " select_team=" << plan.select_team
              << " select_fallback=" << (plan.select_fallback ? 1 : 0)
              << " read=" << (plan.read_used ? 1 : 0) << " team=" << plan.read_team
              << " fallback=" << (plan.read_fallback ? 1 : 0)
              << " workers=" << plan.read_workers
              << " core_threads=" << plan.read_core_threads << " blocks=" << plan.read_blocks
              << " values=" << plan.read_values << " min_values=" << plan.min_values
              << " pretouch=" << (plan.pretouch ? 1 : 0)
              << " pretouch_stores=" << pretouch_stores()
              << " select_workers=" << plan.select_workers
              << " requested=" << plan.requested_threads << '\n';
}

// Package D (23nov2026): what the fit did with the finer blocks and with the
// read, in the scalars (s_...) and locals (m_...) the ado names; absent names
// are skipped, so an ado of 2.34.2 and this plugin work together.
struct FineReadResults {
    std::optional<std::string> fine_used, fine_parts, hinted_applies, fine_alloc_failed, fine_retry,
        fine_retry_factor, fine_retry_parts, fine_retry_iterations, cache_hit, m_fine_request, m_fine_source,
        read_parallel, read_fallback, read_pretouch, m_read_pretouch_source, m_read_parallel_reason;
    explicit FineReadResults(const ParsedArgs& args)
        : fine_used(args.get_optional("s_reduced_pcg_fine_used")),
          fine_parts(args.get_optional("s_reduced_pcg_fine_parts")),
          hinted_applies(args.get_optional("s_reduced_pcg_hinted_applies")),
          fine_alloc_failed(args.get_optional("s_reduced_pcg_fine_alloc_failed")),
          fine_retry(args.get_optional("s_reduced_pcg_fine_retry")),
          fine_retry_factor(args.get_optional("s_reduced_pcg_fine_retry_factor")),
          fine_retry_parts(args.get_optional("s_reduced_pcg_fine_retry_parts")),
          fine_retry_iterations(args.get_optional("s_reduced_pcg_fine_retry_iterations")),
          cache_hit(args.get_optional("s_reduced_pcg_cache_hit")),
          m_fine_request(args.get_optional("m_reduced_pcg_fine_request")),
          m_fine_source(args.get_optional("m_reduced_pcg_fine_source")),
          read_parallel(args.get_optional("s_read_parallel")),
          read_fallback(args.get_optional("s_read_fallback")),
          read_pretouch(args.get_optional("s_read_pretouch")),
          m_read_pretouch_source(args.get_optional("m_read_pretouch_source")),
          m_read_parallel_reason(args.get_optional("m_read_parallel_reason")) {}
};

void maybe_save_local(const std::optional<std::string>& name, const std::string& value) {
    if (!name || name->empty()) {
        return;
    }
    const std::string local = "_" + *name;
    if (SF_macro_save(const_cast<char*>(local.c_str()), const_cast<char*>(value.c_str()))) {
        throw_with_prefix("xhdfe plugin: ", "failed to save macro: " + *name);
    }
}

struct SlopeSolverOutputs {
    std::optional<std::string> request, source, used, status, reason;
    std::optional<std::string> discarded_iters, scores_used, csr_owner_used;

    explicit SlopeSolverOutputs(const ParsedArgs& args)
        : request(args.get_optional("m_slope_solver_request")),
          source(args.get_optional("m_slope_solver_source")),
          used(args.get_optional("m_slope_solver_used")),
          status(args.get_optional("m_slope_solver_status")),
          reason(args.get_optional("m_slope_solver_reason")),
          discarded_iters(args.get_optional("s_slope_solver_discarded_iters")),
          scores_used(args.get_optional("s_slope_solver_scores_used")),
          csr_owner_used(args.get_optional("s_slope_solver_csr_owner_used")) {}

    void save(const HdfeRegressorV11& reg) const {
        const auto& result = reg.slope_solver_diagnostics();
        maybe_save_local(request, hdfe::slope_solver_request_name(result.request));
        maybe_save_local(source, hdfe::slope_solver_source_name(result.source));
        maybe_save_local(used, hdfe::slope_solver_request_name(result.used));
        maybe_save_local(status, hdfe::slope_solver_status_name(result.status));
        maybe_save_local(reason, result.reason);
        maybe_save_scalar(discarded_iters, static_cast<double>(result.discarded_iters));
        maybe_save_scalar(scores_used, result.scores_used ? 1.0 : 0.0);
        maybe_save_scalar(csr_owner_used, result.csr_owner_used ? 1.0 : 0.0);
    }
};

const char* source_name(int source) {
    return source == 1 ? "request" : source == 2 ? "environment" : "built-in";
}

void maybe_save_fine_and_read(const FineReadResults& names, const HdfeRegressorV11& reg,
                              const ParallelReadPlan& plan) {
    const hdfe::v11::ReducedPcgFineDiagnostics& fine = reg.reduced_pcg_fine();
    maybe_save_scalar(names.fine_used, static_cast<double>(fine.used));
    maybe_save_scalar(names.fine_parts, static_cast<double>(fine.parts));
    maybe_save_scalar(names.hinted_applies, static_cast<double>(fine.hinted_applies));
    maybe_save_scalar(names.fine_alloc_failed, fine.alloc_failed ? 1.0 : 0.0);
    maybe_save_scalar(names.fine_retry, fine.retry ? 1.0 : 0.0);
    maybe_save_scalar(names.fine_retry_factor, static_cast<double>(fine.retry_factor));
    maybe_save_scalar(names.fine_retry_parts, static_cast<double>(fine.retry_parts));
    maybe_save_scalar(names.fine_retry_iterations, static_cast<double>(fine.retry_iterations));
    maybe_save_scalar(names.cache_hit, fine.cache_hit ? 1.0 : 0.0);
    maybe_save_local(names.m_fine_request,
                     fine.request == hdfe::kReducedPcgApplyFineAuto ? std::string("auto") : std::to_string(fine.request));
    maybe_save_local(names.m_fine_source, source_name(fine.source));
    maybe_save_scalar(names.read_parallel, plan.read_used ? 1.0 : 0.0);
    maybe_save_scalar(names.read_fallback, plan.read_fallback ? 1.0 : 0.0);
    maybe_save_scalar(names.read_pretouch, plan.pretouch ? 1.0 : 0.0);
    maybe_save_local(names.m_read_pretouch_source, source_name(plan.pretouch_source));
    maybe_save_local(names.m_read_parallel_reason, plan.reason);
}

// --- Write-back of e(sample) when nothing else is stored -----------------------
// With e(sample) prefilled by the ado and no residuals, group or effects to
// store, the write-back only checks sample_index and finds the rows to clear.
// Those two passes over the rows run by blocks on the fit's team; the stores
// that clear the dropped rows stay serial, in ascending row order, as before.
// No interface function is called inside a region.
constexpr int kWritebackTeamMinRows = 1 << 20;
constexpr int kWritebackMaxBufferedRows = (8 << 20) / sizeof(int);

// Reuse the fit's team width, allowing work for at most one thread per block.
int writeback_team(const HdfeRegressorV11& reg, int rows) {
#if defined(_OPENMP) && defined(HDFE_USE_OPENMP)
    if (rows >= kWritebackTeamMinRows && !omp_in_parallel()) {
        const int blocks = rows / kParallelReadBlockRows + (rows % kParallelReadBlockRows != 0);
        return std::min(reg.threads_effective(), blocks);
    }
#else
    (void)reg;
    (void)rows;
#endif
    return 1;
}

// keep[sample_index(i)] = 1 for every i (keep may be empty: then only the
// check). False when an index lies outside [0, n), which the caller reports as
// the serial loop does; no store has been made by then in either path.
bool mark_kept_rows_on_team(const Eigen::VectorXi& sample_index, int n,
                            std::vector<uint8_t>& keep, int team,
                            ParallelWorkObserver& observer) {
    const int rows = static_cast<int>(sample_index.size());
    const long long blocks =
        (static_cast<long long>(rows) + kParallelReadBlockRows - 1) / kParallelReadBlockRows;
    const int* const index = sample_index.data();
    uint8_t* const mark = keep.empty() ? nullptr : keep.data();
    std::atomic<int> invalid{0};
    observer.begin_region(team);
#ifdef _OPENMP
#pragma omp parallel for schedule(static) num_threads(team)
#else
    (void)team;
#endif
    for (long long b = 0; b < blocks; ++b) {
        if (invalid.load(std::memory_order_relaxed)) {
            continue;
        }
        const int lo = static_cast<int>(b * kParallelReadBlockRows);
        const int hi = static_cast<int>(
            std::min<long long>(rows, static_cast<long long>(lo) + kParallelReadBlockRows));
        observer.observe_work();
        for (int i = lo; i < hi; ++i) {
            const int orig = index[i];
            if (orig < 0 || orig >= n) {
                invalid.store(1, std::memory_order_relaxed);
                break;
            }
            if (mark != nullptr) {
#ifdef _OPENMP
#pragma omp atomic write
#endif
                mark[orig] = 1;
            }
        }
    }
    observer.end_region();
    return invalid.load() == 0;
}

// Collect a bounded list of dropped rows in ascending order.
std::optional<std::vector<int>> unmarked_rows_on_team(const std::vector<uint8_t>& keep,
                                                      int team, ParallelWorkObserver& observer) {
    const int n = static_cast<int>(keep.size());
    const long long blocks =
        (static_cast<long long>(n) + kParallelReadBlockRows - 1) / kParallelReadBlockRows;
    std::vector<int> count(static_cast<std::size_t>(blocks) + 1, 0);
    const uint8_t* const mark = keep.data();
    observer.begin_region(team);
#ifdef _OPENMP
#pragma omp parallel for schedule(static) num_threads(team)
#else
    (void)team;
#endif
    for (long long b = 0; b < blocks; ++b) {
        const int lo = static_cast<int>(b * kParallelReadBlockRows);
        const int hi = static_cast<int>(
            std::min<long long>(n, static_cast<long long>(lo) + kParallelReadBlockRows));
        observer.observe_work();
        int found = 0;
        for (int i = lo; i < hi; ++i) {
            found += mark[i] == 0 ? 1 : 0;
        }
        count[static_cast<std::size_t>(b) + 1] = found;
    }
    observer.end_region();
    for (long long b = 0; b < blocks; ++b) {
        count[static_cast<std::size_t>(b) + 1] += count[static_cast<std::size_t>(b)];
    }
    if (count.back() > kWritebackMaxBufferedRows) {
        return std::nullopt;
    }
    std::vector<int> rows(static_cast<std::size_t>(count.back()));
    if (rows.empty()) {
        return rows;
    }
    int* const out = rows.data();
    observer.begin_region(team);
#ifdef _OPENMP
#pragma omp parallel for schedule(static) num_threads(team)
#endif
    for (long long b = 0; b < blocks; ++b) {
        int position = count[static_cast<std::size_t>(b)];
        if (position == count[static_cast<std::size_t>(b) + 1]) {
            continue;
        }
        const int lo = static_cast<int>(b * kParallelReadBlockRows);
        const int hi = static_cast<int>(
            std::min<long long>(n, static_cast<long long>(lo) + kParallelReadBlockRows));
        observer.observe_work();
        for (int i = lo; i < hi; ++i) {
            if (mark[i] == 0) {
                out[position++] = i;
            }
        }
    }
    observer.end_region();
    return rows;
}

// Helpers for group/individual singleton dropping (mirrors v11 core logic).
struct FeLookup {
    bool dense = false;
    int min_id = 0;
    int num_groups = 0;
    std::unordered_map<int, int> mapping;

    int index(int raw) const {
        if (dense) {
            return raw - min_id;
        }
        auto it = mapping.find(raw);
        if (it == mapping.end()) {
            throw std::runtime_error("FE lookup missing key");
        }
        return it->second;
    }
};

FeLookup build_lookup(const Eigen::VectorXi& raw_ids) {
    FeLookup lookup;
    if (raw_ids.size() == 0) {
        return lookup;
    }

    int min_id = raw_ids(0);
    int max_id = raw_ids(0);
    for (int i = 1; i < raw_ids.size(); ++i) {
        const int v = raw_ids(i);
        if (v < min_id) {
            min_id = v;
        } else if (v > max_id) {
            max_id = v;
        }
    }
    const long long range =
        static_cast<long long>(max_id) - static_cast<long long>(min_id) + 1LL;
    constexpr long long kDenseRangeCap = 50000000LL;
    if (min_id >= 0 && range > 0 && range <= kDenseRangeCap &&
        range <= static_cast<long long>(raw_ids.size()) * 2LL) {
        lookup.dense = true;
        lookup.min_id = min_id;
        lookup.num_groups = static_cast<int>(range);
        return lookup;
    }

    lookup.dense = false;
    lookup.min_id = 0;
    std::unordered_map<int, int> mapping;
    constexpr std::size_t kMaxReserve = 5000000ULL;
    const long long approx_range =
        range > 0 && range <= static_cast<long long>(kMaxReserve) ? range : 0LL;
    const std::size_t reserve =
        approx_range > 0 ? static_cast<std::size_t>(approx_range)
                         : std::min<std::size_t>(static_cast<std::size_t>(raw_ids.size()),
                                                 kMaxReserve);
    if (reserve > 0) {
        mapping.reserve(reserve);
    }

    int next_id = 0;
    for (int i = 0; i < raw_ids.size(); ++i) {
        const int key = raw_ids(i);
        auto it = mapping.find(key);
        if (it == mapping.end()) {
            mapping.emplace(key, next_id);
            ++next_id;
        }
    }
    lookup.mapping = std::move(mapping);
    lookup.num_groups = next_id;
    return lookup;
}

struct GroupSingletonDropResult {
    std::vector<uint8_t> keep_groups;
    std::vector<int> individual_degrees;
    int dropped_groups = 0;
};

GroupSingletonDropResult drop_singletons_group_individual(
    const std::vector<Eigen::VectorXi>& standard_fes,
    const hdfe::detail::GroupIndividualStructure& gi) {
    const int G = gi.num_groups;
    const int I = gi.num_individuals;
    GroupSingletonDropResult res;
    res.keep_groups.assign(static_cast<std::size_t>(G), 1);
    res.individual_degrees.assign(static_cast<std::size_t>(I), 0);

    if (G <= 0 || I <= 0) {
        return res;
    }
    if (static_cast<int>(gi.group_ptr.size()) != G + 1 ||
        static_cast<int>(gi.individual_ptr.size()) != I + 1) {
        throw std::runtime_error("Invalid group/individual structure");
    }

    for (int i = 0; i < I; ++i) {
        res.individual_degrees[static_cast<std::size_t>(i)] =
            gi.individual_ptr[static_cast<std::size_t>(i + 1)] -
            gi.individual_ptr[static_cast<std::size_t>(i)];
    }

    struct FeLevelIndex {
        FeLookup lookup;
        std::vector<int> level_id;
        std::vector<std::vector<int>> groups_by_level;
        std::vector<int> counts;
    };

    std::vector<FeLevelIndex> feinfo;
    feinfo.reserve(standard_fes.size());
    for (const auto& fe : standard_fes) {
        if (fe.size() != G) {
            throw std::runtime_error("Standard fixed effects must be group-level (length #groups)");
        }
        FeLevelIndex info;
        info.lookup = build_lookup(fe);
        info.level_id.assign(static_cast<std::size_t>(G), 0);
        info.groups_by_level.assign(static_cast<std::size_t>(info.lookup.num_groups), {});
        for (int g = 0; g < G; ++g) {
            const int lid = info.lookup.index(fe(g));
            info.level_id[static_cast<std::size_t>(g)] = lid;
            info.groups_by_level[static_cast<std::size_t>(lid)].push_back(g);
        }
        info.counts.assign(static_cast<std::size_t>(info.lookup.num_groups), 0);
        for (int lid = 0; lid < info.lookup.num_groups; ++lid) {
            info.counts[static_cast<std::size_t>(lid)] =
                static_cast<int>(info.groups_by_level[static_cast<std::size_t>(lid)].size());
        }
        feinfo.push_back(std::move(info));
    }

    std::vector<uint8_t> in_queue(static_cast<std::size_t>(G), 0);
    std::deque<int> queue;
    auto enqueue_group = [&](int g) {
        if (g < 0 || g >= G) {
            return;
        }
        if (!res.keep_groups[static_cast<std::size_t>(g)] ||
            in_queue[static_cast<std::size_t>(g)]) {
            return;
        }
        in_queue[static_cast<std::size_t>(g)] = 1;
        queue.push_back(g);
    };

    for (int g = 0; g < G; ++g) {
        bool singleton = false;
        for (const auto& info : feinfo) {
            const int lid = info.level_id[static_cast<std::size_t>(g)];
            if (info.counts[static_cast<std::size_t>(lid)] == 1) {
                singleton = true;
                break;
            }
        }
        if (singleton) {
            enqueue_group(g);
        }
    }

    for (int i = 0; i < I; ++i) {
        if (res.individual_degrees[static_cast<std::size_t>(i)] == 1) {
            const int only = gi.individual_group[static_cast<std::size_t>(
                gi.individual_ptr[static_cast<std::size_t>(i)])];
            enqueue_group(only);
        }
    }

    while (!queue.empty()) {
        const int g = queue.front();
        queue.pop_front();
        in_queue[static_cast<std::size_t>(g)] = 0;
        if (!res.keep_groups[static_cast<std::size_t>(g)]) {
            continue;
        }

        res.keep_groups[static_cast<std::size_t>(g)] = 0;
        res.dropped_groups += 1;

        for (auto& info : feinfo) {
            const int lid = info.level_id[static_cast<std::size_t>(g)];
            int& count = info.counts[static_cast<std::size_t>(lid)];
            if (count <= 0) {
                continue;
            }
            count -= 1;
            if (count == 1) {
                int remaining = -1;
                for (const int gg : info.groups_by_level[static_cast<std::size_t>(lid)]) {
                    if (res.keep_groups[static_cast<std::size_t>(gg)]) {
                        remaining = gg;
                        break;
                    }
                }
                enqueue_group(remaining);
            }
        }

        const int begin = gi.group_ptr[static_cast<std::size_t>(g)];
        const int end = gi.group_ptr[static_cast<std::size_t>(g + 1)];
        for (int pos = begin; pos < end; ++pos) {
            const int i = gi.group_individual[static_cast<std::size_t>(pos)];
            int& deg = res.individual_degrees[static_cast<std::size_t>(i)];
            if (deg <= 0) {
                continue;
            }
            deg -= 1;
            if (deg == 1) {
                int remaining = -1;
                const int ibegin = gi.individual_ptr[static_cast<std::size_t>(i)];
                const int iend = gi.individual_ptr[static_cast<std::size_t>(i + 1)];
                for (int k = ibegin; k < iend; ++k) {
                    const int gg = gi.individual_group[static_cast<std::size_t>(k)];
                    if (res.keep_groups[static_cast<std::size_t>(gg)]) {
                        remaining = gg;
                        break;
                    }
                }
                enqueue_group(remaining);
            }
        }
    }

    return res;
}

hdfe::detail::GroupIndividualStructure build_group_individual_structure(
    const Eigen::VectorXi& group_index,
    const Eigen::VectorXi& individual_index,
    int num_groups,
    int num_individuals,
    GroupAggregation aggregation) {
    if (group_index.size() != individual_index.size()) {
        throw std::runtime_error("group_index and individual_index must have same length");
    }
    const int n = group_index.size();
    std::vector<uint64_t> edges;
    edges.reserve(static_cast<std::size_t>(n));
    for (int r = 0; r < n; ++r) {
        const uint32_t g = static_cast<uint32_t>(group_index(r));
        const uint32_t i = static_cast<uint32_t>(individual_index(r));
        edges.push_back((static_cast<uint64_t>(g) << 32) | static_cast<uint64_t>(i));
    }
    std::sort(edges.begin(), edges.end());
    edges.erase(std::unique(edges.begin(), edges.end()), edges.end());

    hdfe::detail::GroupIndividualStructure gi;
    gi.num_groups = num_groups;
    gi.num_individuals = num_individuals;
    gi.group_ptr.assign(static_cast<std::size_t>(num_groups) + 1, 0);
    for (const uint64_t key : edges) {
        const int g = static_cast<int>(key >> 32);
        gi.group_ptr[static_cast<std::size_t>(g + 1)] += 1;
    }
    for (int g = 0; g < num_groups; ++g) {
        gi.group_ptr[static_cast<std::size_t>(g + 1)] += gi.group_ptr[static_cast<std::size_t>(g)];
    }
    gi.group_individual.assign(static_cast<std::size_t>(gi.group_ptr.back()), 0);
    std::vector<int> cursor = gi.group_ptr;
    for (const uint64_t key : edges) {
        const int g = static_cast<int>(key >> 32);
        const int i = static_cast<int>(key & 0xffffffffULL);
        gi.group_individual[static_cast<std::size_t>(cursor[static_cast<std::size_t>(g)]++)] = i;
    }

    std::vector<uint64_t> edges_by_indiv;
    edges_by_indiv.reserve(edges.size());
    for (const uint64_t key : edges) {
        const uint32_t g = static_cast<uint32_t>(key >> 32);
        const uint32_t i = static_cast<uint32_t>(key & 0xffffffffULL);
        edges_by_indiv.push_back((static_cast<uint64_t>(i) << 32) | static_cast<uint64_t>(g));
    }
    std::sort(edges_by_indiv.begin(), edges_by_indiv.end());
    edges_by_indiv.erase(std::unique(edges_by_indiv.begin(), edges_by_indiv.end()), edges_by_indiv.end());

    gi.individual_ptr.assign(static_cast<std::size_t>(num_individuals) + 1, 0);
    gi.individual_group.assign(edges_by_indiv.size(), 0);
    for (const uint64_t key : edges_by_indiv) {
        const int i = static_cast<int>(key >> 32);
        gi.individual_ptr[static_cast<std::size_t>(i + 1)] += 1;
    }
    for (int i = 0; i < num_individuals; ++i) {
        gi.individual_ptr[static_cast<std::size_t>(i + 1)] +=
            gi.individual_ptr[static_cast<std::size_t>(i)];
    }
    std::vector<int> icursor = gi.individual_ptr;
    for (const uint64_t key : edges_by_indiv) {
        const int i = static_cast<int>(key >> 32);
        const int g = static_cast<int>(key & 0xffffffffULL);
        gi.individual_group[static_cast<std::size_t>(icursor[static_cast<std::size_t>(i)]++)] = g;
    }

    gi.group_scale.assign(static_cast<std::size_t>(num_groups), 1.0);
    if (aggregation == GroupAggregation::Mean) {
        for (int g = 0; g < num_groups; ++g) {
            const int size = gi.group_ptr[static_cast<std::size_t>(g + 1)] -
                             gi.group_ptr[static_cast<std::size_t>(g)];
            if (size <= 0) {
                throw std::runtime_error("Invalid group with zero individuals");
            }
            gi.group_scale[static_cast<std::size_t>(g)] = 1.0 / static_cast<double>(size);
        }
    }
    return gi;
}

}  // namespace


// ---------------------------------------------------------------------------
// AKM + leave-out (KSS) variance decomposition (opt-in task; mirrors the
// Python py_hdfe_v11.akm_kss free function). Reached only when the caller
// passes task=akm_kss (the xhdfeakm ado); the standard xhdfe fit path below
// is untouched.
// ---------------------------------------------------------------------------

hdfe::akm::LeaveOutLevel parse_akm_leave_out_level(const std::string& name) {
    const std::string lower = to_lower(name);
    if (lower == "match" || lower == "matches") {
        return hdfe::akm::LeaveOutLevel::Match;
    }
    if (lower == "obs" || lower == "observation" || lower == "observations") {
        return hdfe::akm::LeaveOutLevel::Observation;
    }
    throw_with_prefix("xhdfe plugin: ", "unknown leave-out level: " + name);
}

hdfe::akm::LeverageMethod parse_akm_leverage_method(const std::string& name) {
    const std::string lower = to_lower(name);
    if (lower == "auto") {
        return hdfe::akm::LeverageMethod::Auto;
    }
    if (lower == "exact") {
        return hdfe::akm::LeverageMethod::Exact;
    }
    if (lower == "jla" || lower == "jl") {
        return hdfe::akm::LeverageMethod::Jla;
    }
    throw_with_prefix("xhdfe plugin: ", "unknown leverages method: " + name);
}

void akm_save_scalar(const char* name, double value) {
    const ST_retcode rc = SF_scal_save(const_cast<char*>(name), stata_value_or_missing(value));
    if (rc) {
        throw_with_prefix("xhdfe plugin: ", std::string("failed to save scalar: ") + name);
    }
}

void akm_progress_to_stata(const char* line, void* user);

// Leave-out connected set only (task=akm_leave_out_set; the xhdfeconnected
// ado): computes the KSS leave-one-out sample flag and counts without
// running the decomposition.
ST_retcode run_akm_leave_out_set(const ParsedArgs& args) {
    bool has_fweight = false;
    if (auto val = args.get_optional("has_fweight")) {
        has_fweight = parse_bool(*val, "has_fweight");
    }
    // varlist: worker firm [fweight] keep
    const int expected_vars = 2 + (has_fweight ? 1 : 0) + 1;
    if (SF_nvars() != expected_vars) {
        throw_with_prefix("xhdfe plugin: ",
                          "varlist has wrong length (have " + std::to_string(SF_nvars()) +
                              ", want " + std::to_string(expected_vars) + ")");
    }
    const int idx_worker = 1;
    const int idx_firm = 2;
    const int idx_fw = has_fweight ? 3 : -1;
    const int idx_keep = has_fweight ? 4 : 3;

    const ObservationMap obs = selected_observations();
    const int n = obs.n;
    if (n <= 0) {
        return static_cast<ST_retcode>(2000);
    }
    const ST_double missval = SV_missval;
    Eigen::VectorXi worker(n);
    Eigen::VectorXi firm(n);
    Eigen::VectorXd fw;
    if (has_fweight) {
        fw.resize(n);
    }
    for (int i = 0; i < n; ++i) {
        const int row = obs.obs_no(i);
        ST_double z = 0.0;
        if (SF_vdata(idx_worker, row, &z) || !(z < missval)) {
            throw_with_prefix("xhdfe plugin: ", "failed to read worker id");
        }
        worker[i] = static_cast<int>(std::floor(z + 0.5));
        if (SF_vdata(idx_firm, row, &z) || !(z < missval)) {
            throw_with_prefix("xhdfe plugin: ", "failed to read firm id");
        }
        firm[i] = static_cast<int>(std::floor(z + 0.5));
        if (has_fweight) {
            if (SF_vdata(idx_fw, row, &z) || !(z < missval)) {
                throw_with_prefix("xhdfe plugin: ", "failed to read fweight");
            }
            fw[i] = z;
        }
    }

    hdfe::akm::LeaveOutSetOptions options;
    if (auto val = args.get_optional("num_threads")) {
        options.num_threads = parse_int(*val, "num_threads");
    }
    if (auto val = args.get_optional("use_gpu")) {
        options.use_gpu = parse_bool(*val, "use_gpu");
    }
    if (auto val = args.get_optional("verbose")) {
        options.verbose = parse_int(*val, "verbose");
        if (options.verbose > 0) options.progress = &akm_progress_to_stata;
    }

    const hdfe::akm::LeaveOutSetResult set = hdfe::akm::leave_out_connected_set(
        worker, firm, has_fweight ? &fw : nullptr, options);

    for (int i = 0; i < n; ++i) {
        const int row = obs.obs_no(i);
        SF_vstore(idx_keep, row,
                  set.keep[static_cast<std::size_t>(i)] != 0 ? 1.0 : 0.0);
    }
    akm_save_scalar("__xakm_n_obs", static_cast<double>(set.n_obs));
    akm_save_scalar("__xakm_n_obs_input", static_cast<double>(set.n_obs_input));
    akm_save_scalar("__xakm_n_obs_connected",
                    static_cast<double>(set.n_obs_connected));
    akm_save_scalar("__xakm_n_workers", static_cast<double>(set.n_workers));
    akm_save_scalar("__xakm_n_firms", static_cast<double>(set.n_firms));
    akm_save_scalar("__xakm_n_matches", static_cast<double>(set.n_matches));
    akm_save_scalar("__xakm_n_movers", static_cast<double>(set.n_movers));
    akm_save_scalar("__xakm_n_stayers", static_cast<double>(set.n_stayers));
    akm_save_scalar("__xakm_prune_iterations",
                    static_cast<double>(set.prune_iterations));
    akm_save_scalar("__xakm_threads_requested",
                    static_cast<double>(set.threads_requested));
    akm_save_scalar("__xakm_threads_effective",
                    static_cast<double>(set.threads_effective));
    akm_save_scalar("__xakm_threads_used", static_cast<double>(set.threads_used));
    akm_save_scalar("__xakm_workers_active",
                    static_cast<double>(set.parallel_workers_active));
    akm_save_scalar("__xakm_thread_capacity",
                    static_cast<double>(set.thread_capacity));
    akm_save_scalar("__xakm_openmp_enabled", set.openmp_enabled ? 1.0 : 0.0);
    akm_save_scalar("__xakm_thread_limit_code",
                    static_cast<double>(set.thread_limit_code));
    SF_macro_save(const_cast<char*>("_xakm_thread_limit_reason"),
                  const_cast<char*>(set.thread_limit_reason.c_str()));
    akm_save_scalar("__xakm_gpu_used", set.gpu_used ? 1.0 : 0.0);
    akm_save_scalar("__xakm_gpu_status_code",
                    static_cast<double>(set.gpu_status_code));
    return 0;
}

// Verbose progress sink for the companion tasks: route each core progress
// line to the Stata Results window and force it to become visible before the
// next (potentially long) numerical phase starts.  SF_display() alone may
// leave plugin output queued until `plugin call` returns, which turns useful
// progress into an end-of-command dump.  The SPI's output flush plus GUI poll
// are output-only and this callback is invoked exclusively on Stata's calling
// thread, outside OpenMP regions.
void akm_progress_to_stata(const char* line, void* /*user*/) {
    char buf[560];
    std::snprintf(buf, sizeof buf, "%s\n", line);
    SF_display(buf);
    (_stata_)->spoutflush();
    (void)(_stata_)->pollnow();
}

ST_retcode run_akm_kss(const ParsedArgs& args) {
    const int ncontrols = parse_int(args.get_required("ncontrols"), "ncontrols");
    const bool store_effects = parse_bool(args.get_required("store_effects"), "store_effects");
    bool has_fweight = false;
    if (auto val = args.get_optional("has_fweight")) {
        has_fweight = parse_bool(*val, "has_fweight");
    }

    // varlist: y worker firm [fweight] [controls...] [alpha psi] keep
    const int expected_vars =
        3 + (has_fweight ? 1 : 0) + ncontrols + (store_effects ? 2 : 0) + 1;
    if (SF_nvars() != expected_vars) {
        throw_with_prefix("xhdfe plugin: ",
                          "varlist has wrong length (have " + std::to_string(SF_nvars()) +
                              ", want " + std::to_string(expected_vars) + ")");
    }
    const int idx_y = 1;
    const int idx_worker = 2;
    const int idx_firm = 3;
    const int idx_fw = has_fweight ? 4 : -1;
    const int idx_x_start = has_fweight ? 5 : 4;
    const int idx_alpha = store_effects ? idx_x_start + ncontrols : -1;
    const int idx_psi = store_effects ? idx_alpha + 1 : -1;
    const int idx_keep = idx_x_start + ncontrols + (store_effects ? 2 : 0);

    const ObservationMap obs = selected_observations();
    const int n = obs.n;
    if (n <= 0) {
        return static_cast<ST_retcode>(2000);
    }

    const ST_double missval = SV_missval;
    auto read_numeric = [&](int var_idx, int obs_no) {
        ST_double z = 0.0;
        const ST_retcode rc = SF_vdata(var_idx, obs_no, &z);
        if (rc) {
            throw_with_prefix("xhdfe plugin: ",
                              "failed to read data (rc=" + std::to_string(rc) + ")");
        }
        if (!(z < missval)) {
            throw_with_prefix("xhdfe plugin: ",
                              "unexpected missing value; make sure the sample excludes missings");
        }
        return z;
    };
    auto read_id = [&](int var_idx, int obs_no, const char* label) {
        const double z = read_numeric(var_idx, obs_no);
        const double r = std::floor(z + 0.5);
        if (std::abs(z - r) > 1e-6 ||
            r < static_cast<double>(std::numeric_limits<int>::min()) ||
            r > static_cast<double>(std::numeric_limits<int>::max())) {
            throw_with_prefix("xhdfe plugin: ",
                              std::string(label) + " must contain int32-range integer ids");
        }
        return static_cast<int>(r);
    };

    Eigen::VectorXd y(n);
    Eigen::VectorXi worker(n);
    Eigen::VectorXi firm(n);
    Eigen::VectorXd fw;
    if (has_fweight) {
        fw.resize(n);
    }
    Eigen::MatrixXd X;
    if (ncontrols > 0) {
        X.resize(n, ncontrols);
    }
    for (int i = 0; i < n; ++i) {
        const int row = obs.obs_no(i);
        y[i] = read_numeric(idx_y, row);
        worker[i] = read_id(idx_worker, row, "worker");
        firm[i] = read_id(idx_firm, row, "firm");
        if (has_fweight) {
            fw[i] = read_numeric(idx_fw, row);
        }
        for (int j = 0; j < ncontrols; ++j) {
            X(i, j) = read_numeric(idx_x_start + j, row);
        }
    }

    hdfe::akm::AkmOptions options;
    if (auto val = args.get_optional("sigma_centering")) {
        options.sigma_centering = hdfe::akm::parse_sigma_centering(*val);
    }
    if (auto val = args.get_optional("leave_out_level")) {
        options.leave_out_level = parse_akm_leave_out_level(*val);
    }
    if (auto val = args.get_optional("leverages")) {
        options.leverage_method = parse_akm_leverage_method(*val);
    }
    if (auto val = args.get_optional("jla_draws")) {
        options.jla_draws = parse_int(*val, "jla_draws");
    }
    if (auto val = args.get_optional("seed")) {
        options.seed = static_cast<std::uint64_t>(parse_double(*val, "seed"));
    }
    if (auto val = args.get_optional("prune")) {
        options.prune = parse_bool(*val, "prune");
    }
    if (auto val = args.get_optional("exact_max_rows")) {
        options.exact_max_rows = parse_int(*val, "exact_max_rows");
    }
    if (auto val = args.get_optional("direct_max_firms")) {
        options.direct_max_firms = parse_int(*val, "direct_max_firms");
    }
    if (auto val = args.get_optional("direct_max_nnz")) {
        options.direct_max_nnz = static_cast<long long>(parse_double(*val, "direct_max_nnz"));
    }
    if (auto val = args.get_optional("cg_tol")) {
        options.cg_tol = parse_double(*val, "cg_tol");
    }
    if (auto val = args.get_optional("cg_max_iter")) {
        options.cg_max_iter = parse_int(*val, "cg_max_iter");
    }
    if (auto val = args.get_optional("num_threads")) {
        options.num_threads = parse_int(*val, "num_threads");
    }
    if (auto val = args.get_optional("fwl_tol")) {
        options.fwl_tol = parse_double(*val, "fwl_tol");
    }
    if (auto val = args.get_optional("fwl_max_iter")) {
        options.fwl_max_iter = parse_int(*val, "fwl_max_iter");
    }
    if (auto val = args.get_optional("compute_se")) {
        options.compute_se = parse_bool(*val, "compute_se");
    }
    if (auto val = args.get_optional("se_nsim")) {
        options.se_nsim = parse_int(*val, "se_nsim");
    }
    if (auto val = args.get_optional("verbose")) {
        options.verbose = parse_bool(*val, "verbose") ? 1 : 0;
        if (options.verbose) {
            options.progress = &akm_progress_to_stata;
        }
    }
    if (auto val = args.get_optional("eigen_diagnostics")) {
        options.eigen_diagnostics = parse_bool(*val, "eigen_diagnostics");
        if (options.eigen_diagnostics) {
            options.compute_se = true;
        }
    }
    if (auto val = args.get_optional("eig_trace_nsim")) {
        options.eig_trace_nsim = parse_int(*val, "eig_trace_nsim");
    }
    if (auto val = args.get_optional("se_sigma_lowess")) {
        options.se_sigma_lowess = parse_bool(*val, "se_sigma_lowess");
    }
    if (auto val = args.get_optional("use_gpu")) {
        options.use_gpu = parse_bool(*val, "use_gpu");
    }

    const hdfe::akm::AkmKssResult res = hdfe::akm::akm_kss_decompose(
        y, worker, firm, ncontrols > 0 ? &X : nullptr, options, nullptr,
        has_fweight ? &fw : nullptr);

    // Scalars under fixed hidden names; the ado copies them into r().
    akm_save_scalar("__xakm_plugin_var_alpha", res.plugin.var_alpha);
    akm_save_scalar("__xakm_plugin_var_psi", res.plugin.var_psi);
    akm_save_scalar("__xakm_plugin_cov", res.plugin.cov_alpha_psi);
    akm_save_scalar("__xakm_agsu_var_alpha", res.agsu.var_alpha);
    akm_save_scalar("__xakm_agsu_var_psi", res.agsu.var_psi);
    akm_save_scalar("__xakm_agsu_cov", res.agsu.cov_alpha_psi);
    akm_save_scalar("__xakm_kss_var_alpha", res.kss.var_alpha);
    akm_save_scalar("__xakm_kss_var_psi", res.kss.var_psi);
    akm_save_scalar("__xakm_kss_cov", res.kss.cov_alpha_psi);
    akm_save_scalar("__xakm_var_y", res.var_y);
    akm_save_scalar("__xakm_sigma2_ho", res.sigma2_ho);
    akm_save_scalar("__xakm_n_obs", static_cast<double>(res.sample.n_obs));
    akm_save_scalar("__xakm_n_obs_input", static_cast<double>(res.sample.n_obs_input));
    akm_save_scalar("__xakm_n_obs_connected",
                    static_cast<double>(res.sample.n_obs_connected));
    akm_save_scalar("__xakm_n_workers", static_cast<double>(res.sample.n_workers));
    akm_save_scalar("__xakm_n_firms", static_cast<double>(res.sample.n_firms));
    akm_save_scalar("__xakm_n_matches", static_cast<double>(res.sample.n_matches));
    akm_save_scalar("__xakm_n_movers", static_cast<double>(res.sample.n_movers));
    akm_save_scalar("__xakm_n_stayers", static_cast<double>(res.sample.n_stayers));
    akm_save_scalar("__xakm_n_rows", static_cast<double>(res.n_rows));
    akm_save_scalar("__xakm_max_pii", res.max_pii);
    akm_save_scalar("__xakm_mean_pii", res.mean_pii);
    akm_save_scalar("__xakm_leverages_exact", res.leverages_exact ? 1.0 : 0.0);
    akm_save_scalar("__xakm_solver_direct", res.solver_direct ? 1.0 : 0.0);
    akm_save_scalar("__xakm_threads_requested",
                    static_cast<double>(res.threads_requested));
    akm_save_scalar("__xakm_threads_effective",
                    static_cast<double>(res.threads_effective));
    akm_save_scalar("__xakm_solver_threads_effective",
                    static_cast<double>(res.solver_threads_effective));
    akm_save_scalar("__xakm_fwl_threads_effective",
                    static_cast<double>(res.fwl_threads_effective));
    akm_save_scalar("__xakm_fwl_threads_used", static_cast<double>(res.fwl_threads_used));
    akm_save_scalar("__xakm_fwl_workers_active",
                    static_cast<double>(res.fwl_parallel_workers_active));
    akm_save_scalar("__xakm_solver_threads_used",
                    static_cast<double>(res.solver_threads_used));
    akm_save_scalar("__xakm_solver_workers_active",
                    static_cast<double>(res.solver_parallel_workers_active));
    akm_save_scalar("__xakm_threads_used", static_cast<double>(res.threads_used));
    akm_save_scalar("__xakm_workers_active",
                    static_cast<double>(res.parallel_workers_active));
    akm_save_scalar("__xakm_thread_capacity",
                    static_cast<double>(res.thread_capacity));
    akm_save_scalar("__xakm_openmp_enabled", res.openmp_enabled ? 1.0 : 0.0);
    akm_save_scalar("__xakm_thread_limit_code",
                    static_cast<double>(res.thread_limit_code));
    SF_macro_save(const_cast<char*>("_xakm_thread_limit_reason"),
                  const_cast<char*>(res.thread_limit_reason.c_str()));
    akm_save_scalar("__xakm_samp_threads_req",
                    static_cast<double>(res.sample.threads_requested));
    akm_save_scalar("__xakm_samp_threads_eff",
                    static_cast<double>(res.sample.threads_effective));
    akm_save_scalar("__xakm_samp_threads_used",
                    static_cast<double>(res.sample.threads_used));
    akm_save_scalar("__xakm_samp_workers_active",
                    static_cast<double>(res.sample.parallel_workers_active));
    akm_save_scalar("__xakm_samp_thread_capacity",
                    static_cast<double>(res.sample.thread_capacity));
    akm_save_scalar("__xakm_samp_openmp_enabled",
                    res.sample.openmp_enabled ? 1.0 : 0.0);
    akm_save_scalar("__xakm_samp_thread_limit_code",
                    static_cast<double>(res.sample.thread_limit_code));
    SF_macro_save(const_cast<char*>("_xakm_samp_limit_reason"),
                  const_cast<char*>(res.sample.thread_limit_reason.c_str()));
    akm_save_scalar("__xakm_jla_draws", static_cast<double>(res.jla_draws_used));
    akm_save_scalar("__xakm_seed", static_cast<double>(res.seed_used));
    akm_save_scalar("__xakm_solver_iterations", static_cast<double>(res.solver_iterations));
    akm_save_scalar("__xakm_converged", res.converged ? 1.0 : 0.0);
    akm_save_scalar("__xakm_gpu_requested", res.gpu_requested ? 1.0 : 0.0);
    akm_save_scalar("__xakm_gpu_used", res.gpu_used ? 1.0 : 0.0);
    akm_save_scalar("__xakm_gpu_status_code",
                    static_cast<double>(res.gpu_status_code));
    SF_macro_save(const_cast<char*>("_xakm_gpu_backend"),
                  const_cast<char*>(res.gpu_backend.c_str()));
    SF_macro_save(const_cast<char*>("_xakm_gpu_status"),
                  const_cast<char*>(res.gpu_status.c_str()));
    akm_save_scalar("__xakm_fwl_gpu_attempted",
                    res.fwl_gpu_attempted ? 1.0 : 0.0);
    akm_save_scalar("__xakm_fwl_gpu_used", res.fwl_gpu_used ? 1.0 : 0.0);
    akm_save_scalar("__xakm_fwl_gpu_fallback",
                    res.fwl_gpu_fallback ? 1.0 : 0.0);
    akm_save_scalar("__xakm_fwl_gpu_status_code",
                    static_cast<double>(res.fwl_gpu_status_code));
    SF_macro_save(const_cast<char*>("_xakm_fwl_gpu_status"),
                  const_cast<char*>(res.fwl_gpu_status.c_str()));
    akm_save_scalar("__xakm_fwl_iterations",
                    static_cast<double>(res.fwl_iterations));
    akm_save_scalar("__xakm_fwl_abs_residual_rel",
                    res.fwl_abs_residual_rel);
    akm_save_scalar("__xakm_fwl_precision_certified",
                    res.fwl_precision_certified ? 1.0 : 0.0);
    if (options.compute_se) {
        akm_save_scalar("__xakm_se_var_psi", res.se_var_psi);
        akm_save_scalar("__xakm_se_cov", res.se_cov_alpha_psi);
        akm_save_scalar("__xakm_se_var_alpha", res.se_var_alpha);
        akm_save_scalar("__xakm_theta_var_psi", res.theta_c_var_psi);
        akm_save_scalar("__xakm_theta_cov", res.theta_c_cov_alpha_psi);
        akm_save_scalar("__xakm_theta_var_alpha", res.theta_c_var_alpha);
    }
    if (options.eigen_diagnostics) {
        static const char* comp_tag[3] = {"psi", "cov", "alpha"};
        char nm[48];
        for (int c = 0; c < 3; ++c) {
            std::snprintf(nm, sizeof(nm), "__xakm_lambda1_%s", comp_tag[c]);
            akm_save_scalar(nm, res.eig_lambda1[c]);
            std::snprintf(nm, sizeof(nm), "__xakm_eigshare1_%s", comp_tag[c]);
            akm_save_scalar(nm, res.eig_share1[c]);
            std::snprintf(nm, sizeof(nm), "__xakm_lindeberg_%s", comp_tag[c]);
            akm_save_scalar(nm, res.lindeberg_max_x1bar_sq[c]);
            std::snprintf(nm, sizeof(nm), "__xakm_gammasq_%s", comp_tag[c]);
            akm_save_scalar(nm, res.gamma_sq[c]);
            std::snprintf(nm, sizeof(nm), "__xakm_fstat_%s", comp_tag[c]);
            akm_save_scalar(nm, res.f_stat[c]);
            std::snprintf(nm, sizeof(nm), "__xakm_theta1_%s", comp_tag[c]);
            akm_save_scalar(nm, res.theta_1[c]);
            std::snprintf(nm, sizeof(nm), "__xakm_ci_lb_%s", comp_tag[c]);
            akm_save_scalar(nm, res.ci_lb[c]);
            std::snprintf(nm, sizeof(nm), "__xakm_ci_ub_%s", comp_tag[c]);
            akm_save_scalar(nm, res.ci_ub[c]);
            std::snprintf(nm, sizeof(nm), "__xakm_curvature_%s", comp_tag[c]);
            akm_save_scalar(nm, res.curvature[c]);
        }
    }
    SF_macro_save(const_cast<char*>("_xakm_inference_method"),
                  const_cast<char*>(res.projection_inference ? "worker_projection" : "legacy"));
    if (res.projection_inference) {
        const auto& p = *res.projection_inference;
        akm_save_scalar("__xakm_proj_dimension",p.dimension);
        akm_save_scalar("__xakm_proj_rank",p.rank_diagnostic);
        akm_save_scalar("__xakm_proj_clusters",p.clusters);
        akm_save_scalar("__xakm_proj_max_cluster",p.max_cluster_rows);
        akm_save_scalar("__xakm_proj_controls",p.control_rank);
        akm_save_scalar("__xakm_proj_degree",p.polynomial_degree);
        akm_save_scalar("__xakm_proj_critical",p.critical_value);
        akm_save_scalar("__xakm_proj_factor",p.projection_factor);
        akm_save_scalar("__xakm_proj_max_trace",p.max_cluster_leverage_trace);
        akm_save_scalar("__xakm_proj_max_leverage",p.max_row_leverage);
        akm_save_scalar("__xakm_proj_cov_condition",p.covariance_condition);
        akm_save_scalar("__xakm_proj_solver_gap",p.max_trust_region_gap);
        akm_save_scalar("__xakm_proj_bread_reused",p.control_bread_reused ? 1. : 0.);
        akm_save_scalar("__xakm_proj_threads_used",p.threads_used);
        akm_save_scalar("__xakm_proj_workers_active",p.parallel_workers_active);
        const char* names[2] = {"psi","cov"};
        char name[48];
        for (int c = 0; c < 2; ++c) {
            std::snprintf(name,sizeof(name),"__xakm_proj_nonlinear_%s",names[c]);
            akm_save_scalar(name,p.linearisation_index[c]);
            std::snprintf(name,sizeof(name),"__xakm_proj_correction_%s",names[c]);
            akm_save_scalar(name,p.correction_over_se[c]);
            std::snprintf(name,sizeof(name),"__xakm_proj_zero_gradient_%s",names[c]);
            akm_save_scalar(name,hdfe::detail::ieee_finite(p.linearisation_index[c]) ? 0. : 1.);
        }
    }
    if (!res.notes.empty()) {
        SF_macro_save(const_cast<char*>("_xakm_notes"), const_cast<char*>(res.notes.c_str()));
    }
    SF_macro_save(const_cast<char*>("_xakm_sigma_centering"),
                  const_cast<char*>(hdfe::akm::sigma_centering_name(options.sigma_centering)));

    // Control coefficients into the caller-supplied matrix (1 x k).
    if (ncontrols > 0) {
        if (auto bname = args.get_optional("b")) {
            for (int j = 0; j < res.beta.size(); ++j) {
                SF_mat_store(const_cast<char*>(bname->c_str()), 1, j + 1, res.beta[j]);
            }
        }
    }

    // keep flag over the sample rows; alpha/psi on kept rows, missing elsewhere.
    std::size_t kept_cursor = 0;
    for (int i = 0; i < n; ++i) {
        const int row = obs.obs_no(i);
        const bool kept = res.sample.keep[static_cast<std::size_t>(i)] != 0;
        SF_vstore(idx_keep, row, kept ? 1.0 : 0.0);
        if (store_effects) {
            if (kept && kept_cursor < static_cast<std::size_t>(res.alpha.size()) &&
                kept_cursor < static_cast<std::size_t>(res.psi.size())) {
                SF_vstore(idx_alpha, row, stata_value_or_missing(res.alpha[static_cast<Eigen::Index>(kept_cursor)]));
                SF_vstore(idx_psi, row, stata_value_or_missing(res.psi[static_cast<Eigen::Index>(kept_cursor)]));
            } else {
                SF_vstore(idx_alpha, row, missval);
                SF_vstore(idx_psi, row, missval);
            }
        }
        if (kept) {
            ++kept_cursor;
        }
    }
    return 0;
}


ST_retcode run_gelbach(const ParsedArgs& args) {
    const int p = parse_int(args.get_required("p"), "p");
    const int q = parse_int(args.get_required("q"), "q");
    const int nfe = parse_int(args.get_required("nfe"), "nfe");
    const int ncommonfe = args.has("ncommonfe")
        ? parse_int(args.get_required("ncommonfe"), "ncommonfe")
        : 0;
    if (ncommonfe < 0 || nfe < 0) {
        throw_with_prefix(
            "xhdfe plugin: ", "ncommonfe and nfe must be nonnegative");
    }
    const int nfe_union = ncommonfe + nfe;
    const bool has_cluster = parse_bool(args.get_required("has_cluster"), "has_cluster");
    const bool has_weight = parse_bool(args.get_required("has_weight"), "has_weight");
    const bool has_sample_output =
        args.has("has_sample_output")
            ? parse_bool(args.get_required("has_sample_output"),
                         "has_sample_output")
            : false;
    const bool freq_weights = has_weight &&
        to_lower(args.get_required("weight_type")).rfind("fw", 0) == 0;

    std::vector<int> sizes;
    {
        const std::string raw = args.get_required("group_sizes");
        std::string buf;
        for (char c : raw) {
            if (c == ',') { if (!buf.empty()) sizes.push_back(std::stoi(buf)); buf.clear(); }
            else buf.push_back(c);
        }
        if (!buf.empty()) sizes.push_back(std::stoi(buf));
    }

    const int input_vars =
        1 + p + q + nfe_union + (has_cluster ? 1 : 0) +
        (has_weight ? 1 : 0);
    const int expected_vars = input_vars + (has_sample_output ? 1 : 0);
    const int sample_output_var =
        has_sample_output ? input_vars + 1 : -1;
    if (SF_nvars() != expected_vars) {
        throw_with_prefix("xhdfe plugin: ",
                          "varlist has wrong length (have " + std::to_string(SF_nvars()) +
                              ", want " + std::to_string(expected_vars) + ")");
    }
    const ObservationMap obs = selected_observations();
    const int n = obs.n;
    if (n <= 0) return static_cast<ST_retcode>(2000);

    const ST_double missval = SV_missval;
    auto read_numeric = [&](int var_idx, int obs_no) {
        ST_double z = 0.0;
        if (SF_vdata(var_idx, obs_no, &z)) {
            throw_with_prefix("xhdfe plugin: ", "failed to read data");
        }
        if (!(z < missval)) {
            throw_with_prefix("xhdfe plugin: ", "unexpected missing value");
        }
        return z;
    };
    auto read_id = [&](int var_idx, int obs_no) {
        const double z = read_numeric(var_idx, obs_no);
        const double r = std::floor(z + 0.5);
        if (z != r) {
            throw_with_prefix("xhdfe plugin: ", "ids must be integers");
        }
        if (r < static_cast<double>(std::numeric_limits<std::int32_t>::min()) ||
            r > static_cast<double>(std::numeric_limits<std::int32_t>::max())) {
            throw_with_prefix("xhdfe plugin: ", "ids must fit in int32");
        }
        return static_cast<int>(r);
    };

    Eigen::VectorXd y(n);
    Eigen::MatrixXd X1(n, p);
    Eigen::MatrixXd X2(n, q);
    std::vector<Eigen::VectorXi> fes(
        static_cast<std::size_t>(nfe_union));
    for (auto& f : fes) f.resize(n);
    Eigen::VectorXi cl;
    if (has_cluster) cl.resize(n);
    Eigen::VectorXd wvec;
    if (has_weight) wvec.resize(n);
    for (int i = 0; i < n; ++i) {
        const int row = obs.obs_no(i);
        y[i] = read_numeric(1, row);
        for (int c = 0; c < p; ++c) X1(i, c) = read_numeric(2 + c, row);
        for (int c = 0; c < q; ++c) X2(i, c) = read_numeric(2 + p + c, row);
        for (int d = 0; d < nfe_union; ++d) {
            fes[static_cast<std::size_t>(d)][i] =
                read_id(2 + p + q + d, row);
        }
        if (has_cluster) {
            cl[i] = read_id(2 + p + q + nfe_union, row);
        }
        if (has_weight) {
            wvec[i] = read_numeric(
                2 + p + q + nfe_union + (has_cluster ? 1 : 0), row);
        }
    }

    hdfe::gelbach::GelbachOptions options;
    {
        const std::string v = to_lower(args.get_required("vce"));
        if (v == "unadjusted") options.vce = hdfe::gelbach::GelbachVce::Unadjusted;
        else if (v == "robust") options.vce = hdfe::gelbach::GelbachVce::Robust;
        else if (v == "cluster") options.vce = hdfe::gelbach::GelbachVce::Cluster;
        else throw_with_prefix("xhdfe plugin: ", "unknown vce: " + v);
    }
    options.gamma0 = parse_bool(args.get_required("gamma0"), "gamma0");
    options.cov0 = parse_bool(args.get_required("cov0"), "cov0");
    if (auto val = args.get_optional("absorbed_x1")) {
        std::string buf;
        for (const char c : *val) {
            if (c == ',') {
                if (!buf.empty()) {
                    options.absorbed_x1.push_back(std::stoi(buf));
                    buf.clear();
                }
            } else {
                buf.push_back(c);
            }
        }
        if (!buf.empty()) options.absorbed_x1.push_back(std::stoi(buf));
    }
    if (auto val = args.get_optional("connectivity_fe_pair")) {
        std::string buf;
        for (const char c : *val) {
            if (c == ',') {
                if (!buf.empty()) {
                    options.connectivity_fe_pair.push_back(std::stoi(buf));
                    buf.clear();
                }
            } else {
                buf.push_back(c);
            }
        }
        if (!buf.empty()) {
            options.connectivity_fe_pair.push_back(std::stoi(buf));
        }
    }
    if (auto val = args.get_optional("require_connected")) {
        options.require_connected_fe_split =
            parse_bool(*val, "require_connected");
    }
    options.tol = parse_double(args.get_required("tol"), "tol");
    if (auto val = args.get_optional("num_threads")) {
        options.num_threads = parse_int(*val, "num_threads");
    }
    bool use_gpu = false;
    if (auto val = args.get_optional("use_gpu")) {
        use_gpu = parse_bool(*val, "use_gpu");
    }
    options.use_gpu = use_gpu;
    if (auto val = args.get_optional("weighted_cpu_route")) {
        options.weighted_cpu_route = parse_bool(*val, "weighted_cpu_route");
    }
    if (auto val = args.get_optional("capture_sample_provenance")) {
        options.capture_sample_provenance =
            parse_bool(*val, "capture_sample_provenance");
    }
    options.return_sample_index = has_sample_output;
    if (auto val = args.get_optional("verbose")) {
        options.verbose = parse_int(*val, "verbose");
        if (options.verbose > 0) options.progress = &akm_progress_to_stata;
    }

    const hdfe::gelbach::GelbachResult res = hdfe::gelbach::decompose(
        y, X1, X2, sizes, fes, ncommonfe,
        has_cluster ? &cl : nullptr, options,
        has_weight ? &wvec : nullptr, freq_weights);

    if (has_sample_output) {
        if (res.sample_index.size() != res.n_obs) {
            throw_with_prefix(
                "xhdfe plugin: ",
                "Gelbach retained-sample index has the wrong length");
        }
        for (Eigen::Index i = 0; i < res.sample_index.size(); ++i) {
            const int input_row = res.sample_index[i];
            if (input_row < 0 || input_row >= n) {
                throw_with_prefix(
                    "xhdfe plugin: ",
                    "Gelbach retained-sample index is out of range");
            }
            if (SF_vstore(sample_output_var, obs.obs_no(input_row), 1.0)) {
                throw_with_prefix(
                    "xhdfe plugin: ",
                    "failed to write Gelbach retained-sample indicator");
            }
        }
    }

    const int G = static_cast<int>(res.delta.cols());
    const int k1 = p + 1;
    const std::string dmat = args.get_required("dmat");
    const std::string semat = args.get_required("semat");
    const std::string totmat = args.get_required("totmat");
    const std::string bbasemat = args.get_required("bbasemat");
    const std::string bfullmat = args.get_required("bfullmat");
    const std::string absmat = args.get_required("absmat");
    const std::string covmat = args.get_required("covmat");
    const std::string totcovmat = args.get_required("totcovmat");
    const std::string feratiomat = args.get_required("feratiomat");
    const std::string nearmaskmat = args.get_required("nearmaskmat");
    const std::string basecovmat = args.get_required("basecovmat");
    const std::string covdbmat = args.get_required("covdbmat");
    const std::string covtbmat = args.get_required("covtbmat");
    for (int g = 0; g < G; ++g) {
        for (int r = 0; r < k1; ++r) {
            const double delta_value =
                stata_value_or_missing(res.delta(r, g));
            SF_mat_store(
                const_cast<char*>(dmat.c_str()), r + 1, g + 1,
                delta_value);
            const double variance = res.cov(g * k1 + r, g * k1 + r);
            SF_mat_store(const_cast<char*>(semat.c_str()), r + 1, g + 1,
                         stata_value_or_missing(std::sqrt(variance)));
        }
    }
    for (int r = 0; r < k1; ++r) {
        SF_mat_store(
            const_cast<char*>(totmat.c_str()), r + 1, 1,
            stata_value_or_missing(res.total[r]));
        const double variance = res.total_cov(r, r);
        SF_mat_store(const_cast<char*>(totmat.c_str()), r + 1, 2,
                     stata_value_or_missing(std::sqrt(variance)));
    }
    for (int c = 0; c < p; ++c) {
        SF_mat_store(const_cast<char*>(bbasemat.c_str()), 1, c + 1, res.b_base[c]);
        SF_mat_store(const_cast<char*>(bfullmat.c_str()), 1, c + 1, res.b_full[c]);
        SF_mat_store(const_cast<char*>(absmat.c_str()), 1, c + 1,
                     static_cast<double>(res.x1_absorbed[c]));
    }
    for (int r = 0; r < G * k1; ++r) {
        for (int c = 0; c < G * k1; ++c) {
            SF_mat_store(const_cast<char*>(covmat.c_str()), r + 1, c + 1,
                         stata_value_or_missing(res.cov(r, c)));
        }
    }
    for (int r = 0; r < k1; ++r) {
        for (int c = 0; c < k1; ++c) {
            SF_mat_store(const_cast<char*>(totcovmat.c_str()), r + 1, c + 1,
                         stata_value_or_missing(res.total_cov(r, c)));
        }
    }
    store_row_vector(feratiomat, res.x1_fe_collinear_ratio);
    {
        Eigen::MatrixXd near_mask(1, res.x1_near_collinear_mask.size());
        near_mask.row(0) =
            res.x1_near_collinear_mask.cast<double>().transpose();
        store_matrix(nearmaskmat, near_mask);
    }
    store_matrix(basecovmat, res.base_cov);
    store_matrix(covdbmat, res.cov_delta_bbase);
    store_matrix(covtbmat, res.cov_total_bbase);
    if (auto gammamat = args.get_optional("gammamat")) {
        store_matrix(*gammamat, res.gamma);
    }
    if (auto beta2mat = args.get_optional("beta2mat")) {
        store_row_vector(*beta2mat, res.beta2);
    }
    if (auto beta2covmat = args.get_optional("beta2covmat")) {
        store_matrix(*beta2covmat, res.beta2_cov);
    }
    if (auto auxloadmat = args.get_optional("auxloadmat")) {
        store_matrix(*auxloadmat, res.auxiliary_loadings);
    }
    if (auto loaddiagmat = args.get_optional("loaddiagmat")) {
        Eigen::MatrixXd diag(res.auxiliary_loading_ss_ratio.size(), 3);
        for (Eigen::Index g = 0;
             g < res.auxiliary_loading_ss_ratio.size(); ++g) {
            diag(g, 0) = res.auxiliary_loading_ss_ratio[g];
            diag(g, 1) =
                static_cast<double>(res.auxiliary_loading_rank[g]);
            diag(g, 2) =
                res.auxiliary_loading_condition_number[g];
        }
        store_matrix(*loaddiagmat, diag);
    }
    if (auto loadzmat = args.get_optional("loadzmat")) {
        store_matrix(*loadzmat, res.auxiliary_loading_max_abs_z);
    }
    if (auto loadpmat = args.get_optional("loadpmat")) {
        store_matrix(*loadpmat, res.auxiliary_loading_pvalue);
    }
    if (auto loadevalmat = args.get_optional("loadevalmat")) {
        store_matrix(
            *loadevalmat,
            res.auxiliary_loading_test_evaluated.cast<double>());
    }
    if (auto beta2waldmat = args.get_optional("beta2waldmat")) {
        Eigen::MatrixXd wald(res.beta2_wald_stat.size(), 3);
        for (Eigen::Index g = 0; g < res.beta2_wald_stat.size(); ++g) {
            wald(g, 0) = res.beta2_wald_stat[g];
            wald(g, 1) = static_cast<double>(res.beta2_wald_df[g]);
            wald(g, 2) = res.beta2_wald_pvalue[g];
        }
        store_matrix(*beta2waldmat, wald);
    }
    if (auto gradnormmat = args.get_optional("gradnormmat")) {
        store_matrix(*gradnormmat, res.contribution_gradient_norm);
    }
    if (auto regvalidmat = args.get_optional("regvalidmat")) {
        store_matrix(*regvalidmat,
                     res.regular_inference_valid.cast<double>());
    }
    if (auto regstatusmat = args.get_optional("regstatusmat")) {
        Eigen::MatrixXd status =
            Eigen::MatrixXd::Constant(k1, sizes.size(), -1.0);
        std::string status_words;
        for (std::size_t i = 0; i < res.regular_inference_status.size(); ++i) {
            const std::string& value = res.regular_inference_status[i];
            double code = -1.0;
            if (value == "not_applicable_common_fe_intercept") code = -2.0;
            else if (value == "nonregular_not_ruled_out") code = 0.0;
            else if (value == "regular_beta_nonzero") code = 1.0;
            else if (value == "regular_loading_nonzero") code = 2.0;
            const int g = static_cast<int>(i) / k1;
            const int r = static_cast<int>(i) % k1;
            status(r, g) = code;
            if (!status_words.empty()) status_words.push_back(' ');
            status_words += value;
        }
        store_matrix(*regstatusmat, status);
        SF_macro_save(
            const_cast<char*>("_xgel_regular_inference_status"),
            const_cast<char*>(status_words.c_str()));
    }
    akm_save_scalar("__xgel_identity_gap", res.identity_gap);
    akm_save_scalar("__xgel_n_common_fes",
                    static_cast<double>(res.n_common_fes));
    akm_save_scalar("__xgel_common_fes_applied",
                    res.common_fes_applied ? 1.0 : 0.0);
    akm_save_scalar("__xgel_intercept_inf",
                    res.intercept_inference_available ? 1.0 : 0.0);
    akm_save_scalar("__xgel_n_obs_input", static_cast<double>(res.n_obs_input));
    akm_save_scalar("__xgel_n_obs", static_cast<double>(res.n_obs));
    akm_save_scalar("__xgel_n_obs_eff",
                    static_cast<double>(res.n_obs_effective));
    akm_save_scalar("__xgel_n_singletons_dropped",
                    static_cast<double>(res.n_singletons_dropped));
    akm_save_scalar("__xgel_n_mobility_components",
                    static_cast<double>(res.n_mobility_components));
    akm_save_scalar("__xgel_largest_mob_n",
                    static_cast<double>(
                        res.largest_mobility_component_n_obs));
    akm_save_scalar("__xgel_largest_mob_share",
                    res.largest_mobility_component_share);
    akm_save_scalar("__xgel_largest_mob_wshare",
                    res.largest_mobility_component_weight_share);
    akm_save_scalar("__xgel_fe_split_identified",
                    res.fe_split_identified ? 1.0 : 0.0);
    akm_save_scalar("__xgel_connectivity_fe1",
                    static_cast<double>(res.connectivity_fe_index1));
    akm_save_scalar("__xgel_connectivity_fe2",
                    static_cast<double>(res.connectivity_fe_index2));
    akm_save_scalar("__xgel_connectivity_explicit",
                    res.connectivity_pair_explicit ? 1.0 : 0.0);
    akm_save_scalar("__xgel_df_full", res.df_full);
    akm_save_scalar("__xgel_df_base", res.df_base);
    akm_save_scalar("__xgel_n_clusters",
                    static_cast<double>(res.n_clusters));
    akm_save_scalar("__xgel_feclass_tol", res.fe_collinear_ss_ratio_tol);
    akm_save_scalar("__xgel_near_fe_warn_upper",
                    res.near_fe_collinear_ss_ratio_warn_upper);
    akm_save_scalar("__xgel_fewG_threshold",
                    static_cast<double>(res.few_cluster_warning_threshold));
    akm_save_scalar("__xgel_abs_inf_valid",
                    res.absorbed_target_inference_valid ? 1.0 : 0.0);
    akm_save_scalar("__xgel_abs_fe_index",
                    static_cast<double>(res.absorbing_fe_index));
    akm_save_scalar("__xgel_regular_all_valid",
                    res.regular_inference_all_valid ? 1.0 : 0.0);
    akm_save_scalar("__xgel_regularity_alpha",
                    res.regularity_test_alpha);
    akm_save_scalar("__xgel_converged", res.converged ? 1.0 : 0.0);
    akm_save_scalar("__xgel_threads_requested",
                    static_cast<double>(res.threads_requested));
    akm_save_scalar("__xgel_threads_effective",
                    static_cast<double>(res.threads_effective));
    akm_save_scalar("__xgel_recovery_thr_eff",
                    static_cast<double>(res.recovery_threads_effective));
    akm_save_scalar("__xgel_fullfit_threads_used",
                    static_cast<double>(res.fullfit_threads_used));
    akm_save_scalar("__xgel_fullfit_workers_active",
                    static_cast<double>(
                        res.fullfit_parallel_workers_active));
    akm_save_scalar("__xgel_recovery_threads_used",
                    static_cast<double>(res.recovery_threads_used));
    akm_save_scalar("__xgel_recovery_workers_active",
                    static_cast<double>(
                        res.recovery_parallel_workers_active));
    akm_save_scalar("__xgel_cov_threads_used",
                    static_cast<double>(res.covariance_threads_used));
    akm_save_scalar("__xgel_cov_workers_active",
                    static_cast<double>(
                        res.covariance_parallel_workers_active));
    akm_save_scalar("__xgel_threads_used", static_cast<double>(res.threads_used));
    akm_save_scalar("__xgel_workers_active",
                    static_cast<double>(res.parallel_workers_active));
    akm_save_scalar("__xgel_thread_capacity",
                    static_cast<double>(res.thread_capacity));
    akm_save_scalar("__xgel_openmp_enabled",
                    res.openmp_enabled ? 1.0 : 0.0);
    akm_save_scalar("__xgel_thread_limit_code",
                    static_cast<double>(res.thread_limit_code));
    SF_macro_save(const_cast<char*>("_xgel_thread_limit_reason"),
                  const_cast<char*>(res.thread_limit_reason.c_str()));
    akm_save_scalar("__xgel_gpu_requested",
                    res.gpu_requested ? 1.0 : 0.0);
    akm_save_scalar("__xgel_gpu_used", res.gpu_used ? 1.0 : 0.0);
    akm_save_scalar("__xgel_gpu_status_code",
                    static_cast<double>(res.gpu_status_code));
    akm_save_scalar("__xgel_gpu_attempted", res.gpu_attempted ? 1.0 : 0.0);
    akm_save_scalar("__xgel_gpu_absorption_converged",
                    res.gpu_absorption_converged ? 1.0 : 0.0);
    akm_save_scalar("__xgel_gpu_absorption_iterations",
                    static_cast<double>(res.gpu_absorption_iterations));
    akm_save_scalar("__xgel_cuda_tail_code",
                    static_cast<double>(res.cuda_tail_code));
    SF_macro_save(const_cast<char*>("_xgel_fe_split_status"),
                  const_cast<char*>(res.fe_split_status.c_str()));
    SF_macro_save(const_cast<char*>("_xgel_connectivity_pair_status"),
                  const_cast<char*>(
                      res.connectivity_pair_status.c_str()));
    SF_macro_save(const_cast<char*>("_xgel_connected_mode"),
                  const_cast<char*>(res.connected_mode.c_str()));
    SF_macro_save(const_cast<char*>("_xgel_mobility_component_scope"),
                  const_cast<char*>(
                      res.mobility_component_scope.c_str()));
    SF_macro_save(const_cast<char*>("_xgel_intercept_status"),
                  const_cast<char*>(res.intercept_status.c_str()));
    if (!res.sample_hash.empty()) {
        SF_macro_save(
            const_cast<char*>("_xgel_sample_hash"),
            const_cast<char*>(res.sample_hash.c_str()));
        SF_macro_save(
            const_cast<char*>("_xgel_sample_hash_algorithm"),
            const_cast<char*>(
                res.sample_hash_algorithm.c_str()));
        SF_macro_save(
            const_cast<char*>("_xgel_sample_index_scope"),
            const_cast<char*>(res.sample_index_scope.c_str()));
    }
    if (!res.notes.empty()) {
        SF_macro_save(const_cast<char*>("_xgel_notes"), const_cast<char*>(res.notes.c_str()));
    }
    return 0;
}

STDLL stata_call(int argc, char* argv[]) {
    const auto plugin_total_t0 = std::chrono::steady_clock::now();
    try {
        ParsedArgs args(argc, argv);

        if (auto task = args.get_optional("task")) {
            if (*task == "buildinfo") {
                return xhdfe_stata::save_buildinfo("xhdfe");
            }
            if (*task == "akm_kss") {
                return run_akm_kss(args);
            }
            if (*task == "akm_leave_out_set") {
                return run_akm_leave_out_set(args);
            }
            if (*task == "gelbach") {
                return run_gelbach(args);
            }
            throw_with_prefix("xhdfe plugin: ", "unknown task: " + *task);
        }
        PluginProfileLaps laps(plugin_total_t0);

        const std::string bmat = args.get_required("b");
        const std::string Vmat = args.get_required("V");

        const int p = parse_int(args.get_required("p"), "p");
        const int nfe = parse_int(args.get_required("nfe"), "nfe");
        const int nslope =
            args.has("nslope") ? parse_int(args.get_required("nslope"), "nslope") : 0;
        const int nclust = parse_int(args.get_required("nclust"), "nclust");
        const int ninst = parse_int(args.get_required("ninst"), "ninst");

        const bool has_weight = parse_bool(args.get_required("has_weight"), "has_weight");
        const bool group_mode = parse_bool(args.get_required("group_mode"), "group_mode");
        const bool has_individual = parse_bool(args.get_required("has_individual"), "has_individual");
        const int individual_fe_pos =
            has_individual
                ? parse_int(args.get_required("individual_fe_pos"), "individual_fe_pos")
                : 0;

        const bool store_resid = parse_bool(args.get_required("store_resid"), "store_resid");
        const bool store_groupvar = parse_bool(args.get_required("store_groupvar"), "store_groupvar");
        const bool store_fes = parse_bool(args.get_required("store_fes"), "store_fes");
        bool esample_prefilled = false;
        if (auto val = args.get_optional("esample_prefilled")) {
            esample_prefilled = parse_bool(*val, "esample_prefilled");
        }

        HdfeOptions opts;
        opts.se_type = parse_se_type(args.get_required("se_type"));
        if (auto val = args.get_optional("dkraay_bandwidth")) {
            opts.dkraay_bandwidth = parse_int(*val, "dkraay_bandwidth");
            if (opts.dkraay_bandwidth < 0 || opts.se_type != StandardErrorType::Cluster || nclust != 1) {
                throw_with_prefix("xhdfe plugin: ", "Driscoll-Kraay requires one time variable and a nonnegative bandwidth code");
            }
        }
        opts.tol = parse_double(args.get_required("tol"), "tol");
        opts.max_iter = parse_int(args.get_required("max_iter"), "max_iter");
        opts.fit_intercept = parse_bool(args.get_required("fit_intercept"), "fit_intercept");
        opts.num_threads = parse_int(args.get_required("num_threads"), "num_threads");
        ScopedPluginThreadRequest plugin_thread_request(opts.num_threads);
        opts.drop_singletons = parse_bool(args.get_required("drop_singletons"), "drop_singletons");
        opts.retain_fixed_effects = parse_bool(args.get_required("retain_fes"), "retain_fes");
        opts.refine_stored_residuals = store_resid;
        opts.symmetric_sweep = parse_bool(args.get_required("symmetric_sweep"), "symmetric_sweep");
        opts.absorption_method = parse_absorption_method(args.get_required("absorption_method"));
        opts.ordinary_krylov_parity_floor = !group_mode && nslope == 0;
        opts.ordinary_auto_routing_retry = !group_mode && nslope == 0;
        if (auto val = args.get_optional("convergence")) {
            opts.convergence_criterion = parse_convergence_criterion(*val);
        }
        // The reduced-system tier for this fit: the ado passes reduced_pcg only
        // when reducedpcg() or the Stata global XHDFE_REDUCED_PCG decided;
        // otherwise the process default (the environment variable) applies.
        if (auto val = args.get_optional("reduced_pcg")) {
            if (*val == "on") {
                opts.reduced_pcg = hdfe::ReducedPcgRequest::On;
            } else if (*val == "off") {
                opts.reduced_pcg = hdfe::ReducedPcgRequest::Off;
            } else {
                throw_with_prefix("xhdfe plugin: ", "reduced_pcg must be on or off");
            }
        }
        // The experimental CUDA variant of the tier for this fit: the ado passes
        // reduced_pcg_cuda only when reducedpcgcuda() or the Stata global
        // XHDFE_REDUCED_PCG_CUDA decided; otherwise the process default (the
        // environment variable) applies. Inert unless the fit runs on CUDA.
        if (auto val = args.get_optional("reduced_pcg_cuda")) {
            if (*val == "on") {
                opts.reduced_pcg_cuda = hdfe::ReducedPcgRequest::On;
            } else if (*val == "off") {
                opts.reduced_pcg_cuda = hdfe::ReducedPcgRequest::Off;
            } else {
                throw_with_prefix("xhdfe plugin: ", "reduced_pcg_cuda must be on or off");
            }
        }
        // Package D (23nov2026): the finer blocks of the tier's segment pass for
        // this fit; the ado passes reduced_pcg_fine only when reducedpcgfine() or
        // the Stata global XHDFE_REDUCED_PCG_APPLY_FINE decided; otherwise the
        // process value (the environment variable, else the built-in value) applies.
        if (auto val = args.get_optional("reduced_pcg_fine")) {
            if (*val == "auto") {
                opts.reduced_pcg_apply_fine = hdfe::kReducedPcgApplyFineAuto;
            } else if (val->size() == 1 && (*val)[0] >= '1' && (*val)[0] <= '8') {
                opts.reduced_pcg_apply_fine = (*val)[0] - '0';
            } else {
                throw_with_prefix("xhdfe plugin: ", "reduced_pcg_fine must be auto or an integer from 1 to 8");
            }
        }
        if (auto val = args.get_optional("slope_solver")) {
            if (!hdfe::parse_slope_solver_request(*val, opts.slope_solver)) {
                throw_with_prefix("xhdfe plugin: ", "slope_solver must be off, schur, network or direct");
            }
            if (auto global = args.get_optional("slope_solver_from_global")) {
                opts.slope_solver_from_global = parse_bool(*global, "slope_solver_from_global");
            }
        }
        const auto slope_helper = [&args](const char* name) -> std::optional<bool> {
            const auto value = args.get_optional(name);
            if (!value) return std::nullopt;
            if (*value == "on") return true;
            if (*value == "off") return false;
            throw_with_prefix("xhdfe plugin: ", std::string(name) + " must be on or off");
        };
        opts.slope_scores = slope_helper("slope_scores");
        opts.slope_csr_owner = slope_helper("slope_csr_owner");
        if (auto val = args.get_optional("weighted_cpu_route")) {
            opts.weighted_cpu_route = parse_bool(*val, "weighted_cpu_route");
        }
        opts.jacobi_relaxation = parse_double(args.get_required("jacobi_relaxation"), "jacobi_relaxation");
        opts.level = parse_double(args.get_required("level"), "level");
        opts.save_groupvar = store_groupvar;
        bool importance_weights = false;
        if (has_weight) {
            if (auto val = args.get_optional("weight_type")) {
                const std::string wt = to_lower(*val);
                importance_weights = wt == "iweight" || wt == "iw";
                if (wt == "fweight" || wt == "fw") {
                    opts.weights_are_frequencies = true;
                } else if (wt == "aweight" || wt == "aw" || wt == "pweight" || wt == "pw" ||
                           wt == "iweight" || wt == "iw") {
                    opts.weights_are_frequencies = false;
                } else if (!wt.empty()) {
                    throw_with_prefix("xhdfe plugin: ", "unknown weight_type: " + *val);
                }
            }
        }
        if (auto val = args.get_optional("fetol")) {
            opts.fe_tolerance = parse_double(*val, "fetol");
        }
        if (auto val = args.get_optional("fe_recovery_method")) {
            opts.fe_recovery_method = parse_fe_recovery_method(*val);
        }
        if (auto val = args.get_optional("tolerance_mode")) {
            opts.tolerance_mode = parse_tolerance_mode(*val);
        }
        // P7 (lean 2.31.0): after the tolerance mode is known. Package B: for strict-residual the core
        // decides (the scope of its CUDA acceptance keeps the fit's own residuals, every other strict
        // fit the re-absorption).
        opts.stored_residuals_fit_state = store_resid && !legacy_stored_residual_refinement();

        const ParsedDofAdjustments dof = parse_dofadjustments(args.get_optional("dofadjustments"));
        opts.dof_method = dof.method;
        opts.dof_mobility_groups = dof.mobility_groups;
        opts.dof_adjust_clusters = dof.adjust_clusters;
        opts.dof_adjust_continuous = dof.adjust_continuous;

        if (auto val = args.get_optional("ssc_k_adj")) {
            opts.ssc_k_adj = parse_bool(*val, "ssc_k_adj");
        }
        if (auto val = args.get_optional("ssc_k_fixef")) {
            opts.ssc_k_fixef = parse_fixef_method(*val);
        }
        if (auto val = args.get_optional("ssc_k_exact")) {
            opts.ssc_k_exact = parse_bool(*val, "ssc_k_exact");
        }
        if (auto val = args.get_optional("ssc_g_adj")) {
            opts.ssc_g_adj = parse_bool(*val, "ssc_g_adj");
        }
        if (auto val = args.get_optional("ssc_g_df")) {
            opts.ssc_g_df = parse_cluster_df(*val);
        }
        if (auto val = args.get_optional("ssc_t_df")) {
            opts.ssc_t_df = parse_double(*val, "ssc_t_df");
        }
        if (auto val = args.get_optional("statstyle")) {
            opts.stats_style = parse_stats_style(*val);
        }

        ThreadingOptions threading;
        threading.default_threads = parse_int(args.get_required("default_threads"), "default_threads");
        threading.max_threads = parse_int(args.get_required("max_threads"), "max_threads");
        threading.min_parallel_rows = parse_int(args.get_required("min_parallel_rows"), "min_parallel_rows");
        threading.target_rows_per_thread =
            parse_int(args.get_required("target_rows_per_thread"), "target_rows_per_thread");
        threading.symmetric_sweep = opts.symmetric_sweep;

        std::optional<hdfe::detail::ScopedGpuBackendOverride> gpu_backend_scope;
        if (auto val = args.get_optional("gpu_backend")) {
            const std::string backend = normalize_gpu_backend(*val);
            gpu_backend_scope.emplace(parse_gpu_backend_override(backend));
        }
        std::optional<ScopedEnvVar> mobility_profile_env;
        if (auto val = args.get_optional("mobility_profile")) {
            if (!val->empty()) {
                mobility_profile_env.emplace("XHDFE_MOBILITY_PROFILE", *val);
            }
        }
        std::optional<ScopedEnvVar> mobility_mode_env;
        if (auto val = args.get_optional("mobility_profile_mode")) {
            if (!val->empty()) {
                mobility_mode_env.emplace("XHDFE_MOBILITY_MODE", *val);
            }
        }
        std::optional<ScopedEnvVar> absorption_cache_env;
        if (auto val = args.get_optional("absorption_cache")) {
            if (!val->empty()) {
                absorption_cache_env.emplace("XHDFE_ABSORPTION_CACHE", *val);
            }
        }
        std::optional<ScopedEnvVar> absorption_cache_mode_env;
        if (auto val = args.get_optional("absorption_cache_mode")) {
            if (!val->empty()) {
                absorption_cache_mode_env.emplace("XHDFE_ABSORPTION_CACHE_MODE", *val);
            }
        }
        std::optional<ScopedEnvVar> fe_structure_cache_env;
        if (auto val = args.get_optional("fe_structure_cache")) {
            if (!val->empty()) {
                fe_structure_cache_env.emplace("XHDFE_FE_STRUCTURE_CACHE", *val);
            }
        }
        std::optional<ScopedEnvVar> fe_structure_cache_mode_env;
        if (auto val = args.get_optional("fe_structure_cache_mode")) {
            if (!val->empty()) {
                fe_structure_cache_mode_env.emplace("XHDFE_FE_STRUCTURE_MODE", *val);
            }
        }

        if (p < 0 || nfe < 0 || nslope < 0 || nclust < 0 || ninst < 0) {
            throw_with_prefix("xhdfe plugin: ", "negative dimension argument");
        }
        if (has_individual && (individual_fe_pos < 1 || individual_fe_pos > nfe)) {
            throw_with_prefix("xhdfe plugin: ",
                              "individual_fe_pos must identify a 1-based absorb() dimension");
        }
        if (opts.se_type == StandardErrorType::Cluster && nclust <= 0) {
            throw_with_prefix("xhdfe plugin: ", "se_type=cluster requires nclust>0");
        }
        if (store_fes && !opts.retain_fixed_effects) {
            throw_with_prefix("xhdfe plugin: ", "store_fes requires retain_fes=1");
        }
        if (group_mode && ninst > 0) {
            throw_with_prefix("xhdfe plugin: ", "group()/individual() mode does not support instruments");
        }
        if (group_mode && nslope > 0) {
            throw_with_prefix("xhdfe plugin: ",
                              "group()/individual() mode does not support heterogeneous slopes");
        }

        int out_fes = store_fes ? nfe : 0;
        if (store_fes) {
            if (auto val = args.get_optional("savefe_out_count")) {
                out_fes = parse_int(*val, "savefe_out_count");
            }
            if (out_fes < 0) {
                throw_with_prefix("xhdfe plugin: ", "savefe_out_count must be nonnegative");
            }
        }
        const int nout = (store_resid ? 1 : 0) + (store_groupvar ? 1 : 0) + out_fes + 1;  // +1 esample
        // With sample_marker the ado appends the estimation-sample marker after
        // every other variable; only the parallel input read uses it.
        const bool has_sample_marker = args.has("sample_marker");

        const int expected_vars = 1 + p + nfe + nslope + nclust + (has_weight ? 1 : 0) + (group_mode ? 1 : 0) +
                                  (has_individual ? 1 : 0) + ninst + nout + (has_sample_marker ? 1 : 0);
        const int have_vars = SF_nvars();
        if (have_vars != expected_vars) {
            throw_with_prefix(
                "xhdfe plugin: ",
                "varlist has wrong length (have " + std::to_string(have_vars) + ", want " +
                    std::to_string(expected_vars) + ")");
        }

        // varlist indices (1-based).
        const int idx_y = 1;
        const int idx_x_start = idx_y + 1;
        const int idx_fe_start = idx_x_start + p;
        const int idx_slope_start = idx_fe_start + nfe;
        const int idx_clust_start = idx_slope_start + nslope;
        const int idx_weight = idx_clust_start + nclust;  // when has_weight
        const int idx_group = idx_weight + (has_weight ? 1 : 0);
        const int idx_individual = idx_group + (group_mode ? 1 : 0);
        const int idx_inst_start = idx_individual + (has_individual ? 1 : 0);
        const int idx_out_start = idx_inst_start + ninst;

        int out_cursor = idx_out_start;
        const int idx_resid_out = store_resid ? out_cursor++ : -1;
        const int idx_groupvar_out = store_groupvar ? out_cursor++ : -1;
        const int idx_fes_out_start = store_fes ? out_cursor : -1;
        if (store_fes) {
            out_cursor += out_fes;
        }
        const int idx_esample_out = out_cursor;
        const int idx_sample_marker = has_sample_marker ? idx_esample_out + 1 : 0;
        if (has_sample_marker &&
            parse_int(args.get_required("sample_marker"), "sample_marker") != idx_sample_marker) {
            throw_with_prefix("xhdfe plugin: ", "sample_marker must index the last variable");
        }

        laps.lap("options");
        ParallelReadPlan parallel_read = plan_parallel_read(
            args, idx_sample_marker, opts.num_threads, nfe,
            fused_read_variable_count(args, p, nfe, nslope, nclust, has_weight, ninst));
        // A regressor with the fit's options and threading, which are complete
        // here, answers how many threads each pass of the read gets. Building it
        // allocates nothing large and touches no data; if it fails the read
        // stays serial and the fit reports any problem where it does today.
        std::optional<HdfeRegressorV11> read_thread_query;
        if (parallel_read.allowed) {
            try {
                read_thread_query.emplace(opts, threading);
                parallel_read.core = &*read_thread_query;
            } catch (const std::exception&) {
                parallel_read.core = nullptr;
            }
        }
        laps.lap("read_plan");
        const auto select_t0 = std::chrono::steady_clock::now();
        const ObservationMap obs = select_observations_for_read(parallel_read);
        plugin_cpu_profile_log_elapsed("select_observations", select_t0);
        if (plugin_cpu_profile_enabled()) {
            std::cerr << "plugin_profile label=select_observations_mode contiguous="
                      << (obs.contiguous ? 1 : 0)
                      << " n=" << obs.n << '\n';
        }
        laps.restart();
        const int n = obs.n;
        if (n <= 0) {
            if (plugin_cpu_profile_enabled() && fused_read_enabled()) {
                log_parallel_read_mode(parallel_read);
            }
            return static_cast<ST_retcode>(2000);  // no observations
        }

        const ST_double missval = SV_missval;
        auto read_numeric = [&](int var_idx, int obs_no) {
            ST_double z = 0.0;
            const ST_retcode rc = SF_vdata(var_idx, obs_no, &z);
            if (rc) {
                throw_with_prefix("xhdfe plugin: ", "failed to read data (rc=" + std::to_string(rc) + ")");
            }
            if (!std::isfinite(z) || !(z < missval)) {
                throw_with_prefix("xhdfe plugin: ", "unexpected missing value; make sure sample excludes missings");
            }
            return z;
        };
        auto read_categorical_numeric = [&](int var_idx, const char* what,
                                            bool validate_individual_id = false) {
            Eigen::VectorXi ids(n);
            // Most FE/cluster variables already fit int32 exactly. Fill ids
            // directly in that case and only materialize the raw double column
            // if we encounter sparse/out-of-range values that require dense coding.
            const auto read_raw_t0 = std::chrono::steady_clock::now();
            std::vector<double> raw;
            bool all_int = true;
            for (int i = 0; i < n; ++i) {
                const double z = read_numeric(var_idx, obs.obs_no(i));
                if (validate_individual_id) {
                    if (z < 0.0) {
                        throw_with_prefix("xhdfe plugin: ",
                                          "individual identifier must be nonnegative");
                    }
                    if (std::trunc(z) != z) {
                        throw_with_prefix("xhdfe plugin: ",
                                          "individual identifier must be integer-valued");
                    }
                    if (z > kMaxExactIntegerId) {
                        throw_with_prefix(
                            "xhdfe plugin: ",
                            "individual identifier exceeds the exact integer range of a double");
                    }
                }
                if (all_int) {
                    int id = 0;
                    if (exact_int32_id(z, id)) {
                        ids(i) = id;
                        continue;
                    }
                    all_int = false;
                    raw.resize(static_cast<std::size_t>(n));
                    for (int k = 0; k < i; ++k) {
                        raw[static_cast<std::size_t>(k)] = static_cast<double>(ids(k));
                    }
                }
                raw[static_cast<std::size_t>(i)] = z;
            }
            plugin_cpu_profile_log_elapsed(std::string("read_") + what + "_raw", read_raw_t0);
            if (all_int) {
                // Integer-valued ids in range are passed through verbatim; ids
                // were filled during the single Stata read above.
                const auto code_int_t0 = std::chrono::steady_clock::now();
                plugin_cpu_profile_log_elapsed(std::string("code_") + what + "_raw_int",
                                               code_int_t0);
                return ids;
            }

            // Sparse / out-of-range values: dense-rank by ascending value. The id
            // assigned to each observation equals the number of distinct values
            // below it, which is invariant to how the sort orders equal keys, so
            // this is bit-for-bit identical to the previous std::sort-based code.
            const auto code_dense_t0 = std::chrono::steady_clock::now();
            std::vector<std::pair<double, int>> keyed;
            keyed.resize(static_cast<std::size_t>(n));
            for (int j = 0; j < n; ++j) {
                keyed[static_cast<std::size_t>(j)] =
                    std::pair<double, int>(raw[static_cast<std::size_t>(j)], j);
            }
            XHDFE_PARALLEL_SORT(keyed.begin(), keyed.end(),
                                [](const std::pair<double, int>& a,
                                   const std::pair<double, int>& b) {
                                    return a.first < b.first;
                                });
            int next_id = -1;
            double prev = 0.0;
            for (const auto& kv : keyed) {
                const double value = kv.first;
                if (next_id < 0 || value != prev) {
                    ++next_id;
                    prev = value;
                }
                ids(kv.second) = next_id;
            }
            if (next_id < 0) {
                throw_with_prefix("xhdfe plugin: ",
                                  std::string("empty categorical variable: ") + what);
            }
            plugin_cpu_profile_log_elapsed(std::string("code_") + what + "_dense",
                                           code_dense_t0);
            return ids;
        };

        laps.lap("read_setup");
        const auto read_total_t0 = std::chrono::steady_clock::now();
        Eigen::VectorXd y(n);
        Eigen::MatrixXd X(n, p);

        // One pass over the observations for every numeric input (see
        // read_columns_fused). When it completes, the stages below take their
        // columns from here; otherwise they read as before and report.
        struct FusedInputs {
            bool done = false;
            bool parallel = false;  // done by read_inputs_parallel itself
            std::vector<Eigen::VectorXi> fes;
            std::vector<char> fe_ready;
            std::vector<Eigen::VectorXd> slopes;
            Eigen::VectorXd weights;
            std::vector<Eigen::VectorXi> clusters;
            std::vector<char> cluster_ready;
            Eigen::MatrixXd instruments;
        } fused;
        if (fused_read_enabled()) {
            const auto read_fused_t0 = std::chrono::steady_clock::now();
            int fused_id_columns = 0;
            int fused_id_columns_left = 0;
            try {
                fused.done = [&]() {
                    // The maps decide which identifier columns are read at
                    // all. A malformed map is reported by its own stage.
                    std::vector<int> dup_map;
                    const std::optional<std::string> dup_arg = args.get_optional("fe_dup_map");
                    if (dup_arg && !dup_arg->empty()) {
                        dup_map = parse_csv_ints_ordered(*dup_arg, "fe_dup_map");
                        if (static_cast<int>(dup_map.size()) != nfe) {
                            return false;
                        }
                    }
                    int individual_index = individual_fe_pos - 1;
                    if (has_individual) {
                        if (individual_index < 0 || individual_index >= nfe) {
                            return false;
                        }
                        while (!dup_map.empty() &&
                               dup_map[static_cast<std::size_t>(individual_index)] >= 0) {
                            const int dup = dup_map[static_cast<std::size_t>(individual_index)];
                            if (dup >= individual_index) {
                                return false;
                            }
                            individual_index = dup;
                        }
                    }
                    std::vector<int> cluster_map;
                    if (nclust > 0) {
                        const std::optional<std::string> cluster_arg =
                            args.get_optional("cluster_fe_map");
                        if (cluster_arg && !cluster_arg->empty()) {
                            cluster_map = parse_csv_ints_ordered(*cluster_arg, "cluster_fe_map");
                            if (static_cast<int>(cluster_map.size()) != nclust) {
                                return false;
                            }
                        }
                    }

                    const std::size_t rows = static_cast<std::size_t>(n);
                    std::vector<FusedDoubleColumn> doubles;
                    std::vector<FusedIdColumn> ids;
                    std::vector<Eigen::VectorXi*> id_storage;
                    std::vector<char*> id_ready;
                    doubles.push_back({idx_y, y.data()});
                    for (int j = 0; j < p; ++j) {
                        doubles.push_back(
                            {idx_x_start + j, X.data() + static_cast<std::size_t>(j) * rows});
                    }
                    fused.fes.resize(static_cast<std::size_t>(nfe));
                    fused.fe_ready.assign(static_cast<std::size_t>(nfe), 0);
                    for (int d = 0; d < nfe; ++d) {
                        const int dup = dup_map.empty() ? -1 : dup_map[static_cast<std::size_t>(d)];
                        if (dup >= 0) {
                            if (dup >= d) {
                                return false;
                            }
                            continue;
                        }
                        Eigen::VectorXi& column = fused.fes[static_cast<std::size_t>(d)];
                        column.resize(n);
                        ids.push_back({idx_fe_start + d, column.data(),
                                       has_individual && d == individual_index, true});
                        id_storage.push_back(&column);
                        id_ready.push_back(&fused.fe_ready[static_cast<std::size_t>(d)]);
                    }
                    fused.slopes.resize(static_cast<std::size_t>(nslope));
                    for (int d = 0; d < nslope; ++d) {
                        Eigen::VectorXd& column = fused.slopes[static_cast<std::size_t>(d)];
                        column.resize(n);
                        doubles.push_back({idx_slope_start + d, column.data()});
                    }
                    if (has_weight) {
                        fused.weights.resize(n);
                        doubles.push_back({idx_weight, fused.weights.data()});
                    }
                    fused.clusters.resize(static_cast<std::size_t>(nclust));
                    fused.cluster_ready.assign(static_cast<std::size_t>(nclust), 0);
                    for (int d = 0; d < nclust; ++d) {
                        const int mapped =
                            cluster_map.empty() ? -1 : cluster_map[static_cast<std::size_t>(d)];
                        if (mapped >= 0) {
                            if (mapped >= nfe) {
                                return false;
                            }
                            continue;
                        }
                        Eigen::VectorXi& column = fused.clusters[static_cast<std::size_t>(d)];
                        column.resize(n);
                        ids.push_back({idx_clust_start + d, column.data(), false, true});
                        id_storage.push_back(&column);
                        id_ready.push_back(&fused.cluster_ready[static_cast<std::size_t>(d)]);
                    }
                    if (ninst > 0) {
                        fused.instruments.resize(n, ninst);
                        for (int j = 0; j < ninst; ++j) {
                            doubles.push_back({idx_inst_start + j,
                                               fused.instruments.data() +
                                                   static_cast<std::size_t>(j) * rows});
                        }
                    }

                    // The parallel pass when allowed; on any anomaly it is
                    // discarded and the serial pass reads everything again.
                    // Only a success of the parallel pass itself lets the
                    // column stages read a wide column on the team.
                    const bool parallel_done =
                        read_inputs_parallel(parallel_read, obs, doubles, ids);
                    if (!parallel_done && !read_columns_fused(obs, doubles, ids)) {
                        return false;
                    }
                    fused.parallel = parallel_done;
                    fused_id_columns = static_cast<int>(ids.size());
                    for (std::size_t k = 0; k < ids.size(); ++k) {
                        if (ids[k].exact_int32) {
                            *id_ready[k] = 1;
                        } else {
                            // Its column reader allocates what it needs.
                            *id_storage[k] = Eigen::VectorXi();
                            ++fused_id_columns_left;
                        }
                    }
                    return true;
                }();
            } catch (const std::exception&) {
                fused.done = false;
            }
            if (!fused.done) {
                fused = FusedInputs{};
            }
            plugin_cpu_profile_log_elapsed("read_fused", read_fused_t0);
            if (plugin_cpu_profile_enabled()) {
                std::cerr << "plugin_profile label=read_fused_mode done=" << (fused.done ? 1 : 0)
                          << " id_columns=" << fused_id_columns
                          << " id_columns_left_to_column_reader=" << fused_id_columns_left << '\n';
                log_parallel_read_mode(parallel_read);
            }
        }

        const auto read_yx_t0 = std::chrono::steady_clock::now();
        if (!fused.done) {
            for (int i = 0; i < n; ++i) {
                y(i) = read_numeric(idx_y, obs.obs_no(i));
            }
            for (int j = 0; j < p; ++j) {
                const int var_idx = idx_x_start + j;
                for (int i = 0; i < n; ++i) {
                    X(i, j) = read_numeric(var_idx, obs.obs_no(i));
                }
            }
        }
        plugin_cpu_profile_log_elapsed("read_yx", read_yx_t0);

        const auto read_fes_t0 = std::chrono::steady_clock::now();
        std::vector<int> fe_dup_map;
        const std::optional<std::string> fe_dup_map_arg = args.get_optional("fe_dup_map");
        if (fe_dup_map_arg && !fe_dup_map_arg->empty()) {
            fe_dup_map = parse_csv_ints_ordered(*fe_dup_map_arg, "fe_dup_map");
            if (static_cast<int>(fe_dup_map.size()) != nfe) {
                throw_with_prefix("xhdfe plugin: ", "fe_dup_map length must equal nfe");
            }
        }
        int individual_fe_read_index = individual_fe_pos - 1;
        while (has_individual && !fe_dup_map.empty() &&
               fe_dup_map[static_cast<std::size_t>(individual_fe_read_index)] >= 0) {
            const int dup = fe_dup_map[static_cast<std::size_t>(individual_fe_read_index)];
            if (dup >= individual_fe_read_index) {
                throw_with_prefix("xhdfe plugin: ", "fe_dup_map entry out of range");
            }
            individual_fe_read_index = dup;
        }
        std::vector<Eigen::VectorXi> fes;
        fes.reserve(static_cast<std::size_t>(nfe));
        for (int d = 0; d < nfe; ++d) {
            const int dup =
                fe_dup_map.empty() ? -1 : fe_dup_map[static_cast<std::size_t>(d)];
            if (dup >= 0) {
                if (dup >= d) {
                    throw_with_prefix("xhdfe plugin: ", "fe_dup_map entry out of range");
                }
                // Same absorb() id variable as an earlier dimension (e.g. two
                // slope terms on one FE): reuse the coded ids instead of
                // re-reading and re-coding the full column.
                fes.push_back(fes[static_cast<std::size_t>(dup)]);
                continue;
            }
            const int var_idx = idx_fe_start + d;
            const bool validate_individual = has_individual && d == individual_fe_read_index;
            Eigen::VectorXi v;
            if (fused.done && fused.fe_ready[static_cast<std::size_t>(d)]) {
                v = std::move(fused.fes[static_cast<std::size_t>(d)]);
            } else if (!(fused.done &&
                         read_wide_id_on_team(parallel_read, fused.parallel, obs, var_idx,
                                              validate_individual, "fes", v))) {
                // A column the fused pass left (wide) whose team read did
                // not run or was discarded, or no fused pass: today's reader.
                v = read_categorical_numeric(var_idx, "fes", validate_individual);
            }
            fes.push_back(std::move(v));
        }
        plugin_cpu_profile_log_elapsed("read_fes", read_fes_t0);

        std::vector<HeterogeneousSlopeTerm> slopes;
        if (nslope > 0) {
            std::vector<int> slope_fe_map =
                parse_csv_ints_ordered(args.get_required("slope_fe_map"), "slope_fe_map");
            std::vector<int> slope_intercepts =
                parse_csv_ints_ordered(args.get_required("slope_intercepts"), "slope_intercepts");
            if (static_cast<int>(slope_fe_map.size()) != nslope) {
                throw_with_prefix("xhdfe plugin: ",
                                  "slope_fe_map length must equal nslope");
            }
            if (static_cast<int>(slope_intercepts.size()) != nslope) {
                throw_with_prefix("xhdfe plugin: ",
                                  "slope_intercepts length must equal nslope");
            }
            const auto read_slopes_t0 = std::chrono::steady_clock::now();
            slopes.reserve(static_cast<std::size_t>(nslope));
            for (int d = 0; d < nslope; ++d) {
                const int mapped_fe = slope_fe_map[static_cast<std::size_t>(d)];
                if (mapped_fe < 0 || mapped_fe >= nfe) {
                    throw_with_prefix("xhdfe plugin: ",
                                      "slope_fe_map entry out of range");
                }
                const int include_intercept = slope_intercepts[static_cast<std::size_t>(d)];
                if (include_intercept != 0 && include_intercept != 1) {
                    throw_with_prefix("xhdfe plugin: ",
                                      "slope_intercepts entries must be 0 or 1");
                }
                Eigen::VectorXd values;
                const int var_idx = idx_slope_start + d;
                if (fused.done) {
                    values = std::move(fused.slopes[static_cast<std::size_t>(d)]);
                } else {
                    values.resize(n);
                    for (int i = 0; i < n; ++i) {
                        values(i) = read_numeric(var_idx, obs.obs_no(i));
                    }
                }
                HeterogeneousSlopeTerm term;
                term.fe_index = mapped_fe;
                term.include_intercept = include_intercept != 0;
                term.values = std::move(values);
                slopes.push_back(std::move(term));
            }
            plugin_cpu_profile_log_elapsed("read_slopes", read_slopes_t0);
        }

        std::optional<Eigen::VectorXd> weights;
        if (has_weight) {
            const auto read_weights_t0 = std::chrono::steady_clock::now();
            Eigen::VectorXd w;
            if (fused.done) {
                w = std::move(fused.weights);
            } else {
                w.resize(n);
                for (int i = 0; i < n; ++i) {
                    w(i) = read_numeric(idx_weight, obs.obs_no(i));
                }
            }
            weights = std::move(w);
            plugin_cpu_profile_log_elapsed("read_weights", read_weights_t0);
        }
        const Eigen::VectorXd* w_ptr = weights ? &(*weights) : nullptr;

        std::optional<std::vector<Eigen::VectorXi>> clusters;
        if (nclust > 0) {
            std::vector<int> cluster_fe_map;
            const std::optional<std::string> cluster_fe_map_arg =
                args.get_optional("cluster_fe_map");
            if (cluster_fe_map_arg && !cluster_fe_map_arg->empty()) {
                cluster_fe_map =
                    parse_csv_ints_ordered(*cluster_fe_map_arg, "cluster_fe_map");
                if (static_cast<int>(cluster_fe_map.size()) != nclust) {
                    throw_with_prefix("xhdfe plugin: ",
                                      "cluster_fe_map length must equal nclust");
                }
            }
            const auto read_clusters_t0 = std::chrono::steady_clock::now();
            std::vector<Eigen::VectorXi> c;
            c.reserve(static_cast<std::size_t>(nclust));
            for (int d = 0; d < nclust; ++d) {
                const int mapped_fe =
                    cluster_fe_map.empty() ? -1 : cluster_fe_map[static_cast<std::size_t>(d)];
                if (mapped_fe >= 0) {
                    if (mapped_fe >= nfe) {
                        throw_with_prefix("xhdfe plugin: ",
                                          "cluster_fe_map entry out of range");
                    }
                    c.push_back(fes[static_cast<std::size_t>(mapped_fe)]);
                    continue;
                }
                const int var_idx = idx_clust_start + d;
                Eigen::VectorXi v;
                if (fused.done && fused.cluster_ready[static_cast<std::size_t>(d)]) {
                    v = std::move(fused.clusters[static_cast<std::size_t>(d)]);
                } else if (!(fused.done &&
                             read_wide_id_on_team(parallel_read, fused.parallel, obs, var_idx,
                                                  false, "clusters", v))) {
                    v = read_categorical_numeric(var_idx, "clusters");
                }
                c.push_back(std::move(v));
            }
            clusters = std::move(c);
            plugin_cpu_profile_log_elapsed("read_clusters", read_clusters_t0);
        }
        const std::vector<Eigen::VectorXi>* c_ptr = clusters ? &(*clusters) : nullptr;

        std::optional<Eigen::MatrixXd> instruments;
        if (ninst > 0) {
            const auto read_instruments_t0 = std::chrono::steady_clock::now();
            Eigen::MatrixXd Z;
            if (fused.done) {
                Z = std::move(fused.instruments);
            } else {
                Z.resize(n, ninst);
                for (int j = 0; j < ninst; ++j) {
                    const int var_idx = idx_inst_start + j;
                    for (int i = 0; i < n; ++i) {
                        Z(i, j) = read_numeric(var_idx, obs.obs_no(i));
                    }
                }
            }
            instruments = std::move(Z);
            plugin_cpu_profile_log_elapsed("read_instruments", read_instruments_t0);
        }
        const Eigen::MatrixXd* inst_ptr = instruments ? &(*instruments) : nullptr;
        plugin_cpu_profile_log_elapsed("read_total", read_total_t0);
        laps.restart();
        if (plugin_cpu_profile_enabled()) {
            // Order-sensitive fingerprint of every input as read, so that the
            // fused pass and the column readers can be compared on real data
            // without exporting a single value.
            std::uint64_t digest = 0x243F6A8885A308D3ULL;
            const auto mix = [&digest](std::uint64_t bits) {
                digest = (digest ^ bits) * 0x9E3779B97F4A7C15ULL;
                digest ^= digest >> 29;
            };
            const auto mix_doubles = [&mix](const double* data, Eigen::Index count) {
                for (Eigen::Index k = 0; k < count; ++k) {
                    std::uint64_t bits = 0;
                    std::memcpy(&bits, data + k, sizeof(bits));
                    mix(bits);
                }
            };
            const auto mix_ints = [&mix](const int* data, Eigen::Index count) {
                for (Eigen::Index k = 0; k < count; ++k) {
                    mix(static_cast<std::uint64_t>(static_cast<std::uint32_t>(data[k])));
                }
            };
            mix_doubles(y.data(), y.size());
            mix_doubles(X.data(), X.size());
            for (const Eigen::VectorXi& ids : fes) {
                mix_ints(ids.data(), ids.size());
            }
            for (const HeterogeneousSlopeTerm& term : slopes) {
                mix_doubles(term.values.data(), term.values.size());
            }
            if (weights) {
                mix_doubles(weights->data(), weights->size());
            }
            if (clusters) {
                for (const Eigen::VectorXi& ids : *clusters) {
                    mix_ints(ids.data(), ids.size());
                }
            }
            if (instruments) {
                mix_doubles(instruments->data(), instruments->size());
            }
            std::cerr << "plugin_profile label=input_digest value=" << digest
                      << " fused=" << (fused.done ? 1 : 0) << '\n';
        }
        // The digest above exists only under the profile: its time has its own label.
        laps.lap("input_digest_profile_only");

        std::vector<int> endogenous_idx;
        if (args.has("endogenous_idx")) {
            endogenous_idx = parse_csv_ints_0based(args.get_required("endogenous_idx"));
        }
        if (ninst > 0 && endogenous_idx.empty()) {
            throw_with_prefix("xhdfe plugin: ", "instruments require endogenous_idx");
        }
        if (!endogenous_idx.empty() && ninst == 0) {
            throw_with_prefix("xhdfe plugin: ", "endogenous_idx requires instruments");
        }

        const std::optional<std::string> s_N = args.get_optional("s_N");
        const std::optional<std::string> s_N_full = args.get_optional("s_N_full");
        const std::optional<std::string> s_num_singletons = args.get_optional("s_num_singletons");
        const std::optional<std::string> s_df_r = args.get_optional("s_df_r");
        const std::optional<std::string> s_df_r_unadj = args.get_optional("s_df_r_unadj");
        const std::optional<std::string> s_df_m = args.get_optional("s_df_m");
        const std::optional<std::string> s_df_a = args.get_optional("s_df_a");
        const std::optional<std::string> s_df_a_levels = args.get_optional("s_df_a_levels");
        const std::optional<std::string> s_df_a_exact = args.get_optional("s_df_a_exact");
        const std::optional<std::string> s_df_a_nested = args.get_optional("s_df_a_nested");
        const std::optional<std::string> s_model_has_constant =
            args.get_optional("s_model_has_constant");
        const std::optional<std::string> s_r2 = args.get_optional("s_r2");
        const std::optional<std::string> s_r2_within = args.get_optional("s_r2_within");
        const std::optional<std::string> s_sigma2 = args.get_optional("s_sigma2");
        const std::optional<std::string> s_rss = args.get_optional("s_rss");
        const std::optional<std::string> s_tss = args.get_optional("s_tss");
        const std::optional<std::string> s_tss_within = args.get_optional("s_tss_within");
        const std::optional<std::string> s_saturated = args.get_optional("s_saturated");
        const std::optional<std::string> s_iterations = args.get_optional("s_iterations");
        const std::optional<std::string> s_converged = args.get_optional("s_converged");
        const std::optional<std::string> s_abs_residual =
            args.get_optional("s_abs_residual");
        const std::optional<std::string> s_abs_residual_rel =
            args.get_optional("s_abs_residual_rel");
        const std::optional<std::string> s_krylov_internal_tolerance =
            args.get_optional("s_krylov_internal_tolerance");
        const std::optional<std::string> s_krylov_max_final_backward_error =
            args.get_optional("s_krylov_max_final_backward_error");
        const std::optional<std::string> s_krylov_max_condition =
            args.get_optional("s_krylov_max_condition");
        const std::optional<std::string> s_krylov_max_condition_times_backward_error =
            args.get_optional("s_krylov_max_condition_times_backward_error");
        const std::optional<std::string> s_auto_routing_retry_policy_enabled =
            args.get_optional("s_auto_routing_retry_policy_enabled");
        const std::optional<std::string> s_auto_routing_retry_eligible =
            args.get_optional("s_auto_routing_retry_eligible");
        const std::optional<std::string> s_auto_routing_retry_fired =
            args.get_optional("s_auto_routing_retry_fired");
        const std::optional<std::string> s_auto_routing_retry_status =
            args.get_optional("s_auto_routing_retry_status");
        const std::optional<std::string> s_auto_routing_retry_primary_method =
            args.get_optional("s_auto_routing_retry_primary_method");
        const std::optional<std::string> s_auto_routing_retry_primary_iterations =
            args.get_optional("s_auto_routing_retry_primary_iterations");
        const std::optional<std::string> s_auto_routing_retry_primary_abs_residual_rel =
            args.get_optional("s_auto_routing_retry_primary_abs_residual_rel");
        const std::optional<std::string> s_auto_routing_retry_iterations =
            args.get_optional("s_auto_routing_retry_iterations");
        const std::optional<std::string> s_auto_routing_retry_abs_residual_rel =
            args.get_optional("s_auto_routing_retry_abs_residual_rel");
        const std::optional<std::string> s_auto_routing_retry_elapsed_seconds =
            args.get_optional("s_auto_routing_retry_elapsed_seconds");
        const std::optional<std::string> s_slope_block_checked =
            args.get_optional("s_slope_block_checked");
        const std::optional<std::string> s_slope_block_residual_rel =
            args.get_optional("s_slope_block_residual_rel");
        const std::optional<std::string> s_slope_block_frobenius_rel =
            args.get_optional("s_slope_block_frobenius_rel");
        const std::optional<std::string> s_slope_block_rms_rel =
            args.get_optional("s_slope_block_rms_rel");
        const std::optional<std::string> s_slope_block_max_rel =
            args.get_optional("s_slope_block_max_rel");
        const std::optional<std::string> s_slope_block_skipped_max_rel =
            args.get_optional("s_slope_block_skipped_max_rel");
        const std::optional<std::string> s_slope_certificate_worst_fe =
            args.get_optional("s_slope_certificate_worst_fe");
        const std::optional<std::string> s_slope_certificate_worst_moment =
            args.get_optional("s_slope_certificate_worst_moment");
        const std::optional<std::string> s_slope_accuracy_retry_stages =
            args.get_optional("s_slope_accuracy_retry_stages");
        const std::optional<std::string> s_slope_accuracy_retry_iterations =
            args.get_optional("s_slope_accuracy_retry_iterations");
        const std::optional<std::string> s_slope_internal_tolerance =
            args.get_optional("s_slope_internal_tolerance");
        const std::optional<std::string> s_precision_certified =
            args.get_optional("s_precision_certified");
        const std::optional<std::string> s_fe_recovery_converged =
            args.get_optional("s_fe_recovery_converged");
        const std::optional<std::string> s_fe_recovery_iterations =
            args.get_optional("s_fe_recovery_iterations");
        const std::optional<std::string> s_fe_recovery_max_delta =
            args.get_optional("s_fe_recovery_max_delta");
        const std::optional<std::string> s_threads_used = args.get_optional("s_threads_used");
        const std::optional<std::string> s_threads_requested =
            args.get_optional("s_threads_requested");
        const std::optional<std::string> s_threads_effective =
            args.get_optional("s_threads_effective");
        const std::optional<std::string> s_parallel_workers_active =
            args.get_optional("s_parallel_workers_active");
        const std::optional<std::string> s_thread_capacity =
            args.get_optional("s_thread_capacity");
        const std::optional<std::string> s_openmp_enabled =
            args.get_optional("s_openmp_enabled");
        const std::optional<std::string> s_thread_limit_code =
            args.get_optional("s_thread_limit_code");
        const std::optional<std::string> s_gpu_used = args.get_optional("s_gpu_used");
        const std::optional<std::string> s_gpu_status_code = args.get_optional("s_gpu_status_code");
        const std::optional<std::string> s_gpu_attempted = args.get_optional("s_gpu_attempted");
        const std::optional<std::string> s_gpu_absorption_converged =
            args.get_optional("s_gpu_absorption_converged");
        const std::optional<std::string> s_gpu_absorption_iterations =
            args.get_optional("s_gpu_absorption_iterations");
        const std::optional<std::string> s_cuda_tail_code =
            args.get_optional("s_cuda_tail_code");
        const std::optional<std::string> s_method_used = args.get_optional("s_method_used");
        const std::optional<std::string> s_reduced_pcg_status =
            args.get_optional("s_reduced_pcg_status");
        const std::optional<std::string> m_reduced_pcg_reason =
            args.get_optional("m_reduced_pcg_reason");
        const std::optional<std::string> s_reduced_pcg_discarded_iterations =
            args.get_optional("s_reduced_pcg_discarded_iterations");
        const FineReadResults fine_read_results(args);
        const SlopeSolverOutputs slope_outputs(args);
        const std::optional<std::string> s_num_clusters = args.get_optional("s_num_clusters");
        const std::optional<std::string> s_cluster_scale = args.get_optional("s_cluster_scale");
        const std::optional<std::string> s_vcv_psd_fixed = args.get_optional("s_vcv_psd_fixed");
        const std::optional<std::string> cluster_diag = args.get_optional("cluster_diag");
        const std::optional<std::string> dof_table = args.get_optional("dof_table");
        const std::optional<std::string> omit_reason = args.get_optional("omit_reason");
        const std::optional<std::string> omit_priority = args.get_optional("omit_priority");

        if (omit_priority && !omit_priority->empty()) {
            opts.collinear_priority = read_matrix_vector_int(*omit_priority, "omit_priority");
        }
        if (!opts.collinear_priority.empty() &&
            static_cast<int>(opts.collinear_priority.size()) < p) {
            throw_with_prefix("xhdfe plugin: ", "omit_priority length is smaller than p");
        }

        const auto save_auto_routing_retry = [&](const hdfe::HdfeResults& result) {
            maybe_save_scalar(s_auto_routing_retry_policy_enabled,
                              result.auto_routing_retry_policy_enabled ? 1.0 : 0.0);
            maybe_save_scalar(s_auto_routing_retry_eligible,
                              result.auto_routing_retry_eligible ? 1.0 : 0.0);
            maybe_save_scalar(s_auto_routing_retry_fired,
                              result.auto_routing_retry_fired ? 1.0 : 0.0);
            maybe_save_scalar(s_auto_routing_retry_status,
                              static_cast<double>(result.auto_routing_retry_status));
            maybe_save_scalar(s_auto_routing_retry_primary_method,
                              static_cast<double>(result.auto_routing_retry_primary_method));
            maybe_save_scalar(s_auto_routing_retry_primary_iterations,
                              static_cast<double>(result.auto_routing_retry_primary_iterations));
            maybe_save_scalar(s_auto_routing_retry_primary_abs_residual_rel,
                              result.auto_routing_retry_primary_abs_residual_rel);
            maybe_save_scalar(s_auto_routing_retry_iterations,
                              static_cast<double>(result.auto_routing_retry_iterations));
            maybe_save_scalar(s_auto_routing_retry_abs_residual_rel,
                              result.auto_routing_retry_abs_residual_rel);
            maybe_save_scalar(s_auto_routing_retry_elapsed_seconds,
                              result.auto_routing_retry_elapsed_seconds);
        };
        HdfeRegressorV11 reg(opts, threading);

        // Group/individual mode: estimate on collapsed group observations and map results back to a
        // representative row per group (first occurrence).
        if (group_mode) {
            if (opts.retain_fixed_effects && has_individual) {
                throw_with_prefix("xhdfe plugin: ",
                                  "retain_fes is not supported with group/individual fixed effects");
            }
            if (store_fes && has_individual) {
                throw_with_prefix("xhdfe plugin: ",
                                  "store_fes is not supported with group/individual fixed effects");
            }

            Eigen::VectorXi group_ids(n);
            for (int i = 0; i < n; ++i) {
                group_ids(i) =
                    to_int_checked(read_numeric(idx_group, obs.obs_no(i)), "group");
            }

            // Group-only mode: collapse to one row per group and run the standard estimator.
            if (!has_individual) {
                std::unordered_map<int, int> group_map;
                group_map.reserve(static_cast<std::size_t>(n));
                std::vector<int> rep_row;
                rep_row.reserve(static_cast<std::size_t>(n));
                std::vector<int> group_index(static_cast<std::size_t>(n), -1);
                for (int i = 0; i < n; ++i) {
                    const int raw = group_ids(i);
                    auto it = group_map.find(raw);
                    if (it == group_map.end()) {
                        const int g = static_cast<int>(rep_row.size());
                        group_map.emplace(raw, g);
                        rep_row.push_back(i);
                        group_index[static_cast<std::size_t>(i)] = g;
                    } else {
                        group_index[static_cast<std::size_t>(i)] = it->second;
                    }
                }
                const int G = static_cast<int>(rep_row.size());
                if (G <= 0) {
                    throw_with_prefix("xhdfe plugin: ", "no groups found");
                }

                // Verify group-constant requirements (same checks as the C++ backend).
                for (int i = 0; i < n; ++i) {
                    const int g = group_index[static_cast<std::size_t>(i)];
                    const int r = rep_row[static_cast<std::size_t>(g)];
                    if (!approx_equal(y(i), y(r))) {
                        throw_with_prefix("xhdfe plugin: ", "y is not constant within group()");
                    }
                    for (int j = 0; j < p; ++j) {
                        if (!approx_equal(X(i, j), X(r, j))) {
                            throw_with_prefix("xhdfe plugin: ", "X is not constant within group()");
                        }
                    }
                    if (weights && !approx_equal((*weights)(i), (*weights)(r))) {
                        throw_with_prefix("xhdfe plugin: ", "weights are not constant within group()");
                    }
                    if (clusters) {
                        for (const auto& cvec : *clusters) {
                            if (cvec(i) != cvec(r)) {
                                throw_with_prefix("xhdfe plugin: ", "clusters are not constant within group()");
                            }
                        }
                    }
                    for (int d = 0; d < nfe; ++d) {
                        if (fes[static_cast<std::size_t>(d)](i) != fes[static_cast<std::size_t>(d)](r)) {
                            throw_with_prefix("xhdfe plugin: ", "fixed effects are not constant within group()");
                        }
                    }
                }

                Eigen::VectorXd y_g(G);
                Eigen::MatrixXd X_g(G, p);
                std::vector<Eigen::VectorXi> fes_g;
                fes_g.reserve(static_cast<std::size_t>(nfe));
                for (int d = 0; d < nfe; ++d) {
                    fes_g.emplace_back(Eigen::VectorXi::Zero(G));
                }
                std::optional<Eigen::VectorXd> w_g;
                if (weights) {
                    w_g = Eigen::VectorXd::Zero(G);
                }
                std::optional<std::vector<Eigen::VectorXi>> c_g;
                if (clusters) {
                    c_g = std::vector<Eigen::VectorXi>{};
                    c_g->reserve(clusters->size());
                    for (std::size_t j = 0; j < clusters->size(); ++j) {
                        c_g->emplace_back(Eigen::VectorXi::Zero(G));
                    }
                }

                std::vector<int> rep_obs(static_cast<std::size_t>(G), 0);
                for (int g = 0; g < G; ++g) {
                    const int r = rep_row[static_cast<std::size_t>(g)];
                    rep_obs[static_cast<std::size_t>(g)] = obs.obs_no(r);
                    y_g(g) = y(r);
                    X_g.row(g) = X.row(r);
                    for (int d = 0; d < nfe; ++d) {
                        fes_g[static_cast<std::size_t>(d)](g) = fes[static_cast<std::size_t>(d)](r);
                    }
                    if (w_g) {
                        (*w_g)(g) = (*weights)(r);
                    }
                    if (c_g) {
                        for (std::size_t j = 0; j < c_g->size(); ++j) {
                            (*c_g)[j](g) = (*clusters)[j](r);
                        }
                    }
                }

                const Eigen::VectorXd* wptr_g = w_g ? &(*w_g) : nullptr;
                const std::vector<Eigen::VectorXi>* cptr_g = c_g ? &(*c_g) : nullptr;
                {
                    // Package B: this call is the group() collapse of the plugin, marked
                    // for this call only (cleared on every exit, an exception included).
                    HdfeRegressorV11::GroupedCallMark grouped_call(reg);
                    reg.fit(y_g, X_g, fes_g, wptr_g, cptr_g, nullptr, {});
                }
                if (importance_weights) reg.apply_importance_weights(*wptr_g);

                const hdfe::HdfeResults& r = reg.results();

                if (r.coefficients.size() > 0) {
                    store_row_vector(bmat, r.coefficients);
                    store_matrix(Vmat, r.covariance);
                }

                maybe_save_scalar(s_N, r.nobs_effective);
                maybe_save_scalar(s_N_full, r.nobs_full_effective);
                maybe_save_scalar(s_num_singletons, r.num_singletons_effective);
                maybe_save_scalar(s_df_r, r.df_resid);
                maybe_save_scalar(s_df_r_unadj, r.df_resid_unadj);
                maybe_save_scalar(s_df_m, r.df_m);
                maybe_save_scalar(s_df_a, r.df_a);
                maybe_save_scalar(s_df_a_levels, r.df_a_levels);
                maybe_save_scalar(s_df_a_exact, r.df_a_exact);
                maybe_save_scalar(s_df_a_nested, r.df_a_nested);
                maybe_save_scalar(s_model_has_constant, r.model_has_constant ? 1.0 : 0.0);
                maybe_save_scalar(s_r2, r.r2);
                maybe_save_scalar(s_r2_within, r.r2_within);
                maybe_save_scalar(s_sigma2, r.sigma2);
                maybe_save_scalar(s_rss, r.rss);
                maybe_save_scalar(s_tss, r.tss);
                maybe_save_scalar(s_tss_within, r.tss_within);
                maybe_save_scalar(s_saturated, r.is_saturated() ? 1.0 : 0.0);
                maybe_save_scalar(s_iterations, static_cast<double>(r.num_iterations));
                maybe_save_scalar(s_converged, r.converged ? 1.0 : 0.0);
                maybe_save_scalar(s_abs_residual, r.abs_residual);
                maybe_save_scalar(s_abs_residual_rel, r.abs_residual_rel);
                maybe_save_scalar(s_krylov_internal_tolerance,
                                  stata_krylov_diagnostic(r.krylov_internal_tolerance));
                maybe_save_scalar(s_krylov_max_final_backward_error,
                                  stata_krylov_diagnostic(
                                      r.krylov_max_final_backward_error));
                maybe_save_scalar(s_krylov_max_condition,
                                  stata_krylov_diagnostic(r.krylov_max_condition));
                maybe_save_scalar(s_krylov_max_condition_times_backward_error,
                                  stata_krylov_diagnostic(
                                      r.krylov_max_condition_times_backward_error));
                save_auto_routing_retry(r);
                maybe_save_scalar(s_slope_block_checked, r.slope_block_checked ? 1.0 : 0.0);
                maybe_save_scalar(s_slope_block_residual_rel, r.slope_block_residual_rel);
                maybe_save_scalar(s_slope_block_frobenius_rel, r.slope_block_frobenius_rel);
                maybe_save_scalar(s_slope_block_rms_rel, r.slope_block_rms_rel);
                maybe_save_scalar(s_slope_block_max_rel, r.slope_block_max_rel);
                maybe_save_scalar(s_slope_block_skipped_max_rel,
                                  r.slope_block_skipped_max_rel);
                maybe_save_scalar(s_slope_certificate_worst_fe,
                                  static_cast<double>(r.slope_certificate_worst_fe));
                maybe_save_scalar(s_slope_certificate_worst_moment,
                                  static_cast<double>(r.slope_certificate_worst_moment));
                maybe_save_scalar(s_slope_accuracy_retry_stages,
                                  static_cast<double>(r.slope_accuracy_retry_stages));
                maybe_save_scalar(s_slope_accuracy_retry_iterations,
                                  static_cast<double>(r.slope_accuracy_retry_iterations));
                maybe_save_scalar(s_slope_internal_tolerance,
                                  r.slope_internal_tolerance);
                maybe_save_scalar(s_precision_certified,
                                  r.precision_certified ? 1.0 : 0.0);
                maybe_save_scalar(s_fe_recovery_converged, r.fe_recovery_converged ? 1.0 : 0.0);
                maybe_save_scalar(s_fe_recovery_iterations, static_cast<double>(r.fe_recovery_iterations));
                maybe_save_scalar(s_fe_recovery_max_delta, r.fe_recovery_max_delta);
                maybe_save_thread_diagnostics(
                    s_threads_used, s_threads_requested, s_threads_effective,
                    s_parallel_workers_active, s_thread_capacity,
                    s_openmp_enabled, s_thread_limit_code, reg,
                    parallel_read_threads_used(parallel_read),
                    parallel_read_workers_active(parallel_read));
                maybe_save_scalar(s_gpu_used, reg.gpu_used() ? 1.0 : 0.0);
                maybe_save_gpu_diagnostics(s_gpu_status_code, s_gpu_attempted,
                                           s_gpu_absorption_converged,
                                           s_gpu_absorption_iterations, reg);
                maybe_save_scalar(s_cuda_tail_code, static_cast<double>(reg.cuda_tail_code()));
                maybe_save_scalar(s_method_used, static_cast<double>(static_cast<int>(reg.absorption_method_used())));
                maybe_save_reduced_pcg(s_reduced_pcg_status, m_reduced_pcg_reason,
                                       s_reduced_pcg_discarded_iterations, reg);
                maybe_save_fine_and_read(fine_read_results, reg, parallel_read);
                slope_outputs.save(reg);
                maybe_save_scalar(s_num_clusters, static_cast<double>(r.num_clusters));
                maybe_save_scalar(s_cluster_scale, r.cluster_scale);
                maybe_save_scalar(s_vcv_psd_fixed, r.vcv_psd_fixed ? 1.0 : 0.0);
                maybe_store_cluster_diag(cluster_diag, r);
                maybe_store_dof_table(dof_table, r);
                maybe_store_omit_reason(omit_reason, r);

                if (r.sample_index.size() != r.nobs) {
                    throw_with_prefix("xhdfe plugin: ", "unexpected sample_index size");
                }
                std::vector<const double*> fe_ptrs;
                if (store_fes) {
                    if (static_cast<int>(r.fe_effects.size()) != nfe) {
                        throw_with_prefix("xhdfe plugin: ", "unexpected fe_effects size");
                    }
                    fe_ptrs.reserve(static_cast<std::size_t>(nfe));
                    for (int d = 0; d < nfe; ++d) {
                        fe_ptrs.push_back(r.fe_effects[static_cast<std::size_t>(d)].data());
                    }
                }

                if (store_fes) {
                    std::ostringstream oss;
                    oss << "event=plugin_writeback_begin mode=group_collapsed nobs=" << r.nobs
                        << " nfe=" << nfe;
                    plugin_savefe_profile_log(oss.str());
                }
                std::optional<PluginSavefeTimer> writeback_timer;
                if (store_fes) {
                    writeback_timer.emplace("plugin_writeback_group_collapsed");
                }
                for (int i = 0; i < r.nobs; ++i) {
                    const int gi = r.sample_index(i);
                    if (gi < 0 || gi >= G) {
                        throw_with_prefix("xhdfe plugin: ", "invalid sample_index in grouped regression");
                    }
                    const int obs_no = rep_obs[static_cast<std::size_t>(gi)];
                    if (store_resid) {
                        const ST_retcode rc =
                            SF_vstore(idx_resid_out, obs_no, r.residuals(i));
                        if (rc) {
                            throw_with_prefix("xhdfe plugin: ", "failed to store residuals");
                        }
                    }
                    if (store_groupvar) {
                        const double gv = (r.groupvar.size() == r.nobs)
                                              ? static_cast<double>(r.groupvar(i))
                                              : SV_missval;
                        const ST_retcode rc = SF_vstore(idx_groupvar_out, obs_no, gv);
                        if (rc) {
                            throw_with_prefix("xhdfe plugin: ", "failed to store groupvar");
                        }
                    }
                    if (store_fes) {
                        for (int d = 0; d < nfe; ++d) {
                            const ST_retcode rc = SF_vstore(idx_fes_out_start + d, obs_no,
                                                            fe_ptrs[static_cast<std::size_t>(d)][i]);
                            if (rc) {
                                throw_with_prefix("xhdfe plugin: ", "failed to store fe_effects");
                            }
                        }
                    }
                    const ST_retcode rc = SF_vstore(idx_esample_out, obs_no, 1.0);
                    if (rc) {
                        throw_with_prefix("xhdfe plugin: ", "failed to store e(sample)");
                    }
                }

                return static_cast<ST_retcode>(0);
            }

            // Full group/individual mode.
            const Eigen::VectorXi& individual_ids =
                fes[static_cast<std::size_t>(individual_fe_pos - 1)];

            const GroupAggregation agg = parse_aggregation(args.get_required("aggregation"));

            reg.fit_grouped(y, X, fes, group_ids, &individual_ids, agg, w_ptr, c_ptr);
            if (importance_weights) reg.apply_importance_weights(*w_ptr);
            const hdfe::HdfeResults& r = reg.results();

            if (r.coefficients.size() > 0) {
                store_row_vector(bmat, r.coefficients);
                store_matrix(Vmat, r.covariance);
            }

            maybe_save_scalar(s_N, r.nobs_effective);
            maybe_save_scalar(s_N_full, r.nobs_full_effective);
            maybe_save_scalar(s_num_singletons, r.num_singletons_effective);
            maybe_save_scalar(s_df_r, r.df_resid);
            maybe_save_scalar(s_df_r_unadj, r.df_resid_unadj);
            maybe_save_scalar(s_df_m, r.df_m);
            maybe_save_scalar(s_df_a, r.df_a);
            maybe_save_scalar(s_df_a_levels, r.df_a_levels);
            maybe_save_scalar(s_df_a_exact, r.df_a_exact);
            maybe_save_scalar(s_df_a_nested, r.df_a_nested);
            maybe_save_scalar(s_model_has_constant, r.model_has_constant ? 1.0 : 0.0);
            maybe_save_scalar(s_r2, r.r2);
            maybe_save_scalar(s_r2_within, r.r2_within);
            maybe_save_scalar(s_sigma2, r.sigma2);
            maybe_save_scalar(s_rss, r.rss);
            maybe_save_scalar(s_tss, r.tss);
            maybe_save_scalar(s_tss_within, r.tss_within);
            maybe_save_scalar(s_saturated, r.is_saturated() ? 1.0 : 0.0);
            maybe_save_scalar(s_iterations, static_cast<double>(r.num_iterations));
            maybe_save_scalar(s_converged, r.converged ? 1.0 : 0.0);
            maybe_save_scalar(s_abs_residual, r.abs_residual);
            maybe_save_scalar(s_abs_residual_rel, r.abs_residual_rel);
            maybe_save_scalar(s_krylov_internal_tolerance,
                              stata_krylov_diagnostic(r.krylov_internal_tolerance));
            maybe_save_scalar(s_krylov_max_final_backward_error,
                              stata_krylov_diagnostic(
                                  r.krylov_max_final_backward_error));
            maybe_save_scalar(s_krylov_max_condition,
                              stata_krylov_diagnostic(r.krylov_max_condition));
            maybe_save_scalar(s_krylov_max_condition_times_backward_error,
                              stata_krylov_diagnostic(
                                  r.krylov_max_condition_times_backward_error));
            save_auto_routing_retry(r);
            maybe_save_scalar(s_slope_block_checked, r.slope_block_checked ? 1.0 : 0.0);
            maybe_save_scalar(s_slope_block_residual_rel, r.slope_block_residual_rel);
            maybe_save_scalar(s_slope_block_frobenius_rel, r.slope_block_frobenius_rel);
            maybe_save_scalar(s_slope_block_rms_rel, r.slope_block_rms_rel);
            maybe_save_scalar(s_slope_block_max_rel, r.slope_block_max_rel);
            maybe_save_scalar(s_slope_block_skipped_max_rel,
                              r.slope_block_skipped_max_rel);
            maybe_save_scalar(s_slope_certificate_worst_fe,
                              static_cast<double>(r.slope_certificate_worst_fe));
            maybe_save_scalar(s_slope_certificate_worst_moment,
                              static_cast<double>(r.slope_certificate_worst_moment));
            maybe_save_scalar(s_slope_accuracy_retry_stages,
                              static_cast<double>(r.slope_accuracy_retry_stages));
            maybe_save_scalar(s_slope_accuracy_retry_iterations,
                              static_cast<double>(r.slope_accuracy_retry_iterations));
            maybe_save_scalar(s_slope_internal_tolerance,
                              r.slope_internal_tolerance);
            maybe_save_scalar(s_precision_certified,
                              r.precision_certified ? 1.0 : 0.0);
            maybe_save_scalar(s_fe_recovery_converged, r.fe_recovery_converged ? 1.0 : 0.0);
            maybe_save_scalar(s_fe_recovery_iterations, static_cast<double>(r.fe_recovery_iterations));
            maybe_save_scalar(s_fe_recovery_max_delta, r.fe_recovery_max_delta);
            maybe_save_thread_diagnostics(
                s_threads_used, s_threads_requested, s_threads_effective,
                s_parallel_workers_active, s_thread_capacity,
                s_openmp_enabled, s_thread_limit_code, reg,
                parallel_read_threads_used(parallel_read),
                parallel_read_workers_active(parallel_read));
            maybe_save_scalar(s_gpu_used, reg.gpu_used() ? 1.0 : 0.0);
            maybe_save_gpu_diagnostics(s_gpu_status_code, s_gpu_attempted,
                                       s_gpu_absorption_converged,
                                       s_gpu_absorption_iterations, reg);
            maybe_save_scalar(s_cuda_tail_code, static_cast<double>(reg.cuda_tail_code()));
            maybe_save_scalar(s_method_used, static_cast<double>(static_cast<int>(reg.absorption_method_used())));
            maybe_save_reduced_pcg(s_reduced_pcg_status, m_reduced_pcg_reason,
                                   s_reduced_pcg_discarded_iterations, reg);
            maybe_save_fine_and_read(fine_read_results, reg, parallel_read);
            slope_outputs.save(reg);
            maybe_save_scalar(s_num_clusters, static_cast<double>(r.num_clusters));
            maybe_save_scalar(s_cluster_scale, r.cluster_scale);
            maybe_save_scalar(s_vcv_psd_fixed, r.vcv_psd_fixed ? 1.0 : 0.0);
            maybe_store_cluster_diag(cluster_diag, r);
            maybe_store_dof_table(dof_table, r);
            maybe_store_omit_reason(omit_reason, r);

            if (r.sample_index.size() != r.nobs) {
                throw_with_prefix("xhdfe plugin: ", "unexpected sample_index size in grouped regression");
            }
            for (int i = 0; i < r.nobs; ++i) {
                const int orig = r.sample_index(i);
                if (orig < 0 || orig >= n) {
                    throw_with_prefix("xhdfe plugin: ", "invalid sample_index in grouped regression");
                }
                const int obs_no = obs.obs_no(orig);
                if (store_resid) {
                    const ST_retcode rc =
                        SF_vstore(idx_resid_out, obs_no, r.residuals(i));
                    if (rc) {
                        throw_with_prefix("xhdfe plugin: ", "failed to store residuals");
                    }
                }
                if (store_groupvar) {
                    const double gv = (r.groupvar.size() == r.nobs)
                                          ? static_cast<double>(r.groupvar(i))
                                          : SV_missval;
                    const ST_retcode rc = SF_vstore(idx_groupvar_out, obs_no, gv);
                    if (rc) {
                        throw_with_prefix("xhdfe plugin: ", "failed to store groupvar");
                    }
                }
                const ST_retcode rc = SF_vstore(idx_esample_out, obs_no, 1.0);
                if (rc) {
                    throw_with_prefix("xhdfe plugin: ", "failed to store e(sample)");
                }
            }
            return static_cast<ST_retcode>(0);
        }

        // Standard HDFE mode (observation-level).
        laps.lap("fit_setup");
        const auto fit_standard_t0 = std::chrono::steady_clock::now();
        reg.fit(y, X, fes, w_ptr, c_ptr, inst_ptr, endogenous_idx,
                slopes.empty() ? nullptr : &slopes);
        if (importance_weights) reg.apply_importance_weights(*w_ptr);
        plugin_cpu_profile_log_elapsed("fit_standard", fit_standard_t0);
        laps.restart();
        const hdfe::HdfeResults& r = reg.results();

        if (r.coefficients.size() > 0) {
            store_row_vector(bmat, r.coefficients);
            store_matrix(Vmat, r.covariance);
        }

        maybe_save_scalar(s_N, r.nobs_effective);
        maybe_save_scalar(s_N_full, r.nobs_full_effective);
        maybe_save_scalar(s_num_singletons, r.num_singletons_effective);
        maybe_save_scalar(s_df_r, r.df_resid);
        maybe_save_scalar(s_df_r_unadj, r.df_resid_unadj);
        maybe_save_scalar(s_df_m, r.df_m);
        maybe_save_scalar(s_df_a, r.df_a);
        maybe_save_scalar(s_df_a_levels, r.df_a_levels);
        maybe_save_scalar(s_df_a_exact, r.df_a_exact);
        maybe_save_scalar(s_df_a_nested, r.df_a_nested);
        maybe_save_scalar(s_model_has_constant, r.model_has_constant ? 1.0 : 0.0);
        maybe_save_scalar(s_r2, r.r2);
        maybe_save_scalar(s_r2_within, r.r2_within);
        maybe_save_scalar(s_sigma2, r.sigma2);
        maybe_save_scalar(s_rss, r.rss);
        maybe_save_scalar(s_tss, r.tss);
        maybe_save_scalar(s_tss_within, r.tss_within);
        maybe_save_scalar(s_saturated, r.is_saturated() ? 1.0 : 0.0);
        maybe_save_scalar(s_iterations, static_cast<double>(r.num_iterations));
        maybe_save_scalar(s_converged, r.converged ? 1.0 : 0.0);
        maybe_save_scalar(s_abs_residual, r.abs_residual);
        maybe_save_scalar(s_abs_residual_rel, r.abs_residual_rel);
        maybe_save_scalar(s_krylov_internal_tolerance,
                          stata_krylov_diagnostic(r.krylov_internal_tolerance));
        maybe_save_scalar(s_krylov_max_final_backward_error,
                          stata_krylov_diagnostic(
                              r.krylov_max_final_backward_error));
        maybe_save_scalar(s_krylov_max_condition,
                          stata_krylov_diagnostic(r.krylov_max_condition));
        maybe_save_scalar(s_krylov_max_condition_times_backward_error,
                          stata_krylov_diagnostic(
                              r.krylov_max_condition_times_backward_error));
        save_auto_routing_retry(r);
        maybe_save_scalar(s_slope_block_checked, r.slope_block_checked ? 1.0 : 0.0);
        maybe_save_scalar(s_slope_block_residual_rel, r.slope_block_residual_rel);
        maybe_save_scalar(s_slope_block_frobenius_rel, r.slope_block_frobenius_rel);
        maybe_save_scalar(s_slope_block_rms_rel, r.slope_block_rms_rel);
        maybe_save_scalar(s_slope_block_max_rel, r.slope_block_max_rel);
        maybe_save_scalar(s_slope_block_skipped_max_rel,
                          r.slope_block_skipped_max_rel);
        maybe_save_scalar(s_slope_certificate_worst_fe,
                          static_cast<double>(r.slope_certificate_worst_fe));
        maybe_save_scalar(s_slope_certificate_worst_moment,
                          static_cast<double>(r.slope_certificate_worst_moment));
        maybe_save_scalar(s_slope_accuracy_retry_stages,
                          static_cast<double>(r.slope_accuracy_retry_stages));
        maybe_save_scalar(s_slope_accuracy_retry_iterations,
                          static_cast<double>(r.slope_accuracy_retry_iterations));
        maybe_save_scalar(s_slope_internal_tolerance,
                          r.slope_internal_tolerance);
        maybe_save_scalar(s_precision_certified,
                          r.precision_certified ? 1.0 : 0.0);
        maybe_save_scalar(s_fe_recovery_converged, r.fe_recovery_converged ? 1.0 : 0.0);
        maybe_save_scalar(s_fe_recovery_iterations, static_cast<double>(r.fe_recovery_iterations));
        maybe_save_scalar(s_fe_recovery_max_delta, r.fe_recovery_max_delta);
        maybe_save_scalar(s_gpu_used, reg.gpu_used() ? 1.0 : 0.0);
        maybe_save_gpu_diagnostics(s_gpu_status_code, s_gpu_attempted,
                                   s_gpu_absorption_converged,
                                   s_gpu_absorption_iterations, reg);
        maybe_save_scalar(s_cuda_tail_code, static_cast<double>(reg.cuda_tail_code()));
        maybe_save_scalar(s_method_used, static_cast<double>(static_cast<int>(reg.absorption_method_used())));
        maybe_save_reduced_pcg(s_reduced_pcg_status, m_reduced_pcg_reason,
                               s_reduced_pcg_discarded_iterations, reg);
        maybe_save_fine_and_read(fine_read_results, reg, parallel_read);
        slope_outputs.save(reg);
        maybe_save_scalar(s_num_clusters, static_cast<double>(r.num_clusters));
        maybe_save_scalar(s_cluster_scale, r.cluster_scale);
        maybe_save_scalar(s_vcv_psd_fixed, r.vcv_psd_fixed ? 1.0 : 0.0);
        maybe_store_cluster_diag(cluster_diag, r);
        maybe_store_dof_table(dof_table, r);
        maybe_store_omit_reason(omit_reason, r);

        if (r.sample_index.size() != r.nobs) {
            throw_with_prefix("xhdfe plugin: ", "unexpected sample_index size");
        }

        std::vector<uint8_t> keep;
        if (esample_prefilled && r.nobs < n) {
            keep.assign(static_cast<std::size_t>(n), 0);
        }

        if (store_fes) {
            std::ostringstream oss;
            oss << "event=plugin_writeback_begin mode=standard nobs=" << r.nobs
                << " nfe=" << nfe
                << " out_fes=" << out_fes;
            plugin_savefe_profile_log(oss.str());
        }
        std::optional<PluginSavefeTimer> writeback_timer;
        if (store_fes) {
            writeback_timer.emplace("plugin_writeback_standard");
        }
        laps.lap("results_store");
        const auto writeback_standard_t0 = std::chrono::steady_clock::now();
        const int mark_team =
            esample_prefilled && !store_resid && !store_groupvar && !store_fes
                ? writeback_team(reg, r.nobs)
                : 1;
        std::optional<ParallelWorkObserver> writeback_observer;
        if (mark_team > 1) {
            writeback_observer.emplace();
            if (!mark_kept_rows_on_team(r.sample_index, n, keep, mark_team,
                                        *writeback_observer)) {
                throw_with_prefix("xhdfe plugin: ", "invalid sample_index");
            }
        }
        for (int i = 0; mark_team <= 1 && i < r.nobs; ++i) {
            const int orig = r.sample_index(i);
            if (orig < 0 || orig >= n) {
                throw_with_prefix("xhdfe plugin: ", "invalid sample_index");
            }
            if (!keep.empty()) {
                keep[static_cast<std::size_t>(orig)] = 1;
            }
            const int obs_no = obs.obs_no(orig);
            if (store_resid) {
                const ST_retcode rc =
                    SF_vstore(idx_resid_out, obs_no, r.residuals(i));
                if (rc) {
                    throw_with_prefix("xhdfe plugin: ", "failed to store residuals");
                }
            }
            if (store_groupvar) {
                const double gv = (r.groupvar.size() == r.nobs)
                                      ? static_cast<double>(r.groupvar(i))
                                      : SV_missval;
                const ST_retcode rc = SF_vstore(idx_groupvar_out, obs_no, gv);
                if (rc) {
                    throw_with_prefix("xhdfe plugin: ", "failed to store groupvar");
                }
            }
            if (store_fes) {
                const std::vector<Eigen::VectorXd>& fe_write =
                    r.fe_save_effects.empty() ? r.fe_effects : r.fe_save_effects;
                if (static_cast<int>(fe_write.size()) != out_fes) {
                    throw_with_prefix("xhdfe plugin: ", "unexpected saved FE effect count");
                }
                for (int d = 0; d < out_fes; ++d) {
                    const ST_retcode rc = SF_vstore(idx_fes_out_start + d, obs_no,
                                                    fe_write[static_cast<std::size_t>(d)](i));
                    if (rc) {
                        throw_with_prefix("xhdfe plugin: ", "failed to store saved FE effects");
                    }
                }
            }
            if (!esample_prefilled) {
                const ST_retcode rc = SF_vstore(idx_esample_out, obs_no, 1.0);
                if (rc) {
                    throw_with_prefix("xhdfe plugin: ", "failed to store e(sample)");
                }
            }
        }

        // When the ado prefills e(sample)=1 for the candidate sample, clear dropped observations
        // only. This avoids O(nobs) SF_vstore calls on large panels when singletons are dropped.
        if (!keep.empty()) {
            const auto clear_row = [&](int i) {
                const int obs_no = obs.obs_no(i);
                const ST_retcode rc = SF_vstore(idx_esample_out, obs_no, 0.0);
                if (rc) {
                    throw_with_prefix("xhdfe plugin: ", "failed to clear e(sample)");
                }
            };
            std::optional<std::vector<int>> dropped_rows;
            if (writeback_observer && n - r.nobs <= kWritebackMaxBufferedRows) {
                try {
                    dropped_rows = unmarked_rows_on_team(keep, mark_team, *writeback_observer);
                } catch (const std::bad_alloc&) {
                    // The original scan needs no temporary list.
                }
            }
            if (dropped_rows) {
                for (const int i : *dropped_rows) {
                    clear_row(i);
                }
            } else {
                for (int i = 0; i < n; ++i) {
                    if (!keep[static_cast<std::size_t>(i)]) {
                        clear_row(i);
                    }
                }
            }
        }
        const int writeback_workers = writeback_observer ? writeback_observer->active_workers() : 1;
        const int writeback_threads = writeback_observer ? writeback_observer->max_team_size() : 1;
        if (plugin_cpu_profile_enabled()) {
            std::cerr << "plugin_profile label=writeback_work team=" << writeback_threads
                      << " workers=" << writeback_workers << '\n';
        }
        maybe_save_thread_diagnostics(
            s_threads_used, s_threads_requested, s_threads_effective,
            s_parallel_workers_active, s_thread_capacity,
            s_openmp_enabled, s_thread_limit_code, reg,
            std::max(parallel_read_threads_used(parallel_read), writeback_threads),
            std::max(parallel_read_workers_active(parallel_read), writeback_workers));
        plugin_cpu_profile_log_elapsed("writeback_standard", writeback_standard_t0);
        plugin_cpu_profile_log_elapsed("plugin_total", plugin_total_t0);

        return static_cast<ST_retcode>(0);
    } catch (const std::exception& e) {
        std::string msg = e.what();
        if (msg.find("no observations remain for estimation") != std::string::npos) {
            return static_cast<ST_retcode>(2001);  // insufficient observations
        }
        if (msg.find("No observations left after dropping singleton observations") !=
            std::string::npos) {
            return static_cast<ST_retcode>(2000);
        }
        if (msg.empty() || msg.back() != '\n') {
            msg.push_back('\n');
        }
        const bool numerical_failure =
            msg.find(": did not converge;") != std::string::npos ||
            msg.find(": precision certification failed;") != std::string::npos ||
            msg.find(": heterogeneous-slope acceptance criteria not met after continuation;") !=
                std::string::npos ||
            msg.find("fixed-effect recovery did not converge") != std::string::npos ||
            msg.find("Fixed-effect recovery did not converge") != std::string::npos ||
            msg.find("FE extraction absorption did not converge") != std::string::npos ||
            msg.find("group FE rank is numerically ambiguous") != std::string::npos ||
            msg.find("dofadjustments(exact): rational rank") != std::string::npos ||
            msg.find(
                "Group/individual HDFE absorption did not converge; "
                "no estimates were produced") != std::string::npos ||
            msg.find(
                "Group/individual HDFE absorption failed the independent "
                "precision certificate; no estimates were produced") !=
                std::string::npos;
        SF_error(const_cast<char*>(msg.c_str()));
        return static_cast<ST_retcode>(numerical_failure ? 498 : 198);
    } catch (...) {
        const char* msg = "xhdfe plugin: unknown error\n";
        SF_error(const_cast<char*>(msg));
        return static_cast<ST_retcode>(198);
    }
}
