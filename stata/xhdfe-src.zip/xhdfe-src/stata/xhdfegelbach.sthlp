{smcl}
{* *! version 1.6.2  25nov2026}{...}
{vieweralsosee "xhdfe" "help xhdfe"}{...}
{vieweralsosee "xhdfeakm" "help xhdfeakm"}{...}
{vieweralsosee "xhdfegelbachbootstrap" "help xhdfegelbachbootstrap"}{...}
{vieweralsosee "xhdfegelbachetable" "help xhdfegelbachetable"}{...}
{vieweralsosee "xhdfegelbachcoefplot" "help xhdfegelbachcoefplot"}{...}
{title:Title}

{p2colset 5 22 24 2}{...}
{p2col :{cmd:xhdfegelbach} {hline 2}}Gelbach (2016) conditional decomposition of coefficient movements{p_end}
{p2colreset}{...}

{pstd}
{bf:Version 1.6.2 (25nov2026), distributed with shared package}
{bf:2.35.1.20261125.} The shared package includes common HDFE, selectable connectivity
diagnostics, retained-sample provenance, conservative inference gates, and the
bootstrap/table/waterfall companion commands.{p_end}


{title:Syntax}

{p 8 15 2}
{cmd:xhdfegelbach} {depvar} {ifin} {weight}{cmd:,}
{opt x1(varlist)}
[{it:options}]

{synoptset 26 tabbed}{...}
{synopthdr}
{synoptline}
{synopt :{opt x1(varlist)}}base covariates whose coefficient movement is decomposed; {bf:required}{p_end}
{synopt :{opt x2groups(spec)}}named covariate groups added in the full model{p_end}
{synopt :{opth fes(varlist)}}fixed-effect dimensions added in the full model{p_end}
{synopt :{opth commonfes(varlist)}}fixed-effect dimensions absorbed in both base and full models{p_end}
{synopt :{opt connected(mode)}}{cmd:diagnose} (default) or fail-closed {cmd:require}{p_end}
{synopt :{opt connectivityfes(varlist)}}exactly two variables from {opt fes()} used by the pair diagnostic{p_end}
{synopt :{opt absorbedtargets(varlist)}}opt-in X1 targets absorbed by {opt fes()}; full coefficients imposed at zero{p_end}
{synopt :{opt focal(varlist)}}subset of {opt x1()} displayed as focal; reporting only{p_end}
{synopt :{opt shares(type)}}signed shares of {cmd:movement}, {cmd:base}, or {cmd:base_fixed}{p_end}
{synopt :{opt sharetol(#)}}absolute denominator threshold for shares; default {cmd:1e-12}{p_end}
{synopt :{opt sharetmin(#)}}minimum denominator |t| for first-order share inference; default {cmd:3}{p_end}
{synopt :{opt fevarmin(#)}}residual/total X1 variance-ratio gate for conditional FE inference; default {cmd:0.35}{p_end}
{synopt :{opt level(#)}}confidence level used for share intervals; default {cmd:c(level)}{p_end}
{synopt :{opt vce(vcetype)}}{cmd:unadjusted} (default), {cmd:robust}, or {cmd:cluster}{p_end}
{synopt :{opth cluster(varname)}}cluster identifier (with {cmd:vce(cluster)}){p_end}
{synopt :{opt gamma0}}reproduce b1x2's {cmd:gamma0} variant{p_end}
{synopt :{opt cov0}}reproduce b1x2's {cmd:cov0} variant{p_end}
{synopt :{opt tol(#)}}FE absorption tolerance; default {cmd:1e-8}{p_end}
{synopt :{opt threads(#)}}explicit OpenMP request (0 = automatic policy){p_end}
{synopt :{opt gpu}}request CUDA for the full HDFE absorption{p_end}
{synopt :{opt weightedcpuroute(on|off)}}request CPU for eligible weighted CUDA fits; default {cmd:off}{p_end}
{synopt :{opt verbose}}stream deterministic phase progress and elapsed time live{p_end}
{synopt :{opt sampleaudit}}compute and return a stable retained-sample identifier{p_end}
{synopt :{opth generate(newvar)}}also generate the retained-sample indicator{p_end}
{synoptline}
{p2colreset}{...}
{p 4 6 2}{cmd:aweight}s and {cmd:fweight}s are allowed (b1x2 conventions).{p_end}


{title:Description}

{pstd}
{cmd:xhdfegelbach} implements the Gelbach (2016) decomposition: it accounts for the
movement of the {opt x1()} coefficients between the {it:base} regression
({it:y} on {it:x1}, absorbing {opt commonfes()}) and the {it:full} regression
({it:y} on {it:x1} plus the covariate groups in {opt x2groups()} and the added
fixed effects in {opt fes()}, while absorbing the same {opt commonfes()}) as a
sum of observed and added-FE contributions

{p 8 8 2}{it:delta_g = (X1'X1)^-1 X1'X2g beta_g}{p_end}

{pstd}
with a standard error for each contribution. The contributions sum exactly to
the total coefficient movement ({it:base} minus {it:full}); the residual of
that identity is returned in {cmd:r(identity_gap)}. Numerical semantics follow
Gelbach's {cmd:b1x2} (the reference implementation this command is validated
against), including its {opt gamma0}/{opt cov0} variants and the aweight/
fweight conventions. Fixed-effect groups are absorbed with the xhdfe backend,
so high-dimensional FE groups are practical. Shares the compiled backend with
the Python {cmd:xhdfe.gelbach.decompose} and R {cmd:xhdfe_gelbach} front-ends.

{pstd}
The default is the standard Gelbach estimand and continues to reject every
rank-deficient {opt x1()} or X2 column. {opt absorbedtargets()} activates a
different, constrained estimand for named {opt x1()} columns that belong to
the span of the added FE (for example, a worker-invariant group indicator with
worker FE). Every declared target must be classified by the backend
specifically as collinear with {opt fes()}; its full-model coefficient is
imposed at zero, not estimated. Undeclared omissions and other rank failures
remain errors. The result is labelled {cmd:absorbed_target_allocation}.{p_end}

{pstd}{bf:Interpretation warning.} This is a decomposition of coefficient
movement for two declared specifications, not causal mediation. Causal
interpretation requires a separately justified research design. Adding
post-treatment variables, colliders, or fixed effects that alter the identifying
comparisons can change the estimand or introduce bias. Block names and causal
roles are supplied by the researcher and are not validated by the command.{p_end}


{title:Specification and sample contract}

{pstd}
The decomposition always uses one jointly declared full model. Every
{opt commonfes()} dimension is absorbed in both specifications; every
{opt x2groups()} block and every {opt fes()} dimension is added simultaneously;
their order does not create a sequential or path-dependent allocation. Group
names must be valid, unique Stata names. Observed variables may appear in only
one block and may not overlap {opt x1()}. Empty groups, duplicate variables,
cross-block rank dependencies and undeclared omissions fail closed.{p_end}

{pstd}
Stata constructs one common complete-case sample using the outcome, all X1/X2
columns, common and added FE identifiers, cluster identifier and weight. The
backend drops recursive singletons using the union of common and added FEs.
Base, full and auxiliary projections then use exactly that retained full-model
sample, the same weight inner product, and the same common-FE projection.
Inspect
{cmd:r(n_obs_input)}, {cmd:r(n_obs)}, {cmd:r(n_obs_effective)} and
{cmd:r(n_singletons_dropped)}. With {cmd:fweight}, the displayed and effective
N is the sum of retained weights; {cmd:r(n_obs)} remains the retained row
count.{p_end}

{pstd}
Counts alone do not identify which rows survived recursive singleton removal.
{opt sampleaudit} therefore requests a stable, non-cryptographic retained-
sample hash. {opt generate(newvar)} additionally creates a byte indicator:
missing outside Stata's marked input sample, 0 for marked rows dropped as
singletons, and 1 for retained rows. The hash is defined on zero-based
positions within that marked input, binds input row order as well as
membership, and uses the declared {cmd:fnv1a64-le-v1} byte contract. It is a
reproducibility identifier, not a cryptographic integrity guarantee. Both
options are opt-in, so the default path performs no O(N) provenance hash or
output write.{p_end}

{pstd}
The implicit intercept belongs to both models. Do not include a manually
generated constant in {opt x1()}. The matrices {cmd:r(delta)}, {cmd:r(se)} and
{cmd:r(total)} nevertheless retain an explicit final {cmd:_cons} row for
cross-frontend compatibility. Without {opt commonfes()}, it preserves the
historical auditable normalization shift. With {opt commonfes()}, all entries
in that row and the corresponding covariance rows/columns are missing because
the intercept allocation depends on the common-FE normalization. The slope
identity and slope inference remain available.{p_end}


{title:Displayed output}

{pstd}
The default display is organized as one panel for each coefficient in
{opt x1()}, followed by the intercept only when {opt commonfes()} is empty.
Each {opt x1()} panel first reports the
base-model coefficient, full-model coefficient, total movement
({it:base minus full}), and its standard error. It then reports each declared
covariate and absorbed-FE block with its contribution and standard error. When
{opt fes()} is used, an FE subtotal is shown without adding it again to the
overall total.{p_end}

{pstd}
In absorbed-target mode, the display identifies the constrained targets next
to the estimand. The full-coefficient cell itself reads {cmd:0 (imposed)} so
the restriction remains visible when a row is transcribed without its header.
It must not be described as an estimated within-FE coefficient.{p_end}

{pstd}
With {opt focal()}, only the selected coefficient panels are printed; all
variables in {opt x1()} remain in both the base and full models and all
full-precision rows remain in {cmd:r()}. This separates the empirical focal
coefficient from low-dimensional controls common to both specifications
without changing the estimand. With {opt shares()}, the table adds signed
percentages. Negative shares and totals above 100 percent are deliberately
preserved and never renormalized.{p_end}

{pstd}
The final status panel reports convergence and the maximum residual from the
summation identity. This residual is a consistency check, not an accuracy or
causal-identification certificate. Displayed values use compact significant-
digit formatting; all matrices in {cmd:r()} retain their full double-precision
values. Solver and inferential warnings are printed in full immediately and
are also retained in {cmd:r(notes)}.{p_end}


{title:Options}

{phang}{opt x1(varlist)} lists the base covariates whose coefficient movement
is decomposed. {bf:Required}.

{phang}{cmd:aweight} and {cmd:fweight} apply the same strictly positive weight
to the base, full and auxiliary projections. Frequency weights must be positive
integers; their sum defines {cmd:r(n_obs_effective)}. Probability, importance
and survey weights are not implemented by this command.{p_end}

{phang}{opt x2groups(spec)} names the covariate groups added in the full model
with the b1x2-style syntax {cmd:x2groups("A = a1 a2 : B = b1 b2 b3")} (groups
separated by colons; each group is {it:name} {cmd:=} {it:varlist}). Each named
group becomes one column of the contribution matrix.

{phang}{opth fes(varlist)} gives fixed-effect dimensions (numeric categorical
identifiers) added in the full model, each absorbed with the xhdfe backend and
treated as its own group (always gamma0-style). Raw codes outside the signed
32-bit range, and non-integer numeric labels, are compacted internally without
changing category membership or results.

{phang}{opth commonfes(varlist)} gives fixed-effect dimensions absorbed in both
the base and full models. They condition the decomposition and do not become
component columns in {cmd:r(delta)}. Their identifiers follow the same exact
categorical compaction rule as {opt fes()}. At least one {opt x2groups()} block
or added dimension in {opt fes()} is still required; common FEs alone leave
nothing to decompose.{p_end}

{phang}{opt connected(mode)} controls the FE-split connectivity gate.
{cmd:connected(diagnose)} is the default: it reports the selected-pair
diagnostic without changing the sample or fit. {cmd:connected(require)} fails
closed unless {opt commonfes()} is empty and exactly two retained added FE
dimensions form one mobility component. It rejects specifications with common
FEs or fewer/more than two added FEs because those per-dimension splits are not
yet connectivity-certified.{p_end}

{phang}{opt connectivityfes(varlist)} selects exactly two distinct variables
from the added dimensions in {opt fes()} for the retained-sample pair
diagnostic. A variable in {opt commonfes()} cannot be selected. The default is
the first two added FE dimensions. With common FEs or three or more added FEs,
a connected selected pair is still only a diagnostic and never upgrades the
global split to identified.{p_end}

{pstd}
Because the two option names share a prefix, {opt connected()} may be
abbreviated to {cmd:conn()}, {cmd:connec()} or {cmd:connect()}, whereas
{opt connectivityfes()} requires at least {cmd:connecti()}. Spelling the
full names is recommended in reproducibility scripts.{p_end}

{phang}{opt absorbedtargets(varlist)} must be a subset of {opt x1()} and
requires {opt fes()}. It is an explicit request for absorbed-target allocation,
not an instruction to ignore arbitrary collinearity. Each named target must be
omitted because it is in the FE span; if it remains identified, is omitted for
another rank dependency, or any undeclared X1/X2 column is omitted, the command
fails. {cmd:r(b_full_status)} labels each X1 entry as {cmd:estimated} or
{cmd:imposed_zero}.{p_end}

{phang}{opt focal(varlist)} selects a nonempty subset of {opt x1()} for the
human-facing panels and share table. It is reporting metadata only. In
particular, a common control must remain in {opt x1()} even when it is omitted
from {opt focal()}; moving it into {opt x2groups()} changes the base model and
therefore changes the decomposition.{p_end}

{phang}{opt sampleaudit} computes the retained-sample hash and returns
{cmd:r(sample_hash)}, {cmd:r(sample_hash_algorithm)}, and
{cmd:r(sample_index_scope)} without creating a variable. The scope is
{cmd:marked_input_rows_zero_based}: compare hashes across frontends only after
supplying the same ordered complete-case input rows.{p_end}

{phang}{opth generate(newvar)} requests the same hash and creates
{it:newvar}=1 for retained marked rows, 0 for recursively dropped marked rows,
and missing outside the marked input. The variable is created only after a
successful backend call and its name is returned in
{cmd:r(sample_variable)}.{p_end}

{phang}{opt shares(type)} adds signed share estimates and stores their
full-precision matrices. {cmd:shares(movement)} divides each contribution by
the total movement and computes ratio SEs by the delta method from the joint
component covariance. {cmd:shares(base)} divides by the base coefficient, the
normalization used in several applications, and computes full ratio SEs and
normal-approximation confidence intervals from {cmd:r(cov)},
{cmd:r(base_cov)}, and {cmd:r(cov_delta_bbase)}. Its variance includes
uncertainty in both numerator and denominator and their covariance:
{p_end}
{p 8 8 2}
{it:Var(delta_g/b) = Var(delta_g)/b^2}
{it:+ delta_g^2 Var(b)/b^4 - 2 delta_g Cov(delta_g,b)/b^3}.
{p_end}
{pstd}
This full ratio convention is labelled
{cmd:joint_base_covariance_delta_method}.
{cmd:shares(base_fixed)} is a separate descriptive convention that scales
component SEs while holding the reported base coefficient fixed; it is labelled
{cmd:fixed_base_denominator_scaling} and must not be presented as full ratio
inference. Contributions in levels remain the primary result.{p_end}

{phang}{opt sharetol(#)} sets the absolute threshold below which a share
denominator is treated as undefined. It must be finite and nonnegative; the
default is {cmd:1e-12}. Undefined shares are missing and generate a warning.
The warning is printed and appended to {cmd:r(notes)}. This protects against
unstable percentages when the gap or movement is nearly zero.{p_end}

{phang}{opt sharetmin(#)} sets the separate weak-denominator diagnostic.
For a defined share, the command computes
{it:|t_den| = |denominator|/se(denominator)} from {cmd:r(base_cov)} for
base shares or {cmd:r(total_cov)} for movement shares. Values below the
default {cmd:3} retain the point share and numerical SE, but receive
{cmd:weak_denominator_delta_method_unreliable}; the SE type gains
{cmd:_weak_denominator_diagnostic_only}, the full-delta-method display header
is suppressed, and one warning directs the user to
{helpb xhdfegelbachbootstrap}. This option does not change
{opt sharetol()} or construct a weak-inference confidence set.{p_end}

{phang}{opt fevarmin(#)} sets the residual-to-total X1 squared-norm threshold
for the conditional FE-variance gate. With added FEs, a ratio at or below the
default {cmd:0.35} sets the corresponding
{cmd:r(fe_variance_status)} entry to
{cmd:conditional_only_between_fe_dominant}; FE-component and mixed-total SE
types gain {cmd:_conditional_only_diagnostic}. Estimates, covariance entries
and numerical SE values are unchanged. This is a reporting gate directing
users to the existing pairs bootstrap, not nonconditional recovered-FE
inference.{p_end}

{phang}{opt level(#)} sets the normal-approximation confidence level for share
intervals. It has no effect unless {opt shares()} is specified and never
changes the underlying Gelbach fit.{p_end}

{pstd}{it:Common fixed effects and generated terms.} High-dimensional effects
common to base and full belong in {opt commonfes()}; added, decomposable effects
belong in {opt fes()}. Explicit low-dimensional indicator columns in
{opt x1()} remain useful when their individual coefficients are desired.
Polynomial, spline, factor, and interaction blocks are supported after
the researcher generates the corresponding numeric columns and groups those
columns explicitly. This keeps the exact design matrix auditable.{p_end}

{pstd}For absorbed FE blocks, the reported standard errors are conditional/
{cmd:gamma0}: uncertainty from estimating the absorbed effects is not fully
included. {cmd:r(fe_total)} reports the aggregate of all added absorbed-FE dimensions;
this is the preferred FE object when the FE graph has several mobility
components.{p_end}

{phang}{opt vce(vcetype)} selects the variance estimator: {cmd:unadjusted}
(default), {cmd:robust}, or {cmd:cluster} (supply {opth cluster(varname)}).
The cluster identifier is compacted under the same exact categorical rule.

{pstd}{it:Few clusters.} One-way clustered estimates remain available when
there are at least two retained clusters, but fewer than 30 triggers a loud
finite-sample warning in the Results window and {cmd:r(notes)}. The count and
warning threshold are returned in {cmd:r(n_clusters)} and
{cmd:r(few_cluster_warning_threshold)}. The command does not silently replace
the requested covariance with a bootstrap or another small-G procedure.{p_end}

{pstd}{bf:Absorbed-target inference.} For a declared target,
{it:total_j = b_base_j - 0} is the base-coefficient estimator itself. Its
target-target entry in {cmd:r(total_cov)} is therefore exactly the requested
base-model VCE. Inference for a target invariant within an absorbing FE must
be clustered at that FE dimension. {cmd:unadjusted}, {cmd:robust}, or
clustering on a crossed dimension can be anti-conservative; these choices are
retained for descriptive accounting but print a loud warning and set
{cmd:r(absorbed_target_inference_valid)} to 0. Inspect
{cmd:r(inference_status)} and {cmd:r(absorbing_fe_index)}.{p_end}

{pstd}The Gelbach covariance follows {cmd:b1x2}'s random-design stacked-
moment variance, including uncertainty in the auxiliary projections. It is
not the smaller variance conditional on the realized covariate design.
Absorbed-FE component covariances remain conditional/{cmd:gamma0}; hence an
absorbed-target total is labelled
{cmd:target_exact_base_vce_mixed_components}.{p_end}

{pstd}{bf:Conditional FE-variance diagnostic.} For every X1 row,
{cmd:r(fe_variance_status)} is {cmd:valid_first_order} unless added FEs are
present and {cmd:r(x1_fe_collinear_ratio)} is at or below
{cmd:r(fe_variance_ratio_min)}. A triggered row is labelled
{cmd:conditional_only_between_fe_dominant}; FE and mixed-total normal
intervals are diagnostic only, while all stored numbers remain unchanged.
Use {helpb xhdfegelbachbootstrap} with pairs resampling for the calibrated
alternative available in this package.{p_end}

{pstd}{bf:Product-regularity diagnostic.} For observed block {it:g} and
coefficient row {it:r}, the contribution is
{it:delta_rg = Gamma_rg beta2_g}; its first derivative is
{it:[beta2_g, Gamma_rg]}. If both parts are zero, the usual first-order
delta approximation is nonregular (Gelbach 2016, footnote 14). The shared
core first performs a requested-VCE joint Wald test of {it:beta2_g=0}. If
that null is not rejected, it performs requested-VCE marginal tests of the
corresponding auxiliary-loading row {it:Gamma_rg=0}, with a within-row
Bonferroni adjustment. Each of these two component tests uses one half of
{cmd:r(regularity_test_alpha)}; the returned value 0.05 is the family-wise
level for their union. Regularity is marked valid only when one null is
rejected. Otherwise the status is
{cmd:nonregular_not_ruled_out}; failure to reject is not proof that the
population gradient is zero.{p_end}

{pstd}
Flagged numerical SEs are retained for diagnosis and reproducibility, but the
Results window, {cmd:r(notes)}, {cmd:r(regular_inference_valid)}, and
{cmd:r(regular_inference_status_code)} state that their normal-theory
confidence intervals and p-values are diagnostic only. This gate covers
observed X2 contributions. Recovered-FE components retain their separate
conditional-inference qualification. The command does not yet construct a
product-aware bootstrap or weak-inference confidence set.{p_end}

{phang}{opt gamma0} retains the auxiliary-regression part of the component
variance and omits the sampling variance of the full-model added coefficients,
matching Gelbach's {cmd:b1x2}. Absorbed-FE components always carry this
conditional/{cmd:gamma0} treatment because their full sampling covariance is
not available.{p_end}

{phang}{opt cov0} removes the robust stacked-system cross terms, matching
{cmd:b1x2}. It affects robust or clustered covariance and is a no-op for
{cmd:vce(unadjusted)}. {cmd:r(observed_se_type)} and
{cmd:r(total_se_type)} disclose the effective inference contract.{p_end}

{phang}{opt tol(#)} sets the fixed-effect absorption tolerance. It must be
finite and strictly positive; the default {cmd:1e-8} preserves the historical
effective tolerance. It does not control the separate absorption-
classification boundary. The backend classifies an X1 column as FE-collinear
when {it:||M_D x||^2 / ||x||^2 <= 1e-9} (relative norm about 3.16e-5) and
returns that exact squared-norm threshold in
{cmd:r(fe_collinear_ss_ratio_tol)}. For every X1 column,
{cmd:r(x1_fe_collinear_ratio)} returns the measured ratio and
{cmd:r(x1_near_collinear_mask)} marks ratios in
{it:(1e-9, 1e-4]}. Such a column remains in the standard estimand, but the
command prints a loud warning because its component split and SEs can be
sensitive near the classification boundary. The diagnostic does not change
any estimate. {cmd:XHDFE_GELBACH_NEAR_COLLINEAR_WARN=0} suppresses only that
warning for controlled A/B runs; the matrices remain available.{p_end}

{phang}{opt threads(#)} requests the OpenMP team used by the CPU absorption,
FE-recovery and covariance phases; 0 selects the automatic policy. A positive
request bypasses workload/environment heuristics and is limited only by the
logical-processor/OpenMP capacity visible to the process. Some phases that do
not execute report zero, and CUDA kernel scheduling is separate. The returned
phase diagnostics distinguish configured budgets, observed teams, and workers
that actually processed useful work.

{phang}{opt gpu} requests the CUDA backend for the full HDFE specification.
The exact MLSMR fixed-effect recovery and the Gelbach covariance algebra stay
on CPU; this hybrid split preserves the certified FE normalization while
accelerating the absorption phase that benefits from the GPU. If CUDA is not
compiled, unavailable, fails, or does not converge, the existing xhdfe
fallback rules preserve the CPU result. Inspect {cmd:r(gpu_used)} and
{cmd:r(gpu_status)} to identify the backend used. With {cmd:weightedcpuroute(on)}, an eligible weighted
full model with two or more absorbed effects is fitted on the CPU and
reports {cmd:r(gpu_status)} = {cmd:weighted_cpu_route} (see
{help xhdfe##gpu_weighted_cpu_route:weighted fits on CUDA}), except when the
fixed-effect recovery falls back to the full refit ({cmd:XHDFE_GELBACH_WARM_RECOVERY=0},
or a warm start that is not certified): the status reported is then that refit's,
which runs after the CUDA request has ended (code 0 when nothing else requests
CUDA), as for an unweighted model. CUDA applies
only to the full-model HDFE absorption; it does not move the base regression,
auxiliary covariance algebra, share delta method, or FE recovery to the GPU.

{phang}{opt verbose} streams phase-level progress live for the full fit,
certified FE recovery, base fit, covariance construction, and final
convergence check. Each line is flushed before the next phase. It changes
output only: quiet and verbose runs with the same inputs return identical
matrices.

{pstd}At least one of {opt x2groups()} or {opt fes()} must be supplied.

{pstd}{it:Performance environment switches} (A/B reproduction only — NOT a
safety fallback): {cmd:XHDFE_GELBACH_FAST_FIT=0} restores the single retained
full-model fit; {cmd:XHDFE_GELBACH_WARM_RECOVERY=0} disables the shared MLSMR
absorption that warm-starts the fixed-effect recovery and provides the within
transform (a convergence gate falls back to the retained fit automatically
when the recovery does not certify); {cmd:XHDFE_GELBACH_WITHIN_BATCH=0}
restores per-column within fits.

{pstd}{it:Warning (adversarial audit, 09jul2026).} The default fast path is
the MORE-converged one: it resolves the per-dimension FE split with an exact
normal-equations (MLSMR) solve behind a fail-closed convergence gate,
validated against direct sparse oracles up to 1M rows on adversarial FE
graphs. The legacy retained path recovers the split with Gauss-Seidel map
sweeps whose stopping rule is blind to the slow modes of ill-conditioned FE
graphs: on such graphs it can return a materially wrong per-dimension split
(sign flips observed) while reporting convergence. Do not set
{cmd:XHDFE_GELBACH_FAST_FIT=0} "to be safe" — it exists only to reproduce
pre-2.14.1 output bitwise for A/B comparison. Since 2.14.2 the legacy and
fallback paths cross-check their FE split against the exact normal equations
and set {cmd:r(converged)}=0 with an explanatory note when the check fails.
On well-conditioned designs the two paths agree to ~1e-11.

{pstd}{it:Near-collinear observed blocks.} A full model can converge and the
Gelbach summation identity can be exact while columns inside one
{opt x2groups()} block are so nearly collinear that the block's standard
errors depend materially on solver/ISA rounding. The backend runs a
bounded-cost normalized-Gram diagnostic and writes a warning to
the Results window and {cmd:r(notes)} for severe cases; point estimates are not
altered. In the
11jul2026 adversarial fixture (correlation 0.9999999999995), the default
tolerance agreed with a dense oracle within 0.024%, but alternative tight
tolerances moved the ill-conditioned block SE by as much as 7%, while a
well-conditioned block stayed within 2e-8. Such a warning means the split SE
is numerically indeterminate; tightening {opt tol()} does not select a unique
correct answer.{p_end}

{pstd}{it:Near-FE-collinear X1 columns.} This is distinct from near-collinearity
inside an observed X2 block. A standard-estimand X1 column with
{it:||M_D x||^2 / ||x||^2} just above the FE-omission boundary is still
estimated, but its location in the warning band is disclosed per column in
{cmd:r(x1_fe_collinear_ratio)} and {cmd:r(x1_near_collinear_mask)}. Review the
declared specification; use {opt absorbedtargets()} only when the variable is
conceptually invariant within an added FE and the constrained estimand is
actually intended.{p_end}

{pstd}{it:Floating-point reproducibility.} For {cmd:vce(cluster)}, the streamed
cluster-meat kernel may contract multiply-add operations (FMA). Relative to
the former materialized-score path this changes converged-cell SEs by at most
one last-place unit in the audited matrix (1.388e-17 absolute; coefficients
and deltas bit-identical). This deterministic rounding is accepted to retain
the large memory/runtime improvement. On deliberately ill-conditioned,
already non-converged cells it can be amplified; rely on {cmd:r(converged)}
and the conditioning note, not cross-build bit identity. Well-conditioned
Python/Stata/R specifications retain machine-precision parity. A separate
Stata-vs-Python plateau of about 7e-8 (or 2.6e-7 with fweights) was observed
only in an ill-conditioned FE/block split; its block-SE differences were much
larger and are covered by the warning above, so no universal 1e-7 accuracy
claim is made.{p_end}

{pstd}{it:Interpretation of per-FE-dimension contributions.} Diagnostics are
computed after recursive singleton removal for the added-FE pair selected by
{opt connectivityfes()}, or the first two added FE dimensions by default. With
no common FEs and exactly two added FE dimensions, one component gives
{cmd:r(fe_split_status) = identified_two_way} for the X1 rows; multiple
components give {cmd:normalization_dependent} and a runtime warning.
{cmd:connected(require)} turns this certificate into a fail-closed
precondition. With any {opt commonfes()}, the pair remains informative but
{cmd:r(fe_split_status) = not_certified_with_common_fes}: it cannot certify a
normalization of the larger common-plus-added FE system. With three or more
added dimensions, either a connected or disconnected selected pair remains
insufficient as a full multiway rank certificate and therefore gives
{cmd:not_certified_multiway} plus a warning.
The FE intercept-row allocation is not certified by this flag. In every
uncertified case, use the normalization-invariant {cmd:r(fe_total)} subtotal
unless identification is established externally. The total across FE
dimensions and b_base - b_full are convention-invariant. A small
{cmd:r(identity_gap)} certifies only the summation identity — it is NOT
evidence that the per-dimension split is identified or accurate; also check
{cmd:r(converged)} and {cmd:r(fe_split_status)}.


{title:Programmatic matrix layout}

{pstd}
Rows of {cmd:r(delta)} and {cmd:r(se)} are {opt x1()} in declared order followed
by {cmd:_cons}. Columns are all observed groups in {opt x2groups()} order,
followed by the FE dimensions in {opt fes()} order. {cmd:r(total)} has the same
rows and columns {cmd:delta} and {cmd:se}. {cmd:r(b_base)}, {cmd:r(b_full)} and
{cmd:r(absorbed_mask)} contain only the X1 columns, not the intercept.
{opt commonfes()} never adds a contribution column. With common FEs, every
{cmd:_cons} point, SE and covariance entry is missing by contract.{p_end}

{pstd}
{cmd:r(cov)} is group-major. If {it:k1 = number of X1 columns + 1}, its ordering
is
{cmd:[group1:X1, group1:_cons, group2:X1, group2:_cons, ...]}.
This is the authoritative object for sums and linear contrasts because it
retains every cross-component covariance. Do not add component variances or
SEs as if blocks were independent. Python's {cmd:gelbach.contrast()} and R's
{cmd:xhdfe_gelbach_contrast()} provide convenience wrappers around the same
algebra; Stata users can construct the corresponding weight vector against
{cmd:r(cov)}.{p_end}

{pstd}
{cmd:r(base_cov)} is the requested-VCE covariance of the base coefficients in
{cmd:[X1, _cons]} order. {cmd:r(cov_delta_bbase)} has group-major contribution
rows and {cmd:[X1, _cons]} base-coefficient columns.
{cmd:r(cov_total_bbase)} is their sum over groups. These matrices support
joint inference for base-normalized shares and other smooth functions; they
must be used rather than assuming an independent denominator.{p_end}

{pstd}
{cmd:r(gamma)} contains the full-model coefficients of observed
{opt x2groups()} blocks. Columns follow observed-block declaration order;
rows are coefficient positions within a block, padded with missing values to
the widest observed block. FE blocks have no columns in {cmd:r(gamma)} because
their effects are absorbed rather than represented by one finite coefficient
vector.{p_end}

{pstd}
For the product-regularity contract, {cmd:r(beta2)} and
{cmd:r(beta2_cov)} use original observed-X2 column order.
{cmd:r(auxiliary_loadings)} contains the true {it:Gamma} matrix, with
{opt x1()} plus {cmd:_cons} in rows and the original X2 variables in columns.
The rowwise matrices {cmd:r(auxiliary_loading_max_abs_z)},
{cmd:r(auxiliary_loading_pvalue)},
{cmd:r(auxiliary_loading_test_evaluated)},
{cmd:r(contribution_gradient_norm)}, {cmd:r(regular_inference_valid)}, and
{cmd:r(regular_inference_status_code)} have {opt x1()} plus {cmd:_cons} in
rows and observed block names in columns.
{cmd:r(beta2_wald)} and {cmd:r(auxiliary_loading_diagnostics)} have one row
per observed block. Status codes are -1 {cmd:not_certified}, 0
{cmd:nonregular_not_ruled_out}, 1 {cmd:regular_beta_nonzero}, and 2
{cmd:regular_loading_nonzero}; the corresponding group-major words are also
returned in {cmd:r(regular_inference_status)}. Code -2 means
{cmd:not_applicable_common_fe_intercept} for the deliberately unavailable
common-FE intercept row.{p_end}

{pstd}
When {opt shares()} is requested, {cmd:r(share)}, {cmd:r(share_se)} and the two
CI matrices have the same shape and names as {cmd:r(delta)}. The one-column
{cmd:r(share_defined)} marks usable denominators; an unusable denominator
makes its share, SE and interval missing and adds a warning to {cmd:r(notes)}.
{cmd:r(share_denominator_t)} reports the denominator t-statistic and
{cmd:r(share_interval_status_code)} distinguishes first-order-valid from
weak-denominator diagnostic rows.
{cmd:r(residual_share)} is defined only for X1 rows under a base-coefficient
denominator; it is missing for movement shares and for undefined denominators.
Stored shares are fractions even though the display multiplies them by 100.{p_end}


{title:Deliberate limits}

{pstd}
The current command supports linear OLS coefficient-movement accounting with
unadjusted, robust or one-way clustered inference. It does not implement
automatic restriction/refitting on the largest connected component, an exact
multiway-FE rank certificate, multiway clustering, wild-cluster bootstrap,
BCa/studentized bootstrap intervals or weak-inference confidence sets, or a
claim that the available full-refit pairs bootstrap cures nonregular
contribution cells,
IV/2SLS or LATE allocation,
split-panel/dynamic corrections, nonconditional recovered-FE covariance
(the {cmd:fe_variance_status} gate detects a problematic conditional region
but does not estimate the omitted uncertainty),
inference or a normalization-independent intercept decomposition with common
FEs, a connectivity certificate for added-FE contributions conditional on
common FEs,
kernel/MM-quantile/KHB/GLM/distributional decompositions, Oaxaca wrappers, or
causal-mediation estimands. These require separate estimators and must not be
approximated by relabelling the OLS output.{p_end}

{pstd}
High-dimensional FE common to base and full belong in {opt commonfes()}; every
dimension in {opt fes()} is an added full-model component. Stata
factor-variable notation is not expanded inside {opt x1()} or
{opt x2groups()}; generate numeric indicators, powers, bins, splines and
interactions explicitly. Explicit low-dimensional indicators in {opt x1()}
remain supported when their coefficients are desired.{p_end}

{pstd}
For a binary outcome, the command can decompose coefficients from a declared
linear probability model. Contributions are then in probability units (or
percentage points after multiplying by 100), and robust or substantively
appropriate clustered inference is normally preferable to unadjusted OLS
inference. This remains a linear coefficient-movement accounting exercise;
it is not a decomposition of nonlinear response probabilities and does not
repair misspecification or justify a causal interpretation.{p_end}


{title:Stored results}

{pstd}{cmd:xhdfegelbach} stores the following in {cmd:r()}:
{cmd:r(fe_total)} exists only with {opt fes()}; share matrices and share macros
exist only with {opt shares()}; {cmd:r(gamma)} exists only with
{opt x2groups()}; {cmd:r(notes)} exists only when the backend or the reporting
layer emits a note or warning.{p_end}

{synoptset 20 tabbed}{...}
{p2col 5 20 24 2: Matrices}{p_end}
{synopt:{cmd:r(delta)}}contributions, rows for {opt x1()} plus {cmd:_cons}, one column per group{p_end}
{synopt:{cmd:r(se)}}standard errors matching {cmd:r(delta)}{p_end}
{synopt:{cmd:r(total)}}total movement for {opt x1()} plus {cmd:_cons}; columns {cmd:delta} and {cmd:se}{p_end}
{synopt:{cmd:r(b_base)}}base-model coefficients on {opt x1()}{p_end}
{synopt:{cmd:r(b_full)}}full-model coefficients on {opt x1()}; absorbed targets are imposed zero{p_end}
{synopt:{cmd:r(absorbed_mask)}}backend classification mask in X1 order (1 = imposed absorbed target){p_end}
{synopt:{cmd:r(x1_fe_collinear_ratio)}}per-X1 squared residual-norm ratio after absorbing common plus added FEs{p_end}
{synopt:{cmd:r(x1_near_collinear_mask)}}per-X1 warning-band indicator{p_end}
{synopt:{cmd:r(gamma)}}padded full-model coefficients for observed X2 blocks{p_end}
{synopt:{cmd:r(beta2)}}full-model observed-X2 coefficients in original column order{p_end}
{synopt:{cmd:r(beta2_cov)}}requested-VCE covariance of {cmd:r(beta2)}{p_end}
{synopt:{cmd:r(auxiliary_loadings)}}true auxiliary {it:Gamma} loadings, rows X1 plus intercept, columns original X2{p_end}
{synopt:{cmd:r(auxiliary_loading_diagnostics)}}per-observed-block loading SS ratio, rank, and condition number{p_end}
{synopt:{cmd:r(auxiliary_loading_max_abs_z)}}rowwise maximum marginal absolute loading z statistic{p_end}
{synopt:{cmd:r(auxiliary_loading_pvalue)}}rowwise Bonferroni-adjusted loading-null p-value{p_end}
{synopt:{cmd:r(auxiliary_loading_test_evaluated)}}indicator that the rowwise loading test was needed and evaluated{p_end}
{synopt:{cmd:r(beta2_wald)}}per-block beta2-null statistic, numerical df, and chi-square p-value{p_end}
{synopt:{cmd:r(contribution_gradient_norm)}}norm of each observed contribution's product gradient{p_end}
{synopt:{cmd:r(regular_inference_valid)}}1 only where a nonzero product-gradient part is statistically established{p_end}
{synopt:{cmd:r(regular_inference_status_code)}}per-cell status code (-2, -1, 0, 1, or 2){p_end}
{synopt:{cmd:r(cov)}}joint covariance of all group contributions{p_end}
{synopt:{cmd:r(total_cov)}}covariance of the total movement{p_end}
{synopt:{cmd:r(base_cov)}}requested-VCE covariance of base coefficients plus intercept{p_end}
{synopt:{cmd:r(cov_delta_bbase)}}cross-covariance of group-major contributions with base coefficients{p_end}
{synopt:{cmd:r(cov_total_bbase)}}cross-covariance of total movement with base coefficients{p_end}
{synopt:{cmd:r(fe_total)}}aggregate absorbed-FE contribution and conditional SE for {opt x1()} plus {cmd:_cons}{p_end}
{synopt:{cmd:r(share)}}signed component shares; returned only with {opt shares()}{p_end}
{synopt:{cmd:r(share_se)}}delta-method share SEs; fixed-denominator scaling only under {cmd:base_fixed}{p_end}
{synopt:{cmd:r(share_ci_low)}, {cmd:r(share_ci_high)}}share confidence limits{p_end}
{synopt:{cmd:r(share_defined)}}row indicator that the denominator exceeds {opt sharetol()}{p_end}
{synopt:{cmd:r(share_denominator_t)}}absolute denominator t-statistic by coefficient row{p_end}
{synopt:{cmd:r(share_interval_status_code)}}1 first-order valid; 0 weak-denominator diagnostic{p_end}
{synopt:{cmd:r(residual_share)}}full-model coefficient divided by the base coefficient, when defined{p_end}

{p2col 5 20 24 2: Scalars}{p_end}
{synopt:{cmd:r(identity_gap)}}residual of the summation identity (should be ~0){p_end}
{synopt:{cmd:r(n_obs_input)}}observations entering the backend after Stata markout{p_end}
{synopt:{cmd:r(n_obs)}}retained row count (historical field){p_end}
{synopt:{cmd:r(n_obs_effective)}}reported N: retained rows normally, sum of retained weights under {cmd:fweight}{p_end}
{synopt:{cmd:r(n_singletons_dropped)}}observations removed by recursive FE singleton dropping{p_end}
{synopt:{cmd:r(n_common_fes)}}number of FE dimensions absorbed in both models{p_end}
{synopt:{cmd:r(common_fes_applied)}}1 when {opt commonfes()} is nonempty{p_end}
{synopt:{cmd:r(intercept_inference_available)}}0 with common FEs; 1 under the historical no-common-FE contract{p_end}
{synopt:{cmd:r(n_mobility_components)}}exact retained-sample components of the selected FE pair; 0 with fewer than two FEs{p_end}
{synopt:{cmd:r(largest_mobility_component_n_obs)}}physical rows in the row-largest selected-pair component{p_end}
{synopt:{cmd:r(largest_mobility_component_share)}}retained-row share of the row-largest selected-pair component{p_end}
{synopt:{cmd:r(largest_mobility_weight_share)}}retained-weight share of the weight-largest selected-pair component{p_end}
{synopt:{cmd:r(fe_split_identified)}}1 only for the X1-row split of an exactly two-way, connected FE design{p_end}
{synopt:{cmd:r(connectivity_fe1_index)}}zero-based first selected FE index, or -1{p_end}
{synopt:{cmd:r(connectivity_fe2_index)}}zero-based second selected FE index, or -1{p_end}
{synopt:{cmd:r(connectivity_pair_explicit)}}1 when {opt connectivityfes()} was specified{p_end}
{synopt:{cmd:r(df_full)}}residual degrees of freedom of the full model{p_end}
{synopt:{cmd:r(df_base)}}residual degrees of freedom of the base model{p_end}
{synopt:{cmd:r(n_clusters)}}retained independent clusters for {cmd:vce(cluster)}; 0 otherwise{p_end}
{synopt:{cmd:r(converged)}}1 if the computation converged{p_end}
{synopt:{cmd:r(tol)}}fixed-effect absorption tolerance used{p_end}
{synopt:{cmd:r(focal_selection_explicit)}}1 when {opt focal()} was specified{p_end}
{synopt:{cmd:r(conf_level)}}requested {opt level()} as a fraction; returned even without shares{p_end}
{synopt:{cmd:r(share_tol)}}requested denominator threshold; returned even without shares{p_end}
{synopt:{cmd:r(share_t_min)}}requested denominator-t threshold; returned even without shares{p_end}
{synopt:{cmd:r(fe_variance_ratio_min)}}requested conditional FE-variance threshold{p_end}
{synopt:{cmd:r(sample_info_requested)}}1 with {opt sampleaudit} or {opt generate()}; 0 otherwise{p_end}
{synopt:{cmd:r(fe_collinear_ss_ratio_tol)}}squared-norm FE-classification threshold ({cmd:1e-9}){p_end}
{synopt:{cmd:r(near_fe_warn_upper)}}upper warning-band edge ({cmd:1e-4}); the shortened name respects Stata's identifier limit{p_end}
{synopt:{cmd:r(few_cluster_warning_threshold)}}cluster-count warning threshold ({cmd:30}){p_end}
{synopt:{cmd:r(absorbed_target_inference_valid)}}1 only when absorbed-target inference is clustered at a matching absorbing FE{p_end}
{synopt:{cmd:r(absorbing_fe_index)}}zero-based matching FE dimension, or -1{p_end}
{synopt:{cmd:r(regular_inference_all_valid)}}1 iff every observed-X2 contribution row passes the conservative gate{p_end}
{synopt:{cmd:r(regularity_test_alpha)}}product-regularity test threshold (0.05){p_end}
{synopt:{cmd:r(threads_requested)} {cmd:r(threads_effective)}}raw request and capacity-limited command budget{p_end}
{synopt:{cmd:r(recovery_threads_effective)}}FE-recovery/covariance CPU phase budget{p_end}
{synopt:{cmd:r(threads_used)} {cmd:r(parallel_workers_active)}}largest observed team and useful-worker count over all phases{p_end}
{synopt:{cmd:r(thread_capacity)} {cmd:r(openmp_enabled)}}runtime-visible capacity and OpenMP availability{p_end}
{synopt:{cmd:r(thread_limit_code)}}capacity/availability limit code; its label is the macro {cmd:r(thread_limit_reason)}{p_end}
{synopt:{cmd:r(fullfit_threads_used)} {cmd:r(fullfit_parallel_workers_active)}}observed full-fit team/workers{p_end}
{synopt:{cmd:r(recovery_threads_used)} {cmd:r(recovery_parallel_workers_active)}}observed recovery team/workers (0 when absent){p_end}
{synopt:{cmd:r(covariance_threads_used)} {cmd:r(cov_parallel_workers_active)}}
observed base/auxiliary/covariance team/workers; the worker-field name is shortened
for Stata's identifier limit{p_end}
{synopt:{cmd:r(gpu_requested)}}1 when CUDA was requested by {opt gpu} or the active backend selector{p_end}
{synopt:{cmd:r(gpu_used)}}1 only if CUDA was actually used{p_end}
{synopt:{cmd:r(gpu_status_code)}}0 not requested; 1 used; 2 unavailable; 3 not converged; 4 failed; 5 CPU cache; 6 not applicable;
7 weighted full-model fit run on the CPU by design (see {help xhdfe##gpu_weighted_cpu_route:weighted fits on CUDA}){p_end}
{synopt:{cmd:r(gpu_attempted)}}1 if GPU absorption was attempted{p_end}
{synopt:{cmd:r(gpu_absorption_converged)}}1 if attempted GPU absorption converged{p_end}
{synopt:{cmd:r(gpu_absorption_iterations)}}iterations of attempted GPU absorption{p_end}
{synopt:{cmd:r(cuda_tail_code)}}CUDA completion of the full-model fit: 0 none, 1 GPU LSMR,
2 CPU MLSMR after the GPU sweeps (see {help xhdfe}){p_end}

{p2col 5 20 24 2: Macros}{p_end}
{synopt:{cmd:r(vce)}}the variance estimator used{p_end}
{synopt:{cmd:r(groups)}}the group names{p_end}
{synopt:{cmd:r(common_fes)}}common-FE variable names; these are not contribution groups{p_end}
{synopt:{cmd:r(sample_hash)}}opt-in retained-sample identifier{p_end}
{synopt:{cmd:r(sample_hash_algorithm)}}{cmd:fnv1a64-le-v1}; reproducible and non-cryptographic{p_end}
{synopt:{cmd:r(sample_index_scope)}}{cmd:marked_input_rows_zero_based}{p_end}
{synopt:{cmd:r(sample_variable)}}name created by {opt generate()}, when requested{p_end}
{synopt:{cmd:r(intercept_status)}}{cmd:estimated_no_common_fes} or {cmd:not_certified_common_fes}{p_end}
{synopt:{cmd:r(x1_names)}}all {opt x1()} variable names in design order{p_end}
{synopt:{cmd:r(focal_indices)}}zero-based reporting indices; all X1 indices when {opt focal()} is omitted{p_end}
{synopt:{cmd:r(focal_names)}}reporting names; all X1 names when {opt focal()} is omitted{p_end}
{synopt:{cmd:r(share_denominator)}}{cmd:movement}, {cmd:base}, or {cmd:base_fixed}{p_end}
{synopt:{cmd:r(share_se_type)}}movement/base joint delta method or fixed-denominator scaling{p_end}
{synopt:{cmd:r(share_interval_status)}}per-row {cmd:valid_first_order} or {cmd:weak_denominator_delta_method_unreliable}{p_end}
{synopt:{cmd:r(share_interval_status_order)}}X1 rows followed by {cmd:_cons}{p_end}
{synopt:{cmd:r(share_units)}}{cmd:fraction}; the display multiplies by 100{p_end}
{synopt:{cmd:r(notes)}}any solver notes{p_end}
{synopt:{cmd:r(estimand)}}{cmd:coefficient_movement} or {cmd:absorbed_target_allocation}{p_end}
{synopt:{cmd:r(identity_status)}}{cmd:exact_ols}, {cmd:exact_ols_constrained}, or {cmd:exact_ols_conditional_common_fes}{p_end}
{synopt:{cmd:r(absorbed_targets)}}zero-based backend-classified absorbed X1 indices, consistent across frontends{p_end}
{synopt:{cmd:r(absorbed_target_names)}}backend-classified absorbed X1 variable names{p_end}
{synopt:{cmd:r(b_full_status)}}per-X1 {cmd:estimated}/{cmd:imposed_zero} labels, in X1 order{p_end}
{synopt:{cmd:r(focal_status)}}per-X1 identification labels, {cmd:identified} or {cmd:absorbed}; unrelated to the reporting selector{p_end}
{synopt:{cmd:r(observed_se_type)}}{cmd:full}, {cmd:gamma0}, or {cmd:cov0}{p_end}
{synopt:{cmd:r(total_se_type)}}whether total inference is full, conditional, or mixed{p_end}
{synopt:{cmd:r(inference_status)}}absorbed-target clustering status or {cmd:not_applicable}{p_end}
{synopt:{cmd:r(causal_interpretation)}}{cmd:no}{p_end}
{synopt:{cmd:r(fe_se_type)}}{cmd:conditional_gamma0}, with a diagnostic suffix when the FE-variance gate fires{p_end}
{synopt:{cmd:r(fe_variance_status)}}per-X1 {cmd:valid_first_order} or {cmd:conditional_only_between_fe_dominant}{p_end}
{synopt:{cmd:r(fe_variance_status_order)}}{opt x1()} column order{p_end}
{synopt:{cmd:r(fe_split_status)}}{cmd:not_applicable}, {cmd:single_fe_dimension},
{cmd:identified_two_way}, {cmd:normalization_dependent}, {cmd:not_certified_multiway},
or {cmd:not_certified_with_common_fes}{p_end}
{synopt:{cmd:r(connected_mode)}}{cmd:diagnose} or {cmd:require}{p_end}
{synopt:{cmd:r(connectivity_fes)}}selected FE variable names{p_end}
{synopt:{cmd:r(connectivity_fe_indices)}}selected zero-based FE indices{p_end}
{synopt:{cmd:r(connectivity_pair_status)}}{cmd:not_applicable}, {cmd:connected}, or {cmd:disconnected}{p_end}
{synopt:{cmd:r(mobility_component_scope)}}historical FE-pair scope, added-FE-pair scope with common FEs, or {cmd:not_applicable}{p_end}
{synopt:{cmd:r(gpu_backend)}}effective backend, {cmd:cuda} or {cmd:cpu}{p_end}
{synopt:{cmd:r(gpu_status)}}{cmd:not_requested}, {cmd:used}, {cmd:unavailable},
{cmd:not_converged}, {cmd:failed}, {cmd:cpu_cache}, {cmd:not_applicable}, or {cmd:weighted_cpu_route}{p_end}
{synopt:{cmd:r(cuda_tail)}}label of {cmd:r(cuda_tail_code)}: {cmd:none}, {cmd:device-lsmr}, or {cmd:host-mlsmr}{p_end}
{synopt:{cmd:r(thread_limit_reason)}}label of {cmd:r(thread_limit_code)}{p_end}
{synopt:{cmd:r(regular_inference_status)}}group-major status words, X1 rows then intercept within each observed block{p_end}
{synopt:{cmd:r(regular_inference_status_order)}}ordering description for the status words{p_end}
{synopt:{cmd:r(regular_inference_codebook)}}mapping from numeric status codes to status words{p_end}
{p2colreset}{...}


{title:Examples}

{pstd}Decompose the movement in the tenure coefficient when experience, job
characteristics and occupation effects enter the wage model.{p_end}
{phang2}{cmd:. use "https://www.stata-press.com/data/r19/nlswork.dta", clear}{p_end}
{phang2}{cmd:. xhdfegelbach ln_wage, x1(tenure)}
{cmd:x2groups("experience = ttl_exp : job = union south not_smsa") commonfes(year)}
{cmd:fes(occ_code) vce(cluster) cluster(idcode) shares(movement) sampleaudit generate(in_gelbach)}{p_end}
{phang2}{cmd:. matrix list r(delta)}{p_end}

{pstd}See the complete {help xhdfe_examples##gelbach:table and graph example},
the {help xhdfe_examples##gelbach_absorbed:absorbed-target example} and
{help xhdfe_examples##bootstrap:bootstrap examples}.{p_end}

{title:References}

{pstd}
Gelbach, J. B. 2016. When do covariates matter? And which ones, and how much?
{it:Journal of Labor Economics} 34(2): 509-543. Validated against his
{cmd:b1x2} Stata implementation.{p_end}

{pstd}
The design of this command and of its companions also drew on the following sources. The decomposition
interface of {cmd:pyfixest} (groups of covariates, tables, plots and bootstrap intervals) was the reference
for a modern interface; Guimaraes, Portugal and Reis (2026) was the starting point for the decomposition
with high-dimensional fixed effects; Gaure (2013) sets out what is estimable about absorbed effects. The
others delimit how the decomposition may be read: Kohler, Karlson and Holm (2011) for nonlinear probability
models, Fortin, Lemieux and Firpo (2011) for its relation to Oaxaca-Blinder decompositions, Cameron, Gelbach
and Miller (2008) for bootstrap inference with clustered errors, and Acharya, Blackwell and Sen (2016) and
Tingley et al. (2014) for causal mediation, which the decomposition does not identify.{p_end}

{phang}
The PyFixest Authors. "{cmd:pyfixest}: Fast high-dimensional fixed effect estimation in Python."
{browse "https://github.com/py-econometrics/pyfixest":https://github.com/py-econometrics/pyfixest}.{p_end}

{phang}
Guimaraes, P., P. Portugal, and H. Reis. 2026. Labor market sorting in Portugal, with a practitioner
corner on the decomposition of the regression coefficient estimates.
{it:Banco de Portugal Economic Studies} XII(3).{p_end}

{phang}
Gaure, S. 2013. lfe: Linear group fixed effects. {it:The R Journal} 5(2): 104-116.
{browse "https://doi.org/10.32614/RJ-2013-031":doi:10.32614/RJ-2013-031}.{p_end}

{phang}
Kohler, U., K. B. Karlson, and A. Holm. 2011. Comparing coefficients of nested nonlinear probability
models. {it:Stata Journal} 11(3): 420-438.
{browse "https://doi.org/10.1177/1536867X1101100306":doi:10.1177/1536867X1101100306}.{p_end}

{phang}
Fortin, N., T. Lemieux, and S. Firpo. 2011. Decomposition methods in economics. In
{it:Handbook of Labor Economics}, vol. 4A, 1-102.
{browse "https://doi.org/10.1016/S0169-7218(11)00407-2":doi:10.1016/S0169-7218(11)00407-2}.{p_end}

{phang}
Cameron, A. C., J. B. Gelbach, and D. L. Miller. 2008. Bootstrap-based improvements for inference with
clustered errors. {it:Review of Economics and Statistics} 90(3): 414-427.
{browse "https://doi.org/10.1162/rest.90.3.414":doi:10.1162/rest.90.3.414}.{p_end}

{phang}
Acharya, A., M. Blackwell, and M. Sen. 2016. Explaining causal findings without bias: Detecting and
assessing direct effects. {it:American Political Science Review} 110(3): 512-529.
{browse "https://doi.org/10.1017/S0003055416000216":doi:10.1017/S0003055416000216}.{p_end}

{phang}
Tingley, D., T. Yamamoto, K. Hirose, L. Keele, and K. Imai. 2014. mediation: R package for causal
mediation analysis. {it:Journal of Statistical Software} 59(5): 1-38.
{browse "https://doi.org/10.18637/jss.v059.i05":doi:10.18637/jss.v059.i05}.{p_end}

{pstd}
For the packages and papers on which the shared xhdfe backend builds, see
{help xhdfe##acknowledgements:help xhdfe, Acknowledgements}.{p_end}


{title:Also see}

{psee}
{helpb xhdfe}, {helpb xhdfeakm}, {helpb xhdfeconnected},
{helpb xhdfegelbachbootstrap}, {helpb xhdfegelbachetable},
{helpb xhdfegelbachcoefplot}
{p_end}
