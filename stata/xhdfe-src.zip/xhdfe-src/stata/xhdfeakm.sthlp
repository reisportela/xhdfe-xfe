{smcl}
{* *! version 1.9.0  25nov2026}{...}
{vieweralsosee "xhdfe" "help xhdfe"}{...}
{vieweralsosee "xhdfeconnected" "help xhdfeconnected"}{...}
{vieweralsosee "xhdfegelbach" "help xhdfegelbach"}{...}
{title:Title}

{p2colset 5 20 22 2}{...}
{p2col :{cmd:xhdfeakm} {hline 2}}AKM worker-firm estimation with leave-out (KSS) variance decomposition{p_end}
{p2colreset}{...}


{title:Syntax}

{p 8 15 2}
{cmd:xhdfeakm} {depvar} {ifin} {weight}{cmd:,}
{opth work:er(varname)} {opth firm(varname)}
[{it:options}]

{synoptset 28 tabbed}{...}
{synopthdr}
{synoptline}
{syntab:Model}
{synopt :{opth work:er(varname)}}numeric worker (person) identifier; {bf:required}{p_end}
{synopt :{opth firm(varname)}}numeric firm (establishment) identifier; {bf:required}{p_end}
{synopt :{opth control:s(varlist)}}covariates partialled out (FWL) before the two-way step{p_end}
{synopt :{opt leaveout:level(unit)}}leave-out unit: {cmd:match} (default) or {cmd:obs}{p_end}
{synopt :{opt sigmac:entering(mode)}}{cmd:leaveouttwoway} (default) or invariant {cmd:personyear}, with optional worker projection inference{p_end}
{synopt :{opt noprune}}skip the leave-out connected-set pruning{p_end}

{syntab:Leverages (Pii, Bii)}
{synopt :{opt lev:erages(method)}}{cmd:auto} (default), {cmd:exact}, or {cmd:jla}{p_end}
{synopt :{opt draws(#)}}JLA random projections (default 200){p_end}
{synopt :{opt seed(#)}}seed for the JLA draws (default 20260705){p_end}
{synopt :{opt exactmax:rows(#)}}row cap for {cmd:auto} to pick the exact path (default 10000){p_end}

{syntab:Inference}
{synopt :{opt se}}component standard errors (KSS leave-out inference){p_end}
{synopt :{opt sensim(#)}}simulation draws for the SE quadratic part (default 1000){p_end}
{synopt :{opt ci}}weak-id diagnostics + Andrews-Mikusheva q=1 CIs; implies {opt se}{p_end}
{synopt :{opt eigtracensim(#)}}Hutchinson draws for tr(Atilde^2) (default 100){p_end}
{synopt :{opt sigmalow:ess}}lowess sigma-tilde fit instead of the binned default{p_end}

{syntab:Solver / technical}
{synopt :{opt gpu}}solve the two-way systems on the CUDA backend{p_end}
{synopt :{opt threads(#)}}explicit OpenMP request (0 = automatic policy){p_end}
{synopt :{opt directmax:firms(#)}}firm cap for the direct sparse solve (default 50000){p_end}
{synopt :{opt cgtol(#)}}two-way solver tolerance (default 1e-10){p_end}
{synopt :{opt fwltol(#)}}absorber tolerance for the control step (default 1e-10){p_end}

{syntab:Output}
{synopt :{opt verb:ose}}stream the active phase live (leave-out set, FWL, solver, JLA draws d/D with elapsed/ETA, SE sims, ...){p_end}
{synopt :{opth gen:erate(stub)}}save {it:stub}{cmd:_alpha}, {it:stub}{cmd:_psi}, {it:stub}{cmd:_keep}{p_end}
{synopt :{opt replace}}overwrite existing {opt generate()} variables{p_end}
{synoptline}
{p2colreset}{...}
{p 4 6 2}{cmd:fweight}s are allowed (match-level point decomposition only; a
weighted run equals the row-expanded run exactly). {cmd:r(n_obs_input)},
{cmd:r(n_obs_connected)} and {cmd:r(n_obs)} are the sums of the weights
over their respective samples.{p_end}


{title:Description}

{pstd}
{cmd:xhdfeakm} estimates the two-way AKM model

{p 8 8 2}{it:y_it = alpha_i + psi_j(i,t) + X_it' beta + e_it}{p_end}

{pstd}
(worker effect {it:alpha}, firm effect {it:psi}) on the largest leave-one-out
connected set and reports the wage-variance decomposition in three flavours:
{it:plug-in} (the biased sample decomposition), {it:AGSU} (Andrews, Gill,
Schank and Upward 2008, homoskedastic bias correction) and {it:KSS} (Kline,
Saggio and Soelvsten 2020, heteroskedasticity-robust leave-out correction).
Default numerical semantics follow Saggio's {it:LeaveOutTwoWay} (the canonical KSS
implementation this command is validated against): leave-a-match-out by
default, person-year weighted components with denominator {it:n}-1, exact
leverages on small samples and the Johnson-Lindenstrauss (JLA) approximation
with deterministic per-draw seeding on large ones.

{pstd}
The command shares the compiled xhdfe backend with the Python
{cmd:xhdfe.akm.akm_kss} and R {cmd:xhdfe_akm_kss} front-ends and requires the
{cmd:xhdfe.plugin} shipped with this version. It is a self-contained
post-estimation-style command: it does not change any {helpb xhdfe}
estimation path. To only build the leave-out sample without estimating, use
{helpb xhdfeconnected}.

{pstd}
{cmd:xhdfe} is, by design, primarily a high-performance replica of
{helpb reghdfe}; from {cmd:pytwoway} (Lamadon and Oppenheimer's reference
Python toolkit for two-way worker-firm models) and the related AKM literature
it adopts {it:only} what adds value inside that reghdfe universe -- this
leave-out decomposition, the connected set and the Gelbach companion -- rather
than reproducing pytwoway's broader structural models (CRE, BLM). The layer is
validated at machine precision against both {cmd:pytwoway} and Saggio's
{cmd:LeaveOutTwoWay}, and interoperates with pytwoway (the Python front-end can
export the leave-out sample to the pytwoway / bipartitepandas format). When
comparing against pytwoway directly, note two deliberate convention choices
(both follow the canonical {cmd:LeaveOutTwoWay}): the stayer variance rule
matches pytwoway's {it:non-default} {cmd:Sii_stayers='upper_bound'} option
(pytwoway's default {cmd:'firm_mean'} imputes stayer variances from firm-level
mover averages and can differ by 1-2 percent in var(alpha)/cov on
stayer-heavy panels — a convention gap, not a discrepancy), and the plug-in
components use the 1/(n-1) denominator versus pytwoway's 1/n (negligible
above ~10,000 person-years). Avoid pytwoway's {cmd:exact_trace_ho/he=True}
paths as an oracle: a broadcasting defect in pytwoway 0.3.21 corrupts every
exact-trace quadrant that uses its alpha-alpha inverse block, including
var(alpha) and the exact HE cov(alpha,psi) cross-quadrant. The latter differs
by 3.1e-4 to 7.3e-4 on audited stayer-heavy panels; replacing the broadcast
with a diagonal matrix restores the dense/xhdfe result to about 4e-10
(audited 11jul2026). The
combination is most useful with large linked employer-employee data: do the
fast HDFE regression and the leave-out variance decomposition here in a
familiar reghdfe workflow, and use pytwoway for the structural models outside
{cmd:xhdfe}'s scope.


{title:Options}

{dlgtab:Model}

{phang}{opth worker(varname)} and {opth firm(varname)} are the two
high-dimensional numeric identifiers. Both are {bf:required}. Codes outside
the signed 32-bit range, and non-integer numeric labels, are compacted
internally without changing the worker-firm graph or results.

{phang}{opth controls(varlist)} lists covariates that are partialled out at the
person-year level with the xhdfe absorber (Frisch-Waugh-Lovell) before the
two-way machinery runs; their coefficients are returned in {cmd:r(b)}.
Factor-variable notation is allowed, so {cmd:controls(i.year)} works directly
(base level omitted, as with manual dummies) instead of expanding the dummies by
hand; {cmd:i.}, {cmd:c.}, interactions and a chosen base ({cmd:ib#.}) are all
supported.

{pstd}If a control is collinear with the absorbed effects or another control,
its coefficient is set to zero under the reduced-model convention and
{cmd:r(notes)} identifies the one-based control column. Extremely
near-collinear controls can have individually unstable coefficients even when
fitted values are stable; do not interpret an omitted zero as estimated
evidence.{p_end}

{phang}{opt leaveoutlevel(match|obs)} chooses the leave-out unit:
{cmd:match} (worker-firm pair; the default and Saggio's default) or
{cmd:obs} (a single person-year observation). At {cmd:match} level,
{it:var(alpha)} component SE/CI are returned as missing whether or not stayers
are present: canonical {cmd:leave_out_COMPLETE} reports only var(psi) and
cov(alpha,psi) inference on this level, and the former movers-only extension
was anti-conservative in fixed-design Monte Carlo (SE/empirical-SD 0.56-0.65;
95% AM coverage 0.68-0.77). Use {cmd:obs} for var(alpha) inference; the
var(alpha) point decompositions remain available at both levels. The command
prints this reason immediately as a warning and retains the same text in
{cmd:r(notes)} for programmatic use.

{phang}{opt noprune} skips the leave-out connected-set computation; use only
when the estimation sample is already leave-out connected (for example after
{helpb xhdfeconnected}).

{dlgtab:Leverages}

{phang}{opt leverages(auto|exact|jla)} selects the statistical leverages
{it:P_ii} and quadratic-form weights {it:B_ii}. {cmd:auto} (default) uses the
{cmd:exact} per-observation solve up to {opt exactmaxrows()} and the JLA
approximation above it. {cmd:exact} and {cmd:jla} force either path.

{phang}{opt draws(#)} sets the number of JLA random projections (default 200,
the LeaveOutTwoWay default). {opt seed(#)} makes the random streams
deterministic. Thread/backend reductions preserve the estimator and FP64
tolerance but can differ at the last-ulp level.

{phang}{opt exactmaxrows(#)} sets the inclusive cap for the exact path
(default 10000). It counts marked input person-years before leave-out pruning.
With frequency weights it counts their sum.

{dlgtab:Inference}

{phang}{opt se} under the default centring computes component standard errors by KSS leave-out inference
(person-year block leave-out with a binned nonparametric sigma-tilde fit and a
simulated quadratic term). {opt sensim(#)} sets the number of simulation draws
for the quadratic part (default 1000).

{phang}{opt ci} under the default centring adds weak-identification diagnostics and the Andrews-Mikusheva
q=1 confidence intervals for each component (the LeaveOutTwoWay
{it:eigen_diagno} path): the top eigenvalue of Atilde and its share of the
sum of squared eigenvalues, the weak-Lindeberg condition, gamma-squared, the
F statistic, the curvature-adjusted point estimate {it:theta_1}, the AM
confidence bounds and the curvature. Implies {opt se}. {opt eigtracensim(#)}
sets the Hutchinson draws for tr(Atilde^2) (default 100, the oracle
default).

{pstd}{bf:Default convention (public issue #18).} Under {cmd:leaveoutlevel(match)},
KSS-corrected variance components depend on outcome shifts when matches have unequal length: adding a
constant to {depvar} changes them. The standard errors and confidence intervals of {opt se} and {opt ci}
also depend on the outcome level, under both {cmd:obs} and {cmd:match}. These default numerical conventions are retained.{p_end}

{phang}{opt sigmacentering(personyear)} selects an alternative point estimator.
For each match, the numerator is sqrt(match length) times the difference between
its adjusted mean outcome and the weighted person-year mean. The mean is computed
on the final retained sample after partialling out controls. This makes the point
components invariant to a common shift in the outcome with unequal match lengths.
The default {cmd:sigmacentering(leaveouttwoway)} reproduces the previous convention.{p_end}

{pstd}{bf:Statistical limit.} Person-year centring uses an estimated mean and does
not preserve exact finite-sample unbiasedness under arbitrary heteroskedasticity.
It is an explicit statistical alternative. With {opt se} or {opt ci}, it returns
regular-case delta standard errors and simultaneous 95% projection intervals for
var(psi) and cov(alpha,psi). The full-model calculation includes uncertainty from
estimating the controls and clusters by worker, allowing dependence across a
worker's jobs. The point formula and its leave-out unit remain unchanged.
{opt se} also prints the primary joint intervals in this mode.{p_end}

{pstd}Projection coverage is asymptotic under independent workers, bounded cluster
sizes and fourth moments, nondegenerate error covariance, a fixed firm count and
diffuse identified full-model contrasts. The intervals apply at weak signal;
the delta SEs require first-order regularity and a negligible point correction.
They are conditional on the JLA seed. The intervals can be wider than point
+/- 1.96 SE and need not contain the corrected point. No preliminary test switches
the interval. This mode supports 2--128 firms and unit weights. var(alpha)
inference, {opt sigmalowess} and lincom are unavailable. Inference runs on CPU;
{opt gpu} retains its existing meaning for the point and leverage solves.{p_end}

{pstd}The default inference retains its existing semantics and limitations. Its
standard errors accompany {cmd:r(theta_}{it:C}{cmd:)}, which are distinct from
{cmd:r(kss_}{it:C}{cmd:)}. With estimated controls, that legacy calculation treats
the adjusted outcome as fixed and does not propagate control-estimation uncertainty.
The derivation and diagnostics of the new option are in
{browse "https://github.com/reisportela/xhdfe-xfe/blob/main/docs/akm-projection-inference.md":the worker projection guide}.{p_end}

{pstd}{bf:Version 1.8.2.} With {opt controls()}, the internal control-partialling fit no longer evaluates
Student-t quantiles, which it never reported. On Windows this removes spurious {cmd:r(198)} refusals
("Student-t root is not bracketed"); the estimates are unchanged.{p_end}

{pstd}Bias-corrected variance components can be negative and are not clipped.
The reported worker-firm correlation is missing unless both component variances are finite and strictly positive.

{pstd}Simulation-based variance estimates can be negative in finite samples.
The established convention truncates the corresponding component SE to zero;
the command prints the full warning immediately and also records it in
{cmd:r(notes)}. If the AM interval is
mathematically undefined (for example a nonpositive quadratic variance or no
admissible real-root envelope), both bounds are returned as missing and the
reason is printed; internal finite sentinels are never exposed. Python and R
front-ends additionally raise a warning for these inferential diagnostics.
{p_end}

{pstd}With {opt verbose}, progress is flushed to the Results window as each
phase starts or advances; it is not buffered until the final table. Long JLA
and SE-simulation loops report completed work, elapsed time and ETA at
throttled intervals. Without {opt verbose}, the standard compact output is
unchanged.{p_end}

{phang}{opt sigmalowess} uses the LeaveOutTwoWay mode-0 lowess surface fit of
sigma-i on ({it:P_ii}, {it:B_ii}) for the SE quadratic part instead of the
binned default. Intended for small/medium-sample sensitivity analysis
(O(n^2)); the binned fit is the validated default.

{dlgtab:Solver / technical}

{phang}{opt gpu} solves the two-way linear systems on the CUDA backend when the
plugin was built with CUDA support; require {cmd:r(gpu_used)}==1 and
{cmd:r(gpu_status)}=={cmd:"used"}. The CPU path is the numerical reference.
With {opt controls()}, the FWL absorber reports separate {cmd:r(fwl_gpu_*)}
diagnostics and deliberately uses the certified CPU reference path
({cmd:r(fwl_gpu_status)}=={cmd:"cpu_reference"}). This prevents a CUDA
or CPU update-norm trigger on an ill-conditioned worker-firm graph from being
mistaken for forward-accurate residualization. The reference FWL uses MLSMR
and a strict residual certificate without relaxing {opt fwltol()}; the two-way
solver remains independently eligible for real CUDA execution.

{phang}{opt threads(#)} sets the OpenMP request for this command (0 =
automatic policy). A positive request bypasses workload and environment
heuristics and is limited only by the logical-processor/OpenMP capacity
visible to the process. The leave-out sample, FWL absorber, and two-way KSS
solver report their effective teams and useful-worker counts separately.

{phang}{opt directmaxfirms(#)} caps the firm dimension for the direct sparse
Cholesky solve (default 50000); larger problems use preconditioned CG.

{phang}{opt cgtol(#)} is the two-way solver tolerance (default 1e-10);
{opt fwltol(#)} is the absorber tolerance for the {opt controls()} step
(default 1e-10).

{phang}{it:Advanced performance environment variables} (defaults are tuned;
override only for diagnostics or unusual hardware; none changes the default
numeric output). With {cmd:threads(0)}, {cmd:XHDFE_AKM_TEAM} tunes the
automatic per-iteration solver team. A positive {cmd:threads()} request
bypasses it. {cmd:XHDFE_AKM_JLA_BLOCK} overrides the JLA multi-RHS block
size (default 8; {cmd:0} selects the pre-2.14 sequential solver, whose
per-edge instruction schedule differs from the batched kernels at the
last-ulp level). {cmd:XHDFE_AKM_SE_BLOCK} does the same for the component-SE /
eigen-diagnostics / lincom solves (default 8; {cmd:0} = sequential).
{cmd:XHDFE_AKM_SCATTER_CSR} (default on) selects the parallel CSR-ordered
Rademacher scatter at scale; {cmd:0} restores the sequential scatter. The
leverage and SE solves are batched without changing the estimator or solver
tolerances; different schedules can differ at the last-ulp level.

{dlgtab:Output}

{phang}{opt verbose} prints phase-by-phase progress to the Results window:
the leave-out sample counts, the FWL control step, the solver choice, the
leverage phase with a running {it:draws done/total} counter (elapsed time and
an ETA — the long phase on big panels), the SE simulations and the eigen
diagnostics. Output only: results are identical with or without it.
{cmd:set rmsg on} complements it with per-command timing.

{phang}{opth generate(stub)} stores {it:stub}{cmd:_alpha} and
{it:stub}{cmd:_psi} (observation-level worker and firm effects on the leave-out
sample; {it:psi} normalized to a zero person-year mean) and
{it:stub}{cmd:_keep} (1 for rows in the leave-out sample). {opt replace}
overwrites existing such variables.


{title:Stored results}

{pstd}{cmd:xhdfeakm} stores the following in {cmd:r()}:

{synoptset 26 tabbed}{...}
{p2col 5 26 30 2: Decomposition (each estimator {it:E} in {cmd:plugin}, {cmd:agsu}, {cmd:kss})}{p_end}
{synopt:{cmd:r(}{it:E}{cmd:_var_alpha)}}variance of worker effects{p_end}
{synopt:{cmd:r(}{it:E}{cmd:_var_psi)}}variance of firm effects{p_end}
{synopt:{cmd:r(}{it:E}{cmd:_cov)}}covariance of worker and firm effects{p_end}
{synopt:{cmd:r(}{it:E}{cmd:_corr)}}correlation of worker and firm effects{p_end}
{synopt:{cmd:r(}{it:E}{cmd:_var_sum)}}variance of {it:alpha}+{it:psi}{p_end}
{synopt:{cmd:r(}{it:E}{cmd:_share_alpha)}}var(alpha) as a share of var(y){p_end}
{synopt:{cmd:r(}{it:E}{cmd:_share_psi)}}var(psi) as a share of var(y){p_end}
{synopt:{cmd:r(}{it:E}{cmd:_share_2cov)}}2*cov as a share of var(y){p_end}

{p2col 5 26 30 2: Sample and diagnostics}{p_end}
{synopt:{cmd:r(var_y)}}person-year variance of {it:y}{p_end}
{synopt:{cmd:r(sigma2_ho)}}homoskedastic error variance (AGSU){p_end}
{synopt:{cmd:r(n_obs)}}person-year observations in the leave-out set{p_end}
{synopt:{cmd:r(n_obs_input)}}marked input person-years before leave-out pruning{p_end}
{synopt:{cmd:r(n_obs_connected)}}person-years after the largest-CC step{p_end}
{synopt:{cmd:r(n_workers)} {cmd:r(n_firms)} {cmd:r(n_matches)}}sample sizes{p_end}
{synopt:{cmd:r(n_movers)} {cmd:r(n_stayers)}}worker mobility counts{p_end}
{synopt:{cmd:r(n_rows)}}working rows (matches or observations){p_end}
{synopt:{cmd:r(max_pii)} {cmd:r(mean_pii)}}leverage diagnostics{p_end}
{synopt:{cmd:r(leverages_exact)}}1 if the exact leverage path was used{p_end}
{synopt:{cmd:r(solver_direct)}}1 if the direct sparse solve was used{p_end}
{synopt:{cmd:r(threads_requested)} {cmd:r(threads_effective)}}raw request and capacity-limited command budget{p_end}
{synopt:{cmd:r(threads_used)} {cmd:r(parallel_workers_active)}}largest observed team and useful-worker count over all phases{p_end}
{synopt:{cmd:r(thread_capacity)} {cmd:r(openmp_enabled)}}runtime-visible capacity and OpenMP availability{p_end}
{synopt:{cmd:r(thread_limit_code)} {cmd:r(thread_limit_reason)}}capacity/availability limit diagnostics{p_end}
{synopt:{cmd:r(fwl_threads_effective)}}FWL phase budget (0 without controls){p_end}
{synopt:{cmd:r(fwl_threads_used)} {cmd:r(fwl_parallel_workers_active)}}observed FWL team/workers (0 without controls){p_end}
{synopt:{cmd:r(fwl_iterations)} {cmd:r(fwl_abs_residual_rel)} {cmd:r(fwl_precision_certified)}}
accepted FWL iterations and independent
precision certificate{p_end}
{synopt:{cmd:r(fwl_gpu_attempted)} {cmd:r(fwl_gpu_used)} {cmd:r(fwl_gpu_fallback)}}FWL CUDA diagnostics; all are 0 under the current CPU-reference policy{p_end}
{synopt:{cmd:r(fwl_gpu_status_code)} {cmd:r(fwl_gpu_status)}}FWL backend status; code 8 is the certified CPU-reference policy{p_end}
{synopt:{cmd:r(solver_threads_effective)}}two-way solver phase budget{p_end}
{synopt:{cmd:r(solver_threads_used)} {cmd:r(solver_parallel_workers_active)}}observed two-way solver team/workers{p_end}
{synopt:{cmd:r(sample_threads_requested)} {cmd:r(sample_threads_effective)}}leave-out sample request/budget{p_end}
{synopt:{cmd:r(sample_threads_used)} {cmd:r(sample_parallel_workers_active)}}observed leave-out sample team/workers{p_end}
{synopt:{cmd:r(sample_thread_capacity)} {cmd:r(sample_openmp_enabled)}}sample-phase capacity/OpenMP status{p_end}
{synopt:{cmd:r(sample_thread_limit_code)} {cmd:r(sample_thread_limit_reason)}}sample-phase limit diagnostics{p_end}
{synopt:{cmd:r(jla_draws)} {cmd:r(seed)}}JLA draws and seed actually used{p_end}
{synopt:{cmd:r(solver_iterations)} {cmd:r(converged)}}solver diagnostics{p_end}
{synopt:{cmd:r(gpu_requested)} {cmd:r(gpu_used)}}two-way-solver CUDA request and actual use{p_end}
{synopt:{cmd:r(gpu_status_code)} {cmd:r(gpu_backend)} {cmd:r(gpu_status)}}two-way-solver backend diagnostics{p_end}

{p2col 5 26 30 2: With {opt se} (component {it:C} in {cmd:var_psi}, {cmd:cov}, {cmd:var_alpha})}{p_end}
{synopt:{cmd:r(se_}{it:C}{cmd:)}}standard error accompanying {cmd:r(theta_}{it:C}{cmd:)}{p_end}
{synopt:{cmd:r(theta_}{it:C}{cmd:)}}the leave_out_COMPLETE point estimate accompanied by the reported SE/CI; distinct from {cmd:r(kss_}{it:C}{cmd:)}{p_end}

{p2col 5 26 30 2: With {opt ci} (component suffix {it:c} in {cmd:_psi}, {cmd:_cov}, {cmd:_alpha})}{p_end}
{synopt:{cmd:r(lambda1_}{it:c}{cmd:)}}top eigenvalue of Atilde{p_end}
{synopt:{cmd:r(eigshare1_}{it:c}{cmd:)}}its share of the sum of squared eigenvalues{p_end}
{synopt:{cmd:r(lindeberg_}{it:c}{cmd:)}}weak-Lindeberg condition{p_end}
{synopt:{cmd:r(gammasq_}{it:c}{cmd:)}}gamma-squared{p_end}
{synopt:{cmd:r(fstat_}{it:c}{cmd:)}}F statistic{p_end}
{synopt:{cmd:r(theta1_}{it:c}{cmd:)}}curvature-adjusted point estimate{p_end}
{synopt:{cmd:r(ci_lb_}{it:c}{cmd:)} {cmd:r(ci_ub_}{it:c}{cmd:)}}AM q=1 bounds by default; simultaneous worker projection bounds with {cmd:personyear}{p_end}
{synopt:{cmd:r(curvature_}{it:c}{cmd:)}}curvature{p_end}

{p2col 5 26 30 2: Macros / matrices}{p_end}
{synopt:{cmd:r(cmd)}}{cmd:xhdfeakm}{p_end}
{synopt:{cmd:r(leave_out_level)}}the leave-out unit used{p_end}
{synopt:{cmd:r(sigma_centering)}}{cmd:leaveouttwoway} or {cmd:person_year}{p_end}
{synopt:{cmd:r(inference_method)}}{cmd:worker_projection} with invariant-mode inference{p_end}
{synopt:{cmd:r(inference_cluster)}}{cmd:worker} for that inference{p_end}
{synopt:{cmd:r(inference_backend)}}{cmd:cpu} for that inference{p_end}
{synopt:{cmd:r(se_method)}}{cmd:regular_delta} for that inference{p_end}
{synopt:{cmd:r(notes)}}any solver/identification notes{p_end}
{synopt:{cmd:r(b)}}control coefficients (with {opt controls()}){p_end}
{p2colreset}{...}

{pstd}Worker projection additionally returns {cmd:r(proj_dimension)},
{cmd:r(proj_rank)}, {cmd:r(proj_clusters)}, {cmd:r(proj_max_cluster)},
{cmd:r(proj_controls)}, {cmd:r(proj_degree)}, {cmd:r(proj_critical)},
{cmd:r(proj_factor)}, {cmd:r(proj_max_trace)}, {cmd:r(proj_max_leverage)},
{cmd:r(proj_cov_condition)}, {cmd:r(proj_solver_gap)}, {cmd:r(proj_bread_reused)},
{cmd:r(proj_threads_used)} and {cmd:r(proj_workers_active)}. These are diagnostics,
not automatic certificates of modelling assumptions. For each {it:c} in
{cmd:psi cov}, {cmd:r(proj_nonlinear_}{it:c}{cmd:)} is the linearization index,
{cmd:r(proj_correction_}{it:c}{cmd:)} is the absolute correction/SE ratio and
{cmd:r(proj_zero_gradient_}{it:c}{cmd:)} flags when a zero gradient is not excluded.
An infinite index is missing in Stata, with the flag set to one.{p_end}


{title:Examples}

{pstd}Compute AKM/KSS components and save effects on the public project simulation.{p_end}
{phang2}{cmd:. use "https://raw.githubusercontent.com/reisportela/xhdfe-xfe/main/data/felsdvsimul.dta", clear}{p_end}
{phang2}{cmd:. xhdfeconnected i j, generate(in_connected)}{p_end}
{phang2}{cmd:. xhdfeakm y if in_connected == 1, worker(i) firm(j) noprune}
{cmd:leverages(exact) sigmacentering(personyear) generate(akm)}{p_end}
{phang2}{cmd:. display r(kss_var_psi), r(kss_corr)}{p_end}

{pstd}For an example that partials out controls and reports an interval with
its matching point estimate, see {help xhdfe_examples##akm_inference:AKM inference on NLS data}.{p_end}

{title:References}

{pstd}
Abowd, J., F. Kramarz, and D. Margolis. 1999. High wage workers and high wage
firms. {it:Econometrica} 67(2): 251-333.{p_end}
{pstd}
Andrews, M., L. Gill, T. Schank, and R. Upward. 2008. High wage workers and
low wage firms: negative assortative matching or limited mobility bias?
{it:JRSS-A} 171(3): 673-697.{p_end}
{pstd}
Kline, P., R. Saggio, and M. Soelvsten. 2020. Leave-out estimation of variance
components. {it:Econometrica} 88(5): 1859-1898.{p_end}
{pstd}
For the packages and papers on which the shared xhdfe backend builds, see
{help xhdfe##acknowledgements:help xhdfe, Acknowledgements}.{p_end}


{title:Also see}

{psee}
{helpb xhdfe}, {helpb xhdfeconnected}, {helpb xhdfegelbach}
{p_end}
