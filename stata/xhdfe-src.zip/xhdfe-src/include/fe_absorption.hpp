#ifndef HDFE_FE_ABSORPTION_HPP
#define HDFE_FE_ABSORPTION_HPP

#include <Eigen/Dense>

#include <type_traits>
#include <memory>
#include <vector>

#include "hdfe/hdfe_regressor.hpp"

namespace hdfe {
namespace detail {

struct N1FeEvidence;

struct CudaForwardProbeSummary {
    int status = 0;  // 0 not run, 1 ok, 2 fit error, 3 CUDA error, 4 ineligible
    int continuation_sweeps = 0;
    double coefficient_drift_abs = 0.0;
    double rss_drift_rel = 0.0;
    double standard_error_drift_abs = 0.0;
    double covariance_drift_abs = 0.0;
    double contraction = 0.0;
    double coefficient_tail_abs = 0.0;
    double condition_proxy = 0.0;
};
static_assert(std::is_trivially_copyable<CudaForwardProbeSummary>::value,
              "CUDA forward-probe summary must remain POD-like");

struct GroupIndividualStructure {
    int num_groups = 0;
    int num_individuals = 0;
    std::vector<int> group_ptr;
    std::vector<int> group_individual;
    std::vector<int> individual_ptr;
    std::vector<int> individual_group;
    std::vector<double> group_scale;
};

// Codes of AbsorptionResult::cuda_tail. With three ordinary fixed effects in
// reghdfe-comparable mode, the CUDA path completes the projection after its
// sweeps (the "tail"): on the device with LSMR, or, when a short device probe
// predicts a long device solve and the CPU's own route selector would use
// MLSMR on this fit, on the host with MLSMR. kCudaTailNone when no completion
// ran (CPU fits, other routes, cache hits). The cold restart after a broken
// CG stage (F2-B) is probed the same way: kCudaTailHostMlsmr when the host
// MLSMR solved it from the original data; a restart kept on the device
// reports kCudaTailNone, as in 2.30.1.
constexpr int kCudaTailNone = 0;
constexpr int kCudaTailDeviceLsmr = 1;
constexpr int kCudaTailHostMlsmr = 2;

inline const char* cuda_tail_name(int code) noexcept {
    return code == kCudaTailDeviceLsmr ? "device-lsmr"
         : code == kCudaTailHostMlsmr  ? "host-mlsmr"
                                       : "none";
}

struct AbsorptionResult {
    std::shared_ptr<N1FeEvidence> n1_fe;
    Eigen::VectorXd y_tilde;
    Eigen::MatrixXd X_tilde;
    std::vector<int> fe_levels;
    std::vector<std::vector<int>> fe_group_ids;
    std::vector<Eigen::VectorXd> fe_means;
    std::vector<Eigen::VectorXd> fe_weight_sums;
    std::vector<Eigen::VectorXd> fe_alpha_y;
    std::vector<Eigen::MatrixXd> fe_alpha_X;
    std::vector<Eigen::VectorXd> fe_slope_alpha_y;
    std::vector<Eigen::MatrixXd> fe_slope_alpha_X;
    std::vector<int> sweep_order_used;
    int iterations = 0;
    bool converged = true;
    // A failed CG recurrence can lose components outside the FE span.
    // Its output must never seed a precision repair.
    bool cg_restart_required = false;
    double abs_residual = 0.0;      // verified ||D' W v_tilde||_2, max over RHS columns
    double abs_residual_rel = 0.0;  // max ||D' W v_tilde||_2 / (||D' W||_F ||v||_2)
    bool slope_block_checked = false;  // false in fast mode; block metrics then not applicable
    double slope_block_residual_rel = 0.0;  // max scale-invariant per-block/RHS certificate
    double slope_block_frobenius_rel = 0.0;  // max ||m||/(sqrt(sum d)||u_tilde||_W)
    double slope_block_rms_rel = 0.0;  // max RMS diagonal-scaled group moment
    double slope_block_max_rel = 0.0;  // max worst-group diagonal-scaled moment
    double slope_block_skipped_max_rel = 0.0;  // max skipped rank-deficient-group cosine
    int slope_certificate_worst_fe = -1;
    int slope_certificate_worst_moment = -1;  // 0 intercept/plain, 1 slope
    int slope_accuracy_retry_stages = 0;
    int slope_accuracy_retry_iterations = 0;
    double slope_internal_tolerance = 0.0;
    double krylov_internal_tolerance = 0.0;
    double krylov_max_final_backward_error = 0.0;
    double krylov_max_condition = 0.0;
    double krylov_max_condition_times_backward_error = 0.0;
    bool auto_routing_retry_policy_enabled = false;
    bool auto_routing_retry_eligible = false;
    bool auto_routing_retry_fired = false;
    int auto_routing_retry_status = 0;
    int auto_routing_retry_primary_method = -1;
    int auto_routing_retry_primary_iterations = 0;
    double auto_routing_retry_primary_abs_residual_rel = 0.0;
    int auto_routing_retry_iterations = 0;
    double auto_routing_retry_abs_residual_rel = 0.0;
    double auto_routing_retry_elapsed_seconds = 0.0;
    // Early routing (options.early_routing): 0 none, 1 a sweep or a gated
    // conjugate-gradient stage left at a checkpoint (predictive rule), 2 the
    // hand-off to a conjugate-gradient stage was not made (structural rule).
    // A left result is unconverged and is discarded: the regressor runs the
    // retry's MLSMR instead.
    int early_routing_left = 0;
    double early_routing_prediction = 0.0;  // kappa*q*tol at the leave
    double early_routing_kappa = 0.0;       // certificate / stop quantity
    double early_routing_rate = 0.0;        // q, decay of the stop quantity per iteration
    bool precision_certified = true;
    bool schwarz_used = false;  // true when the Schwarz/approx-Cholesky PCG path ran (forced or auto-gated)
    bool mlsmr_used = false;    // true when the MLSMR absorber ran via the auto-gate promotion
    bool gpu_used = false;
    int gpu_status_code = 0;  // 0 none, 1 used, 2 unavailable, 3 not converged, 4 failed, 5 CPU cache/profile
    bool gpu_attempted = false;
    bool gpu_absorption_converged = false;
    int gpu_absorption_iterations = 0;
    CudaForwardProbeSummary cuda_forward_probe;
    int cuda_accuracy_retry_trigger = 0;  // 0 none, 1 residual, 2 forward
    int cuda_accuracy_retry_stage = 0;    // 0 none, 1-3 warm, 4 cold
    int cuda_accuracy_retry_iterations = 0;
    int cuda_tail = kCudaTailNone;  // how the three-FE Comparable CUDA completion ran
    // F2-B ledger of a CUDA CG stage entered from the IT sweeps: the sweeps
    // before the hand-off that `iterations` does not count (2.30.1
    // accounting), why the sweeps handed off (1 divergence, 2 iteration cap),
    // and the wall seconds of the sweeps and of the CG stage (trace only; no
    // decision reads them). The cold restart that follows a broken CG stage
    // charges these sweeps to the fit's budget and to `iterations`.
    int cuda_cg_uncounted_it_iterations = 0;
    int cuda_it_handoff_reason = 0;
    double cuda_it_seconds = 0.0;
    double cuda_cg_seconds = 0.0;
    // P3-fix: cold restarts of a broken xhdfe-fast CUDA CG stage (0 none) and
    // whether the device LSMR completed the fit after them (fe_absorption_cuda.cu,
    // restart_fast_cg_after_breakdown). Diagnostics and the refusal message only.
    int cuda_fast_cg_restarts = 0;
    bool cuda_fast_lsmr_restart = false;
    // P3-fix (C): set by the bounded xhdfe-fast CUDA repair (hdfe_regressor_v11.cpp)
    // when its result converged and passed the public certificate but missed the
    // repair acceptance target, which it holds (0.5*tol); 0 otherwise. The fit is
    // refused as before; only the message changes.
    double fast_repair_target = 0.0;
    // P3-fix (3'), strict scope: a stage with the strict provenance restarted its
    // broken CG stage with the device LSMR and the strict check, or met a second
    // breakdown after the sequence had used that restart (fe_absorption_cuda.cu,
    // restart_strict_after_breakdown). The dispatch carries it into a "not
    // converged" result (fe_absorption.cpp); the regressor hands it to the fit's
    // one strict repair as HdfeOptions::strict_lsmr_consumed.
    bool cuda_strict_lsmr_restart = false;
};

struct HeterogeneousSlopeTerm {
    int fe_index = -1;
    Eigen::VectorXd values;
    bool include_intercept = false;
};

struct FeRecoveryResult {
    std::vector<Eigen::VectorXd> contributions;
    int iterations = 0;
    double max_delta = 0.0;
    bool converged = true;
};

// Compute an explicit normal-equation residual for the returned within
// transform. The diagnostic is independent of the solver's internal stopping
// proxy and uses fixed logical chunks, so its value is invariant to the OpenMP
// team size within one artefact/backend.
void certify_absorption_result(
    const Eigen::Ref<const Eigen::VectorXd>& y,
    const Eigen::Ref<const Eigen::MatrixXd>& X,
    const std::vector<Eigen::VectorXi>& fes,
    const Eigen::VectorXd* weights,
    const HdfeOptions& options,
    const std::vector<HeterogeneousSlopeTerm>& slopes,
    AbsorptionResult& result,
    const GroupIndividualStructure* group_individual = nullptr);

// Authoritative convergence gate for group()/individual() absorption.
// The norm-change proxy is only a candidate trigger: this routine certifies
// the explicit backward error (and the strict maximum-mean condition when
// requested), then makes converged and precision_certified agree.
// Forward-error target accepted by the group/individual Krylov solver: the
// running LSMR condition estimate times the dual residual test must not
// exceed it before a dual stop is accepted. Derived from the public
// tolerance of the mode (100 x the mode's dual tolerance, floored at 1e-8)
// unless options.group_forward_tolerance carries an explicit value.
double group_forward_tolerance(const HdfeOptions& options);

// Weighted relative residual sum of squares of the ones vector projected on
// the span of the absorbed effects (ordinary FEs and the group/individual
// incidence). Decides whether a design spans the constant when its structure
// alone cannot (sum aggregation, no ordinary FE, uneven team sizes). One
// right-hand side solved by the exact direct route when the design is
// eligible, otherwise by the LSMR of the backend that did the absorption
// (gpu_cuda), outside the certificate, refinement and retry machinery: a
// consistent system has no dual residual to certify, and the decision only
// needs the residual norm.
double group_constant_projection_residual_rel(
    const std::vector<Eigen::VectorXi>& standard_fes,
    const GroupIndividualStructure& gi,
    const Eigen::VectorXd* weights,
    const HdfeOptions& options,
    bool gpu_cuda);

bool certify_group_individual_candidate(
    const Eigen::Ref<const Eigen::VectorXd>& y,
    const Eigen::Ref<const Eigen::MatrixXd>& X,
    const std::vector<Eigen::VectorXi>& standard_fes,
    const GroupIndividualStructure& group_individual,
    const Eigen::VectorXd* weights,
    const HdfeOptions& options,
    AbsorptionResult& result);

AbsorptionResult absorb_fixed_effects(const Eigen::VectorXd& y,
                                      const Eigen::MatrixXd& X,
                                      const std::vector<Eigen::VectorXi>& fes,
                                      const Eigen::VectorXd* weights,
                                      const HdfeOptions& options);

AbsorptionResult absorb_fixed_effects_v6(const Eigen::Ref<const Eigen::VectorXd>& y,
                                         const Eigen::Ref<const Eigen::MatrixXd>& X,
                                         const std::vector<Eigen::VectorXi>& fes,
                                         const Eigen::VectorXd* weights,
                                         const HdfeOptions& options,
                                         AbsorptionMethod method,
                                         const std::vector<HeterogeneousSlopeTerm>& slopes = {});

AbsorptionResult absorb_fixed_effects_group_individual(const Eigen::VectorXd& y,
                                                       const Eigen::MatrixXd& X,
                                                       const std::vector<Eigen::VectorXi>& standard_fes,
                                                       const GroupIndividualStructure& gi,
                                                       const Eigen::VectorXd* weights,
                                                       const HdfeOptions& options,
                                                       AbsorptionMethod method);

AbsorptionResult absorb_fixed_effects_krylov(const Eigen::VectorXd& y,
                                             const Eigen::MatrixXd& X,
                                             const std::vector<Eigen::VectorXi>& fes,
                                             const Eigen::VectorXd* weights,
                                             const HdfeOptions& options);

// Matrix-free LSMR / modified-LSMR (MLSMR) additive-Schwarz absorber.
// Standalone, CPU-only; reached by explicit absorptionmethod(lsmr|mlsmr),
// explicit auto-mlsmr, or the default auto selector on eligible standard-FE
// designs. Fails closed for savefe/retain-FE paths.
AbsorptionResult absorb_fixed_effects_mlsmr(const Eigen::VectorXd& y,
                                            const Eigen::MatrixXd& X,
                                            const std::vector<Eigen::VectorXi>& fes,
                                            const Eigen::VectorXd* weights,
                                            const HdfeOptions& options);

FeRecoveryResult recover_fixed_effects(const Eigen::VectorXd& partial,
                                       const std::vector<Eigen::VectorXi>& fes,
                                       const Eigen::VectorXd* weights,
                                       const HdfeOptions& options);

FeRecoveryResult recover_fixed_effects(const Eigen::VectorXd& partial,
                                       const std::vector<Eigen::VectorXi>& fes,
                                       const Eigen::VectorXd* weights,
                                       const HdfeOptions& options,
                                       double solver_fe_tolerance);

FeRecoveryResult recover_fixed_effects_group_ids(const Eigen::VectorXd& partial,
                                                 const std::vector<std::vector<int>>& fe_group_ids,
                                                 const std::vector<int>& fe_levels,
                                                 const Eigen::VectorXd* weights,
                                                 const HdfeOptions& options,
                                                 const std::vector<Eigen::VectorXd>* weight_sums_override = nullptr);

FeRecoveryResult recover_fixed_effects_group_ids(const Eigen::VectorXd& partial,
                                                 const std::vector<std::vector<int>>& fe_group_ids,
                                                 const std::vector<int>& fe_levels,
                                                 const Eigen::VectorXd* weights,
                                                 const HdfeOptions& options,
                                                 const std::vector<Eigen::VectorXd>* weight_sums_override,
                                                 double solver_fe_tolerance);

// Explicit coordinates for a correction in an already-normalized problem.
// Existing overloads retain automatic normalization and their ABI.
FeRecoveryResult recover_fixed_effects_group_ids(const Eigen::VectorXd& partial,
                                                 const std::vector<std::vector<int>>& fe_group_ids,
                                                 const std::vector<int>& fe_levels,
                                                 const Eigen::VectorXd* weights,
                                                 const HdfeOptions& options,
                                                 const std::vector<Eigen::VectorXd>* weight_sums_override,
                                                 double solver_fe_tolerance,
                                                 int coordinate_exponent);


double fe_recovery_max_delta(Eigen::VectorXd& residual,
                             const std::vector<std::vector<int>>& fe_group_ids,
                             const std::vector<int>& fe_levels,
                             const Eigen::VectorXd* weights,
                             const HdfeOptions& options,
                             const std::vector<Eigen::VectorXd>* weight_sums_override = nullptr);

}  // namespace detail
}  // namespace hdfe

#endif  // HDFE_FE_ABSORPTION_HPP
