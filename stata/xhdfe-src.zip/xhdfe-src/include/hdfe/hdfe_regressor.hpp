#ifndef HDFE_REGRESSOR_HPP
#define HDFE_REGRESSOR_HPP

#include <Eigen/Dense>

#include <functional>
#include <vector>

namespace hdfe {

namespace detail {
class ParallelWorkObserver;

/** \brief Internal (F2-A): the CPU automatic route selector's answer for one fit. */
struct AutoRouteAnswer {
    bool mlsmr = false;    //!< The selector picks MLSMR (otherwise its sweep fallback).
    double rho = 0.0;      //!< Its sampled per-sweep contraction (NaN when not probed).
    double seconds = 0.0;  //!< Wall time of its one evaluation in this fit (trace only).
    int evaluations = 0;   //!< Evaluations so far in this fit (at most one).
};
}

/** \brief Supported covariance estimators for coefficient inference. */
enum class StandardErrorType { Homoskedastic, Robust, Cluster };

/** \brief Algorithmic strategy used for the fixed-effect absorber. */
enum class AbsorptionMethod { Auto, GaussSeidel, SymmetricGaussSeidel, Jacobi, Schwarz, Lsmr, Mlsmr, AutoMlsmr };

/** \brief Numerical stopping rule used by the alternating-projection absorber. */
enum class ConvergenceCriterion { Auto, NormChange, Reghdfe, Both };

/** \brief Algorithmic strategy used to recover fixed effects when saving them. */
enum class FeRecoveryMethod { Map, Hybrid };

/** \brief Degree-of-freedom adjustment strategy for absorbed fixed effects (reghdfe-style). */
enum class DofAdjustmentMethod { All, None, FirstPair, Pairwise, Exact };

/** \brief Fixed-effect DoF counting strategy for SSC (fixest-style). */
enum class FixefDofMethod { Full, None, Nonnested };

/** \brief Multiway cluster DoF strategy for SSC (fixest-style). */
enum class ClusterDofMethod { Min, Conventional };

/** \brief Statistics style for small-sample corrections and fit statistics. */
enum class StatsStyle { Reghdfe, Legacy };

/** \brief Absorber convergence mode. */
enum class ToleranceMode { XhdfeFast, ReghdfeComparable, StrictResidual };

/**
 * \brief Configuration parameters controlling numerical tolerances and options for HDFE estimation.
 */
struct HdfeOptions {
    StandardErrorType se_type = StandardErrorType::Robust; //!< Covariance estimator to use after estimation.
    double level = 95.0;                                   //!< Confidence level (percent) used for confidence intervals.
    bool inference_quantiles = true;                       //!< Internal: false skips the Student-t critical value and p-values (conf_int and pvalues are NaN; t is still computed). Only the AKM/KSS control-partialling (FWL) fit sets it: its caller uses coefficients and the convergence, certificate and omission flags only. Every public fit keeps the default.
    bool fit_intercept = true;                             //!< Whether to append an intercept column to X automatically.
    double tol = 1e-8;                                     //!< Convergence tolerance for the fixed-effect absorber.
    ToleranceMode tolerance_mode = ToleranceMode::ReghdfeComparable; //!< Absorber stopping semantics.
                                                           //!< Default (since 2.7.0): reghdfe-comparable stops when one
                                                           //!< full sweep moves the working data by less than tol in
                                                           //!< relative norm (reghdfe's meaning of tolerance).
                                                           //!< XhdfeFast restores the pre-2.7.0 fast trigger;
                                                           //!< StrictResidual is the audited certificate mode.
    double fe_tolerance = 1e-6;                            //!< Convergence tolerance for fixed-effect recovery (savefes).
    double group_forward_tolerance = 0.0;                  //!< Internal: forward-error target of the group/individual Krylov
                                                           //!< solver (condition estimate x dual residual). 0 derives it from
                                                           //!< the public tolerance of the mode; internal retries carry the
                                                           //!< public value so a tighter dual tolerance never tightens it.
    FeRecoveryMethod fe_recovery_method = FeRecoveryMethod::Hybrid; //!< Fixed-effect recovery strategy.
    int max_iter = 100000;                                 //!< Maximum alternating-projection iterations.
    int convergence_check_interval = 1;                    //!< Check convergence every k absorption iterations (1 = every iteration).
    ConvergenceCriterion convergence_criterion = ConvergenceCriterion::Auto; //!< Heterogeneous-slope absorber stopping rule.
                                                           //!< Auto (default) follows tolerance_mode: reghdfe-comparable maps
                                                           //!< to the reghdfe-style update criterion, xhdfe-fast to normchange.
                                                           //!< Explicit values override; standard (slope-free) absorption is
                                                           //!< governed by tolerance_mode alone.
    int num_threads = 0;                                   //!< Threads for absorption (0 = library default / auto).
    bool num_threads_explicit = false;                     //!< Internal: explicit positive request; bypass auto-only shape heuristics.
    detail::ParallelWorkObserver* parallel_observer = nullptr; //!< Internal: records workers executing real loop iterations.
    bool drop_singletons = true;                           //!< When true, iteratively drop singleton observations before estimation (reghdfe default).
    bool weights_are_frequencies = false;                  //!< Interpret weights as frequency weights for N/df bookkeeping.
    bool capture_fe_collinear_ss_ratio = false;             //!< Retain the already-computed FE-collinearity ratios for diagnostic consumers.
    bool capture_first_pair_component_stats = false;       //!< Retain first-pair mobility-component counts/shares during the existing DoF pass.
    bool retain_fixed_effects = false;                     //!< When true, recover and cache observation-level fixed effects.
    bool refine_stored_residuals = false;                  //!< When true, recompute stored residuals via a final absorption of y-Xb.
    bool stored_residuals_fit_state = false;               //!< Internal (P7, 2.31.0): set only by the Stata plugin for residuals(), together with refine_stored_residuals, which keeps recording the request (the opt-in accuracy prototypes read it). The stored residuals are then the fit's own within residuals, the vector behind rss and the covariance, and the late re-absorption of y-Xb does not run. Other callers keep the meaning of refine_stored_residuals. Not user-facing.
    int savefe_fastpath_max_cols = 8;                      //!< Max X columns to enable savefe alpha accumulation during absorption.
    bool symmetric_sweep = false;                          //!< When true, apply a forward and backward sweep per iteration for faster convergence.
    AbsorptionMethod absorption_method = AbsorptionMethod::Auto; //!< Absorption strategy selector (auto picks based on FE count and threads).
    bool from_auto = false;                                //!< Internal: set by the regressor when absorption_method was left Auto, so the adaptive Schwarz gate can fire after Auto is resolved to a concrete MAP method. Not user-facing.
    bool auto_intent = false;                              //!< Internal: provenance only, the public absorption_method is Auto. Set once by the regressor from the original request and never changed during the fit; unlike from_auto (which route selectors clear, and which on CUDA keeps its two-FE Comparable meaning) it never enables a route by itself. Not user-facing.
    bool fast_intent = false;                              //!< Internal (P3-fix): provenance only, the public request is tolerance_mode xhdfe-fast without saved fixed effects. Set once by the regressor from the original request and never changed during the fit, so an internal conversion (strict-residual repaired natively as xhdfe-fast, the savefe projection continuation) keeps it false; the CUDA xhdfe-fast restart of a broken CG stage applies only when it is true. Not user-facing.
    bool comparable_intent = false;                        //!< Internal (P8): provenance only, the public request is tolerance_mode reghdfe-comparable. Set once by the regressor from the original request and never changed during the fit, so an internal conversion to Comparable (the weighted native repairs, configure_native_cuda_repair) keeps it false; the weighted CPU retry and the weighted CUDA three-FE completion apply only when it is true. Not user-facing.
    bool strict_provenance = false;                        //!< Internal (P3-fix (3'), strict scope): provenance only, set by the regressor on the native CUDA attempt of a strict-residual fit (after configure_native_cuda_repair), on the CUDA primary of a strict-residual fit outside that branch (an explicit criterion or method), and on the strict repair of either, and nowhere else. A broken CUDA CG stage of such a stage, outside the Comparable rule, restarts cold with the device LSMR and the strict check (fe_absorption_cuda.cu, restart_strict_after_breakdown) unless strict_lsmr_consumed, never with the 2.30.1 cold MAP. It changes nothing else. Not user-facing.
    bool strict_lsmr_consumed = false;                     //!< Internal (P3-fix (3'), strict scope): state, not provenance: the strict recovery sequence of this fit already used its one device LSMR restart (the native attempt's result reported cuda_strict_lsmr_restart); set by the regressor on the strict repair's options. A broken CG stage of that repair then ends the fit with an honest refusal. Not user-facing.
    const std::function<detail::AutoRouteAnswer()>* cuda_tail_route = nullptr; //!< Internal (F2-A): the CPU automatic route selector of this fit, owned by the regressor for the duration of the fit and given only to the primary absorption; the CUDA three-FE Comparable completion consults it after it predicts a long tail. Not user-facing.
    double jacobi_relaxation = 0.0;                         //!< Optional relaxation factor for Jacobi (<=0 uses default 2/(J+1)).
    bool use_krylov = false;                               //!< When true, use Krylov-PCG partialling-out (v7+ only).
    bool ordinary_krylov_parity_floor = false;             //!< Internal caller contract: enable the ordinary no-slope LSMR/MLSMR parity floor.
    bool ordinary_auto_routing_retry = true;               //!< Default-on bounded CPU Auto sweep-to-MLSMR retry policy; env kill switch may disable.
    bool ordinary_auto_early_routing = true;               //!< Default-on early routing on the retry's eligible route: the primary leaves its sweep or gated conjugate-gradient stage for the retry's MLSMR when it is predicted to end above the retry trigger, and does not hand off to a conjugate-gradient stage (status 4); env kill switch XHDFE_AUTO_EARLY_ROUTING=0.
    bool early_routing = false;                            //!< Internal: set by the regressor on the eligible primary solve only, so that the absorber may leave early. Not user-facing.
    double krylov_lambda = 1e-6;                           //!< Ridge regularization for Krylov-PCG (v7+ only).
    int krylov_probe_iters = 0;                            //!< Internal: when >0, the Jacobi-PCG absorber caps the leading (y) solve at this many iterations and returns converged=false if it does not converge, so the adaptive Schwarz gate can fall back to the approx-Cholesky path on graphs where matrix-free PCG stalls. 0 = solve fully (no probe). Not user-facing.
    bool use_sparse_solver = false;                        //!< When true, attempt sparse direct/PCG absorption before MAP.
    double sparse_threshold = 0.0;                         //!< Max total FE levels to enable sparse absorption (0 = heuristic).
    DofAdjustmentMethod dof_method = DofAdjustmentMethod::All; //!< Degrees-of-freedom adjustment method (reghdfe default is all).
    bool dof_mobility_groups = true;                        //!< Run first-pair/pairwise FE mobility-group redundancy checks.
    bool dof_adjust_clusters = true;                       //!< Apply cluster nesting DoF adjustments when clustering on absorbed variables.
    bool dof_adjust_continuous = true;                     //!< Apply reghdfe-compatible continuous-interaction DoF checks.
    bool save_groupvar = false;                            //!< When true, compute and store the first mobility group variable (reghdfe groupvar()).
    std::vector<int> sweep_order_override;                 //!< Optional sweep order override (0-based FE indices); empty = auto.
    bool ssc_k_adj = true;                                 //!< Apply (N-1)/(N-K) small-sample adjustment (fixest K.adj).
    FixefDofMethod ssc_k_fixef = FixefDofMethod::Full;      //!< How to count fixed effects in K (fixest K.fixef).
    bool ssc_k_exact = true;                               //!< Use exact FE rank when counting K (fixest K.exact).
    bool ssc_g_adj = true;                                 //!< Apply G/(G-1) cluster adjustment (fixest G.adj).
    ClusterDofMethod ssc_g_df = ClusterDofMethod::Min;      //!< Multiway cluster DoF (fixest G.df).
    double ssc_t_df = -1.0;                                //!< Override t df (fixest t.df); <=0 disables.
    StatsStyle stats_style = StatsStyle::Reghdfe;          //!< Fit-statistics style (reghdfe default).
    std::vector<int> collinear_priority;                   //!< Column priority when dropping collinear regressors (higher = keep).
    int dkraay_bandwidth = -1;                            //!< -1: ordinary VCE; 0: automatic DK bandwidth; >0: Bartlett bandwidth. Requires one chronologically ordered cluster ID.
};

/**
 * \brief Dense summary of estimation results and auxiliary diagnostics.
 */
struct HdfeResults {
    Eigen::VectorXd coefficients;  //!< Estimated regression coefficients in the order passed to X (including intercept when active).
    Eigen::VectorXd std_errors;        //!< Standard errors corresponding to each coefficient.
    Eigen::VectorXd tvalues;       //!< t-statistics computed from coefficients and the chosen covariance estimator.
    Eigen::VectorXd pvalues;       //!< Two-sided p-values based on the normal approximation.
    Eigen::MatrixXd conf_int;      //!< Column-wise confidence intervals (p x 2) for the requested confidence level (default 95%).
    Eigen::MatrixXd covariance;    //!< Variance-covariance matrix corresponding to the stored coefficients.
    Eigen::VectorXd residuals;     //!< Regression residuals after absorbing fixed effects.
    std::vector<int> omitted_reason; //!< Omitted-regressor reason codes (0=kept, 1=collinear with FEs, 2=other collinearity).
    Eigen::VectorXd fe_collinear_ss_ratio; //!< Per-slope ||M_D x||^2 / ||x||^2 used by the FE-collinearity classifier.
    int nobs = 0;                  //!< Number of observations used in estimation.
    int nobs_full = 0;             //!< Number of observations prior to singleton dropping (if enabled).
    int num_singletons = 0;        //!< Number of singleton observations dropped prior to estimation.
    double nobs_effective = 0.0;   //!< Effective N used for df/statistics (row count unless frequency weights are active).
    double nobs_full_effective = 0.0; //!< Effective full N prior to singleton dropping.
    double num_singletons_effective = 0.0; //!< Effective singleton count (nobs_full_effective - nobs_effective).
    Eigen::VectorXi sample_index;  //!< 0-based indices of kept observations into the input arrays (length nobs).
    double df_resid = 0.0;         //!< Residual degrees of freedom.
    double df_resid_unadj = 0.0;   //!< Unclustered residual degrees of freedom (before cluster df adjustment).
    double df_m = 0.0;             //!< Model degrees of freedom excluding the intercept.
    double df_a = 0.0;             //!< Degrees of freedom absorbed by fixed effects (reghdfe-style).
    double df_a_levels = 0.0;      //!< Raw FE level count (sum of levels across dimensions).
    double df_a_exact = 0.0;       //!< Exact FE DoF after redundancy (sum of non-redundant levels).
    double df_a_nested = 0.0;      //!< FE DoF nested within clusters (used in SSC adjustments).
    bool model_has_constant = true; //!< The fitted model contains a constant: an explicit intercept or one spanned by the absorbed effects. False for noconstant fits without absorbed levels and for group/individual sum aggregation whose membership columns do not span the constant.
    double r2 = 0.0;               //!< Overall (between) R-squared.
    double r2_within = 0.0;        //!< Within R-squared measured on transformed data.
    double sigma2 = 0.0;           //!< Estimated variance of residuals under the selected covariance model.
    double rss = 0.0;              //!< Residual sum of squares.
    double tss = 0.0;              //!< Total sum of squares.
    double tss_within = 0.0;       //!< Within total sum of squares.
    std::vector<int> fe_num_levels; //!< Number of levels in each fixed-effect dimension.
    std::vector<int> fe_base_levels; //!< Distinct FE levels present in the estimation sample per dimension (before any heterogeneous-slope DoF expansion).
    std::vector<int> fe_base_redundant; //!< Redundant intercept-category DoF before heterogeneous-slope expansion.
    std::vector<int> fe_redundant;  //!< Redundant FE levels (M) per dimension (reghdfe-style).
    std::vector<int> fe_num_coefs;  //!< Non-redundant FE levels (K-M) per dimension.
    std::vector<int> fe_inexact;    //!< Flags for inexact redundancy counts per FE (1=inexact).
    std::vector<int> fe_nested;     //!< Flags for FEs nested within clusters (1=nested).
    int num_iterations = 0;        //!< Number of absorption iterations performed.
    Eigen::VectorXi groupvar;      //!< First mobility group (connected component) identifier, when requested via groupvar().
    std::vector<Eigen::VectorXd> fe_effects; //!< Observation-level contribution of each FE dimension (one vector per FE).
    std::vector<Eigen::VectorXd> fe_save_effects; //!< Variables to write for savefe/savefes (includes heterogeneous slope coefficients).
    int fe_recovery_iterations = 0; //!< Number of sweeps used to recover fixed effects when retained.
    double fe_recovery_max_delta = 0.0; //!< Maximum change observed in the final FE recovery sweep.
    bool fe_recovery_converged = true; //!< Whether the FE recovery loop converged within the iteration cap.
    bool converged = true;         //!< Flag indicating whether the absorber reached tolerance.
    double abs_residual = 0.0;     //!< Verified absolute normal-equation residual after absorption.
    double abs_residual_rel = 0.0; //!< Verified relative normal-equation residual after absorption.
    bool slope_block_checked = false; //!< Whether block diagnostics were computed; false in fast mode.
    double slope_block_residual_rel = 0.0; //!< Undiluted max per-block/RHS slope certificate.
    double slope_block_frobenius_rel = 0.0; //!< Max per-block Frobenius-scaled moment.
    double slope_block_rms_rel = 0.0; //!< Max RMS diagonal-scaled group moment.
    double slope_block_max_rel = 0.0; //!< Max worst-group diagonal-scaled moment.
    double slope_block_skipped_max_rel = 0.0; //!< Max skipped rank-deficient-group cosine.
    int slope_certificate_worst_fe = -1; //!< Internal FE dimension attaining the slope gate.
    int slope_certificate_worst_moment = -1; //!< 0 intercept/plain, 1 slope.
    int slope_accuracy_retry_stages = 0; //!< Adaptive continuation stages completed.
    int slope_accuracy_retry_iterations = 0; //!< Continuation iterations beyond primary.
    double slope_internal_tolerance = 0.0; //!< Last internal continuation tolerance.
    double krylov_internal_tolerance = 0.0; //!< Internal ordinary no-slope LSMR/MLSMR tolerance; zero otherwise.
    double krylov_max_final_backward_error = 0.0; //!< Maximum final LSMR test2 across RHS solves.
    double krylov_max_condition = 0.0; //!< Maximum running Krylov condition estimate across RHS solves.
    double krylov_max_condition_times_backward_error = 0.0; //!< Maximum condition*test2 across RHS solves.
    bool auto_routing_retry_policy_enabled = false; //!< Default-on bounded Auto retry policy state.
    bool auto_routing_retry_eligible = false; //!< Whether all bounded retry eligibility gates passed.
    bool auto_routing_retry_fired = false; //!< Whether the one cold MLSMR retry ran.
    int auto_routing_retry_status = 0; //!< 0 ineligible/disabled, 1 below trigger, 2 retry returned, 3 retry failed/primary returned, 4 primary left early and the retry returned.
    int auto_routing_retry_primary_method = -1; //!< Concrete primary AbsorptionMethod code.
    int auto_routing_retry_primary_iterations = 0; //!< Iterations used by the primary sweep.
    double auto_routing_retry_primary_abs_residual_rel = 0.0; //!< Existing primary canonical certificate metric.
    int auto_routing_retry_iterations = 0; //!< Iterations used by the cold MLSMR retry.
    double auto_routing_retry_abs_residual_rel = 0.0; //!< Retry canonical certificate metric.
    double auto_routing_retry_elapsed_seconds = 0.0; //!< Wall time of the retry phase only.
    bool precision_certified = true; //!< Whether the verified residual meets the declared certificate limit.
    int num_clusters = 0;          //!< Minimum number of clusters across dimensions (if clustered).
    std::vector<int> cluster_counts; //!< Number of clusters for each dimension (if clustered).
    std::vector<int> cluster_combo_counts; //!< Cluster counts for each multiway combination (optional).
    double cluster_scale = 1.0;    //!< Final scale applied to the cluster covariance matrix.
    bool vcv_psd_fixed = false;    //!< Multiway-cluster VCV needed the Cameron-Gelbach-Miller PSD adjustment.

    //! Saturated / perfect-fit design: the absorbed FEs plus the regressors span
    //! the data, so the within residuals are ~0 (within R-sq = 1). The point
    //! estimates are exact, but the error variance — and hence the standard
    //! errors — is not identified. True only with estimated regressors
    //! (df_m > 0) and a residual sum of squares negligible relative to the
    //! within total. Purely derived from already-computed quantities, so it adds
    //! no work to estimation. Lets a consumer distinguish a legitimate zero SE
    //! (saturated, e.g. synthetic-zigzag) from a zero/garbage SE produced by a
    //! failed or unstable solve (where rss is not ~0).
    bool is_saturated() const {
        return df_m > 0.0 && tss_within > 0.0 && rss <= 1.0e-9 * tss_within;
    }
};

}  // namespace hdfe

#endif  // HDFE_REGRESSOR_HPP
