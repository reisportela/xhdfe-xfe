#include <pybind11/eigen.h>
#include <pybind11/numpy.h>
#include <pybind11/pybind11.h>
#include <pybind11/stl.h>

#include <algorithm>
#include <cctype>
#include <cmath>
#include <iomanip>
#include <limits>
#include <optional>
#include <sstream>
#include <string>
#include <cstdint>
#include <unordered_map>

#include "hdfe/akm_kss.hpp"
#include "hdfe/hdfe_regressor_v11.hpp"

namespace py = pybind11;
using hdfe::AbsorptionMethod;
using hdfe::ConvergenceCriterion;
using hdfe::DofAdjustmentMethod;
using hdfe::FixefDofMethod;
using hdfe::HdfeOptions;
using hdfe::StandardErrorType;
using hdfe::ClusterDofMethod;
using hdfe::ToleranceMode;
using hdfe::detail::HeterogeneousSlopeTerm;
using hdfe::v11::HdfeRegressorV11;
using hdfe::v11::GroupAggregation;
using hdfe::v11::ThreadingOptions;

namespace hdfe {
namespace v11 {

class BindingAttemptGuard {
public:
    BindingAttemptGuard(HdfeRegressorV11& owner, bool weights_are_frequencies)
        : owner_(owner),
          previous_weights_are_frequencies_(
              owner.options_.weights_are_frequencies) {
        owner_.begin_attempt();
        owner_.options_.weights_are_frequencies = weights_are_frequencies;
    }

    ~BindingAttemptGuard() {
        if (!committed_) {
            owner_.fail_attempt();
            owner_.options_.weights_are_frequencies =
                previous_weights_are_frequencies_;
        }
    }

    void commit() noexcept { committed_ = true; }

private:
    HdfeRegressorV11& owner_;
    bool previous_weights_are_frequencies_ = false;
    bool committed_ = false;
};

}  // namespace v11
}  // namespace hdfe

namespace {

// Observation counts are integral row counts unless frequency weights are
// active, in which case the effective count is a weighted total that can
// exceed the int range. Return the plain row count when the effective count
// carries no extra information, so the common case keeps its Python int type.
py::object effective_count_or_rows(double effective, int rows) {
    if (effective == static_cast<double>(rows)) {
        return py::int_(rows);
    }
    if (effective >= 0.0 &&
        effective <= 9223372036854774784.0 &&
        std::floor(effective) == effective) {
        return py::int_(static_cast<std::int64_t>(effective));
    }
    return py::float_(effective);
}

int checked_index_id(std::int64_t value, const char* label) {
    if (value < 0) {
        throw std::runtime_error(
            std::string(label) +
            " must contain only nonnegative IDs; pandas.factorize() uses -1 "
            "for missing categories");
    }
    if (value < static_cast<std::int64_t>(std::numeric_limits<int>::min()) ||
        value > static_cast<std::int64_t>(std::numeric_limits<int>::max())) {
        throw std::runtime_error(std::string(label) + " contains an id outside the int32 range");
    }
    return static_cast<int>(value);
}

bool fits_int32(std::int64_t value) {
    return value >= static_cast<std::int64_t>(std::numeric_limits<int>::min()) &&
           value <= static_cast<std::int64_t>(std::numeric_limits<int>::max());
}

template <typename Getter>
Eigen::VectorXi remap_or_cast_int64_ids(ssize_t n, const char* label, Getter&& get_value) {
    Eigen::VectorXi ids(static_cast<int>(n));
    // Common path (covers every in-range int64 id column, e.g. the simulated-panel and QP
    // benchmarks): a SINGLE pass that casts directly and bails to the remap only if it ever
    // meets an out-of-int32 value. The earlier two-pass form (pre-scan + cast) doubled the
    // per-column parse cost on large int64 inputs for no benefit on the dominant in-range
    // case.
    ssize_t i = 0;
    for (; i < n; ++i) {
        const std::int64_t value = get_value(i);
        if (value < 0) {
            throw std::runtime_error(
                std::string(label) +
                " must contain only nonnegative IDs; pandas.factorize() uses "
                "-1 for missing categories");
        }
        if (!fits_int32(value)) {
            break;
        }
        ids(static_cast<int>(i)) = static_cast<int>(value);
    }
    if (i == n) {
        return ids;
    }

    // Some id exceeds the int32 range: remap ALL ids of this column to compact [0,next)
    // codes (by first appearance) so distinct labels can never collide via 32-bit
    // truncation. Restart from 0 so the mapping is consistent across the whole column.
    std::unordered_map<std::int64_t, int> levels;
    levels.reserve(static_cast<std::size_t>(std::min<ssize_t>(n, 1'000'000)));
    int next = 0;
    for (ssize_t i = 0; i < n; ++i) {
        const std::int64_t value = get_value(i);
        if (value < 0) {
            throw std::runtime_error(
                std::string(label) +
                " must contain only nonnegative IDs; pandas.factorize() uses "
                "-1 for missing categories");
        }
        auto it = levels.find(value);
        if (it == levels.end()) {
            if (next == std::numeric_limits<int>::max()) {
                throw std::runtime_error(std::string(label) + " has too many distinct ids");
            }
            it = levels.emplace(value, next++).first;
        }
        ids(static_cast<int>(i)) = it->second;
    }
    return ids;
}

StandardErrorType parse_se_type(const std::string& name) {
    const std::string lower = [&name]() {
        std::string tmp = name;
        std::transform(tmp.begin(), tmp.end(), tmp.begin(), [](unsigned char c) {
            return static_cast<char>(std::tolower(c));
        });
        return tmp;
    }();
    if (lower == "homoskedastic" || lower == "classical" || lower == "unadjusted" ||
        lower == "unadj" || lower == "ols") {
        return StandardErrorType::Homoskedastic;
    }
    if (lower == "robust" || lower == "hc1" || lower == "heteroskedastic") {
        return StandardErrorType::Robust;
    }
    if (lower == "cluster" || lower == "clustered") {
        return StandardErrorType::Cluster;
    }
    throw std::runtime_error("Unknown standard error type: " + name);
}

AbsorptionMethod parse_absorption_method(const std::string& name) {
    const std::string lower = [&name]() {
        std::string tmp = name;
        std::transform(tmp.begin(), tmp.end(), tmp.begin(), [](unsigned char c) {
            return static_cast<char>(std::tolower(c));
        });
        return tmp;
    }();
    if (lower == "auto") {
        return AbsorptionMethod::Auto;
    }
    if (lower == "gs" || lower == "gauss-seidel" || lower == "gauss_seidel") {
        return AbsorptionMethod::GaussSeidel;
    }
    if (lower == "sym" || lower == "symmetric" || lower == "symgs" ||
        lower == "symmetric-gauss-seidel" || lower == "symmetric_gauss_seidel") {
        return AbsorptionMethod::SymmetricGaussSeidel;
    }
    if (lower == "jacobi") {
        return AbsorptionMethod::Jacobi;
    }
    if (lower == "schwarz" || lower == "pcg" || lower == "schwarz-pcg") {
        return AbsorptionMethod::Schwarz;
    }
    if (lower == "lsmr" || lower == "plain-lsmr" || lower == "plain_lsmr") {
        return AbsorptionMethod::Lsmr;
    }
    if (lower == "mlsmr" || lower == "modified-lsmr" || lower == "modified_lsmr" ||
        lower == "within" || lower == "within-additive" || lower == "within_additive") {
        return AbsorptionMethod::Mlsmr;
    }
    if (lower == "auto-mlsmr" || lower == "auto_mlsmr" ||
        lower == "mlsmr-auto" || lower == "mlsmr_auto") {
        return AbsorptionMethod::AutoMlsmr;
    }
    throw std::runtime_error("Unknown absorption method: " + name);
}

ToleranceMode parse_tolerance_mode(const std::string& name) {
    const std::string lower = [&name]() {
        std::string tmp = name;
        std::transform(tmp.begin(), tmp.end(), tmp.begin(), [](unsigned char c) {
            return static_cast<char>(std::tolower(c));
        });
        return tmp;
    }();
    if (lower == "xhdfe-fast" || lower == "xhdfe_fast" || lower == "xhdfe" ||
        lower == "fast" || lower == "current") {
        return ToleranceMode::XhdfeFast;
    }
    if (lower == "reghdfe-comparable" || lower == "reghdfe_comparable" ||
        lower == "reghdfe" || lower == "comparable") {
        return ToleranceMode::ReghdfeComparable;
    }
    if (lower == "strict-residual" || lower == "strict_residual" ||
        lower == "residual-certificate" || lower == "residual_certificate" ||
        lower == "strict") {
        return ToleranceMode::StrictResidual;
    }
    throw std::runtime_error("Unknown tolerance mode: " + name);
}

ConvergenceCriterion parse_convergence_criterion(const std::string& name) {
    const std::string lower = [&name]() {
        std::string tmp = name;
        std::transform(tmp.begin(), tmp.end(), tmp.begin(), [](unsigned char c) {
            return static_cast<char>(std::tolower(c));
        });
        return tmp;
    }();
    if (lower == "auto" || lower.empty()) {
        return ConvergenceCriterion::Auto;
    }
    if (lower == "normchange" || lower == "norm_change" || lower == "norm-change" ||
        lower == "norm") {
        return ConvergenceCriterion::NormChange;
    }
    if (lower == "reghdfe" || lower == "update" || lower == "reldif") {
        return ConvergenceCriterion::Reghdfe;
    }
    if (lower == "both") {
        return ConvergenceCriterion::Both;
    }
    throw std::runtime_error("Unknown convergence criterion: " + name);
}

FixefDofMethod parse_fixef_method(const std::string& name) {
    const std::string lower = [&name]() {
        std::string tmp = name;
        std::transform(tmp.begin(), tmp.end(), tmp.begin(), [](unsigned char c) {
            return static_cast<char>(std::tolower(c));
        });
        return tmp;
    }();
    if (lower == "full" || lower == "true" || lower == "yes") {
        return FixefDofMethod::Full;
    }
    if (lower == "none" || lower == "false" || lower == "no") {
        return FixefDofMethod::None;
    }
    if (lower == "nonnested" || lower == "non-nested" || lower == "non_nested") {
        return FixefDofMethod::Nonnested;
    }
    throw std::runtime_error("Unknown K.fixef: " + name);
}

ClusterDofMethod parse_cluster_df(const std::string& name) {
    const std::string lower = [&name]() {
        std::string tmp = name;
        std::transform(tmp.begin(), tmp.end(), tmp.begin(), [](unsigned char c) {
            return static_cast<char>(std::tolower(c));
        });
        return tmp;
    }();
    if (lower == "min") {
        return ClusterDofMethod::Min;
    }
    if (lower == "conventional" || lower == "conv") {
        return ClusterDofMethod::Conventional;
    }
    throw std::runtime_error("Unknown G.df: " + name);
}

GroupAggregation parse_group_aggregation(const std::string& name) {
    const std::string lower = [&name]() {
        std::string tmp = name;
        std::transform(tmp.begin(), tmp.end(), tmp.begin(), [](unsigned char c) {
            return static_cast<char>(std::tolower(c));
        });
        return tmp;
    }();
    if (lower == "mean" || lower == "average" || lower == "avg") {
        return GroupAggregation::Mean;
    }
    if (lower == "sum") {
        return GroupAggregation::Sum;
    }
    throw std::runtime_error("Unknown aggregation: " + name);
}

Eigen::VectorXi parse_index_vector(const py::handle& obj,
                                  const char* label,
                                  ssize_t expected_n) {
    if (expected_n <= 0) {
        return Eigen::VectorXi();
    }
    py::array raw;
    if (py::isinstance<py::array>(obj)) {
        raw = py::reinterpret_borrow<py::array>(obj);
    } else {
        auto converted = py::array_t<std::int64_t, py::array::forcecast>::ensure(obj);
        if (!converted) {
            throw std::runtime_error(std::string(label) + " must be array-like");
        }
        raw = converted;
    }
    if (!raw) {
        throw std::runtime_error(std::string(label) + " must be array-like");
    }
    if (raw.ndim() != 1) {
        throw std::runtime_error(std::string(label) + " must be 1-D");
    }
    if (raw.shape(0) != expected_n) {
        throw std::runtime_error(std::string(label) + " length must match nobs");
    }

    const auto dtype = raw.dtype();
    if (dtype.is(py::dtype::of<std::int32_t>())) {
        auto arr = py::array_t<std::int32_t, py::array::c_style | py::array::forcecast>(raw);
        return Eigen::Map<const Eigen::VectorXi>(arr.data(),
                                                static_cast<Eigen::Index>(expected_n));
    }
    if (dtype.is(py::dtype::of<std::int64_t>())) {
        auto arr = py::array_t<std::int64_t, py::array::c_style | py::array::forcecast>(raw);
        const std::int64_t* data = arr.data();
        return remap_or_cast_int64_ids(expected_n, label, [data](ssize_t i) {
            return data[i];
        });
    }
    auto arr = py::array_t<std::int64_t, py::array::c_style | py::array::forcecast>(raw);
    const std::int64_t* data = arr.data();
    return remap_or_cast_int64_ids(expected_n, label, [data](ssize_t i) {
        return data[i];
    });
}

Eigen::VectorXi parse_index_matrix_column(const py::array& arr,
                                         const char* label,
                                         ssize_t row,
                                         ssize_t col) {
    if (row <= 0) {
        return Eigen::VectorXi();
    }
    const auto dtype = arr.dtype();
    if (dtype.is(py::dtype::of<std::int32_t>())) {
        auto c_arr =
            py::array_t<std::int32_t, py::array::c_style | py::array::forcecast>(arr);
        const std::int32_t* data = c_arr.data();
        const ssize_t stride = arr.shape(1);
        Eigen::VectorXi ids(static_cast<int>(row));
        for (ssize_t i = 0; i < row; ++i) {
            ids(static_cast<int>(i)) = checked_index_id(data[i * stride + col], label);
        }
        return ids;
    }
    if (dtype.is(py::dtype::of<std::int64_t>())) {
        auto c_arr = py::array_t<std::int64_t, py::array::c_style | py::array::forcecast>(arr);
        const std::int64_t* data = c_arr.data();
        const ssize_t stride = arr.shape(1);
        return remap_or_cast_int64_ids(row, label, [data, stride, col](ssize_t i) {
            return data[i * stride + col];
        });
    }
    auto c_arr = py::array_t<std::int64_t, py::array::c_style | py::array::forcecast>(arr);
    const std::int64_t* data = c_arr.data();
    const ssize_t stride = arr.shape(1);
    return remap_or_cast_int64_ids(row, label, [data, stride, col](ssize_t i) {
        return data[i * stride + col];
    });
}

Eigen::VectorXd parse_double_vector(const py::handle& obj,
                                    const char* label,
                                    ssize_t expected_n) {
    if (expected_n <= 0) {
        return Eigen::VectorXd();
    }
    auto borrowed = py::reinterpret_borrow<py::object>(obj);
    auto arr = py::array_t<double, py::array::c_style | py::array::forcecast>(borrowed);
    if (arr.ndim() != 1) {
        throw std::runtime_error(std::string(label) + " must be 1-D");
    }
    if (arr.shape(0) != expected_n) {
        throw std::runtime_error(std::string(label) + " length must match nobs");
    }
    return Eigen::Map<const Eigen::VectorXd>(arr.data(),
                                            static_cast<Eigen::Index>(expected_n));
}

HeterogeneousSlopeTerm parse_slope_term(const py::handle& obj,
                                        ssize_t expected_n) {
    HeterogeneousSlopeTerm term;
    if (py::isinstance<py::dict>(obj)) {
        py::dict item = py::reinterpret_borrow<py::dict>(obj);
        if (!item.contains("fe_index")) {
            throw std::runtime_error("Each heterogeneous slope dict needs fe_index");
        }
        if (!item.contains("values")) {
            throw std::runtime_error("Each heterogeneous slope dict needs values");
        }
        term.fe_index = py::cast<int>(item["fe_index"]);
        term.values = parse_double_vector(item["values"], "heterogeneous slope values", expected_n);
        term.include_intercept =
            item.contains("include_intercept") ? py::cast<bool>(item["include_intercept"]) : false;
        return term;
    }

    py::sequence item = py::reinterpret_borrow<py::sequence>(obj);
    if (item.size() < 2 || item.size() > 3) {
        throw std::runtime_error(
            "Each heterogeneous slope tuple must be (fe_index, values[, include_intercept])");
    }
    term.fe_index = py::cast<int>(item[0]);
    term.values = parse_double_vector(item[1], "heterogeneous slope values", expected_n);
    term.include_intercept = item.size() == 3 ? py::cast<bool>(item[2]) : false;
    return term;
}

std::optional<std::vector<HeterogeneousSlopeTerm>> parse_slope_terms(py::object slopes_obj,
                                                                     ssize_t expected_n) {
    if (slopes_obj.is_none()) {
        return std::nullopt;
    }
    std::vector<HeterogeneousSlopeTerm> out;
    if (py::isinstance<py::dict>(slopes_obj)) {
        out.push_back(parse_slope_term(slopes_obj, expected_n));
        return out;
    }

    py::sequence seq = py::reinterpret_borrow<py::sequence>(slopes_obj);
    out.reserve(seq.size());
    for (auto item : seq) {
        out.push_back(parse_slope_term(item, expected_n));
    }
    return out;
}

std::string method_name(AbsorptionMethod method) {
    switch (method) {
        case AbsorptionMethod::GaussSeidel:
            return "gauss-seidel";
        case AbsorptionMethod::SymmetricGaussSeidel:
            return "symmetric-gauss-seidel";
        case AbsorptionMethod::Jacobi:
            return "jacobi";
        case AbsorptionMethod::Schwarz:
            return "schwarz";
        case AbsorptionMethod::Lsmr:
            return "lsmr";
        case AbsorptionMethod::Mlsmr:
            return "mlsmr";
        case AbsorptionMethod::AutoMlsmr:
            return "auto-mlsmr";
        case AbsorptionMethod::Auto:
        default:
            return "auto";
    }
}

struct ParsedDofAdjustments {
    DofAdjustmentMethod method = DofAdjustmentMethod::All;
    bool mobility_groups = true;
    bool adjust_clusters = true;
    bool adjust_continuous = true;
};

ParsedDofAdjustments parse_dofadjustments(py::object dof_obj) {
    ParsedDofAdjustments parsed;
    if (dof_obj.is_none()) {
        return parsed;
    }

    std::vector<std::string> tokens;
    auto append_tokens = [&tokens](std::string raw) {
        std::replace(raw.begin(), raw.end(), ',', ' ');
        std::istringstream iss(raw);
        std::string tok;
        while (iss >> tok) {
            tokens.push_back(tok);
        }
    };
    if (py::isinstance<py::str>(dof_obj)) {
        append_tokens(dof_obj.cast<std::string>());
    } else if (py::isinstance<py::sequence>(dof_obj)) {
        py::sequence seq = py::reinterpret_borrow<py::sequence>(dof_obj);
        tokens.reserve(seq.size());
        for (auto item : seq) {
            append_tokens(py::cast<std::string>(item));
        }
    } else {
        throw std::runtime_error("dofadjustments must be a string or a sequence of strings");
    }
    if (tokens.empty()) {
        return parsed;
    }

    // A non-empty explicit option starts from a blank slate; a token-free
    // string/sequence is equivalent to the absent Stata option and returned
    // the defaults above.
    parsed.method = DofAdjustmentMethod::All;
    parsed.mobility_groups = false;
    parsed.adjust_clusters = false;
    parsed.adjust_continuous = false;

    auto normalize = [](std::string s) {
        std::transform(s.begin(), s.end(), s.begin(), [](unsigned char c) {
            return static_cast<char>(std::tolower(c));
        });
        return s;
    };

    bool seen_all = false;
    bool seen_none = false;
    bool seen_firstpair = false;
    bool seen_pairwise = false;
    bool seen_clusters = false;
    bool seen_continuous = false;
    for (const auto& tok_raw : tokens) {
        const std::string tok = normalize(tok_raw);
        if (tok.empty()) {
            continue;
        }
        if (tok == "all") {
            seen_all = true;
            parsed.method = DofAdjustmentMethod::All;
            parsed.mobility_groups = true;
            parsed.adjust_clusters = true;
            parsed.adjust_continuous = true;
            continue;
        }
        if (tok == "none") {
            seen_none = true;
            parsed.method = DofAdjustmentMethod::None;
            continue;
        }
        if (tok == "firstpair" || tok == "first") {
            seen_firstpair = true;
            parsed.method = DofAdjustmentMethod::FirstPair;
            parsed.mobility_groups = true;
            continue;
        }
        if (tok == "pairwise" || tok == "pair") {
            seen_pairwise = true;
            parsed.method = DofAdjustmentMethod::Pairwise;
            parsed.mobility_groups = true;
            continue;
        }
        if (tok == "clusters" || tok == "cluster") {
            seen_clusters = true;
            parsed.adjust_clusters = true;
            continue;
        }
        if (tok == "continuous" || tok == "cont") {
            seen_continuous = true;
            parsed.adjust_continuous = true;
            continue;
        }
        throw std::runtime_error("Unknown dofadjustments token: " + tok_raw);
    }

    const int token_classes = static_cast<int>(seen_all) + static_cast<int>(seen_none) +
                              static_cast<int>(seen_firstpair) + static_cast<int>(seen_pairwise) +
                              static_cast<int>(seen_clusters) + static_cast<int>(seen_continuous);
    if ((seen_all && token_classes > 1) || (seen_none && token_classes > 1) ||
        (seen_firstpair && seen_pairwise)) {
        throw std::runtime_error("Mutually exclusive dofadjustments tokens");
    }

    return parsed;
}

std::string summarize(const hdfe::HdfeResults& res,
                      int threads_used,
                      AbsorptionMethod method_used) {
    std::ostringstream oss;
    oss << "High-dimensional FE regression (v11)\n";
    oss << "Observations: " << res.nobs << ", Threads: " << threads_used
        << ", Absorption: " << method_name(method_used) << "\n";
    if (res.num_singletons > 0 || res.nobs_full > 0) {
        oss << "N (full): " << res.nobs_full << ", singletons dropped: " << res.num_singletons
            << ", df_a: " << res.df_a << ", df_r: " << res.df_resid << "\n";
    }
    oss << "Within R^2: " << res.r2_within << ", Overall R^2: " << res.r2 << "\n";
    oss << "Converged: " << (res.converged ? "yes" : "no")
        << ", iterations: " << res.num_iterations << "\n";
    if (!res.fe_num_levels.empty()) {
        oss << "Fixed effects: ";
        for (std::size_t i = 0; i < res.fe_num_levels.size(); ++i) {
            oss << res.fe_num_levels[i];
            if (i + 1 < res.fe_num_levels.size()) {
                oss << ", ";
            }
        }
        oss << "\n";
    }
    oss << "\n";
    oss << std::left << std::setw(12) << "Variable" << std::right << std::setw(14) << "Coef"
        << std::setw(14) << "Std.Err" << std::setw(10) << "t" << std::setw(10) << "P>|t|"
        << std::setw(14) << "CI Low" << std::setw(14) << "CI High" << "\n";
    for (int j = 0; j < res.coefficients.size(); ++j) {
        oss << std::left << std::setw(12) << ("b" + std::to_string(j)) << std::right
            << std::setw(14) << res.coefficients(j) << std::setw(14) << res.std_errors(j)
            << std::setw(10) << res.tvalues(j) << std::setw(10) << res.pvalues(j)
            << std::setw(14) << res.conf_int(j, 0) << std::setw(14) << res.conf_int(j, 1) << "\n";
    }
    return oss.str();
}

}  // namespace

PYBIND11_MODULE(py_hdfe_v11, m) {
    m.doc() = R"pbdoc(
Python bindings for the hdfe C++ library (v11).

Adds reghdfe-style defaults: singleton dropping + DoF adjustments for robust/cluster inference.
)pbdoc";
    py::module_::import("numpy");
    pybind11::detail::npy_api::get();
    py::object precision_warning = py::reinterpret_steal<py::object>(
        PyErr_NewException("py_hdfe_v11.PrecisionWarning",
                           PyExc_RuntimeWarning, nullptr));
    if (!precision_warning) {
        throw py::error_already_set();
    }
    m.attr("PrecisionWarning") = precision_warning;

    py::enum_<StandardErrorType>(m, "StandardErrorType", py::module_local())
        .value("homoskedastic", StandardErrorType::Homoskedastic)
        .value("robust", StandardErrorType::Robust)
        .value("cluster", StandardErrorType::Cluster);

    py::enum_<AbsorptionMethod>(m, "AbsorptionMethod", py::module_local())
        .value("auto", AbsorptionMethod::Auto)
        .value("gauss_seidel", AbsorptionMethod::GaussSeidel)
        .value("symmetric_gauss_seidel", AbsorptionMethod::SymmetricGaussSeidel)
        .value("jacobi", AbsorptionMethod::Jacobi)
        .value("schwarz", AbsorptionMethod::Schwarz)
        .value("lsmr", AbsorptionMethod::Lsmr)
        .value("mlsmr", AbsorptionMethod::Mlsmr)
        .value("auto_mlsmr", AbsorptionMethod::AutoMlsmr);

    py::enum_<ConvergenceCriterion>(m, "ConvergenceCriterion", py::module_local())
        .value("auto", ConvergenceCriterion::Auto)
        .value("normchange", ConvergenceCriterion::NormChange)
        .value("reghdfe", ConvergenceCriterion::Reghdfe)
        .value("both", ConvergenceCriterion::Both);

	    py::class_<HdfeRegressorV11>(m, "HdfeRegressor")
	        .def(py::init([](const std::string& se_type,
	                         double tol,
	                         int max_iter,
	                         int check_interval,
	                         const std::string& convergence,
	                         bool fit_intercept,
	                         int num_threads,
	                         int default_threads,
	                         int max_threads,
                         int min_parallel_rows,
                         int target_rows_per_thread,
                         bool drop_singletons,
                         bool retain_fes,
                         bool symmetric_sweep,
                         const std::string& absorption_method,
                         double jacobi_relaxation,
                         double level,
                         py::object keepsingletons,
                         py::object dofadjustments,
                         py::object groupvar,
                         py::object ssc_k_adj,
                         py::object ssc_k_fixef,
                         py::object ssc_k_exact,
                         py::object ssc_g_adj,
                         py::object ssc_g_df,
                         py::object ssc_t_df,
                         const std::string& tolerance_mode) {
                 if (num_threads < 0 || default_threads < 0 ||
                     max_threads < 0) {
                     throw std::invalid_argument(
                         "num_threads, default_threads, and max_threads must be nonnegative");
                 }
                 if (min_parallel_rows <= 0 || target_rows_per_thread <= 0) {
                     throw std::invalid_argument(
                         "min_parallel_rows and target_rows_per_thread must be positive");
                 }
                 HdfeOptions opts;
                 opts.se_type = parse_se_type(se_type);
                 if (level > 0.0 && level <= 1.0) {
                     level *= 100.0;
                 }
                 if (!(level > 0.0 && level < 100.0)) {
                     throw std::runtime_error("level must be between 0 and 100");
                 }
	                 opts.level = level;
		                 opts.tol = tol;
		                 opts.max_iter = max_iter;
		                 opts.convergence_check_interval = std::max(1, check_interval);
	                 opts.convergence_criterion = parse_convergence_criterion(convergence);
		                 opts.fit_intercept = fit_intercept;
	                 opts.num_threads = num_threads;
                 if (!keepsingletons.is_none()) {
                     opts.drop_singletons = !keepsingletons.cast<bool>();
                 } else {
                     opts.drop_singletons = drop_singletons;
                 }
                 opts.retain_fixed_effects = retain_fes;
                 opts.symmetric_sweep = symmetric_sweep;
                 opts.absorption_method = parse_absorption_method(absorption_method);
                 opts.jacobi_relaxation = jacobi_relaxation;
                 opts.use_krylov = false;
                 opts.ordinary_krylov_parity_floor = true;
                 opts.ordinary_auto_routing_retry = true;

                 const ParsedDofAdjustments dof = parse_dofadjustments(dofadjustments);
                 opts.dof_method = dof.method;
                 opts.dof_mobility_groups = dof.mobility_groups;
                 opts.dof_adjust_clusters = dof.adjust_clusters;
                 opts.dof_adjust_continuous = dof.adjust_continuous;

                 if (!groupvar.is_none()) {
                     if (py::isinstance<py::bool_>(groupvar)) {
                         opts.save_groupvar = groupvar.cast<bool>();
                     } else {
                         opts.save_groupvar = true;
                     }
                 }

                 if (!ssc_k_adj.is_none()) {
                     opts.ssc_k_adj = ssc_k_adj.cast<bool>();
                 }
                 if (!ssc_k_fixef.is_none()) {
                     opts.ssc_k_fixef = parse_fixef_method(ssc_k_fixef.cast<std::string>());
                 }
                 if (!ssc_k_exact.is_none()) {
                     opts.ssc_k_exact = ssc_k_exact.cast<bool>();
                 }
                 if (!ssc_g_adj.is_none()) {
                     opts.ssc_g_adj = ssc_g_adj.cast<bool>();
                 }
                 if (!ssc_g_df.is_none()) {
                     opts.ssc_g_df = parse_cluster_df(ssc_g_df.cast<std::string>());
                 }
                 if (!ssc_t_df.is_none()) {
                     opts.ssc_t_df = ssc_t_df.cast<double>();
                 }
                 opts.tolerance_mode = parse_tolerance_mode(tolerance_mode);

                 ThreadingOptions threading;
                 threading.default_threads =
                     default_threads > 0 ? default_threads : (num_threads > 0 ? num_threads : 0);
                 threading.max_threads = max_threads;
                 threading.min_parallel_rows = min_parallel_rows;
                 threading.target_rows_per_thread = target_rows_per_thread;
                 threading.symmetric_sweep = symmetric_sweep;
                 return std::make_unique<HdfeRegressorV11>(opts, threading);
	             }),
	             py::arg("se_type") = "unadjusted",
		             py::arg("tol") = 1e-8,
		             py::arg("max_iter") = 100000,
		             py::arg("check_interval") = 1,
	             py::arg("convergence") = "auto",
		             py::arg("fit_intercept") = true,
	             py::arg("num_threads") = 0,
	             py::arg("default_threads") = 0,
             py::arg("max_threads") = 0,
             py::arg("min_parallel_rows") = 20000,
             py::arg("target_rows_per_thread") = 500000,
             py::arg("drop_singletons") = true,
             py::arg("retain_fes") = false,
             py::arg("symmetric_sweep") = false,
             py::arg("absorption_method") = "auto",
             py::arg("jacobi_relaxation") = 0.0,
             py::arg("level") = 95.0,
             py::arg("keepsingletons") = py::none(),
             py::arg("dofadjustments") = py::none(),
             py::arg("groupvar") = py::none(),
             py::arg("ssc_k_adj") = py::none(),
             py::arg("ssc_k_fixef") = py::none(),
             py::arg("ssc_k_exact") = py::none(),
             py::arg("ssc_g_adj") = py::none(),
             py::arg("ssc_g_df") = py::none(),
             py::arg("ssc_t_df") = py::none(),
             py::arg("tolerance_mode") = "reghdfe-comparable")
        .def(
            "fit",
            [precision_warning](HdfeRegressorV11& self,
               py::array y_obj,
               py::array X_obj,
               py::object fes_obj,
               py::object weights_obj,
               py::object clusters_obj,
               py::object instruments_obj,
               std::vector<int> endogenous,
               py::object group_obj,
               py::object individual_obj,
               const std::string& aggregation,
               py::object slopes_obj,
               bool fweights) {
                hdfe::v11::BindingAttemptGuard attempt(self, fweights);
                if (fweights && weights_obj.is_none()) {
                    throw std::runtime_error(
                        "fweights=True requires a weights vector");
                }
                auto y_arr =
                    py::array_t<double, py::array::c_style | py::array::forcecast>(y_obj);
                if (y_arr.ndim() != 1) {
                    throw std::runtime_error("y must be a 1-D array");
                }
                const ssize_t n = y_arr.shape(0);
                Eigen::Map<const Eigen::VectorXd> y_vec(y_arr.data(), n);

                py::array X_arr = py::array_t<double, py::array::forcecast>(X_obj);
                if (X_arr.ndim() != 2 || X_arr.shape(0) != n) {
                    throw std::runtime_error("X must be a 2-D array with matching rows");
                }
                using RowMajorMatrix =
                    Eigen::Matrix<double, Eigen::Dynamic, Eigen::Dynamic, Eigen::RowMajor>;
                const bool x_f_style = (X_arr.flags() & py::array::f_style) != 0;
                const bool x_c_style = (X_arr.flags() & py::array::c_style) != 0;
                if (!x_f_style && !x_c_style) {
                    X_arr =
                        py::array_t<double, py::array::f_style | py::array::forcecast>(X_obj);
                }

                std::vector<Eigen::VectorXi> fes;
                if (!fes_obj.is_none()) {
                    py::sequence seq = py::reinterpret_borrow<py::sequence>(fes_obj);
                    fes.reserve(seq.size());
                    for (auto item : seq) {
                        fes.push_back(parse_index_vector(item, "Each fixed-effect vector", n));
                    }
                }

                std::optional<Eigen::VectorXd> weights_vec;
                if (!weights_obj.is_none()) {
                    auto w_arr = py::array_t<double, py::array::c_style | py::array::forcecast>(
                        weights_obj);
                    if (w_arr.ndim() != 1 || w_arr.shape(0) != n) {
                        throw std::runtime_error("weights must be length n");
                    }
                    Eigen::Map<const Eigen::VectorXd> w_map(w_arr.data(), n);
                    weights_vec = Eigen::VectorXd(w_map);
                }

                std::optional<std::vector<Eigen::VectorXi>> clusters_vec;
                if (!clusters_obj.is_none()) {
                    std::vector<Eigen::VectorXi> out;
                    if (py::isinstance<py::array>(clusters_obj)) {
                        py::array c_arr = py::array(clusters_obj);
                        if (c_arr.ndim() == 1) {
                            if (c_arr.shape(0) != n) {
                                throw std::runtime_error("clusters must be length n");
                            }
                            out.push_back(parse_index_vector(c_arr, "clusters", n));
                        } else if (c_arr.ndim() == 2) {
                            if (c_arr.shape(0) != n) {
                                throw std::runtime_error("clusters must have shape (n, q)");
                            }
                            const ssize_t q = c_arr.shape(1);
                            out.reserve(static_cast<std::size_t>(q));
                            for (ssize_t j = 0; j < q; ++j) {
                                out.push_back(parse_index_matrix_column(c_arr, "clusters", n, j));
                            }
                        } else {
                            throw std::runtime_error("clusters must be 1-D or 2-D");
                        }
                    } else if (py::isinstance<py::sequence>(clusters_obj)) {
                        py::sequence seq = py::reinterpret_borrow<py::sequence>(clusters_obj);
                        out.reserve(seq.size());
                        for (auto item : seq) {
                            out.push_back(parse_index_vector(item, "Each cluster vector", n));
                        }
                    } else {
                        throw std::runtime_error(
                            "clusters must be a numpy array or a sequence of 1-D arrays");
                    }
                    if (!out.empty()) {
                        clusters_vec = std::move(out);
                    }
                }

                std::optional<Eigen::MatrixXd> instruments_mat;
                if (!instruments_obj.is_none()) {
                    py::array inst_arr =
                        py::array_t<double, py::array::forcecast>(instruments_obj);
                    if (inst_arr.ndim() != 2 || inst_arr.shape(0) != n) {
                        throw std::runtime_error(
                            "instruments must be a 2-D array with matching rows");
                    }
                    const bool inst_f_style = (inst_arr.flags() & py::array::f_style) != 0;
                    const bool inst_c_style = (inst_arr.flags() & py::array::c_style) != 0;
                    if (!inst_f_style && !inst_c_style) {
                        inst_arr = py::array_t<double, py::array::f_style | py::array::forcecast>(
                            instruments_obj);
                    }
                    if ((inst_arr.flags() & py::array::f_style) != 0) {
                        Eigen::Map<const Eigen::MatrixXd> z_map(
                            static_cast<const double*>(inst_arr.data()), n,
                            inst_arr.shape(1));
                        instruments_mat = Eigen::MatrixXd(z_map);
                    } else {
                        Eigen::Map<const RowMajorMatrix> z_map(
                            static_cast<const double*>(inst_arr.data()), n,
                            inst_arr.shape(1));
                        instruments_mat = Eigen::MatrixXd(z_map);
                    }
                }

                const Eigen::VectorXd* w_ptr = weights_vec ? &(*weights_vec) : nullptr;
                const std::vector<Eigen::VectorXi>* c_ptr = clusters_vec ? &(*clusters_vec) : nullptr;
                const GroupAggregation agg = parse_group_aggregation(aggregation);
                std::optional<std::vector<HeterogeneousSlopeTerm>> slopes_vec =
                    parse_slope_terms(slopes_obj, n);
                const std::vector<HeterogeneousSlopeTerm>* slopes_ptr =
                    slopes_vec ? &(*slopes_vec) : nullptr;

                std::optional<Eigen::VectorXi> group_vec;
                if (!group_obj.is_none()) {
                    py::array g_arr = py::array(group_obj);
                    if (g_arr.ndim() != 1 || g_arr.shape(0) != n) {
                        throw std::runtime_error("group must be length n");
                    }
                    group_vec = parse_index_vector(g_arr, "group", n);
                }

                std::optional<Eigen::VectorXi> individual_vec;
                if (!individual_obj.is_none()) {
                    py::array i_arr = py::array(individual_obj);
                    if (i_arr.ndim() != 1 || i_arr.shape(0) != n) {
                        throw std::runtime_error("individual must be length n");
                    }
                    individual_vec = parse_index_vector(i_arr, "individual", n);
                }

                if (group_vec) {
                    if (slopes_ptr && !slopes_ptr->empty()) {
                        throw std::runtime_error(
                            "heterogeneous slopes are not supported with group()/individual() mode");
                    }
                    if (!instruments_obj.is_none() || !endogenous.empty()) {
                        throw std::runtime_error(
                            "IV/instruments are not supported with group()/individual() mode");
                    }
                    const Eigen::VectorXi* ind_ptr =
                        individual_vec ? &(*individual_vec) : nullptr;
                    if ((X_arr.flags() & py::array::f_style) != 0) {
                        Eigen::Map<const Eigen::MatrixXd> X_map(
                            static_cast<const double*>(X_arr.data()), n, X_arr.shape(1));
                        self.fit_grouped(y_vec, X_map, fes, *group_vec, ind_ptr, agg, w_ptr, c_ptr);
                    } else {
                        Eigen::Map<const RowMajorMatrix> X_map(
                            static_cast<const double*>(X_arr.data()), n, X_arr.shape(1));
                        Eigen::MatrixXd X_mat = X_map;
                        self.fit_grouped(y_vec, X_mat, fes, *group_vec, ind_ptr, agg, w_ptr, c_ptr);
                    }
                } else {
                    const Eigen::MatrixXd* inst_ptr =
                        instruments_mat ? &(*instruments_mat) : nullptr;
                    if ((X_arr.flags() & py::array::f_style) != 0) {
                        Eigen::Map<const Eigen::MatrixXd> X_map(
                            static_cast<const double*>(X_arr.data()), n, X_arr.shape(1));
                        self.fit(y_vec, X_map, fes, w_ptr, c_ptr, inst_ptr, endogenous, slopes_ptr);
                    } else {
                        Eigen::Map<const RowMajorMatrix> X_map(
                            static_cast<const double*>(X_arr.data()), n, X_arr.shape(1));
                        Eigen::MatrixXd X_mat = X_map;
                        self.fit(y_vec, X_mat, fes, w_ptr, c_ptr, inst_ptr, endogenous, slopes_ptr);
                    }
                }
                if (!self.results().precision_certified) {
                    if (PyErr_WarnEx(
                            precision_warning.ptr(),
                            "xhdfe fit did not pass the independent "
                            "precision certificate; inspect "
                            "abs_residual_rel_ and consider a stricter "
                            "tolerance mode",
                            1) < 0) {
                        throw py::error_already_set();
                    }
                }
                attempt.commit();
            },
            py::arg("y"),
            py::arg("X"),
            py::arg("fes") = py::none(),
            py::arg("weights") = py::none(),
            py::arg("clusters") = py::none(),
            py::arg("instruments") = py::none(),
            py::arg("endogenous_idx") = std::vector<int>{},
            py::arg("group") = py::none(),
            py::arg("individual") = py::none(),
            py::arg("aggregation") = "mean",
            py::arg("slopes") = py::none(),
            py::arg("fweights") = false,
            R"doc(
Fit the HDFE model.

By default, ``weights`` follow the package's analytic-weight convention. Set
``fweights=True`` to interpret each positive-integer weight as literal row
replication for sample-size, degrees-of-freedom, singleton, and variance
bookkeeping. The flag is reset on every call and requires ``weights``.
)doc")
        .def(
            "extract_group_individual_fes",
            [](const HdfeRegressorV11& self,
               py::array y_obj,
               py::array X_obj,
               py::object fes_obj,
               py::array group_obj,
               py::array individual_obj,
               py::object weights_obj,
               const std::string& aggregation,
               double tol_main,
               double tol_start,
               double tol_final,
               int max_iter_main,
               int max_iter_solver,
               int verbose,
               int accel,
               int start_accel,
               int every_accel,
               double factor,
               double a1p1,
               double a2p1,
               int a2p2) {
                auto y_arr =
                    py::array_t<double, py::array::c_style | py::array::forcecast>(y_obj);
                if (y_arr.ndim() != 1) {
                    throw std::runtime_error("y must be a 1-D array");
                }
                const ssize_t n = y_arr.shape(0);
                Eigen::Map<const Eigen::VectorXd> y_vec(y_arr.data(), n);

                py::array X_arr = py::array_t<double, py::array::forcecast>(X_obj);
                if (X_arr.ndim() != 2 || X_arr.shape(0) != n) {
                    throw std::runtime_error("X must be a 2-D array with matching rows");
                }
                using RowMajorMatrix =
                    Eigen::Matrix<double, Eigen::Dynamic, Eigen::Dynamic, Eigen::RowMajor>;
                const bool x_f_style = (X_arr.flags() & py::array::f_style) != 0;
                const bool x_c_style = (X_arr.flags() & py::array::c_style) != 0;
                if (!x_f_style && !x_c_style) {
                    X_arr =
                        py::array_t<double, py::array::f_style | py::array::forcecast>(X_obj);
                }

                py::array g_arr = py::array(group_obj);
                if (g_arr.ndim() != 1 || g_arr.shape(0) != n) {
                    throw std::runtime_error("group must be a 1-D array with matching rows");
                }
                Eigen::VectorXi g_ids = parse_index_vector(g_arr, "group", n);

                py::array i_arr = py::array(individual_obj);
                if (i_arr.ndim() != 1 || i_arr.shape(0) != n) {
                    throw std::runtime_error("individual must be a 1-D array with matching rows");
                }
                Eigen::VectorXi i_ids = parse_index_vector(i_arr, "individual", n);

                if (fes_obj.is_none()) {
                    throw std::runtime_error("fes must be provided for group/individual extraction");
                }
                std::vector<Eigen::VectorXi> fes;
                if (py::isinstance<py::array>(fes_obj)) {
                    py::array fe_arr = py::array(fes_obj);
                    if (fe_arr.ndim() == 1) {
                        if (fe_arr.shape(0) != n) {
                            throw std::runtime_error("fes vector must be length n");
                        }
                        fes.push_back(parse_index_vector(fe_arr, "fes vector", n));
                    } else if (fe_arr.ndim() == 2) {
                        if (fe_arr.shape(0) != n) {
                            throw std::runtime_error("fes matrix must have shape (n, k)");
                        }
                        const int k = static_cast<int>(fe_arr.shape(1));
                        fes.reserve(static_cast<std::size_t>(k));
                        for (int j = 0; j < k; ++j) {
                            fes.push_back(parse_index_matrix_column(fe_arr, "fes matrix", n, j));
                        }
                    } else {
                        throw std::runtime_error("fes must be a 1-D/2-D array or a sequence of arrays");
                    }
                } else if (py::isinstance<py::sequence>(fes_obj)) {
                    py::sequence seq = py::reinterpret_borrow<py::sequence>(fes_obj);
                    fes.reserve(seq.size());
                    for (auto item : seq) {
                        fes.push_back(parse_index_vector(item, "Each FE vector", n));
                    }
                } else {
                    throw std::runtime_error("fes must be a numpy array or a sequence of arrays");
                }

                std::optional<Eigen::VectorXd> weights_vec;
                if (!weights_obj.is_none()) {
                    auto w_arr =
                        py::array_t<double, py::array::c_style | py::array::forcecast>(weights_obj);
                    if (w_arr.ndim() != 1 || w_arr.shape(0) != n) {
                        throw std::runtime_error("weights must be a 1-D array with matching rows");
                    }
                    Eigen::Map<const Eigen::VectorXd> w_map(w_arr.data(), n);
                    weights_vec = Eigen::VectorXd(w_map);
                }
                const Eigen::VectorXd* w_ptr = weights_vec ? &(*weights_vec) : nullptr;

                hdfe::v11::GroupIndividualFeOptions fe_opts;
                fe_opts.tol_main = tol_main;
                fe_opts.tol_start = tol_start;
                fe_opts.tol_final = tol_final;
                fe_opts.max_iter_main = max_iter_main;
                fe_opts.max_iter_solver = max_iter_solver;
                fe_opts.verbose = verbose;
                fe_opts.accel = accel;
                fe_opts.start_accel = start_accel;
                fe_opts.every_accel = every_accel;
                fe_opts.factor = factor;
                fe_opts.a1p1 = a1p1;
                fe_opts.a2p1 = a2p1;
                fe_opts.a2p2 = a2p2;

                const GroupAggregation agg = parse_group_aggregation(aggregation);
                hdfe::v11::GroupIndividualFeEstimates res;
                if ((X_arr.flags() & py::array::f_style) != 0) {
                    Eigen::Map<const Eigen::MatrixXd> X_map(
                        static_cast<const double*>(X_arr.data()), n, X_arr.shape(1));
                    res = self.extract_group_individual_fes(y_vec, X_map, fes, g_ids, i_ids, agg,
                                                           w_ptr, fe_opts);
                } else {
                    Eigen::Map<const RowMajorMatrix> X_map(
                        static_cast<const double*>(X_arr.data()), n, X_arr.shape(1));
                    Eigen::MatrixXd X_mat(X_map);
                    res = self.extract_group_individual_fes(y_vec, X_mat, fes, g_ids, i_ids, agg,
                                                           w_ptr, fe_opts);
                }

                py::dict out;
                out["individual_ids"] = res.individual_ids;
                out["individual_effects"] = res.individual_effects;
                out["fe_level_ids"] = res.fe_level_ids;
                out["fe_level_effects"] = res.fe_level_effects;
                out["iterations"] = res.iterations;
                out["converged"] = res.converged;
                out["mse"] = res.mse;
                out["threads_requested"] = res.threads_requested;
                out["threads_effective"] = res.threads_effective;
                out["threads_used"] = res.threads_used;
                out["parallel_workers_active"] = res.parallel_workers_active;
                out["thread_capacity"] = res.thread_capacity;
                out["openmp_enabled"] = res.openmp_enabled;
                out["thread_limit_code"] = res.thread_limit_code;
                out["thread_limit_reason"] = res.thread_limit_reason;
                return out;
            },
            py::arg("y"),
            py::arg("X"),
            py::arg("fes"),
            py::arg("group"),
            py::arg("individual"),
            py::arg("weights") = py::none(),
            py::arg("aggregation") = "mean",
            py::arg("tol_main") = 1e-9,
            py::arg("tol_start") = 1e-3,
            py::arg("tol_final") = 1e-9,
            py::arg("max_iter_main") = 100000,
            py::arg("max_iter_solver") = 1000,
            py::arg("verbose") = 0,
            py::arg("accel") = 2,
            py::arg("start_accel") = 5,
            py::arg("every_accel") = 5,
            py::arg("factor") = 1.0,
            py::arg("a1p1") = 0.75,
            py::arg("a2p1") = 1e-8,
            py::arg("a2p2") = 5)
        .def("summary", [](const HdfeRegressorV11& self) {
            if (!self.has_estimation_result()) {
                return std::string("No estimation result available (state: ") +
                       self.lifecycle_state_name() + ")\n";
            }
            return summarize(self.results(), self.threads_used(), self.absorption_method_used());
        })
        .def_property_readonly("coef_", [](const HdfeRegressorV11& self) {
            return self.results().coefficients;
        })
        .def_property_readonly("stderr_", [](const HdfeRegressorV11& self) {
            return self.results().std_errors;
        })
        .def_property_readonly("tvalues_", [](const HdfeRegressorV11& self) {
            return self.results().tvalues;
        })
        .def_property_readonly("pvalues_", [](const HdfeRegressorV11& self) {
            return self.results().pvalues;
        })
        .def_property_readonly("conf_int_", [](const HdfeRegressorV11& self) {
            return self.results().conf_int;
        })
        // N follows the effective count, which is the row count unless
        // frequency weights are active. The Stata plugin already posts
        // nobs_effective as e(N) and the R binding already surfaces it, so
        // returning the row count here made the same fit report a different
        // N in Python than in Stata, and left df_resid_ larger than nobs_.
        .def_property_readonly("nobs_", [](const HdfeRegressorV11& self) {
            return effective_count_or_rows(self.results().nobs_effective,
                                           self.results().nobs);
        })
        .def_property_readonly("nobs_full_", [](const HdfeRegressorV11& self) {
            return effective_count_or_rows(self.results().nobs_full_effective,
                                           self.results().nobs_full);
        })
        .def_property_readonly("num_singletons_", [](const HdfeRegressorV11& self) {
            return effective_count_or_rows(
                self.results().num_singletons_effective,
                self.results().num_singletons);
        })
        // Row counts, always the length of the input arrays; pair these with
        // sample_index_, which indexes rows and not weighted units.
        .def_property_readonly("nobs_rows_", [](const HdfeRegressorV11& self) {
            return self.results().nobs;
        })
        .def_property_readonly("nobs_full_rows_", [](const HdfeRegressorV11& self) {
            return self.results().nobs_full;
        })
        .def_property_readonly("num_singletons_rows_", [](const HdfeRegressorV11& self) {
            return self.results().num_singletons;
        })
        // Which coefficients were dropped, and why. The Stata plugin and the R
        // binding already surface this; without it a Python caller sees a
        // dropped regressor only as a zero coefficient with a NaN standard
        // error, indistinguishable from an estimate of zero. Ordinary
        // collinearity is represented here; an overflowed Gram matrix now
        // fails explicitly and asks the caller to rescale the design.
        .def_property_readonly("omitted_reason_", [](const HdfeRegressorV11& self) {
            return self.results().omitted_reason;
        })
        .def_property_readonly("omitted_", [](const HdfeRegressorV11& self) {
            const auto& reason = self.results().omitted_reason;
            std::vector<bool> flags(reason.size());
            for (std::size_t j = 0; j < reason.size(); ++j) {
                flags[j] = reason[j] != 0;
            }
            return flags;
        })
        .def_property_readonly("any_omitted_", [](const HdfeRegressorV11& self) {
            const auto& reason = self.results().omitted_reason;
            return std::any_of(reason.begin(), reason.end(),
                               [](int code) { return code != 0; });
        })
        .def_property_readonly("nobs_effective_", [](const HdfeRegressorV11& self) {
            return self.results().nobs_effective;
        })
        .def_property_readonly("nobs_full_effective_", [](const HdfeRegressorV11& self) {
            return self.results().nobs_full_effective;
        })
        .def_property_readonly("num_singletons_effective_",
                               [](const HdfeRegressorV11& self) {
            return self.results().num_singletons_effective;
        })
        .def_property_readonly("sample_index_", [](const HdfeRegressorV11& self) {
            return self.results().sample_index;
        })
        .def_property_readonly("df_resid_", [](const HdfeRegressorV11& self) {
            return self.results().df_resid;
        })
        .def_property_readonly("df_resid_unadj_", [](const HdfeRegressorV11& self) {
            return self.results().df_resid_unadj;
        })
        .def_property_readonly("df_m_", [](const HdfeRegressorV11& self) {
            return self.results().df_m;
        })
        .def_property_readonly("df_a_", [](const HdfeRegressorV11& self) {
            return self.results().df_a;
        })
        .def_property_readonly("df_a_levels_", [](const HdfeRegressorV11& self) {
            return self.results().df_a_levels;
        })
        .def_property_readonly("df_a_exact_", [](const HdfeRegressorV11& self) {
            return self.results().df_a_exact;
        })
        .def_property_readonly("df_a_nested_", [](const HdfeRegressorV11& self) {
            return self.results().df_a_nested;
        })
        .def_property_readonly("r2_", [](const HdfeRegressorV11& self) {
            return self.results().r2;
        })
        .def_property_readonly("r2_within_", [](const HdfeRegressorV11& self) {
            return self.results().r2_within;
        })
        .def_property_readonly("rss_", [](const HdfeRegressorV11& self) {
            return self.results().rss;
        })
        .def_property_readonly("tss_", [](const HdfeRegressorV11& self) {
            return self.results().tss;
        })
        .def_property_readonly("tss_within_", [](const HdfeRegressorV11& self) {
            return self.results().tss_within;
        })
        .def_property_readonly("saturated_", [](const HdfeRegressorV11& self) {
            return self.results().is_saturated();
        })
        .def_property_readonly("covariance_", [](const HdfeRegressorV11& self) {
            return self.results().covariance;
        })
        .def_property_readonly("fe_num_levels_",
                              [](const HdfeRegressorV11& self) {
                                   return self.results().fe_num_levels;
                               })
        .def_property_readonly("fe_base_levels_",
                              [](const HdfeRegressorV11& self) {
                                   return self.results().fe_base_levels;
                               })
        .def_property_readonly("fe_base_redundant_",
                              [](const HdfeRegressorV11& self) {
                                   return self.results().fe_base_redundant;
                               })
        .def_property_readonly("fe_redundant_",
                              [](const HdfeRegressorV11& self) {
                                   return self.results().fe_redundant;
                               })
        .def_property_readonly("fe_num_coefs_",
                              [](const HdfeRegressorV11& self) {
                                   return self.results().fe_num_coefs;
                               })
        .def_property_readonly("fe_inexact_",
                              [](const HdfeRegressorV11& self) {
                                   return self.results().fe_inexact;
                               })
        .def_property_readonly("converged_",
                              [](const HdfeRegressorV11& self) {
                                   return self.results().converged;
                               })
        .def_property_readonly("fe_effects_",
                              [](const HdfeRegressorV11& self) {
                                   return self.results().fe_effects;
                               })
        .def_property_readonly("fe_recovery_iterations_",
                              [](const HdfeRegressorV11& self) {
                                   return self.results().fe_recovery_iterations;
                               })
        .def_property_readonly("fe_recovery_max_delta_",
                              [](const HdfeRegressorV11& self) {
                                   return self.results().fe_recovery_max_delta;
                               })
        .def_property_readonly("fe_recovery_converged_",
                              [](const HdfeRegressorV11& self) {
                                   return self.results().fe_recovery_converged;
                               })
        .def_property_readonly("residuals_", [](const HdfeRegressorV11& self) {
            return self.results().residuals;
        })
        .def_property_readonly("num_iterations_", [](const HdfeRegressorV11& self) {
            return self.results().num_iterations;
        })
        .def_property_readonly("abs_residual_", [](const HdfeRegressorV11& self) {
            return self.results().abs_residual;
        })
        .def_property_readonly("abs_residual_rel_", [](const HdfeRegressorV11& self) {
            return self.results().abs_residual_rel;
        })
        .def_property_readonly("krylov_internal_tolerance_", [](const HdfeRegressorV11& self) {
            return self.results().krylov_internal_tolerance;
        })
        .def_property_readonly("krylov_max_final_backward_error_", [](const HdfeRegressorV11& self) {
            return self.results().krylov_max_final_backward_error;
        })
        .def_property_readonly("krylov_max_condition_", [](const HdfeRegressorV11& self) {
            return self.results().krylov_max_condition;
        }, "Maximum running Krylov condition estimate across right-hand sides; zero outside ordinary LSMR/MLSMR.")
        .def_property_readonly("krylov_max_condition_times_backward_error_", [](const HdfeRegressorV11& self) {
            return self.results().krylov_max_condition_times_backward_error;
        })
        .def_property_readonly("auto_routing_retry_policy_enabled_", [](const HdfeRegressorV11& self) {
            return self.results().auto_routing_retry_policy_enabled;
        })
        .def_property_readonly("auto_routing_retry_eligible_", [](const HdfeRegressorV11& self) {
            return self.results().auto_routing_retry_eligible;
        })
        .def_property_readonly("auto_routing_retry_fired_", [](const HdfeRegressorV11& self) {
            return self.results().auto_routing_retry_fired;
        })
        .def_property_readonly("auto_routing_retry_status_", [](const HdfeRegressorV11& self) {
            return self.results().auto_routing_retry_status;
        })
        .def_property_readonly("auto_routing_retry_primary_method_", [](const HdfeRegressorV11& self) {
            return self.results().auto_routing_retry_primary_method;
        })
        .def_property_readonly("auto_routing_retry_primary_iterations_", [](const HdfeRegressorV11& self) {
            return self.results().auto_routing_retry_primary_iterations;
        })
        .def_property_readonly("auto_routing_retry_primary_abs_residual_rel_", [](const HdfeRegressorV11& self) {
            return self.results().auto_routing_retry_primary_abs_residual_rel;
        })
        .def_property_readonly("auto_routing_retry_iterations_", [](const HdfeRegressorV11& self) {
            return self.results().auto_routing_retry_iterations;
        })
        .def_property_readonly("auto_routing_retry_abs_residual_rel_", [](const HdfeRegressorV11& self) {
            return self.results().auto_routing_retry_abs_residual_rel;
        })
        .def_property_readonly("auto_routing_retry_elapsed_seconds_", [](const HdfeRegressorV11& self) {
            return self.results().auto_routing_retry_elapsed_seconds;
        })
        .def_property_readonly("slope_block_residual_rel_", [](const HdfeRegressorV11& self) {
            return self.results().slope_block_residual_rel;
        })
        .def_property_readonly("slope_block_frobenius_rel_", [](const HdfeRegressorV11& self) {
            return self.results().slope_block_frobenius_rel;
        })
        .def_property_readonly("slope_block_rms_rel_", [](const HdfeRegressorV11& self) {
            return self.results().slope_block_rms_rel;
        })
        .def_property_readonly("slope_block_max_rel_", [](const HdfeRegressorV11& self) {
            return self.results().slope_block_max_rel;
        })
        .def_property_readonly("slope_block_skipped_max_rel_", [](const HdfeRegressorV11& self) {
            return self.results().slope_block_skipped_max_rel;
        })
        .def_property_readonly("slope_certificate_worst_fe_", [](const HdfeRegressorV11& self) {
            return self.results().slope_certificate_worst_fe;
        })
        .def_property_readonly("slope_certificate_worst_moment_", [](const HdfeRegressorV11& self) {
            return self.results().slope_certificate_worst_moment;
        })
        .def_property_readonly("slope_accuracy_retry_stages_", [](const HdfeRegressorV11& self) {
            return self.results().slope_accuracy_retry_stages;
        })
        .def_property_readonly("slope_accuracy_retry_iterations_", [](const HdfeRegressorV11& self) {
            return self.results().slope_accuracy_retry_iterations;
        })
        .def_property_readonly("slope_internal_tolerance_", [](const HdfeRegressorV11& self) {
            return self.results().slope_internal_tolerance;
        })
        .def_property_readonly("precision_certified_", [](const HdfeRegressorV11& self) {
            return self.results().precision_certified;
        })
        .def_property_readonly("groupvar_", [](const HdfeRegressorV11& self) {
            return self.results().groupvar;
        })
        .def_property_readonly("num_clusters_", [](const HdfeRegressorV11& self) {
            return self.results().num_clusters;
        })
        .def_property_readonly("cluster_counts_", [](const HdfeRegressorV11& self) {
            return self.results().cluster_counts;
        })
        .def_property_readonly("cluster_combo_counts_", [](const HdfeRegressorV11& self) {
            return self.results().cluster_combo_counts;
        })
        .def_property_readonly("cluster_scale_", [](const HdfeRegressorV11& self) {
            return self.results().cluster_scale;
        })
        .def_property_readonly("threads_used_", [](const HdfeRegressorV11& self) {
            return self.threads_used();
        })
        .def_property_readonly("threads_requested_", [](const HdfeRegressorV11& self) {
            return self.threads_requested();
        })
        .def_property_readonly("threads_effective_", [](const HdfeRegressorV11& self) {
            return self.threads_effective();
        })
        .def_property_readonly("parallel_workers_active_", [](const HdfeRegressorV11& self) {
            return self.parallel_workers_active();
        })
        .def_property_readonly("thread_capacity_", [](const HdfeRegressorV11& self) {
            return self.thread_capacity();
        })
        .def_property_readonly("openmp_enabled_", [](const HdfeRegressorV11& self) {
            return self.openmp_enabled();
        })
        .def_property_readonly("thread_limit_code_", [](const HdfeRegressorV11& self) {
            return self.thread_limit_code();
        })
        .def_property_readonly("thread_limit_reason_", [](const HdfeRegressorV11& self) {
            return self.thread_limit_reason();
        })
        .def_property_readonly("gpu_used_", [](const HdfeRegressorV11& self) {
            return self.gpu_used();
        })
        .def_property_readonly("gpu_status_code_", [](const HdfeRegressorV11& self) {
            return self.gpu_status_code();
        })
        .def_property_readonly("gpu_attempted_", [](const HdfeRegressorV11& self) {
            return self.gpu_attempted();
        })
        .def_property_readonly("gpu_absorption_converged_", [](const HdfeRegressorV11& self) {
            return self.gpu_absorption_converged();
        })
        .def_property_readonly("gpu_absorption_iterations_", [](const HdfeRegressorV11& self) {
            return self.gpu_absorption_iterations();
        })
        .def_property_readonly("absorption_method_used", [](const HdfeRegressorV11& self) {
            return self.absorption_method_used();
        })
        .def_property_readonly("lifecycle_state_", [](const HdfeRegressorV11& self) {
            return std::string(self.lifecycle_state_name());
        })
        .def_property_readonly("generation_", [](const HdfeRegressorV11& self) {
            return self.generation();
        });

    // ---- AKM + leave-out (KSS) variance decomposition (opt-in module) ----
    // Free functions; nothing in the HdfeRegressor paths references them.
    const auto parse_leave_out_level = [](const std::string& name) {
        std::string lower = name;
        std::transform(lower.begin(), lower.end(), lower.begin(), [](unsigned char c) {
            return static_cast<char>(std::tolower(c));
        });
        if (lower == "match" || lower == "matches") {
            return hdfe::akm::LeaveOutLevel::Match;
        }
        if (lower == "obs" || lower == "observation" || lower == "observations") {
            return hdfe::akm::LeaveOutLevel::Observation;
        }
        throw std::runtime_error("Unknown leave_out_level: " + name +
                                 " (use 'match' or 'obs')");
    };
    const auto parse_leverage_method = [](const std::string& name) {
        std::string lower = name;
        std::transform(lower.begin(), lower.end(), lower.begin(), [](unsigned char c) {
            return static_cast<char>(std::tolower(c));
        });
        if (lower == "auto") {
            return hdfe::akm::LeverageMethod::Auto;
        }
        if (lower == "exact") {
            return hdfe::akm::LeverageMethod::Exact;
        }
        if (lower == "jla" || lower == "jl") {
            return hdfe::akm::LeverageMethod::Jla;
        }
        throw std::runtime_error("Unknown leverages method: " + name +
                                 " (use 'auto', 'exact' or 'jla')");
    };
    const auto set_to_dict = [](const hdfe::akm::LeaveOutSetResult& s) {
        py::dict d;
        const std::vector<py::ssize_t> keep_shape{static_cast<py::ssize_t>(s.keep.size())};
        py::array_t<bool> keep(keep_shape);
        bool* keep_ptr = static_cast<bool*>(keep.request().ptr);
        for (std::size_t i = 0; i < s.keep.size(); ++i) {
            keep_ptr[i] = s.keep[i] != 0;
        }
        d["keep"] = keep;
        d["n_obs_input"] = s.n_obs_input;
        d["n_obs_connected"] = s.n_obs_connected;
        d["n_obs"] = s.n_obs;
        d["n_workers"] = s.n_workers;
        d["n_firms"] = s.n_firms;
        d["n_matches"] = s.n_matches;
        d["n_movers"] = s.n_movers;
        d["n_stayers"] = s.n_stayers;
        d["prune_iterations"] = s.prune_iterations;
        d["threads_requested"] = s.threads_requested;
        d["threads_effective"] = s.threads_effective;
        d["threads_used"] = s.threads_used;
        d["parallel_workers_active"] = s.parallel_workers_active;
        d["thread_capacity"] = s.thread_capacity;
        d["openmp_enabled"] = s.openmp_enabled;
        d["thread_limit_code"] = s.thread_limit_code;
        d["thread_limit_reason"] = s.thread_limit_reason;
        d["gpu_used"] = s.gpu_used;
        d["gpu_status_code"] = s.gpu_status_code;
        return d;
    };

    m.def(
        "akm_leave_out_set",
        [set_to_dict](py::object worker_obj, py::object firm_obj,
                      py::object fweights_obj, int num_threads, bool gpu,
                      int verbose) {
            py::array w_arr = py::array(worker_obj);
            py::array f_arr = py::array(firm_obj);
            if (w_arr.ndim() != 1 || f_arr.ndim() != 1 || w_arr.shape(0) != f_arr.shape(0)) {
                throw std::runtime_error("worker and firm must be 1-D arrays of equal length");
            }
            const ssize_t n = w_arr.shape(0);
            Eigen::VectorXi w = parse_index_vector(w_arr, "worker", n);
            Eigen::VectorXi f = parse_index_vector(f_arr, "firm", n);
            std::optional<Eigen::VectorXd> fw_vec;
            if (!fweights_obj.is_none()) {
                auto fw_arr = py::array_t<double, py::array::c_style | py::array::forcecast>(
                    fweights_obj);
                if (fw_arr.ndim() != 1 || fw_arr.shape(0) != n) {
                    throw std::runtime_error("fweights must be a 1-D array of length n");
                }
                fw_vec = Eigen::Map<const Eigen::VectorXd>(fw_arr.data(), n);
            }
            hdfe::akm::LeaveOutSetOptions options;
            options.num_threads = num_threads;
            options.use_gpu = gpu;
            options.verbose = verbose;
            hdfe::akm::LeaveOutSetResult s;
            {
                py::gil_scoped_release release;
                s = hdfe::akm::leave_out_connected_set(
                    w, f, fw_vec ? &(*fw_vec) : nullptr, options);
            }
            return set_to_dict(s);
        },
        py::arg("worker"), py::arg("firm"), py::arg("fweights") = py::none(),
        py::arg("num_threads") = 0, py::arg("gpu") = false,
        py::arg("verbose") = 0,
        "Largest leave-one-out connected set of the worker-firm bipartite graph "
        "(LeaveOutTwoWay / KSS semantics). Returns a dict with a boolean 'keep' "
        "mask over the input rows plus sample and execution diagnostics.");

    m.def(
        "akm_kss",
        [set_to_dict, parse_leave_out_level, parse_leverage_method](
            py::object y_obj, py::object worker_obj, py::object firm_obj, py::object X_obj,
            py::object Z_obj,
            const std::string& leave_out_level, const std::string& leverages, int jla_draws,
            std::uint64_t seed, bool prune, long long exact_max_rows, int direct_max_firms,
            long long direct_max_nnz, double cg_tol, int cg_max_iter, int num_threads,
            double fwl_tol, int fwl_max_iter, bool compute_se, int se_nsim,
            bool eigen_diagnostics, int eig_trace_nsim, bool gpu,
            py::object fweights_obj, bool se_sigma_lowess, int verbose) {
            auto y_arr = py::array_t<double, py::array::c_style | py::array::forcecast>(y_obj);
            if (y_arr.ndim() != 1) {
                throw std::runtime_error("y must be a 1-D array");
            }
            const ssize_t n = y_arr.shape(0);
            Eigen::Map<const Eigen::VectorXd> y_vec(y_arr.data(), n);
            py::array w_raw = py::array(worker_obj);
            py::array f_raw = py::array(firm_obj);
            if (w_raw.ndim() != 1 || w_raw.shape(0) != n || f_raw.ndim() != 1 ||
                f_raw.shape(0) != n) {
                throw std::runtime_error("worker and firm must be 1-D arrays of length n");
            }
            Eigen::VectorXi w = parse_index_vector(w_raw, "worker", n);
            Eigen::VectorXi f = parse_index_vector(f_raw, "firm", n);
            std::optional<Eigen::MatrixXd> X_mat;
            if (!X_obj.is_none()) {
                auto X_arr =
                    py::array_t<double, py::array::c_style | py::array::forcecast>(X_obj);
                if (X_arr.ndim() != 2 || X_arr.shape(0) != n) {
                    throw std::runtime_error("X must be a 2-D array with n rows");
                }
                using RowMajor =
                    Eigen::Matrix<double, Eigen::Dynamic, Eigen::Dynamic, Eigen::RowMajor>;
                Eigen::Map<const RowMajor> X_map(X_arr.data(), n, X_arr.shape(1));
                X_mat = Eigen::MatrixXd(X_map);
            }

            hdfe::akm::AkmOptions opt;
            opt.leave_out_level = parse_leave_out_level(leave_out_level);
            opt.leverage_method = parse_leverage_method(leverages);
            opt.jla_draws = jla_draws;
            opt.seed = seed;
            opt.prune = prune;
            opt.exact_max_rows = static_cast<int>(exact_max_rows);
            opt.direct_max_firms = direct_max_firms;
            opt.direct_max_nnz = direct_max_nnz;
            opt.cg_tol = cg_tol;
            opt.cg_max_iter = cg_max_iter;
            opt.num_threads = num_threads;
            opt.fwl_tol = fwl_tol;
            opt.fwl_max_iter = fwl_max_iter;
            opt.compute_se = compute_se || eigen_diagnostics;
            opt.se_nsim = se_nsim;
            opt.eigen_diagnostics = eigen_diagnostics;
            opt.eig_trace_nsim = eig_trace_nsim;
            opt.se_sigma_lowess = se_sigma_lowess;
            opt.use_gpu = gpu;
            opt.verbose = verbose;  // progress lines go to stderr (C-level,
                                    // safe under gil_scoped_release)

            std::optional<Eigen::MatrixXd> Z_mat;
            if (!Z_obj.is_none()) {
                auto Z_arr =
                    py::array_t<double, py::array::c_style | py::array::forcecast>(Z_obj);
                if (Z_arr.ndim() != 2 || Z_arr.shape(0) != n) {
                    throw std::runtime_error("Z must be a 2-D array with n rows");
                }
                using RowMajorZ =
                    Eigen::Matrix<double, Eigen::Dynamic, Eigen::Dynamic, Eigen::RowMajor>;
                Eigen::Map<const RowMajorZ> Z_map(Z_arr.data(), n, Z_arr.shape(1));
                Z_mat = Eigen::MatrixXd(Z_map);
            }

            std::optional<Eigen::VectorXd> fw_vec;
            if (!fweights_obj.is_none()) {
                auto fw_arr = py::array_t<double, py::array::c_style | py::array::forcecast>(
                    fweights_obj);
                if (fw_arr.ndim() != 1 || fw_arr.shape(0) != n) {
                    throw std::runtime_error("fweights must be a 1-D array of length n");
                }
                fw_vec = Eigen::Map<const Eigen::VectorXd>(fw_arr.data(), n);
            }

            hdfe::akm::AkmKssResult r;
            {
                py::gil_scoped_release release;
                r = hdfe::akm::akm_kss_decompose(y_vec, w, f,
                                                 X_mat ? &(*X_mat) : nullptr, opt,
                                                 Z_mat ? &(*Z_mat) : nullptr,
                                                 fw_vec ? &(*fw_vec) : nullptr);
            }

            py::dict d;
            d["sample"] = set_to_dict(r.sample);
            d["alpha"] = r.alpha;
            d["psi"] = r.psi;
            d["beta"] = r.beta;
            const auto comp_to_dict = [&r](const hdfe::akm::AkmComponents& c) {
                py::dict cd;
                cd["var_alpha"] = c.var_alpha;
                cd["var_psi"] = c.var_psi;
                cd["cov_alpha_psi"] = c.cov_alpha_psi;
                // derived summary (pytwoway-style at-a-glance quantities)
                cd["corr_alpha_psi"] =
                    c.cov_alpha_psi / std::sqrt(c.var_alpha * c.var_psi);
                cd["var_alpha_plus_psi"] =
                    c.var_alpha + c.var_psi + 2.0 * c.cov_alpha_psi;
                if (r.var_y > 0.0) {
                    cd["share_var_alpha"] = c.var_alpha / r.var_y;
                    cd["share_var_psi"] = c.var_psi / r.var_y;
                    cd["share_2cov"] = 2.0 * c.cov_alpha_psi / r.var_y;
                }
                return cd;
            };
            d["plugin"] = comp_to_dict(r.plugin);
            d["agsu"] = comp_to_dict(r.agsu);
            d["kss"] = comp_to_dict(r.kss);
            d["var_y"] = r.var_y;
            d["sigma2_ho"] = r.sigma2_ho;
            d["pii"] = r.pii;
            d["sigma_i"] = r.sigma_i;
            d["row_worker"] = r.row_worker;
            d["row_firm"] = r.row_firm;
            d["row_weight"] = r.row_weight;
            if (compute_se || eigen_diagnostics) {
                py::dict se;
                se["se_var_psi"] = r.se_var_psi;
                se["se_cov_alpha_psi"] = r.se_cov_alpha_psi;
                se["se_var_alpha"] = r.se_var_alpha;
                se["theta_var_psi"] = r.theta_c_var_psi;
                se["theta_cov_alpha_psi"] = r.theta_c_cov_alpha_psi;
                se["theta_var_alpha"] = r.theta_c_var_alpha;
                d["component_se"] = se;
            }
            if (eigen_diagnostics) {
                py::dict wk;
                const char* names[3] = {"var_psi", "cov_alpha_psi", "var_alpha"};
                for (int c = 0; c < 3; ++c) {
                    py::dict cd;
                    cd["lambda1"] = r.eig_lambda1[c];
                    cd["eig_share1"] = r.eig_share1[c];
                    cd["eig_share2"] = r.eig_share2[c];
                    cd["eig_share3"] = r.eig_share3[c];
                    cd["lindeberg_max_x1bar_sq"] = r.lindeberg_max_x1bar_sq[c];
                    cd["gamma_sq"] = r.gamma_sq[c];
                    cd["f_stat"] = r.f_stat[c];
                    cd["theta_1"] = r.theta_1[c];
                    cd["ci_lb"] = r.ci_lb[c];
                    cd["ci_ub"] = r.ci_ub[c];
                    cd["curvature"] = r.curvature[c];
                    cd["b_1"] = r.b_1[c];
                    cd["cov_r1_11"] = r.cov_r1_11[c];
                    cd["cov_r1_12"] = r.cov_r1_12[c];
                    cd["cov_r1_22"] = r.cov_r1_22[c];
                    wk[names[c]] = cd;
                }
                d["weak_id"] = wk;
            }
            if (r.lincom_coef.size() > 0) {
                py::dict lc;
                lc["coef"] = r.lincom_coef;
                lc["se_kss"] = r.lincom_se_kss;
                lc["se_white"] = r.lincom_se_white;
                lc["t"] = r.lincom_t;
                d["lincom"] = lc;
            }
            d["max_pii"] = r.max_pii;
            d["mean_pii"] = r.mean_pii;
            d["n_rows"] = r.n_rows;
            d["leverages_exact"] = r.leverages_exact;
            d["gpu_requested"] = r.gpu_requested;
            d["gpu_used"] = r.gpu_used;
            d["gpu_status_code"] = r.gpu_status_code;
            d["gpu_backend"] = r.gpu_backend;
            d["gpu_status"] = r.gpu_status;
            d["solver_direct"] = r.solver_direct;
            d["threads_requested"] = r.threads_requested;
            d["threads_effective"] = r.threads_effective;
            d["solver_threads_effective"] = r.solver_threads_effective;
            d["fwl_threads_effective"] = r.fwl_threads_effective;
            d["fwl_threads_used"] = r.fwl_threads_used;
            d["fwl_parallel_workers_active"] =
                r.fwl_parallel_workers_active;
            d["fwl_gpu_attempted"] = r.fwl_gpu_attempted;
            d["fwl_gpu_used"] = r.fwl_gpu_used;
            d["fwl_gpu_fallback"] = r.fwl_gpu_fallback;
            d["fwl_gpu_status_code"] = r.fwl_gpu_status_code;
            d["fwl_gpu_status"] = r.fwl_gpu_status;
            d["fwl_iterations"] = r.fwl_iterations;
            d["fwl_abs_residual_rel"] = r.fwl_abs_residual_rel;
            d["fwl_precision_certified"] =
                r.fwl_precision_certified;
            d["solver_threads_used"] = r.solver_threads_used;
            d["solver_parallel_workers_active"] =
                r.solver_parallel_workers_active;
            d["threads_used"] = r.threads_used;
            d["parallel_workers_active"] = r.parallel_workers_active;
            d["thread_capacity"] = r.thread_capacity;
            d["openmp_enabled"] = r.openmp_enabled;
            d["thread_limit_code"] = r.thread_limit_code;
            d["thread_limit_reason"] = r.thread_limit_reason;
            d["jla_draws_used"] = r.jla_draws_used;
            d["seed"] = r.seed_used;
            d["solver_iterations"] = r.solver_iterations;
            d["converged"] = r.converged;
            d["notes"] = r.notes;
            return d;
        },
        py::arg("y"), py::arg("worker"), py::arg("firm"), py::arg("X") = py::none(),
        py::arg("Z") = py::none(),
        py::arg("leave_out_level") = "match", py::arg("leverages") = "auto",
        py::arg("jla_draws") = 200, py::arg("seed") = 20260705ULL, py::arg("prune") = true,
        py::arg("exact_max_rows") = 10000, py::arg("direct_max_firms") = 50000,
        py::arg("direct_max_nnz") = 40000000LL, py::arg("cg_tol") = 1e-10,
        py::arg("cg_max_iter") = 0, py::arg("num_threads") = 0, py::arg("fwl_tol") = 1e-10,
        py::arg("fwl_max_iter") = 100000, py::arg("compute_se") = false,
        py::arg("se_nsim") = 1000, py::arg("eigen_diagnostics") = false,
        py::arg("eig_trace_nsim") = 100, py::arg("gpu") = false,
        py::arg("fweights") = py::none(), py::arg("se_sigma_lowess") = false,
        py::arg("verbose") = 0,
        "AKM two-way estimation with plug-in / AGSU (homoskedastic) / KSS "
        "(heteroskedastic leave-out) variance decomposition on the leave-out "
        "connected set, following LeaveOutTwoWay (KSS 2020) semantics. Controls "
        "in X are partialled out with the xhdfe absorber (FWL). Opt-in: does "
        "not affect any existing estimation path. verbose=1 prints phase "
        "progress to stderr (leave-out set, FWL, solver, JLA draws d/D with "
        "elapsed time and ETA, SE sims, eigen diagnostics); output only, "
        "results are unaffected.");    m.def(
        "gelbach_decompose",
        [](py::object y_obj, py::object X1_obj, py::object X2_obj,
           std::vector<int> x2_group_sizes, py::object fes_obj,
           py::object cluster_obj, const std::string& vce, bool gamma0,
           bool cov0, double tol, int num_threads, py::object weights_obj,
           bool fweights, std::vector<int> absorbed_x1, bool gpu,
           std::vector<int> connectivity_fe_pair,
           bool require_connected, int n_common_fes, bool sample_info) {
            auto y_arr = py::array_t<double, py::array::c_style | py::array::forcecast>(y_obj);
            if (y_arr.ndim() != 1) {
                throw std::runtime_error("y must be a 1-D array");
            }
            const ssize_t n = y_arr.shape(0);
            Eigen::Map<const Eigen::VectorXd> y_vec(y_arr.data(), n);
            using RowMajor =
                Eigen::Matrix<double, Eigen::Dynamic, Eigen::Dynamic, Eigen::RowMajor>;
            auto to_mat = [n](py::object obj, const char* label) {
                auto arr = py::array_t<double, py::array::c_style | py::array::forcecast>(obj);
                if (arr.ndim() != 2 || arr.shape(0) != n) {
                    throw std::runtime_error(std::string(label) + " must be 2-D with n rows");
                }
                Eigen::Map<const RowMajor> mp(arr.data(), n, arr.shape(1));
                return Eigen::MatrixXd(mp);
            };
            Eigen::MatrixXd X1 = to_mat(X1_obj, "x1");
            Eigen::MatrixXd X2(n, 0);
            if (!X2_obj.is_none()) {
                X2 = to_mat(X2_obj, "x2");
            }
            std::vector<Eigen::VectorXi> fes;
            if (!fes_obj.is_none()) {
                py::sequence seq = py::reinterpret_borrow<py::sequence>(fes_obj);
                fes.reserve(seq.size());
                for (auto item : seq) {
                    fes.push_back(parse_index_vector(item, "Each fixed-effect vector", n));
                }
            }
            std::optional<Eigen::VectorXi> cl;
            if (!cluster_obj.is_none()) {
                py::array cl_raw = py::array(cluster_obj);
                cl = parse_index_vector(cl_raw, "cluster", n);
            }
            hdfe::gelbach::GelbachOptions opt;
            {
                std::string lower = vce;
                std::transform(lower.begin(), lower.end(), lower.begin(),
                               [](unsigned char c) { return static_cast<char>(std::tolower(c)); });
                if (lower == "unadjusted" || lower == "homoskedastic" || lower == "iid") {
                    opt.vce = hdfe::gelbach::GelbachVce::Unadjusted;
                } else if (lower == "robust") {
                    opt.vce = hdfe::gelbach::GelbachVce::Robust;
                } else if (lower == "cluster") {
                    opt.vce = hdfe::gelbach::GelbachVce::Cluster;
                } else {
                    throw std::runtime_error("Unknown vce: " + vce);
                }
            }
            opt.gamma0 = gamma0;
            opt.cov0 = cov0;
            opt.absorbed_x1 = std::move(absorbed_x1);
            opt.connectivity_fe_pair =
                std::move(connectivity_fe_pair);
            opt.require_connected_fe_split = require_connected;
            opt.tol = tol;
            opt.num_threads = num_threads;
            opt.use_gpu = gpu;
            opt.capture_sample_provenance = sample_info;
            opt.return_sample_index = sample_info;
            std::optional<Eigen::VectorXd> w_vec;
            if (!weights_obj.is_none()) {
                auto w_arr = py::array_t<double, py::array::c_style | py::array::forcecast>(
                    weights_obj);
                if (w_arr.ndim() != 1 || w_arr.shape(0) != n) {
                    throw std::runtime_error("weights must be a 1-D array of length n");
                }
                Eigen::Map<const Eigen::VectorXd> w_map(w_arr.data(), n);
                w_vec = Eigen::VectorXd(w_map);
            }
            hdfe::gelbach::GelbachResult r;
            {
                py::gil_scoped_release release;
                r = hdfe::gelbach::decompose(
                    y_vec, X1, X2, x2_group_sizes, fes, n_common_fes,
                    cl ? &(*cl) : nullptr, opt,
                    w_vec ? &(*w_vec) : nullptr, fweights);
            }
            py::dict d;
            d["b_base"] = r.b_base;
            d["b_full"] = r.b_full;
            d["x1_absorbed"] = r.x1_absorbed;
            d["x1_fe_collinear_ratio"] = r.x1_fe_collinear_ratio;
            d["x1_near_collinear_mask"] = r.x1_near_collinear_mask;
            d["gamma"] = r.gamma;
            d["beta2"] = r.beta2;
            d["beta2_cov"] = r.beta2_cov;
            d["auxiliary_loadings"] = r.auxiliary_loadings;
            d["auxiliary_loading_ss_ratio"] =
                r.auxiliary_loading_ss_ratio;
            d["auxiliary_loading_rank"] =
                r.auxiliary_loading_rank;
            d["auxiliary_loading_condition_number"] =
                r.auxiliary_loading_condition_number;
            d["auxiliary_loading_max_abs_z"] =
                r.auxiliary_loading_max_abs_z;
            d["auxiliary_loading_pvalue"] =
                r.auxiliary_loading_pvalue;
            d["auxiliary_loading_test_evaluated"] =
                r.auxiliary_loading_test_evaluated;
            d["beta2_wald_stat"] = r.beta2_wald_stat;
            d["beta2_wald_df"] = r.beta2_wald_df;
            d["beta2_wald_pvalue"] = r.beta2_wald_pvalue;
            d["contribution_gradient_norm"] =
                r.contribution_gradient_norm;
            d["regular_inference_valid"] =
                r.regular_inference_valid;
            d["regular_inference_status"] =
                r.regular_inference_status;
            d["regular_inference_all_valid"] =
                r.regular_inference_all_valid;
            d["regularity_test_alpha"] =
                r.regularity_test_alpha;
            d["delta"] = r.delta;
            d["cov"] = r.cov;
            d["base_cov"] = r.base_cov;
            d["cov_delta_bbase"] = r.cov_delta_bbase;
            d["cov_total_bbase"] = r.cov_total_bbase;
            d["total"] = r.total;
            d["total_cov"] = r.total_cov;
            d["n_common_fes"] = r.n_common_fes;
            d["common_fes_applied"] = r.common_fes_applied;
            d["intercept_inference_available"] =
                r.intercept_inference_available;
            d["intercept_status"] = r.intercept_status;
            d["identity_gap"] = r.identity_gap;
            d["n_obs_input"] = r.n_obs_input;
            d["n_obs"] = r.n_obs;
            d["n_obs_effective"] = r.n_obs_effective;
            d["n_singletons_dropped"] = r.n_singletons_dropped;
            d["sample_index"] = r.sample_index;
            d["sample_hash"] = r.sample_hash;
            d["sample_hash_algorithm"] =
                r.sample_hash_algorithm;
            d["sample_index_scope"] = r.sample_index_scope;
            d["n_mobility_components"] = r.n_mobility_components;
            d["largest_mobility_component_n_obs"] =
                r.largest_mobility_component_n_obs;
            d["largest_mobility_component_share"] =
                r.largest_mobility_component_share;
            d["largest_mobility_component_weight_share"] =
                r.largest_mobility_component_weight_share;
            d["fe_split_identified"] = r.fe_split_identified;
            d["fe_split_status"] = r.fe_split_status;
            d["connectivity_fe_index1"] =
                r.connectivity_fe_index1;
            d["connectivity_fe_index2"] =
                r.connectivity_fe_index2;
            d["connectivity_pair_explicit"] =
                r.connectivity_pair_explicit;
            d["connectivity_pair_status"] =
                r.connectivity_pair_status;
            d["connected_mode"] = r.connected_mode;
            d["mobility_component_scope"] =
                r.mobility_component_scope;
            d["df_full"] = r.df_full;
            d["df_base"] = r.df_base;
            d["n_clusters"] = r.n_clusters;
            d["fe_collinear_ss_ratio_tol"] = r.fe_collinear_ss_ratio_tol;
            d["near_fe_collinear_ss_ratio_warn_upper"] =
                r.near_fe_collinear_ss_ratio_warn_upper;
            d["few_cluster_warning_threshold"] =
                r.few_cluster_warning_threshold;
            d["absorbed_target_inference_valid"] =
                r.absorbed_target_inference_valid;
            d["absorbing_fe_index"] = r.absorbing_fe_index;
            d["threads_requested"] = r.threads_requested;
            d["threads_effective"] = r.threads_effective;
            d["recovery_threads_effective"] =
                r.recovery_threads_effective;
            d["fullfit_threads_used"] = r.fullfit_threads_used;
            d["fullfit_parallel_workers_active"] =
                r.fullfit_parallel_workers_active;
            d["recovery_threads_used"] = r.recovery_threads_used;
            d["recovery_parallel_workers_active"] =
                r.recovery_parallel_workers_active;
            d["covariance_threads_used"] = r.covariance_threads_used;
            d["covariance_parallel_workers_active"] =
                r.covariance_parallel_workers_active;
            d["threads_used"] = r.threads_used;
            d["parallel_workers_active"] = r.parallel_workers_active;
            d["thread_capacity"] = r.thread_capacity;
            d["openmp_enabled"] = r.openmp_enabled;
            d["thread_limit_code"] = r.thread_limit_code;
            d["thread_limit_reason"] = r.thread_limit_reason;
            d["gpu_requested"] = r.gpu_requested;
            d["gpu_used"] = r.gpu_used;
            d["gpu_status_code"] = r.gpu_status_code;
            d["gpu_backend"] = r.gpu_backend;
            d["gpu_status"] = r.gpu_status;
            d["gpu_attempted"] = r.gpu_attempted;
            d["gpu_absorption_converged"] =
                r.gpu_absorption_converged;
            d["gpu_absorption_iterations"] =
                r.gpu_absorption_iterations;
            d["converged"] = r.converged;
            d["notes"] = r.notes;
            return d;
        },
        py::arg("y"), py::arg("x1"), py::arg("x2") = py::none(),
        py::arg("x2_group_sizes") = std::vector<int>{}, py::arg("fes") = py::none(),
        py::arg("cluster") = py::none(), py::arg("vce") = "unadjusted",
        py::arg("gamma0") = false, py::arg("cov0") = false,
        py::arg("tol") = 1e-8, py::arg("num_threads") = 0,
        py::arg("weights") = py::none(),
        py::arg("fweights") = false,
        py::arg("absorbed_x1") = std::vector<int>{},
        py::arg("gpu") = false,
        py::arg("connectivity_fe_pair") = std::vector<int>{},
        py::arg("require_connected") = false,
        py::arg("n_common_fes") = 0,
        py::arg("sample_info") = false,
        "Gelbach (2016) conditional decomposition, HDFE-aware (see "
        "xhdfe.gelbach for the friendly wrapper). Opt-in; does not affect "
        "any existing estimation path.");
}
