# AKM + leave-out (KSS) variance decomposition front-end.
#
# R-idiom layer over the compiled hdfe::akm module; mirrors the Python
# py_hdfe_v11.akm_kss / akm_leave_out_set free functions so that the R,
# Python and (future) Stata surfaces sit on the identical compiled estimator.

.akm_id_codes <- function(x, label) {
  if (is.factor(x)) {
    codes <- as.integer(x)
    if (anyNA(codes)) {
      stop(sprintf("%s contains missing ids", label), call. = FALSE)
    }
    return(codes)
  }
  if (is.character(x)) {
    codes <- as.integer(factor(x))
    if (anyNA(codes)) {
      stop(sprintf("%s contains missing ids", label), call. = FALSE)
    }
    return(codes)
  }
  if (any(!is.finite(x))) {
    stop(sprintf("%s contains missing or non-finite ids", label), call. = FALSE)
  }
  # Numeric ids: keep the caller's integer codes when they fit int32; otherwise
  # (e.g. NISS/NIF person codes larger than 2^31, or non-integer labels) compact
  # to dense 1..N codes. The compiled core relabels ids to dense indices
  # internally, so the recoding never changes the estimates.
  if (all(x == floor(x)) && max(abs(x)) <= .Machine$integer.max) {
    return(as.integer(x))
  }
  as.integer(factor(x))
}

#' Largest leave-one-out connected set (KSS)
#'
#' Computes the largest connected set of the worker-firm bipartite graph such
#' that removing any single worker keeps it connected (the Kline-Saggio-
#' Soelvsten (2020) leave-out sample, following Saggio's LeaveOutTwoWay:
#' articulation workers are removed iteratively and workers observed only
#' once are dropped).
#'
#' @param worker Worker identifiers (integer, factor or character), length n.
#' @param firm Firm identifiers (integer, factor or character), length n.
#' @param fweights Optional positive-integer frequency weights.
#' @param num_threads OpenMP thread request (0 = automatic policy). It must be
#'   one nonnegative integer. A positive request bypasses workload heuristics
#'   and is limited only by the processor/OpenMP capacity visible to the
#'   process.
#' @param gpu Use CUDA for the stable match-key sort when the backend is
#'   available and the operation is large enough to benefit.
#' @param verbose Print phase progress. Output only.
#' @return A list with a logical \code{keep} mask over the input rows and the
#'   sample counts (\code{n_obs}, \code{n_workers}, \code{n_firms},
#'   \code{n_matches}, \code{n_movers}, \code{n_stayers}, ...), plus truthful
#'   thread/backend diagnostics including \code{threads_requested},
#'   \code{threads_effective}, \code{threads_used},
#'   \code{parallel_workers_active}, and \code{thread_capacity}.
#' @seealso \code{\link{xhdfe_akm_kss}}
#' @export
xhdfe_akm_leave_out_set <- function(worker, firm, fweights = NULL,
                                    num_threads = 0L, gpu = FALSE,
                                    verbose = FALSE) {
  if (length(worker) != length(firm)) {
    stop("worker and firm must have the same length", call. = FALSE)
  }
  if (length(num_threads) != 1L || !is.numeric(num_threads) ||
      is.logical(num_threads) || is.na(num_threads) ||
      !is.finite(num_threads) || num_threads < 0 ||
      num_threads != floor(num_threads)) {
    stop("num_threads must be one nonnegative integer", call. = FALSE)
  }
  if (length(gpu) != 1L || !is.logical(gpu) || is.na(gpu) ||
      length(verbose) != 1L || !is.logical(verbose) || is.na(verbose)) {
    stop("gpu and verbose must be single nonmissing logical values",
         call. = FALSE)
  }
  if (!is.null(fweights)) {
    fweights <- as.numeric(fweights)
    if (length(fweights) != length(worker)) {
      stop("fweights must have the same length as worker", call. = FALSE)
    }
  }
  .xhdfe_cpp_akm_leave_out_set_opts(
    .akm_id_codes(worker, "worker"),
    .akm_id_codes(firm, "firm"),
    fweights,
    as.integer(num_threads),
    isTRUE(gpu),
    as.integer(isTRUE(verbose))
  )
}

#' AKM estimation with leave-out (KSS) variance decomposition
#'
#' Estimates the two-way AKM model \eqn{y = \alpha_{worker} + \psi_{firm} +
#' X\beta + \epsilon} on the leave-out connected set and reports the variance
#' decomposition in three flavours: plug-in (biased baseline), AGSU
#' (Andrews et al. 2008, homoskedastic correction) and KSS (Kline, Saggio &
#' Soelvsten 2020, heteroskedastic leave-out correction). Default numerical semantics
#' follow Saggio's LeaveOutTwoWay: leave-a-match-out by default (collapse to
#' match means with sqrt(match-length) FGLS weighting), person-year weighted
#' components with denominator (n - 1), and the JLA leverage approximation
#' with deterministic seeding for large samples.
#'
#' @param y Numeric outcome, length n.
#' @param worker,firm Identifiers (integer, factor or character), length n.
#' @param X Optional numeric matrix of controls (n rows); partialled out at
#'   the person-year level with the xhdfe absorber (FWL) before the two-way
#'   machinery runs.
#' @param leave_out_level \code{"match"} (default, Saggio's default) or
#'   \code{"obs"}.
#' @param leverages \code{"auto"} (exact when the input has at most
#'   \code{exact_max_rows} rows, else JLA), \code{"exact"} or \code{"jla"}.
#' @param jla_draws Rademacher simulations for the JLA path (default 200).
#' @param seed Seed for deterministic JLA streams. Different thread counts or
#'   backends preserve the estimator and FP64 tolerance but can differ at the
#'   last-ulp level because floating-point reductions are reassociated.
#' @param prune Compute the leave-out connected set (default TRUE). Set to
#'   FALSE only when the input is already a leave-out sample.
#' @param exact_max_rows,direct_max_firms,direct_max_nnz,cg_tol,cg_max_iter
#'   Solver knobs; see the package vignette sources.
#' @param num_threads OpenMP thread request for the command (0 = automatic
#'   policy). It must be one nonnegative integer. A positive request bypasses
#'   workload/environment heuristics and is limited only by runtime-visible
#'   processor capacity. Sample, FWL, and solver diagnostics distinguish
#'   budgets from observed useful workers.
#' @param fwl_tol,fwl_max_iter Absorber controls for the covariate step.
#' @param compute_se Component standard errors (KSS leave-out inference).
#'   Under the canonical leave_out_COMPLETE rule, match level reports firm and
#'   covariance inference only; var(alpha) SE/CI are missing at match level
#'   even without stayers. Use \code{leave_out_level = "obs"} for var(alpha)
#'   inference.
#' @param se_nsim Simulation draws for the SE quadratic part (default 1000).
#' @param eigen_diagnostics Weak-identification diagnostics and the
#'   Andrews-Mikusheva q = 1 confidence intervals (leave_out_COMPLETE
#'   eigen_diagno path): top eigenvalue/shares of Atilde, Lindeberg
#'   condition, gamma^2, F statistic, theta_1 and the AM CI per component.
#'   Implies \code{compute_se = TRUE}.
#' @param eig_trace_nsim Hutchinson draws for tr(Atilde^2) (default 100,
#'   the oracle default).
#' @param se_sigma_lowess Use the llr_fit mode-0 lowess surface fit of
#'   sigma_i on (Pii, Bii) instead of the binned mode-4 fit (O(n^2);
#'   sensitivity analysis on small/medium samples).
#' @param fweights Optional positive-integer frequency weights (row i stands
#'   for fweights[i] identical person-year observations). Match-level point
#'   decomposition only; equals the row-expanded run exactly.
#' @param verbose Print phase progress to the console (leave-out set, FWL,
#'   solver, JLA draws d/D with elapsed time and an ETA, SE simulations,
#'   eigen diagnostics). Output only; results are unaffected.
#' @param sigma_centering \code{"leaveouttwoway"} (default) preserves the
#'   existing convention. Explicit \code{"person_year"} uses the weighted
#'   person-year mean on the final sample after FWL to make point components
#'   invariant to outcome shifts. It is not exactly unbiased under arbitrary
#'   heteroskedasticity. With \code{compute_se=TRUE}, \code{$projection_inference}
#'   contains simultaneous 95\% worker-cluster projection intervals for firm
#'   variance and worker-firm covariance, including control-estimation
#'   uncertainty. Delta SEs are regular-case only; intervals also cover weak
#'   signals under the stated asymptotic assumptions. Requires independent
#'   workers, bounded moments/cluster sizes, fixed firm count and diffuse
#'   identified contrasts. Supported with 2--128 firms and unit weights;
#'   worker-variance inference and sigma-lowess are unavailable in this mode.
#'   The point formula and its leave-out unit do not change when SEs are requested.
#'   The selected convention is returned as \code{$sigma_centering}.
#' @section Advanced performance environment variables:
#'   Defaults are tuned and none changes the default numeric output.
#'   \code{XHDFE_AKM_TEAM} tunes the automatic
#'   (\code{num_threads = 0}) solver team; an explicit positive request
#'   bypasses it. \code{XHDFE_AKM_JLA_BLOCK} /
#'   \code{XHDFE_AKM_SE_BLOCK} set the
#'   multi-RHS block size for the JLA leverage and the SE/eigen/lincom solves
#'   (default 8; \code{0} = pre-2.14 sequential). \code{XHDFE_AKM_SCATTER_CSR}
#'   (default on) selects the parallel CSR-ordered Rademacher scatter at scale.
#'   The solves are batched without changing the estimator or solver
#'   tolerances; different schedules can differ at the last-ulp level. A
#'   \code{warning()} fires on non-convergence (check \code{$converged}) and
#'   on inferential diagnostics recorded in \code{$notes}, including omitted
#'   collinear controls, truncated negative simulated variances and undefined
#'   AM intervals.
#' @param gpu Solve the two-way systems on the CUDA backend when available.
#' @return An object of class \code{xhdfe_akm_kss}: a list with the sample
#'   summary, observation-level \code{alpha}/\code{psi} on the kept rows,
#'   control coefficients \code{beta}, and the \code{plugin}/\code{agsu}/
#'   \code{kss} component tables. Each component table carries
#'   \code{var_alpha}, \code{var_psi}, \code{cov_alpha_psi} plus the derived
#'   \code{corr_alpha_psi}, \code{var_alpha_plus_psi} and the shares of
#'   \code{var_y} (\code{share_var_alpha}, \code{share_var_psi},
#'   \code{share_2cov}). Also returned: \code{var_y}, \code{sigma2_ho},
#'   row-level leverages \code{pii} and \code{sigma_i}, and solver
#'   diagnostics (\code{leverages_exact}, \code{gpu_requested},
#'   \code{gpu_used}, \code{gpu_status_code}, \code{gpu_status},
#'   \code{threads_requested}, \code{threads_effective},
#'   \code{fwl_threads_used}, \code{fwl_parallel_workers_active},
#'   \code{fwl_gpu_used}, \code{fwl_gpu_fallback},
#'   \code{fwl_gpu_status}, \code{fwl_abs_residual_rel},
#'   \code{fwl_precision_certified},
#'   \code{solver_threads_used}, \code{solver_parallel_workers_active},
#'   \code{threads_used}, \code{parallel_workers_active},
#'   \code{thread_capacity}, \code{converged}, ...).
#'   The nested control-FWL phase deliberately uses the strict-residual MLSMR
#'   CPU reference path (\code{fwl_gpu_status = "cpu_reference"}); the
#'   two-way solver remains independently eligible for CUDA.
#'   With \code{compute_se = TRUE} a \code{component_se} list holds the
#'   standard errors for its \code{theta_*} point estimates, which differ
#'   from the \code{kss} components; with
#'   \code{eigen_diagnostics = TRUE} a \code{weak_id} list holds, per
#'   component, the top eigenvalue and shares of Atilde, the Lindeberg
#'   condition, \code{gamma_sq}, the F statistic, \code{theta_1}, the
#'   Andrews-Mikusheva q = 1 confidence bounds (\code{ci_lb}/\code{ci_ub})
#'   and the curvature.
#' @references Kline P., Saggio R., Soelvsten M. (2020), Econometrica;
#'   Andrews M. et al. (2008), JRSS-A; Abowd J., Kramarz F., Margolis D.
#'   (1999), Econometrica.
#' @examples
#' \donttest{
#' n_w <- 100; n_f <- 12; reps <- 4
#' worker <- rep(seq_len(n_w), each = reps)
#' firm <- sample(seq_len(n_f), n_w * reps, replace = TRUE)
#' y <- rnorm(n_w)[worker] + rnorm(n_f)[firm] + rnorm(n_w * reps)
#' fit <- xhdfe_akm_kss(y, worker, firm)
#' print(fit)
#' }
#' @export
xhdfe_akm_kss <- function(y, worker, firm, X = NULL,
                          leave_out_level = "match",
                          leverages = "auto",
                          jla_draws = 200L,
                          seed = 20260705,
                          prune = TRUE,
                          exact_max_rows = 10000L,
                          direct_max_firms = 50000L,
                          direct_max_nnz = 4e7,
                          cg_tol = 1e-10,
                          cg_max_iter = 0L,
                          num_threads = 0L,
                          fwl_tol = 1e-10,
                          fwl_max_iter = 100000L,
                          compute_se = FALSE,
                          se_nsim = 1000L,
                          eigen_diagnostics = FALSE,
                          eig_trace_nsim = 100L,
                          se_sigma_lowess = FALSE,
                          gpu = FALSE,
                          fweights = NULL,
                          verbose = FALSE,
                          sigma_centering = "leaveouttwoway") {
  if (length(num_threads) != 1L || !is.numeric(num_threads) ||
      is.logical(num_threads) || is.na(num_threads) ||
      !is.finite(num_threads) || num_threads < 0 ||
      num_threads != floor(num_threads)) {
    stop("num_threads must be one nonnegative integer", call. = FALSE)
  }
  y <- as.numeric(y)
  if (length(worker) != length(y) || length(firm) != length(y)) {
    stop("y, worker and firm must have the same length", call. = FALSE)
  }
  if (anyNA(y)) {
    stop("y contains missing values; supply complete cases", call. = FALSE)
  }
  if (!is.null(X)) {
    X <- as.matrix(X)
    storage.mode(X) <- "double"
    if (nrow(X) != length(y)) {
      stop("X must have the same number of rows as y", call. = FALSE)
    }
    if (anyNA(X)) {
      stop("X contains missing values; supply complete cases", call. = FALSE)
    }
  }
  sigma_centering <- match.arg(sigma_centering, c("leaveouttwoway", "person_year"))
  opts <- list(leave_out_level = as.character(leave_out_level),
               sigma_centering = sigma_centering,
               leverages = as.character(leverages),
               jla_draws = as.integer(jla_draws),
               seed = as.double(seed),
               prune = isTRUE(prune),
               exact_max_rows = as.integer(exact_max_rows),
               direct_max_firms = as.integer(direct_max_firms),
               direct_max_nnz = as.double(direct_max_nnz),
               cg_tol = as.double(cg_tol),
               cg_max_iter = as.integer(cg_max_iter),
               num_threads = as.integer(num_threads),
               fwl_tol = as.double(fwl_tol),
               fwl_max_iter = as.integer(fwl_max_iter),
               compute_se = isTRUE(compute_se),
               se_nsim = as.integer(se_nsim),
               eigen_diagnostics = isTRUE(eigen_diagnostics),
               eig_trace_nsim = as.integer(eig_trace_nsim),
               se_sigma_lowess = isTRUE(se_sigma_lowess),
               gpu = isTRUE(gpu),
               verbose = as.integer(isTRUE(verbose)))
  if (!is.null(fweights)) {
    fweights <- as.numeric(fweights)
    if (length(fweights) != length(y)) {
      stop("fweights must have the same length as y", call. = FALSE)
    }
  }
  out <- .xhdfe_cpp_akm_kss(y,
                            .akm_id_codes(worker, "worker"),
                            .akm_id_codes(firm, "firm"),
                            X, opts, fweights)
  if (!identical(out$sigma_centering, sigma_centering)) {
    stop("the loaded backend does not confirm sigma_centering; rebuild the matching package",
         call. = FALSE)
  }
  class(out) <- "xhdfe_akm_kss"
  # Surface non-convergence loudly, matching the Stata front-end and the
  # Gelbach treatment (a silently returned non-converged decomposition is a
  # footgun); the flag stays on the object for programmatic checks.
  if (isFALSE(out$converged)) {
    warning("xhdfe_akm_kss: the AKM/KSS decomposition did not converge - ",
            "results are unreliable (see $notes).", call. = FALSE)
  } else if (nzchar(out$notes) && grepl("warning:", tolower(out$notes),
                                        fixed = TRUE)) {
    warning("xhdfe_akm_kss: inferential diagnostic - ", out$notes,
            call. = FALSE)
  }
  out
}

#' @export
print.xhdfe_akm_kss <- function(x, digits = 6, ...) {
  s <- x$sample
  cat("AKM + leave-out (KSS) variance decomposition\n")
  cat(sprintf("Leave-out sample: %s obs, %s workers (%s movers), %s firms, %s matches\n",
              format(s$n_obs, big.mark = ","), format(s$n_workers, big.mark = ","),
              format(s$n_movers, big.mark = ","), format(s$n_firms, big.mark = ","),
              format(s$n_matches, big.mark = ",")))
  tab <- rbind(plugin = unlist(x$plugin),
               agsu = unlist(x$agsu),
               kss = unlist(x$kss))
  print(round(tab[, c("var_alpha", "var_psi", "cov_alpha_psi")], digits))
  cat(sprintf("var(y) = %s; leverages: %s%s; converged: %s\n",
              format(x$var_y, digits = digits),
              if (isTRUE(x$leverages_exact)) "exact" else "JLA",
              if (isTRUE(x$leverages_exact)) ""
              else sprintf(" (%d draws, seed %.0f)", x$jla_draws_used, x$seed),
              x$converged))
  if (nzchar(x$notes)) cat("notes:", x$notes, "\n")
  invisible(x)
}
