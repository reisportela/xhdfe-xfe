# Documentation-only file: roxygen2 blocks for the xhdfe package.
#
# This file intentionally contains NO functional code. Every topic is
# documented through the `NULL` + `@name` pattern so that the generated
# man/*.Rd pages describe the public R interface. Shared estimator behaviour
# is documented in stata/xhdfe.sthlp. The NAMESPACE is maintained by hand;
# no @export tags appear here.

# ---------------------------------------------------------------------------
# Package overview
# ---------------------------------------------------------------------------

#' xhdfe: Linear Regression with Multiple High-Dimensional Fixed Effects via a C++ Backend
#'
#' The \pkg{xhdfe} package estimates linear models with multiple
#' high-dimensional fixed effects through the compiled C++ estimator shared
#' with the Stata and Python interfaces. The CPU absorber is the reference
#' implementation. Use \code{backend = "cuda"} to require CUDA on supported
#' fits. Where possible the package mirrors
#' \code{reghdfe}'s reporting conventions and defaults, while also exposing
#' \pkg{fixest}-style small-sample corrections and design ideas drawn from
#' \code{pyfixest}, \code{FixedEffectModels.jl}, the \code{within} solvers of
#' Fischer and Schroeder, and \code{fereg} by Schmieder (see the
#' Acknowledgements section). The default \code{"reghdfe-comparable"}
#' mode targets comparable within-projection accuracy. See \link{xhdfe}
#' for the restrictions on specific designs and backends.
#'
#' @section Features:
#' \itemize{
#'   \item A fast fixed-effect absorber with several iterative methods
#'     (Gauss-Seidel, symmetric Gauss-Seidel, Jacobi, additive-Schwarz /
#'     preconditioned conjugate-gradient, LSMR, and modified-LSMR/within
#'     solvers) plus OpenMP multithreading, with an automatic method
#'     selector.
#'   \item Multiway (two-or-more-way) fixed effects, including combined
#'     fixed effects (\code{f1^f2}) and heterogeneous (group-specific)
#'     slopes (\code{fe[x]}, \code{fe[[x]]}).
#'   \item Unadjusted, heteroskedasticity-robust (HC1) and multiway
#'     clustered standard errors with cluster diagnostics, including the
#'     Cameron-Gelbach-Miller positive-semi-definite adjustment used by
#'     \code{reghdfe}.
#'   \item Instrumental variables / two-stage least squares (2SLS) for
#'     supported standard fixed-effect designs.
#'   \item Analytic, frequency, importance and probability weights (Stata
#'     \code{aweight}, \code{fweight}, \code{iweight}, \code{pweight}).
#'   \item \code{reghdfe}-style singleton dropping and degrees-of-freedom
#'     adjustments, plus \pkg{fixest}-style small-sample corrections
#'     (\code{ssc}).
#'   \item Fixed-effect recovery (\code{save_fe = TRUE}, the analogue of
#'     Stata's \code{savefe}), retrieved with \code{fixef()}.
#'   \item Group-level outcomes with individual fixed effects
#'     (\code{group} / \code{individual} / \code{aggregation}), matching
#'     the Stata \code{group()} / \code{individual()} machinery.
#'   \item An optional CUDA GPU absorber with a fail-closed contract:
#'     a requested GPU backend that cannot actually be used raises an
#'     error. \code{weighted_cpu_route = TRUE} requests a CPU fit when
#'     eligible and reports \code{gpu_status = "weighted_cpu_route"} (see
#'     \code{\link{xhdfe}}).
#' }
#'
#' @section Development process:
#' The package was developed through an AI-assisted optimization workflow
#' (OpenAI Codex, Anthropic Claude Code, and some Google Gemini Code Assist)
#' used to study existing high-dimensional fixed-effects packages, review the
#' literature, inspect the mixed Stata/C++/Python/R codebase, draft and
#' revise patches, instrument slow paths, and improve performance. The human
#' authors did not write the package line by line; they defined the
#' econometric target, set numerical and performance guardrails, chose the
#' benchmark and validation criteria, directed the optimization work, decided
#' which changes to keep, and retain full responsibility for the package. No
#' software tool or AI system is credited as author or co-author.
#'
#' @section The xhdfe ecosystem:
#' \pkg{xhdfe} is built to validate against and interoperate with the
#' established high-dimensional fixed-effects estimators:
#' \itemize{
#'   \item xhdfe (Stata, Python, R): \url{https://github.com/reisportela/xhdfe-xfe}
#'   \item reghdfe (Stata, Sergio Correia):
#'     \url{https://github.com/sergiocorreia/reghdfe}
#'   \item fixest (R, Laurent Berge): \url{https://github.com/lrberge/fixest}
#'   \item pyfixest (Python, Alexander Fischer and collaborators):
#'     \url{https://pyfixest.org/},
#'     \url{https://github.com/py-econometrics/pyfixest}
#'   \item FixedEffectModels.jl (Julia, Matthieu Gomez and collaborators):
#'     \url{https://github.com/FixedEffects/FixedEffectModels.jl}
#'   \item within (Rust and Python, Alexander Fischer and Kristof Schroeder):
#'     \url{https://github.com/py-econometrics/within}
#'   \item fereg (Stata, Johannes F. Schmieder):
#'     \url{https://github.com/johannes-schmieder/fereg}
#' }
#' Comparison packages, current releases checked on 14 November 2026:
#' reghdfe 6.14.1 (8 July 2026), fixest 0.14.2 (CRAN, 26 June 2026),
#' pyfixest 0.70.0, FixedEffectModels.jl 2.2.0 (2 November 2026) and fereg
#' 0.6.0.
#'
#' @section Authors:
#' \itemize{
#'   \item Miguel Portela -- NIPE / Universidade do Minho and BPLIM / Banco
#'     de Portugal -- \email{miguel.portela@@eeg.uminho.pt} --
#'     \url{https://reisportela.github.io}
#'   \item Tiago Tavares -- NIPE / Universidade do Minho --
#'     \email{tgstavares@@eeg.uminho.pt} -- \url{https://www.tgstavares.com}
#' }
#' Only the listed human authors are authors or co-authors of this package;
#' no software tool or AI system is credited as author or co-author.
#'
#' @section Acknowledgements:
#' \pkg{xhdfe} is a reimplementation built to validate against and
#' interoperate with \code{reghdfe} (Sergio Correia), \pkg{fixest} (Laurent
#' Berge), \code{pyfixest} (Alexander Fischer and collaborators), and
#' \code{FixedEffectModels.jl} (Matthieu Gomez and collaborators). The
#' \code{within} materials of Alexander Fischer and Kristof Schroeder, with
#' their 2026 paper, were the direct starting point for the
#' graph-preconditioned MLSMR/additive-Schwarz route. The reduced-system tier
#' of version 2.32 (\code{"reduced-pcg"}) follows the design implemented in
#' \code{fereg} 0.6.0 and described in Schmieder (2026), and cites it as such:
#' exact elimination of the fixed effect with the most levels and
#' Jacobi-preconditioned conjugate gradients on the remaining system, for two
#' to five fixed effects, with up to eight columns per pass, a limit of 1,500
#' iterations for that stage and a stall test of the same form (the residual
#' must halve within each window of iterations). As that paper notes, the
#' elimination is the block reduction of Somaini and Wolak (2016), and
#' iterative solutions have precedents in Abowd, Creecy and Kramarz (2002) and
#' in Mittag (2019). \pkg{xhdfe} does not implement what Schmieder (2026)
#' presents as \code{fereg}'s distinguishing contribution in this step, the
#' escalation to stronger preconditioners, including combinatorial multigrid,
#' on poorly connected data: where the Jacobi-preconditioned iteration stalls,
#' \pkg{xhdfe} hands the fit to its previous routes. \pkg{xhdfe}'s part is an
#' independent C++ implementation inside its own routing, certificate,
#' fallbacks and diagnostics. \pkg{xhdfe} contains no \code{fereg} source code;
#' its C++ implementation was written after studying the paper and
#' \code{fereg}'s public source. Two changes of
#' version 2.31.0 followed benchmarks against \code{fereg}: reading the Stata
#' data in parallel on qualified hosts, as \code{fereg} does, and larger
#' automatic thread teams (one thread per 25,000 rows instead of 500,000),
#' where \code{fereg} by default uses all logical processors and sizes the
#' parallel work of each stage by its amount of work; \code{fereg} credits the
#' precedent of parallel copying from Stata to David Roodman's \code{julia}
#' package (Roodman 2025). The
#' authors thank Paulo Guimaraes (Banco de Portugal), Marta Silva (Banco de
#' Portugal), and Nelson Areal (EEG/Universidade do Minho). An earlier proof
#' of concept was shared at BPLIM's "Speeding Up Empirical Research"
#' workshop, in the hands-on session "Parallel and Cross-Language Computing:
#' A Hands-On Workshop for Empirical Researchers" presented by Nelson Areal
#' and Miguel Portela (BPLIM 2025). Financial support from Universidade do
#' Minho, Banco de Portugal, and FCT (UID/03182/2025) is gratefully
#' acknowledged. The usual disclaimer applies.
#'
#' @references
#' Portela, Miguel, and Tiago Tavares. 2026. "xhdfe: High-dimensional fixed
#' effects regression via a C++ backend." Version 2.35.1.
#' \url{https://github.com/reisportela/xhdfe-xfe}
#'
#' Cornelissen, Thomas. 2008. "The Stata command felsdvreg to fit a linear
#' model with two high-dimensional fixed effects." Stata Journal 8(2):
#' 170-189. \doi{10.1177/1536867X0800800202}
#'
#' Guimaraes, Paulo, and Pedro Portugal. 2010. "A simple feasible procedure
#' to fit models with high-dimensional fixed effects." Stata Journal 10(4):
#' 628-649. \doi{10.1177/1536867X1101000406}
#'
#' Gaure, Simen. 2013. "OLS with multiple high dimensional category
#' variables." Computational Statistics & Data Analysis 66: 8-18.
#' \doi{10.1016/j.csda.2013.03.024}
#'
#' Correia, Sergio. 2016. "reghdfe: Estimating linear models with multi-way
#' fixed effects." 2016 Stata Conference. RePEc:boc:scon16:24.
#'
#' Correia, Sergio, Paulo Guimaraes, and Tom Zylkin. 2020. "Fast Poisson
#' estimation with high-dimensional fixed effects." Stata Journal 20(1):
#' 95-115. \doi{10.1177/1536867X20909691}
#'
#' Berge, Laurent, Kyle Butts, and Grant McDermott. 2026. "Fast and
#' user-friendly econometrics estimations: The R package fixest."
#' arXiv:2601.21749.
#'
#' Fischer, Alexander, and collaborators. "pyfixest: Fast high-dimensional
#' fixed effect estimation in Python." Python package.
#' \url{https://pyfixest.org/} and
#' \url{https://github.com/py-econometrics/pyfixest}
#'
#' FixedEffects.jl contributors. 2025. "FixedEffectModels.jl: Linear models
#' with instrumental variables and high dimensional categorical variables."
#' Julia package. \url{https://github.com/FixedEffects/FixedEffectModels.jl}
#'
#' Abowd, John M., Robert H. Creecy, and Francis Kramarz. 2002. "Computing
#' person and firm effects using linked longitudinal employer-employee data."
#' Longitudinal Employer-Household Dynamics Technical Paper TP-2002-06, U.S.
#' Census Bureau.
#'
#' Mittag, Nikolas. 2019. "A simple method to estimate large fixed effects
#' models applied to wage determinants." Labour Economics 61: 101766.
#' \doi{10.1016/j.labeco.2019.101766}
#'
#' Somaini, Paulo, and Frank A. Wolak. 2016. "An algorithm to estimate the
#' two-way fixed effects model." Journal of Econometric Methods 5(1):
#' 143-152. \doi{10.1515/jem-2014-0008}
#'
#' Roodman, David. 2025. "Julia as a universal platform for statistical
#' software development." Stata Journal 25(2): 255-284.
#' \doi{10.1177/1536867X251341105}
#'
#' Fischer, Alexander, and Kristof Schroeder. 2026. "Graph Preconditioning
#' for High-Dimensional Fixed Effects Regression." Mimeo, draft of June 2026.
#' \url{https://github.com/py-econometrics/within-paper}
#'
#' Fischer, Alexander, and Kristof Schroeder. "within: Fast solvers for
#' high-dimensional fixed effects." Rust crate and Python package.
#' \url{https://github.com/py-econometrics/within}
#'
#' Schmieder, Johannes. 2026. "fereg: Fast high-dimensional fixed-effects
#' regressions in Stata." CEPR Discussion Paper No. 22170. CEPR Press, Paris
#' & London. \url{https://cepr.org/publications/dp22170}; software:
#' \url{https://github.com/johannes-schmieder/fereg}
#'
#' @seealso \code{\link{xhdfe}} for the formula interface,
#'   \code{\link{xhdfe_fit}} for the matrix interface,
#'   \code{xhdfe_demean()} for stand-alone demeaning,
#'   \code{xhdfe_group_fes()} for group-level fixed-effect aggregation, and
#'   \code{xhdfe_info()} for version and build information.
#'
#' @name xhdfe-package
#' @aliases xhdfe-package
NULL

# ---------------------------------------------------------------------------
# Main estimator: xhdfe()
# ---------------------------------------------------------------------------

#' Linear regression with multiple high-dimensional fixed effects (C++ backend)
#'
#' @description
#' \code{xhdfe()} estimates linear models with any number of high-dimensional
#' fixed effects through the xhdfe C++ backend -- the same compiled estimator
#' behind the Stata \code{xhdfe} command and the Python \code{xhdfe} package.
#' It mirrors \code{reghdfe}'s reporting conventions and defaults where
#' possible (singleton dropping, degrees-of-freedom accounting, multiway
#' clustered inference, constant reporting) while also exposing
#' \pkg{fixest}-style small-sample corrections.
#'
#' The Stata command's six syntax forms translate to R as follows:
#' \itemize{
#'   \item Least-squares regression without fixed effects:
#'     \code{xhdfe(y ~ x1 + x2, data = df)}.
#'   \item Regression with absorbed fixed effects (Stata
#'     \code{absorb(fe1 fe2)}): \code{xhdfe(y ~ x1 + x2 | fe1 + fe2, data = df)}.
#'   \item Group-level outcomes (Stata \code{group(gid)}):
#'     \code{xhdfe(y ~ x, data = df, group = ~ gid)}, optionally with a
#'     fixed-effects part.
#'   \item Group-level outcomes with individual fixed effects (Stata
#'     \code{group(gid) individual(iid)}):
#'     \code{xhdfe(y ~ x | iid, data = df, group = ~ gid, individual = ~ iid)}.
#'   \item Instrumental variables / 2SLS (Stata \code{endogenous()} +
#'     \code{instruments()}):
#'     \code{xhdfe(y ~ exo | fe1 + fe2 | endo ~ inst, data = df)}; without
#'     absorbed fixed effects, \code{xhdfe(y ~ exo | endo ~ inst, data = df)}.
#'   \item Version information (Stata \code{xhdfe, version}):
#'     \code{xhdfe_info()}.
#' }
#'
#' With absorbed fixed effects a \code{reghdfe}-compatible constant
#' \code{"(Intercept)"} is reported after the regressors; remove it with
#' \code{0 +} in the regressor part (the analogue of Stata's
#' \code{noconstant}).
#'
#' Standard S3 methods are available on the returned object:
#' \code{print}, \code{summary}, \code{coef}, \code{vcov}, \code{confint},
#' \code{nobs}, \code{df.residual}, \code{residuals}, \code{fitted},
#' \code{predict} (with Stata's \code{xb}, \code{xbd}, \code{d},
#' \code{residuals}, \code{dresiduals}, \code{score}, and \code{stdp}
#' statistics), \code{logLik}, \code{deviance}, \code{formula},
#' \code{fixef}, and \code{coeftable}. Unlike Stata, no
#' \code{residuals()}-style option is needed before using the fixed-effect
#' prediction types: residuals and prediction caches are always retained
#' (except in grouped fits).
#'
#' @usage
#' xhdfe(fml, data = NULL,
#'       vcov = NULL, cluster = NULL,
#'       weights = NULL, weights_type = c("analytic", "frequency", "importance", "probability"),
#'       subset = NULL,
#'       group = NULL, individual = NULL, aggregation = "mean",
#'       save_fe = FALSE, groupvar = FALSE,
#'       tol = 1e-8, maxiter = 100000,
#'       tolerance_mode = "reghdfe-comparable",
#'       convergence = "auto", check_interval = 1,
#'       absorption_method = "auto", symmetric_sweep = FALSE,
#'       jacobi_relaxation = 0,
#'       fe_tolerance = 1e-6, fe_recovery_method = "hybrid",
#'       drop_singletons = TRUE, keep_singletons = NULL,
#'       dof = NULL, ssc = NULL, stats_style = "reghdfe",
#'       level = 95,
#'       threads = 0, default_threads = 0, max_threads = 0,
#'       min_parallel_rows = 20000, target_rows_per_thread = 0,
#'       backend = c("default", "cpu", "cuda", "metal"),
#'       na.action = c("omit", "fail"),
#'       reduced_pcg = NULL, reduced_pcg_cuda = NULL,
#'       weighted_cpu_route = FALSE, reduced_pcg_apply_fine = NULL,
#'       slope_solver = NULL, slope_scores = NULL, slope_csr_owner = NULL)
#'
#' @param fml a model formula with up to three \code{|}-separated parts:
#'   \code{y ~ regressors | fixed effects | endogenous ~ instruments}.
#'
#'   \emph{Part 1 -- regressors.} The left-hand side must be numeric. The
#'   regressor part has the full power of R model formulas: factors expand
#'   into dummies (the complete Stata-style stripe with base levels is not
#'   posted; R's usual treatment-contrast columns are used), interactions
#'   (\code{x1:x2}, \code{x1*x2}), and transformations (\code{log(x)},
#'   \code{I(x^2)}, \code{poly(x, 2)}) are accepted. Use \code{0 +} (or
#'   \code{- 1}) to remove the constant, the analogue of Stata's
#'   \code{noconstant}.
#'   Known \code{offset()} terms are subtracted from the response for estimation
#'   and restored in predictions. Fit statistics (including R-squared and TSS)
#'   describe the offset-adjusted response; coefficients, covariance and
#'   residuals have their usual offset-model interpretation.
#'
#'   \emph{Part 2 -- absorbed fixed effects.} A \code{+}-separated list of
#'   fixed-effect terms (see the \emph{Absorbing fixed effects} section for
#'   the complete grammar):
#'   \itemize{
#'     \item \code{fe} -- plain absorbed intercepts, one per level
#'       (Stata \code{absorb(fe)}).
#'     \item \code{f1^f2} -- combined fixed effect, i.e. the interaction of
#'       two (or more, via nesting) id variables; equivalent to Stata
#'       \code{absorb(f1#f2)}. It is \emph{not} expanded into main effects:
#'       write \code{f1 + f2 + f1^f2} explicitly if all three are intended
#'       (this matches \code{reghdfe}, which canonicalizes categorical-only
#'       \code{f1##f2} to the same joint fixed effect as \code{f1#f2}).
#'     \item \code{fe[x]} -- absorbed intercepts plus group-specific
#'       (heterogeneous) slopes on \code{x}; equivalent to Stata
#'       \code{absorb(fe##c.x)}.
#'     \item \code{fe[[x]]} -- group-specific slopes only, without absorbed
#'       intercepts; equivalent to Stata \code{absorb(fe#c.x)}.
#'     \item \code{fe[x1, x2]} -- multiple slope variables on the same
#'       carrier ids; internally one absorbed dimension is created per slope
#'       variable, with the intercept riding on the first, exactly like
#'       Stata's expansion \code{absorb(fe##c.x1 fe#c.x2)}.
#'     \item Arbitrary expressions are evaluated in \code{data}, e.g.
#'       \code{factor(region)} or \code{interaction(a, b)}.
#'   }
#'
#'   \emph{Part 3 -- IV/2SLS.} An optional \code{endo ~ inst} part naming the
#'   endogenous regressors and their instruments (both sides may contain
#'   several variables joined with \code{+}). The endogenous coefficients are
#'   appended \emph{after} the exogenous ones in the coefficient vector.
#'   Without absorbed fixed effects, use the two-part IV form
#'   \code{y ~ exo | endo ~ inst}.
#' @param data a \code{data.frame} (or environment) in which the formula,
#'   \code{cluster}, \code{weights}, \code{subset}, \code{group}, and
#'   \code{individual} specifications are evaluated. Variables not found in
#'   \code{data} are looked up in the formula's environment.
#' @param vcov the variance-covariance estimator. One of:
#'   \itemize{
#'     \item \code{NULL} (default) -- \code{"unadjusted"} when no clusters
#'       are supplied, \code{"cluster"} otherwise.
#'     \item \code{"unadjusted"} (aliases \code{"iid"}, \code{"ols"},
#'       \code{"homoskedastic"}, \code{"classical"}, \code{"unadj"}) --
#'       conventional homoskedastic standard errors; Stata
#'       \code{vce(unadjusted)}.
#'     \item \code{"robust"} (aliases \code{"hc1"},
#'       \code{"heteroskedastic"}) -- HC1-style heteroskedasticity-robust
#'       standard errors; Stata \code{vce(robust)}.
#'     \item \code{"cluster"} (alias \code{"clustered"}) -- (multiway)
#'       clustered standard errors; requires \code{cluster}. Stata
#'       \code{vce(cluster ...)}.
#'     \item a one-sided formula such as \code{~ id1 + id2} -- shorthand for
#'       \code{vcov = "cluster", cluster = ~ id1 + id2}.
#'   }
#'   For Stata-style probability weights use \code{weights_type = "probability"}.
#'   With \code{vcov = NULL}, inference is robust unless clusters are supplied.
#'   Probability weights require robust or clustered inference.
#' @param cluster the cluster dimensions, in any of the equivalent forms:
#'   a one-sided formula (\code{~ firm} or \code{~ firm + year}; terms are
#'   evaluated in \code{data} and \code{a^b} combines ids as in the
#'   fixed-effects part), a character vector of column names in \code{data}
#'   (\code{c("firm", "year")}), a bare vector, a \code{data.frame} or
#'   matrix (one dimension per column), or a list of vectors. Supplying
#'   more than one dimension requests multiway (Cameron-Gelbach-Miller)
#'   clustering, as with Stata \code{vce(cluster id1 id2)}. Passing
#'   \code{cluster} without \code{vcov} implies \code{vcov = "cluster"}.
#' @param weights observation weights: a numeric vector, a column name in
#'   \code{data}, or a one-sided formula (\code{~ w}). Interpretation is
#'   controlled by \code{weights_type}.
#' @param weights_type \code{"analytic"} (default) treats \code{weights}
#'   like Stata \code{aweight}s: relative precision weights, with the number
#'   of observations equal to the number of rows. \code{"frequency"} treats
#'   them like Stata \code{fweight}s: each row counts \code{weights} times,
#'   with \emph{exact replicated-rows semantics} -- observation counts,
#'   degrees of freedom, and the \code{*_effective} count fields use the sum
#'   of the weights, matching a physically duplicated dataset.
#'   \code{"importance"} follows Stata \code{iweight}: classical inference
#'   uses unnormalized weights and \code{floor(sum(weights))} for N; robust
#'   or clustered inference follows the analytic-weight convention.
#'   \code{"probability"} follows \code{pweight} and defaults to robust
#'   inference unless clustering is specified.
#' @param subset an optional expression evaluated in \code{data} (like the
#'   \code{subset} argument of \code{\link[stats]{lm}}): either a logical
#'   vector or a vector of row indices selecting the rows used in
#'   estimation. The analogue of Stata's \code{if}/\code{in}.
#' @param group the group identifier for group-level outcomes (Stata
#'   \code{group(groupvar)}), e.g. a patent id. Accepts a one-sided formula
#'   (\code{~ patent}), a column name, or a vector. When supplied without
#'   \code{individual}, the regression runs on one representative row per
#'   group; see the \emph{Group-level outcomes with individual fixed
#'   effects} section.
#' @param individual the individual identifier whose fixed effect is
#'   absorbed at the group level (Stata \code{individual(indvar)}), e.g. an
#'   inventor id. Requires \code{group}. Same accepted forms as
#'   \code{group}. The individual dimension is automatically appended (last)
#'   to the absorbed dimensions if it is not already among them, mirroring
#'   Stata's behavior.
#' @param aggregation how the individual fixed-effect components are
#'   aggregated within each group: \code{"mean"} (default; Stata aliases
#'   \code{avg}/\code{average}) or \code{"sum"}. Case-insensitive. The
#'   analogue of Stata's \code{aggregation()}.
#' @param save_fe logical; if \code{TRUE}, recover the fixed-effect
#'   contributions (the analogue of Stata's \code{absorb(..., savefe)} /
#'   \code{savefes(prefix)}). The recovered values are stored in the
#'   \code{fe_effects} field (one vector per absorbed dimension, on the
#'   estimation sample) and are most conveniently retrieved with
#'   \code{fixef()}, which expands them to full input length with \code{NA}
#'   off-sample. Where Stata creates variables named \code{__hdfe1__},
#'   \code{__hdfe1__Slope1}, ... , the R interface names the list entries
#'   after the fixed-effect terms. Note that the saved values are
#'   \emph{contributions} (one value per observation), not group ids, and
#'   may not be separately identified in all designs. For heterogeneous
#'   slopes, \code{fe[x]} yields both the level contribution and the slope
#'   contribution while \code{fe[[x]]} yields only the slope contribution,
#'   matching \code{reghdfe}'s layout. With the default
#'   \code{fe_recovery_method = "hybrid"}, the alphas are accumulated during
#'   absorption when feasible so recovery usually avoids a second sweep;
#'   \code{fe_tolerance} applies only to the fallback MAP recovery.
#'   Restrictions: not available together with both \code{group} and
#'   \code{individual}, nor with the LSMR-family absorption methods.
#' @param groupvar logical; if \code{TRUE}, compute the first mobility group
#'   (the connected component of the first two absorbed fixed effects) and
#'   store its 1-based ids in the \code{groupvar} field of the result (the
#'   analogue of Stata's \code{groupvar(newvar)}). Requires at least two
#'   absorbed fixed effects and degrees-of-freedom adjustments that include
#'   the \code{firstpair} or \code{pairwise} logic (the default
#'   \code{dof = "all"} qualifies).
#' @param tol convergence tolerance of the absorber; default \code{1e-8}.
#'   Its exact meaning depends on \code{tolerance_mode}; under the default
#'   \code{"reghdfe-comparable"} mode it carries the same meaning as
#'   \code{reghdfe}'s \code{tolerance()}.
#' @param maxiter maximum number of absorber iterations; default
#'   \code{100000} (the analogue of Stata's \code{maxiter()} /
#'   \code{iterate()}). If the absorber does not converge within
#'   \code{maxiter} iterations, or fails its numerical certificate, an
#'   informative error is raised and no new estimates are returned.
#' @param tolerance_mode the absorber convergence mode; the mode used is
#'   recorded in the \code{tolerance_mode} field (Stata
#'   \code{e(tolerance_mode)}). One of:
#'   \itemize{
#'     \item \code{"reghdfe-comparable"} (default since 2.7.0; aliases
#'       \code{"reghdfe"}, \code{"comparable"}, \code{"reghdfe_comparable"}):
#'       the accelerated absorber stops when one full sweep moves the
#'       working data by less than \code{tol} in relative norm -- the same
#'       meaning \code{reghdfe} attaches to its tolerance -- so coefficients
#'       match \code{reghdfe} at the same nominal tolerance, down to problem
#'       conditioning. Ordinary no-slope LSMR/MLSMR uses
#'       \code{min(effective tolerance, 1e-11)} in comparable and strict modes;
#'       fast mode and requested tolerances at or below \code{1e-11} are unchanged.
#'     \item \code{"xhdfe-fast"} (aliases \code{"fast"}, \code{"xhdfe"},
#'       \code{"current"}, \code{"xhdfe_fast"}): the pre-2.7.0 stopping
#'       rule; typically about 1.5-3x fewer absorber iterations. Its
#'       \emph{effective} precision is data-dependent and can be looser
#'       than the nominal tolerance on ill-conditioned (e.g. sparse
#'       bipartite) designs. Appropriate for exploration and speed
#'       benchmarking -- always state the mode when citing timings.
#'     \item \code{"strict-residual"} (aliases \code{"strict"},
#'       \code{"residual-certificate"}, \code{"strict_residual"},
#'       \code{"residual_certificate"}): a heavier audit mode that treats
#'       a final absolute check as authoritative; it may use extra
#'       iterations up to \code{maxiter} and reports non-convergence if the
#'       check is not met. On the CPU the check is the largest absolute
#'       group mean of the absorbed outcome and of every absorbed regressor;
#'       except in fits with both \code{group} and \code{individual}, only
#'       the sweep methods make it: a CPU fit whose absorption is produced
#'       by another solver (for example the sparse direct solve, LSMR or
#'       MLSMR, or Krylov-PCG; requested, chosen by the automatic method, or
#'       run as the repair after the sweeps fail) is accepted on that
#'       solver's stopping rule and the certificate, without that absolute
#'       check.
#'       An ordinary categorical CUDA fit checks the largest absolute group
#'       mean of its reported residuals, using the fit's weights. This includes
#'       the structural residual for IV and the reconstruction with saved
#'       effects. The automatic unweighted Comparable-based Strict route can
#'       continue from its projected state. Other ordinary CUDA fits can use
#'       one device LSMR projection within the remaining \code{maxiter} budget.
#'       An eligible fit with \code{weighted_cpu_route = TRUE} applies the CPU
#'       checks. Fits with both \code{group} and \code{individual} use their
#'       grouped-absorption checks. The absolute check is in the units of the dependent
#'       variable. When the residuals are so large in those units that the
#'       tolerance is within a few units of roundoff of them (observed on
#'       one synthetic panel, with \code{tol = 1e-8}, from residuals of
#'       about 2e7 to 4e7), the check may be unattainable in double
#'       precision: the fit can then use iterations up to \code{maxiter} and
#'       reports non-convergence, in some runs well before that limit, and
#'       close to that point the same fit can be accepted in one run and
#'       refused in the next. Rescale the
#'       dependent variable, raise \code{tol}, or use
#'       \code{"reghdfe-comparable"}, whose criteria are relative. Not
#'       supported with heterogeneous slopes (an error is raised before
#'       estimation).
#'   }
#'   New in 2.11.0: under the default mode, absorbers on ill-conditioned,
#'   poorly connected multiway fixed-effect graphs -- where accelerated
#'   alternating projections would stall into thousands of plain sweeps --
#'   are automatically handed off to a stable per-column conjugate-gradient
#'   solver on the symmetric demeaning operator. The handoff is transparent:
#'   coefficients, standard errors, default output, and convergence behavior
#'   are unchanged (typically \emph{tighter} agreement with \code{reghdfe}),
#'   it applies on CPU and CUDA alike, well-conditioned problems are
#'   unaffected and numerically identical to prior versions, and runtime can
#'   drop by an order of magnitude on the pathological graphs.
#' @param convergence the stopping criterion of the heterogeneous-slope
#'   absorber, active only when the fixed-effects part contains slope terms
#'   (\code{fe[x]} / \code{fe[[x]]}); standard absorption follows
#'   \code{tolerance_mode}. One of \code{"auto"} (default: follows
#'   \code{tolerance_mode} -- under \code{"reghdfe-comparable"} it stops on
#'   the reghdfe-style update criterion at the nominal tolerance, under
#'   \code{"xhdfe-fast"} it uses the historical norm-change trigger),
#'   \code{"normchange"} (aliases \code{"norm"}, \code{"norm-change"},
#'   \code{"norm_change"}; relative change in the transformed-vector norms),
#'   \code{"reghdfe"} (aliases \code{"update"}, \code{"reldif"};
#'   reghdfe-style vector update criterion, i.e. the maximum weighted mean
#'   relative difference between successive transformed y/X columns), or
#'   \code{"both"} (requires both criteria). Note that
#'   \code{tolerance_mode = "strict-residual"} is not supported with
#'   heterogeneous slopes.
#'   In fast mode, slope absorption uses the historical aggregate residual
#'   check; block checks and block-driven refinement are skipped. Aggregate
#'   failures can still trigger refinement or refusal. Comparable mode keeps
#'   its block checks. The result field \code{slope_block_checked} is false
#'   when block diagnostics were not computed (their values are placeholders).
#' @param check_interval number of absorber iterations between convergence
#'   checks; default \code{1} (check every iteration).
#' @param absorption_method the fixed-effect absorption method
#'   (case-insensitive; the analogue of Stata's \code{absorptionmethod()}):
#'   \itemize{
#'     \item \code{"auto"} (default): first runs the probe-based auto-MLSMR
#'       selector on eligible CPU standard fixed-effect designs with at most
#'       3 fixed-effect dimensions; it promotes slow-converging large
#'       designs to \code{"mlsmr"} and otherwise resolves to a sweep
#'       fallback (\code{"gauss-seidel"} by default,
#'       \code{"symmetric-gauss-seidel"} only when
#'       \code{symmetric_sweep = TRUE}), avoiding a second survey by the
#'       Schwarz/Jacobi-PCG gate. Under
#'       \code{tolerance_mode = "xhdfe-fast"}, MLSMR promotion is limited to
#'       large, many-right-hand-side, multiway moderate-rho designs.
#'       Designs with 4 or more fixed effects stay on the full-data
#'       gate/sweep path so that the 200,000-row sampling probe cannot
#'       over-promote (raise the cap with the environment variable
#'       \code{XHDFE_AUTO_MLSMR_DEFAULT_MAX_FES}; an explicit
#'       \code{"auto-mlsmr"} is uncapped). Comparable CUDA \code{"auto"} selects
#'       device LSMR for ordinary unweighted two-FE graphs with low group occupancy,
#'       using the ordinary Krylov floor \code{min(effective tolerance, 1e-11)}
#'       and ordinary degrees of freedom. Fast, explicit methods/convergence,
#'       \code{save_fe} and heterogeneous slopes retain their primary routing.
#'       A broken ordinary Comparable CG recurrence restarts with device LSMR
#'       within the remaining iteration budget.
#'       Combined \code{group}/\code{individual} fits use joint
#'       LSMR for CPU \code{"auto"}, the existing certified solver for CUDA
#'       \code{"auto"}, and a certified sweep fallback if automatic CPU LSMR
#'       cannot be accepted. Gate
#'       promotions to MLSMR can be disabled entirely with
#'       \code{XHDFE_MLSMR_AUTO_GATE=0}.
#'     \item \code{"gauss-seidel"} (aliases \code{"gs"},
#'       \code{"gauss_seidel"}): alternating-projections Gauss-Seidel
#'       sweeps.
#'     \item \code{"symmetric-gauss-seidel"} (aliases \code{"symmetric"},
#'       \code{"sym"}, \code{"symgs"}, \code{"symmetric_gauss_seidel"}):
#'       forward plus backward sweeps.
#'     \item \code{"jacobi"}: Jacobi sweeps (see \code{jacobi_relaxation}).
#'     \item \code{"schwarz"} (aliases \code{"pcg"}, \code{"schwarz-pcg"}):
#'       the additive-Schwarz / preconditioned conjugate-gradient demeaner.
#'     \item \code{"lsmr"} (aliases \code{"plain-lsmr"},
#'       \code{"plain_lsmr"}): a matrix-free LSMR Krylov absorber.
#'     \item \code{"mlsmr"} (aliases \code{"modified-lsmr"},
#'       \code{"modified_lsmr"}, \code{"within"}, \code{"within-additive"},
#'       \code{"within_additive"}): the modified-LSMR (within) absorber.
#'     \item \code{"auto-mlsmr"} (aliases \code{"auto_mlsmr"},
#'       \code{"mlsmr-auto"}, \code{"mlsmr_auto"}): runs the probe-based
#'       MLSMR selector explicitly (uncapped in the number of fixed
#'       effects).
#'   }
#'   The LSMR/MLSMR family are matrix-free Krylov absorbers and are
#'   \emph{CPU-only}. For standard fixed-effect designs they do not support
#'   \code{save_fe} or heterogeneous slopes. In combined
#'   \code{group}/\code{individual} mode, plain \code{"lsmr"} is supported
#'   on CPU; \code{"mlsmr"}, \code{"auto-mlsmr"}, \code{"schwarz"}, and
#'   \code{"jacobi"} are rejected. The method effectively used is
#'   reported in the \code{absorption_method_used} and
#'   \code{absorption_method_code} fields (same code table as Stata's
#'   \code{e(absorption_method_used)}).
#'   The reduced-system tier is on by default; its method,
#'   \code{"reduced-pcg"} (code 8), is reported but cannot be requested.
#'   \code{"krylov-pcg"} (code 9) is reported, never requested, when the
#'   Krylov-PCG route is forced, for example by a mobility profile that
#'   suggests it. Codes 1 to 3 name the sweep selected for the fit; they are
#'   also reported when a route without a code of its own served it: the
#'   exact projections of weighted designs whose effects have few levels, the exact
#'   sparse solve and the conjugate-gradient accelerator of small path-like
#'   two-way graphs, and the conjugate-gradient stage that can follow the GPU
#'   sweeps.
#'   Before the route chosen by \code{"auto"} runs, an ordinary fit with
#'   \code{tolerance_mode = "reghdfe-comparable"}, \code{convergence = "auto"},
#'   two to five fixed effects and no CUDA or Metal request (\code{backend}
#'   or \code{XHDFE_GPU_BACKEND}), and without weights, instruments,
#'   heterogeneous slopes, \code{save_fe}, \code{groupvar}, \code{group} or
#'   the writing of a mobility profile, eliminates exactly the fixed effect
#'   with the most levels and solves for the others by preconditioned
#'   conjugate gradients on the CPU, in at most \code{min(maxiter, 1500)}
#'   iterations. When the requested tolerance is at least \code{1.25e-12},
#'   a column stops once its reduced-system acceptance quantity is at most
#'   \code{1e-12}, confirmed after recomputing the reduced residual. Existing
#'   exits for trivial or compatible systems remain available. Smaller
#'   requested tolerances retain the former stopping criterion. Passing this
#'   fixed stopping target does not replace the independent final precision
#'   certificate. The result is
#'   published only if it passes the precision certificate, including the
#'   requested tolerance, and the unchanged acceptance trigger, with a verified relative residual of
#'   at most \code{1e-11}; otherwise the attempt is discarded and the route
#'   runs from the original data with its own \code{maxiter} budget, as with
#'   the tier off. The attempt also declines (reason \code{"memory"}) when its
#'   working-memory estimate exceeds the larger of 1 GiB and 16 bytes per
#'   observation for each of the outcome, the regressors and the fixed
#'   effects. The \code{reduced_pcg_*} result fields report what happened;
#'   \code{reduced_pcg = FALSE} turns the tier off for a fit, and
#'   \code{XHDFE_REDUCED_PCG=0} for the process. The one exception to the
#'   condition of no CUDA request is the tier's experimental CUDA variant,
#'   off by default (see \code{reduced_pcg_cuda}). \code{xhdfe_demean()}
#'   and the internal fits of the AKM and Gelbach functions never enter it.
#'   The design follows \code{fereg} 0.6.0 (Schmieder 2026); see the
#'   Acknowledgements of \code{\link{xhdfe-package}}.
#' @param symmetric_sweep logical; if \code{TRUE}, use a forward plus a
#'   backward sweep per iteration for the Gauss-Seidel methods (the analogue
#'   of Stata's \code{symmetricsweep}). It can also influence what
#'   \code{absorption_method = "auto"} selects when several fixed effects
#'   are present.
#' @param jacobi_relaxation relaxation parameter of the Jacobi method.
#'   Values less than or equal to 0 select the default \code{2/(J + 1)},
#'   where \code{J} is the number of fixed-effect dimensions; values above 1
#'   are capped at 1.
#' @param fe_tolerance tolerance of the fixed-effect recovery used by
#'   \code{save_fe} (the analogue of Stata's \code{fetolerance()}); default
#'   \code{1e-6}. It is separate from \code{tol} and is only used when the
#'   MAP fallback recovery path runs.
#' @param fe_recovery_method the fixed-effect recovery strategy for
#'   \code{save_fe}: \code{"hybrid"} (default; reuses alphas cached during
#'   absorption when available, usually avoiding a second recovery sweep) or
#'   \code{"map"} (forces recovery sweeps on the partial residual). The
#'   analogue of Stata's \code{ferecoverymethod()}.
#' @param drop_singletons logical; if \code{TRUE} (default), iteratively
#'   drop singleton observations (observations alone in a level of any
#'   absorbed fixed effect) before estimation, exactly as \code{reghdfe}
#'   does. The counts are reported in \code{num_singletons} /
#'   \code{nobs_full}.
#' @param keep_singletons if \code{TRUE}, keep singleton observations (the
#'   analogue of Stata's \code{keepsingletons}); when supplied it takes
#'   precedence over \code{drop_singletons}. \strong{Warning:} keeping
#'   singletons can bias standard errors when fixed effects are nested
#'   within clusters -- see the note referenced by \code{reghdfe} at
#'   \url{http://scorreia.com/reghdfe/nested_within_cluster.pdf}.
#' @param dof degrees-of-freedom adjustment rules for the absorbed fixed
#'   effects (the analogue of Stata's \code{dofadjustments()}). Default
#'   (\code{NULL}) is the full \code{reghdfe} logic (\code{"all"}). Supply a
#'   character vector of case-insensitive tokens; \strong{when supplied,
#'   only the listed tokens are enabled} (reghdfe semantics):
#'   \describe{
#'     \item{\code{"all"}}{full \code{reghdfe} degrees-of-freedom logic
#'       (implies the cluster and continuous adjustments).}
#'     \item{\code{"none"}}{no fixed-effect degrees-of-freedom correction.}
#'     \item{\code{"firstpair"} / \code{"first"}}{account for redundant
#'       (mobility-group) fixed effects between the first pair of absorbed
#'       dimensions only.}
#'     \item{\code{"pairwise"} / \code{"pair"}}{account for redundancy
#'       across all pairs of absorbed dimensions.}
#'     \item{\code{"clusters"} / \code{"cluster"}}{adjust for absorbed fixed
#'       effects nested within cluster variables.}
#'     \item{\code{"continuous"} / \code{"cont"}}{reserved for
#'       \code{reghdfe}'s continuous-interaction checks (currently a
#'       no-op).}
#'   }
#'   Example: \code{dof = c("firstpair", "clusters")}.
#'   For \code{group}/\code{individual} models, \code{dof = "exact"}
#'   (alone) computes the algebraic rank of the combined membership and
#'   ordinary-FE design using checked rational arithmetic. It counts all
#'   absorbed dimensions, including FE nested in clusters. The selected VCE,
#'   weights and other small-sample conventions still apply. The calculation
#'   is bounded to 25 million design elements and finite arithmetic, storage
#'   and operation budgets; a limit raises an error without estimates or an
#'   approximate-rank fallback. The default grouped count is approximate and
#'   emits a warning. A guaranteed shared constant for mean aggregation or
#'   equal-size sum aggregation is removed when an ordinary FE supplies it;
#'   this can change inference relative to earlier releases. Exact FE rank
#'   and solver convergence are separate requirements.
#' @param ssc \pkg{fixest}-style small-sample corrections. Either a named
#'   list with entries among \code{ssc_k_adj} (logical), \code{ssc_k_fixef}
#'   (\code{"full"}, \code{"none"}, \code{"nonnested"}), \code{ssc_k_exact}
#'   (logical), \code{ssc_g_adj} (logical), \code{ssc_g_df} (\code{"min"} or
#'   \code{"conventional"}/\code{"conv"}), and \code{ssc_t_df} (numeric), or
#'   a single Stata-style string such as
#'   \code{"K.adj=1 K.fixef=nonnested G.df=min"} (case-insensitive tokens,
#'   space or comma separated; flag values \code{1}/\code{true}/\code{yes}
#'   or an omitted value mean \code{TRUE}, \code{0}/\code{false}/\code{no}
#'   mean \code{FALSE}; for \code{K.fixef}, \code{true}/\code{yes} map to
#'   \code{"full"} and \code{false}/\code{no} to \code{"none"}). Defaults
#'   follow \code{stats_style}: \code{K.fixef=full} under
#'   \code{stats_style = "reghdfe"} and \code{K.fixef=nonnested} under
#'   \code{stats_style = "legacy"}. Stata's \code{t.df=min} (fix the
#'   residual degrees of freedom at the minimum cluster count minus one) and
#'   \code{t.df=conventional} are expressed in R through \code{ssc_g_df};
#'   in the R interface \code{ssc_t_df} must be numeric and fixes the
#'   residual degrees of freedom at that value.
#' @param stats_style the fit-statistics and small-sample-scaling
#'   convention: \code{"reghdfe"} (default; matches \code{reghdfe}'s RMSE,
#'   adjusted R-squared, and cluster scaling) or \code{"legacy"} (the
#'   pre-change xhdfe statistics). The analogue of Stata's
#'   \code{statstyle()}.
#' @param level the confidence level for the reported intervals, either in
#'   percent (\code{95}, the default) or as a fraction (\code{0.95}). Must
#'   lie in (0, 100).
#' @param threads requested OpenMP threads; \code{0} (default) enables
#'   automatic threading. A positive request bypasses automatic row-count,
#'   FE-shape, and \code{max_threads} heuristics and is clamped only to the
#'   logical processors/OpenMP runtime limit visible to the process. A serial
#'   build fails explicitly for requests above one.
#' @param default_threads default thread count applied when automatic
#'   threading is enabled; \code{0} lets the backend decide (Stata
#'   \code{defaultthreads()}).
#' @param max_threads maximum thread count when automatic threading is
#'   enabled; \code{0} means no explicit cap (Stata \code{maxthreads()}).
#' @param min_parallel_rows minimum number of rows before parallel
#'   absorption is enabled; default \code{20000} (Stata
#'   \code{minparallelrows()}).
#' @param target_rows_per_thread rows per thread used to size the thread pool
#'   under automatic threading (Stata \code{targetrowsperthread()}). The
#'   default \code{0} is automatic: one thread per 25,000 rows when fixed
#'   effects are absorbed with \code{save_fe = FALSE}, within the problem-size
#'   cap (one thread below 100,000 rows, at most 8 below 250,000 and at most 16
#'   otherwise), and one thread per 500,000 rows with \code{save_fe = TRUE} or
#'   without fixed effects. A positive value applies that fixed number of rows
#'   per thread on every path; \code{500000} restores the automatic rule of
#'   version 2.30.1. Setting \code{XHDFE_AUTO_ROWS_PER_THREAD} to a positive
#'   integer before the first fit replaces the 25,000 for the session. On Linux
#'   and macOS the automatic teams of one user's simultaneous fits share the
#'   machine: such a fit takes the smallest of its automatic team, the logical
#'   processors divided by the number of fits running and the processors not
#'   taken by the other fits' absorptions, never fewer threads than
#'   \code{target_rows_per_thread = 500000} would give. A positive
#'   \code{threads} is never reduced. A lowered team reports
#'   \code{thread_limit_code} 6 and \code{thread_limit_reason}
#'   \code{"auto_team_coordination"}. \code{XHDFE_AUTO_TEAM_COORDINATION=0}
#'   before the first fit turns this off.
#' @param backend the compute backend: \code{"default"} (follow the
#'   \code{XHDFE_GPU_BACKEND} environment variable if set, otherwise CPU),
#'   \code{"cpu"} (force the CPU path), \code{"cuda"} (request the CUDA GPU
#'   absorber), or \code{"metal"} (reserved for Metal builds; errors where
#'   unavailable). Requesting \code{"cuda"} or \code{"metal"} is
#'   \emph{fail-closed}: if the GPU is not effectively used the fit stops
#'   with an error, mirroring the Stata plugin's error 498 contract. With
#'   \code{weighted_cpu_route = TRUE}, eligible fits run on the CPU and report
#'   \code{gpu_status_code} 7. See the \emph{GPU backends} section for the rule, the
#'   build recipe and the diagnostics to check.
#' @param na.action \code{"omit"} (default): rows with missing values in any
#'   estimation variable (outcome, regressors, instruments, fixed-effect
#'   ids, slope variables, clusters, weights, group/individual ids) are
#'   dropped before estimation, and full-length outputs (residuals,
#'   prediction caches) are \code{NA} on those rows. \code{"fail"}: raise an
#'   error if any such missing value is present.
#' @param reduced_pcg the reduced-system tier for this fit (see
#'   \code{absorption_method}): \code{TRUE} on, \code{FALSE} off, \code{NULL}
#'   (default) the process default, which is the environment variable
#'   \code{XHDFE_REDUCED_PCG} (read once per process; \code{0} turns the tier
#'   off) and otherwise on. It allows fits with and without the tier in the
#'   same R session. A fit with the tier switched off reports
#'   \code{reduced_pcg_status} 0 and \code{reduced_pcg_reason} \code{"off"},
#'   and gives the results of the tier switched off for the whole process.
#' @param weighted_cpu_route Logical scalar, default \code{FALSE}. With
#'   \code{TRUE}, request CPU for eligible weighted CUDA fits and report
#'   \code{gpu_status_code} 7. See \emph{GPU backends}.
#' @param reduced_pcg_cuda the experimental CUDA variant of the reduced-system
#'   tier for this fit, which acts only on a fit on CUDA (\code{backend =
#'   "cuda"}, or \code{"default"} with \code{XHDFE_GPU_BACKEND=cuda}):
#'   \code{TRUE} requests it, \code{FALSE} does not, \code{NULL} (default) the
#'   process default, which is the environment variable
#'   \code{XHDFE_REDUCED_PCG_CUDA} (read once per process; \code{1} requests
#'   it) and otherwise off. A \code{"reghdfe-comparable"} fit that meets the
#'   tier's other conditions and uses no mobility profile, absorption cache or
#'   FE-structure cache then attempts the tier with the products of the
#'   reduced system computed on the GPU; the recurrence, the stopping rule,
#'   the acceptance trigger and the certificate are the tier's, computed on
#'   the CPU. A published fit reports \code{absorption_method_code} 8,
#'   \code{reduced_pcg_status} 1, \code{gpu_used} 1 and \code{gpu_status}
#'   \code{"used"}; requesting CUDA alone does not prove entry, so check all of
#'   them. A declined attempt runs the CUDA route that the fit takes without
#'   the request. With the request, a fit kept out by a mobility profile or a
#'   cache reports \code{reduced_pcg_reason} \code{"mobility_profile"},
#'   \code{"absorption_cache"} or \code{"fe_structure_cache"} (the first that
#'   applies, in that order) instead of \code{"gpu"} and runs that same route.
#'   A file \code{xhdfe_mobility_profile.txt} in the working directory is a
#'   mobility profile. An attempt that cannot obtain device memory, or cannot
#'   page-lock the rows it exchanges with the GPU, declines with
#'   \code{reduced_pcg_reason} \code{"memory"} or \code{"pinned"} and runs that
#'   same route. Where that confirmed stopping rule is in force (a requested
#'   tolerance of at least \code{1.25e-12} and
#'   \code{XHDFE_REDUCED_PCG_CHAT_STOP} not \code{0}), the product used to
#'   recompute the reduced residual is computed on the GPU as well; the
#'   stopping decisions stay on the CPU.
#'   \code{XHDFE_REDUCED_PCG_CUDA_REPLACEMENT=0}, set in the environment
#'   before the first fit (read once per process), keeps that product on the
#'   CPU. The acceptance trigger and the certificate, computed on the CPU, are
#'   unchanged. \code{reduced_pcg = FALSE} keeps
#'   both the tier and its CUDA variant off; on the CPU the argument has no
#'   effect.
#' @param reduced_pcg_apply_fine the finer blocks of the segment pass of the
#'   reduced-system tier's operator for this fit, where the tier's kernel for
#'   that pass runs (builds compiled with GCC; an absorbed effect whose rows of
#'   the reduced system take at least 2 MiB): an integer from 1 to 8 asks for
#'   that factor, which is then halved while the private sums of the small
#'   effects would take more than 4 MiB and kept only if its extra bytes fit the
#'   attempt's memory budget; \code{1} keeps the blocks of 2.34.2;
#'   \code{"auto"} starts from 8 and halves the factor while the cells of the
#'   operator's segments per finer block stay below 16 384, then applies the
#'   same rules (a rule of the data only, never of the threads); \code{NULL}
#'   (default) the process value, the environment variable
#'   \code{XHDFE_REDUCED_PCG_APPLY_FINE} (read once per process; \code{auto} or
#'   an integer from 0 to 8, 0 read as 1) and otherwise the built-in value,
#'   \code{1}. A factor above 1 changes the last bits of the fits the kernel
#'   takes, within the precision contract. When an attempt that took finer
#'   blocks declines because an allocation failed, the tier repeats it once on
#'   the coarse blocks and publishes that second result, and the fit writes no
#'   absorption-cache entry. The \code{reduced_pcg_fine_*} result fields report
#'   what happened.
#' @param slope_solver optional reduced solver for eligible unweighted OLS
#'   with two ordinary fixed effects and two slope dimensions on the same
#'   identifiers, at least one with an intercept. \code{"schur"} selects the
#'   diagonal preconditioner (CPU and CUDA); \code{"network"} selects the
#'   forest preconditioner and \code{"direct"} the sparse direct solve (CPU).
#'   Enable the reduced-system tier and use automatic absorption and convergence
#'   in Comparable mode without saved effects or a saved group variable. Turn off
#'   the absorption cache, FE-structure cache and mobility profile for these fits.
#'   CUDA also requires \code{reduced_pcg_cuda = TRUE} or its environment default.
#'   \code{"off"} disables the solver and both
#'   helpers. \code{NULL} follows the per-fit environment switches
#'   \code{XHDFE_EXPERIMENT_SLOPE_DIRECT},
#'   \code{XHDFE_EXPERIMENT_SLOPE_NETWORK}, \code{XHDFE_EXPERIMENT_SLOPE_SCHUR}
#'   in that order, each with value \code{1}, otherwise off.
#' @param slope_scores optional logical for eligible two-way cluster score
#'   reuse, when the partitions match the ordinary effects. \code{NULL}
#'   enables it with an explicit solver mode, or follows
#'   \code{XHDFE_EXPERIMENT_NETWORK_SCORES=1} for an environment solver request.
#' @param slope_csr_owner optional logical for parallel sparse assembly.
#'   \code{NULL} enables it with an explicit solver mode, or follows
#'   \code{XHDFE_EXPERIMENT_NETWORK_CSR_OWNER=1} for an environment solver request.
#'
#' @section Absorbing fixed effects:
#' The second formula part lists the fixed effects to absorb; each term is
#' equivalent to including one dummy per category, without ever building the
#' dummies. The grammar (fixest-compatible) and its Stata
#' \code{absorb()} equivalents:
#'
#' \tabular{lll}{
#'   \strong{R term} \tab \strong{Stata absorb()} \tab \strong{Meaning} \cr
#'   \code{fe} \tab \code{fe} \tab absorbed intercepts (one per level) \cr
#'   \code{f1^f2} \tab \code{f1#f2} \tab combined (interaction) fixed
#'     effect \cr
#'   \code{fe[x]} \tab \code{fe##c.x} \tab absorbed intercepts plus
#'     group-specific slopes on \code{x} \cr
#'   \code{fe[[x]]} \tab \code{fe#c.x} \tab group-specific slopes only \cr
#'   \code{fe[x1, x2]} \tab \code{fe##c.x1 fe#c.x2} \tab several slopes on
#'     one carrier \cr
#' }
#'
#' Notes:
#' \itemize{
#'   \item \emph{Categorical interactions.} \code{f1^f2} builds the joint
#'     fixed effect of the two id variables. Like \code{reghdfe} -- which
#'     canonicalizes a categorical-only \code{f1##f2} to the same joint
#'     fixed effect as \code{f1#f2} -- it is \emph{not} expanded into main
#'     effects plus interaction; write \code{f1 + f2 + f1^f2} explicitly if
#'     all three dimensions are intended.
#'   \item \emph{Heterogeneous slopes.} Slope variables must be numeric and
#'     of full data length. The core absorbs at most one slope per carrier
#'     dimension; multiple slopes on the same ids (\code{fe[x1, x2]}) are
#'     handled internally by duplicating the carrier dimension -- one
#'     absorbed dimension per slope variable, with the intercept (if
#'     requested) riding on the first -- exactly like Stata expands
#'     \code{absorb(fe##c.x1 fe#c.x2)}.
#'   \item \emph{Optional reduced slope solver.}
#'     \code{slope_solver = "schur"} requests the reduced equation solver for
#'     eligible fits. See \code{slope_solver} for mode precedence and the
#'     two assembly and inference controls. Accepted fits report method 9 and
#'     pass the slope certificate; the diagnostics also describe a declined
#'     attempt or an ineligible request.
#'   \item \emph{Id encoding.} Integer id vectors are passed to the core
#'     verbatim (level handling is the core's job); factors use their level
#'     codes; character, logical, and non-integral numeric vectors are
#'     encoded by first appearance. The same rules apply to cluster,
#'     group, and individual ids.
#'   \item \emph{Restrictions.} Heterogeneous slopes are not supported with
#'     \code{group}/\code{individual} or with the LSMR-family absorption
#'     methods (\code{"lsmr"}, \code{"mlsmr"}, \code{"auto-mlsmr"}).
#'   \item \emph{Extreme scaling.} Finite inputs can still overflow their FP64
#'     cross-products when a design is scaled extremely (roughly
#'     \code{abs(X) >= 1e153}). The fit then fails explicitly rather than
#'     treating every slope as collinear; rescale the outcome and/or
#'     regressors.
#' }
#'
#' @section Tolerance modes:
#' The nominal tolerance \code{tol} only has a precise meaning together with
#' \code{tolerance_mode}. Under the default \code{"reghdfe-comparable"} mode
#' (the default since 2.7.0) the absorber stops when one full sweep moves
#' the working data by less than \code{tol} in relative norm -- the same
#' meaning \code{reghdfe} attaches to its tolerance -- so coefficients match
#' \code{reghdfe} at the same nominal tolerance, down to problem
#' conditioning. \code{"xhdfe-fast"} restores the pre-2.7.0 stopping rule:
#' typically about 1.5-3x fewer absorber iterations, but its effective
#' precision is data-dependent and can be looser than the nominal tolerance
#' on ill-conditioned (e.g. sparse bipartite) designs; it is appropriate for
#' exploration and speed benchmarking, and any published timing should state
#' the mode used. Combined group/individual CUDA fits nevertheless use an
#' internal \code{min(tol, 1e-12)} floor before certification, so fast mode
#' cannot re-enable a materially inaccurate early GS stop.
#' \code{"strict-residual"} is a heavier audit mode that
#' treats a final absolute check as authoritative, may use extra iterations
#' up to \code{maxiter}, and reports non-convergence when the check is not
#' met; it is not supported with heterogeneous slopes. On CUDA with the
#' automatic method and criterion, without weights, \code{save_fe} or
#' \code{group}, the check is the largest absolute group mean of the
#' delivered residuals in the units of the dependent variable (see
#' \code{tolerance_mode}).
#'
#' New in 2.11.0: under the default mode, absorption on ill-conditioned,
#' poorly connected multiway fixed-effect graphs is transparently handed off
#' to a stable per-column conjugate-gradient solver on the symmetric
#' demeaning operator, on CPU and CUDA alike. Results on well-conditioned
#' problems are numerically identical to prior versions; on pathological
#' graphs the handoff can cut runtime by an order of magnitude at equal or
#' better precision.
#'
#' The mode used is recorded in the \code{tolerance_mode} field of the
#' result (Stata \code{e(tolerance_mode)}).
#'
#' @section GPU backends:
#' \code{backend = "cuda"} requests the CUDA absorber. It requires a package
#' build with CUDA support, e.g.
#' \preformatted{XHDFE_ENABLE_CUDA=ON XHDFE_CUDA_ARCH=90 R CMD INSTALL xhdfe}
#' where \code{XHDFE_CUDA_ARCH} selects a single target compute capability
#' (default 90, e.g. an NVIDIA H100; the backend requires compute capability
#' 7.5 or newer and the NVCC compiler). The equivalent Stata plugin build is
#' \code{XHDFE_ENABLE_CUDA=ON XHDFE_CUDA_ARCH=90 bash
#' stata/tools/build-plugin.sh --linux --openmp}.
#'
#' \strong{Fail-closed contract.} Requesting \code{"cuda"} (or
#' \code{"metal"}) never silently falls back to the CPU: if the backend is
#' unavailable, fails, does not converge on the GPU, or a CPU cache/profile
#' result would be returned, the fit stops with an error -- mirroring the
#' Stata command, which exits with error 498 in the same situations. The one
#' exception is reported: see \strong{Weighted fits on CUDA} below.
#' After a successful GPU fit, validate real GPU use through the
#' diagnostics on the result object: \code{gpu_used} must be \code{1} and
#' \code{gpu_status} must be \code{"used"} (Stata: \code{e(gpu_used)==1},
#' \code{e(gpu_backend)=="cuda"}, \code{e(gpu_status)=="used"}). The status
#' taxonomy (\code{gpu_status_code} / \code{gpu_status}) is:
#'
#' \strong{Certification boundary.} A GPU-use diagnostic proves execution,
#' not universal numerical equivalence. Validation identifies the tested data,
#' specifications and exact artifacts. A failed convergence or precision check
#' raises an informative error and returns no estimates. Explicit CUDA requests
#' do not substitute CPU estimates for a device result, except the reported
#' weighted CPU route below (\code{gpu_status_code} 7), and Metal requests are rejected until that
#' backend is implemented. Poor conditioning can amplify a small residual;
#' no fixed tolerance guarantees arbitrary coefficient accuracy on every model.
#'
#' Small group/individual designs (at most 1500 FE columns and two million
#' cells after merging identical incidence rows) are projected by a dense
#' column-pivoted QR with iterative refinement, exact to rounding, in every
#' tolerance mode; directions whose relative pivot is below 1e-10 are
#' either exact redundancies (dropped) or, when the exact rational rank of
#' the incidence design exceeds the numerical rank, FP64-ambiguous: such a
#' fit is refused only when the fitted residual depends on the unresolved
#' direction (FE-space forward certificate), never for data that do not.
#' Larger designs use the Krylov solver, whose dual stopping test is accepted
#' only when the running condition estimate times the dual residual meets
#' the public forward target (100 times the mode's dual tolerance, at least
#' 1e-8); in reghdfe-comparable and strict-residual modes a residual
#' refinement then removes nearly null incidence directions, applied to all
#' right-hand sides or to none and only after the primary solution passes
#' the per-column certificate, so 2.26.2 results are the floor and xhdfe-fast
#' keeps its 2.26.2 stopping rule. The shared OLS stage uses
#' additional arithmetic precision only when the FP64 rank decision is not
#' separated from its threshold. Large level offsets alone do not justify
#' omitting a regressor with within variation: the collinearity rule compares
#' the within variation with the centered scale of the column whenever the
#' model contains a constant. Heavy sufficient certificates (FE-space forward
#' bound, exact redundancy proofs, per-row N1 evidence) run only under
#' \code{XHDFE_CERTIFY=1}.
#'
#' Version 2.30.1 corrects an inherited CUDA Comparable covariance error for
#' ordinary models with three fixed effects, no weights and no saved effects.
#' The remaining projection is completed at the existing target within the
#' total iteration budget. GPU repair counters include all attempted work;
#' old absorption caches are invalidated automatically. The release record
#' documents the accepted runtime cost relative to 2.29.1. Fast retains its
#' separate approximation contract.
#'
#' \strong{Weighted fits on CUDA.} With \code{weighted_cpu_route = TRUE},
#' a fit with weights (any type, all ones
#' and zero weights included) and two or more absorbed effect dimensions in
#' \code{reghdfe-comparable} or \code{strict-residual}, whose effective
#' backend is CUDA (\code{backend = "cuda"}, \code{XHDFE_GPU_BACKEND=cuda},
#' or a build whose default backend is CUDA), is absorbed on the CPU and says
#' so: \code{gpu_used} 0 and \code{gpu_status_code} 7
#' (\code{"weighted_cpu_route"}). \code{xhdfe_demean()} keeps its CUDA
#' partial-out route with weights. \code{backend_requested} stays \code{"default"} for a request made by the
#' environment. On CUDA such fits could pass the certificate and still lie
#' outside the comparable contract against reghdfe at tolerance 1e-12
#' (coefficients up to 4.5e-7 and standard errors up to 2.8e-5 relative on a
#' public fixture). The dimensions are counted as the fit receives them,
#' before redundant ones are removed. A weighted fit with \code{group} and
#' without \code{individual} is the collapsed weighted fit and is routed too;
#' its CPU fit runs, as before, without the routing retry and without the
#' saved-effects projection (the \code{group} entry turns both off). With
#' \code{individual} a fit keeps the GPU route and was not measured against
#' the contract on CUDA; \code{xhdfe-fast}, unweighted fits and fits with one
#' absorbed effect keep the GPU route. A routed fit takes the time of the CPU
#' backend. Its results other than the GPU status code are bit for bit those
#' of the same fit with \code{backend = "cpu"}, with the same package build,
#' threads and initial cache and profile state, wherever that CPU fit repeats
#' itself (an automatic fit that benchmarks methods by time while writing a
#' mobility profile from empty does not); the identity is stated for builds
#' whose default backend is the CPU (all released ones). In the ordinary
#' weighted Auto CPU path, the published Comparable projection may use
#' the ordinary selector with four effects and \code{save_fe}, or for
#' just-identified IV with three effects. For ordinary weighted CPU fits with
#' three fixed effects and without saved effects, explicit
#' \code{absorption_method = "gauss-seidel"} checks the fixed-effect moments
#' and may apply one block correction. A routed \code{strict-residual} fit
#' is the CPU's strict fit. An explicit \code{absorption_method = "schwarz"}
#' with weights gets the CPU's answer, which for an ordinary fit is a refusal.
#' A routed fit is the CPU fit also for the optional absorption cache and
#' mobility profile, so in a session that writes profiles a later fit may read
#' what a routed fit wrote, as it reads what a CPU fit wrote.
#' \code{weighted_cpu_route = FALSE} selects the ordinary device route for
#' a fit that requests CUDA.
#'
#' \strong{Known limitations.}
#' With \code{retain_fes = TRUE} in Comparable mode, a fit can publish a
#' separate certified within projection and recover the effects afterwards.
#' Its outcome reconstruction is then limited by FE recovery accuracy.
#' Explicit methods, IV, heterogeneous slopes and grouped fits can publish
#' the effect-capturing sweep, whose accuracy is design-dependent.
#' Ordinary CUDA fits with two to four weighted
#' categorical effects or four unweighted effects check the fixed-effect moments.
#' A measured failure can trigger one device LSMR projection within the budget.
#' For analytic, probability and importance weights, the Comparable
#' correction covers up to 2,000,000 estimation rows.
#' On CUDA, residuals have the accuracy of the CUDA fit. On Windows,
#' near-perfect additive-cell fixtures returned exact coefficients and
#' certified fits with relative covariance errors of 2.65e-9, 1.74e-4 and
#' 1.82e+2 at relative residual noise of 2^-12, 2^-20 and 2^-30 (2.2e-16 on
#' Linux): the exact additive-cell projection needs extended precision, which
#' Windows hosts run at 53 bits.
#' A fit that converges by the solver's rule but
#' does not pass the precision certificate returns no estimates in R, Python
#' and Stata alike. Ill-conditioned specifications can still require a refusal.
#' In \code{reghdfe-comparable}, heterogeneous slopes under an explicit
#' \code{convergence = "reghdfe"} can require continuation at tighter internal
#' tolerances, returning the first certified stage. The default \code{"auto"}
#' checks the slope block; \code{xhdfe-fast} keeps its aggregate certificate
#' without the Comparable block continuation. \code{aggregation = "sum"} without an ordinary
#' absorbed fixed effect spans the constant only for a uniform team size or
#' through a data-dependent combination of individual columns, decided by
#' projecting the ones vector on the absorbed effects as one separate
#' right-hand side; when it is not spanned
#' the fit has no intercept and is reported as one (\code{model_has_constant}
#' is \code{FALSE}, no \code{(Intercept)} entry, uncentered total sum of
#' squares), with coefficients, RSS and residuals unchanged. CUDA with small, ill-conditioned group/individual
#' designs can leave residuals at the 1e-6 relative level where the CPU
#' direct projection is exact; on designs small enough for that projection the
#' device result is compared with it and refused with an informative error when
#' a retained column deviates by more than ten times the forward tolerance of
#' the mode; use the CPU backend for such designs. CUDA with
#' \code{tolerance_mode = "reghdfe-comparable"} on ill-conditioned ordinary
#' designs also checks original-regressor normal equations for unweighted OLS
#' without saved effects. A failed check receives one continuation with the same
#' method and tolerance, within the remaining iteration budget. A persistent
#' failure returns no estimates and does not substitute CPU estimates. This
#' check admits the directors and difficult 10M-row 3-FE benchmark fits covered
#' by the 2.29.0 CUDA validation, with bounded corrections. Other ill-conditioned
#' specifications can still require a refusal. The opt-in accuracy-retry settings
#' cannot bypass this necessary check. The
#' individual block subtracts one exact redundancy against an ordinary fixed
#' effect whenever the constant is provably in the span of the membership
#' columns (mean aggregation, or sum with a uniform team size);
#' \code{dofadjustments = "exact"} computes the exact rank.
#'
#' \tabular{lll}{
#'   \strong{Code} \tab \strong{Label} \tab \strong{Meaning} \cr
#'   0 \tab \code{not_requested} \tab GPU not requested \cr
#'   1 \tab \code{used} \tab GPU backend effectively used \cr
#'   2 \tab \code{backend_unavailable} \tab requested backend unavailable \cr
#'   3 \tab \code{gpu_absorption_not_converged} \tab GPU absorption did not
#'     converge \cr
#'   4 \tab \code{gpu_backend_failed} \tab GPU backend failed \cr
#'   5 \tab \code{cpu_cache_or_profile_result} \tab a CPU cache/profile
#'     result was produced \cr
#'   7 \tab \code{weighted_cpu_route} \tab weighted fit with two or more
#'     absorbed effects run on the CPU by design \cr
#' }
#'
#' As an alternative to the \code{backend} argument, the environment
#' variable \code{XHDFE_GPU_BACKEND} (\code{cpu}|\code{cuda}|\code{metal})
#' selects the backend; the \code{backend} argument temporarily sets that
#' variable around the fit and is the recommended interface.
#' \code{backend = "cpu"} forces the CPU path even when the environment
#' variable is set. \code{"metal"} is reserved for Metal builds and errors
#' where unavailable. CPU behavior is the reference implementation. The joint
#' group/individual LSMR route is CPU-only; CUDA \code{"auto"} retains the
#' existing GPU solver and now requires the authoritative certificate, while
#' explicit LSMR with CUDA is rejected.
#'
#' @section Group-level outcomes with individual fixed effects:
#' \code{xhdfe()} supports individual fixed effects with group-level
#' outcomes (e.g. patent-level citations with inventor fixed effects). The
#' data must be in long format where the group and individual ids together
#' uniquely identify observations (the Stata help's
#' \code{isid patent_id inventor_id} requirement). The combining rules are:
#' \enumerate{
#'   \item no fixed effects, no \code{group}, no \code{individual}:
#'     ordinary least squares with a constant;
#'   \item only absorbed fixed effects: standard fixed-effects regression;
#'   \item \code{group} without \code{individual}: the same as (1)/(2) run
#'     on one observation per group (the data are collapsed to a
#'     representative row per group);
#'   \item \code{group} and \code{individual} (plus, optionally, absorbed
#'     fixed effects): a group-level fixed-effects regression in which each
#'     group's outcome loads on the \code{aggregation} (mean or sum) of its
#'     individuals' fixed-effect components.
#' }
#' The individual dimension is appended (last) to the absorbed dimensions
#' for stability if not already present, exactly as in Stata. In
#' grouped modes the core estimates on one representative row per group:
#' \code{sample} identifies those rows in the original input, residuals and
#' predictions are aligned to the input with \code{NA} outside that sample,
#' and \code{grouped_fit} is \code{TRUE}. \strong{Note:} singleton bookkeeping
#' happens \emph{after} the representative-row construction, so
#' \code{num_singletons} can differ from \code{reghdfe}'s pre-collapse row
#' count even when the effective estimation sample is identical.
#'
#' On CPU, \code{absorption_method = "auto"} uses joint matrix-free LSMR
#' for the standard and individual dimensions; explicit \code{"lsmr"} selects
#' the same CPU route. The independent certificate remains mandatory after
#' any bounded refinement or tighter retry; the original final tolerance,
#' iteration budget and requested backend are preserved. Failure raises an
#' informative error without new estimates. CUDA \code{"auto"} keeps the existing
#' group/individual GPU solver and accepts it only after the authoritative
#' certificate passes. Explicit \code{"gauss-seidel"} and
#' \code{"symmetric-gauss-seidel"} remain supported; \code{"jacobi"},
#' \code{"schwarz"}, \code{"mlsmr"}, and \code{"auto-mlsmr"} are not.
#'
#' IV/2SLS, heterogeneous slopes, and (with both \code{group} and
#' \code{individual}) \code{save_fe} are not supported in group mode.
#'
#' Membership columns span a constant under \code{aggregation = "mean"}
#' and under \code{"sum"} with equal group sizes. Unequal-size sum
#' aggregation need not span a constant. If the intended model requires one,
#' include an ordinary FE, for example a variable \code{c} equal to one in
#' \code{y ~ x | c + inventor}. A reported intercept alone does not add that
#' missing direction to the grouped model. There is one residual per retained
#' group, on its selected input row; other group members have \code{NA}.
#'
#' @section Missing features and restrictions:
#' \itemize{
#'   \item Heterogeneous slopes are not supported together with
#'     \code{group}/\code{individual}, nor with the LSMR-family absorption
#'     methods on standard FE designs.
#'   \item \code{save_fe} is not supported when both \code{group} and
#'     \code{individual} are specified.
#'   \item IV/2SLS is not supported in \code{group} mode.
#'   \item \code{tolerance_mode = "strict-residual"} is not supported with
#'     heterogeneous slopes (an error is raised before estimation).
#'   \item Explicit LSMR-family absorption requests are CPU-only and do not
#'     support \code{save_fe}; only plain LSMR is supported for combined
#'     \code{group}/\code{individual} fits.
#'   \item No HAC or Driscoll-Kraay standard errors (see \code{ivreghdfe}
#'     in the \code{reghdfe} ecosystem).
#' }
#'
#' With IV/2SLS and absorbed fixed effects, the reported
#' \code{"(Intercept)"} is the normalization
#' \eqn{\bar y-\bar x^\prime\hat\beta}, with zero-mean absorbed
#' contributions. It is finite and internally consistent, but remains
#' normalization-dependent and must not be interpreted as a structural IV
#' parameter.
#'
#' With absorbed fixed effects the \code{"(Intercept)"} is the constant
#' recovered by the FE normalisation, \eqn{\bar y-\bar x^\prime\hat\beta}.
#' When a one-way cluster nests an absorbed intercept dimension (every
#' cluster is a union of its levels; \code{fe[x]} keeps the levels,
#' \code{fe[[x]]} has none), the cluster sums of the residuals are exactly
#' zero and the intercept's row and column of the covariance matrix are
#' exactly \eqn{\bar x^\prime V\bar x} and \eqn{-V\bar x}, with \eqn{V} the
#' slope block; this applies on every absorption route and backend, but not
#' with \code{tolerance_mode = "xhdfe-fast"} or instruments. That variance is
#' zero when \eqn{\bar x = 0} or there are no regressors: the intercept's
#' standard error is then zero and its t statistic, p-value and confidence
#' interval are missing. This does not mean a structural parameter known
#' without uncertainty; the constant is a normalisation of the absorbed
#' effects. Saturated designs and fewer than two clusters keep their
#' missing-inference convention.
#'
#' @section Environment variables:
#' The C++ core reads the following runtime knobs:
#' \describe{
#'   \item{\code{XHDFE_GPU_BACKEND}}{backend request
#'     (\code{cpu}|\code{cuda}|\code{metal}) when \code{backend = "default"}.
#'     An explicit \code{backend} argument overrides it for that fit through
#'     a scoped native selection.}
#'   \item{\code{XHDFE_AUTO_MLSMR_DEFAULT_MAX_FES}}{raises the default cap
#'     (3) on the number of fixed-effect dimensions eligible for the
#'     probe-based auto-MLSMR selector under
#'     \code{absorption_method = "auto"}.}
#'   \item{\code{XHDFE_MLSMR_AUTO_GATE}}{set to \code{0} to disable MLSMR
#'     promotions by the automatic gate entirely.}
#'   \item{\code{XHDFE_REDUCED_PCG}}{the process default of the
#'     reduced-system tier (see \code{absorption_method}): \code{0}, set before
#'     the first fit of the R session, turns it off for every fit that leaves
#'     \code{reduced_pcg = NULL}; it is read once per process. The argument
#'     \code{reduced_pcg} overrides it fit by fit. While the tier is on for a
#'     fit, absorption-cache entries written with it off or by an earlier
#'     version are not read, and while it is off, entries written with it on
#'     are not read.}
#'   \item{\code{XHDFE_REDUCED_PCG_CUDA}}{the process default of the
#'     experimental CUDA variant of the tier (see \code{reduced_pcg_cuda}):
#'     \code{1}, set before the first fit of the R session, requests it for
#'     every CUDA fit that leaves \code{reduced_pcg_cuda = NULL}; it is read
#'     once per process. The argument \code{reduced_pcg_cuda} overrides it fit
#'     by fit.}
#'   \item{\code{XHDFE_REDUCED_PCG_TRACE}}{\code{1} writes the tier's plan and
#'     decision to stderr; \code{2} adds the verified residual of each column
#'     of a published fit.}
#'   \item{\code{XHDFE_REDUCED_PCG_CHAT_STOP}}{\code{0}, set before the
#'     first fit of the R session, restores the tier's former
#'     stopping criterion. It is read once per process and
#'     changes neither the acceptance trigger nor the certificate. If the
#'     confirmed target is not reached, the attempt declines to the unchanged
#'     route. Requested tolerances below \code{1.25e-12} retain the former
#'     rule with either setting.}
#'   \item{\code{XHDFE_MOBILITY_PROFILE}, \code{XHDFE_MOBILITY_MODE}}{path
#'     and mode (\code{off}|\code{read}|\code{write}|\code{auto}) of the
#'     mobility-diagnostics profile -- the R route to the Stata
#'     \code{mobilityprofile}/\code{mobfile()} options. Version-2 profiles
#'     distinguish ordinary from group/individual fits. Group/individual
#'     profiles require both domain-separated structural signatures to match;
#'     standard profiles retain their FE-signature contract. Legacy version-1 files and
#'     mismatched profiles are safe misses. In group/individual Auto, profiles
#'     cannot promote Gauss--Seidel or symmetric Gauss--Seidel: CPU retains
#'     joint LSMR and CUDA retains the grouped GPU solver. Profile write/auto
#'     does not benchmark sweep methods. A profile is written only after the
#'     requested route certifies; it suggests LSMR only after safe CPU LSMR and
#'     otherwise records Auto. Writing a profile (mode \code{write}, or
#'     \code{auto} without a matching profile) keeps the fit out of the
#'     reduced-system tier, as does a matching profile that suggests a
#'     Krylov or sparse solver. The group/individual gate uses
#'     the preconditioned operator \eqn{A=W^{1/2}DC}, weighted residuals,
#'     moments \eqn{CD'Wr}, and active normalized columns. Every right-hand
#'     side must pass either the consistent-system residual ratio or the
#'     least-squares optimality ratio.}
#'   \item{\code{XHDFE_ABSORPTION_CACHE},
#'     \code{XHDFE_ABSORPTION_CACHE_MODE}}{path and mode of the absorption
#'     cache that stores transformed outcome/regressors for reuse across
#'     identical specifications (Stata \code{absorptioncache()} /
#'     \code{absorptioncachemode()}). Both cache types accept \code{off},
#'     \code{read}, \code{write}, and \code{auto}. Mode \code{read} leaves
#'     the file untouched. Mode \code{auto} can refresh an invalid entry.}
#'   \item{\code{XHDFE_FE_STRUCTURE_CACHE},
#'     \code{XHDFE_FE_STRUCTURE_MODE}}{path and mode of the fixed-effect
#'     structure cache (normalized group ids and singleton filters) reused
#'     across runs with the same absorb structure (Stata
#'     \code{festructurecache}/\code{fescache()}/\code{fescachemode()}).
#'     Use separate files when combining the caches. Use \code{auto} or
#'     \code{write} to refresh older combined absorption entries.}
#'   \item{\code{XHDFE_FE_DIAG_FILE}}{appends per-run fixed-effect
#'     diagnostics (partial-residual statistics, fixed-effect totals,
#'     residual consistency, recovery method) to the given file.}
#'   \item{\code{XHDFE_PROFILE_SAVEFE}}{nonzero enables fixed-effect
#'     recovery timing traces on stderr (partial-residual construction,
#'     cached-hybrid reconstruction and checks, MAP-fallback stages);
#'     disabled by default with no output or behavior change when unset.}
#'   \item{\code{XHDFE_PROFILE_CPU}}{nonzero enables CPU-stage timing traces
#'     on stderr. Some reduced-system routes are ineligible with profiling on.}
#'   \item{\code{XHDFE_FE_NORMALIZE}}{normalization style of recovered
#'     fixed-effect contributions: \code{component} (default; per-component
#'     normalization) or \code{reghdfe} (aliases \code{mean},
#'     \code{mean_only}; reghdfe-style mean-only normalization).}
#' }
#'
#' @section Warnings and notes:
#' \itemize{
#'   \item \emph{Saturated designs.} If the absorbed model fits the data
#'     perfectly (zero residual degrees of freedom), a note is emitted,
#'     \code{saturated} is set to 1, adjusted R-squared statistics are
#'     forced to 1, and standard errors are not identified. The reported
#'     coefficients are still the exact within-OLS solution.
#'   \item \emph{Multiway-cluster PSD adjustment.} If the multiway-cluster
#'     variance matrix requires the Cameron-Gelbach-Miller
#'     positive-semi-definite adjustment, a warning is printed (matching
#'     \code{reghdfe}) and \code{vcv_psd_fixed} is 1.
#'   \item \emph{Singletons.} \code{keep_singletons = TRUE} can bias
#'     inference when fixed effects are nested within clusters; see
#'     \url{http://scorreia.com/reghdfe/nested_within_cluster.pdf}.
#'   \item \emph{Group-mode singleton bookkeeping.} In
#'     \code{group}/\code{individual} mode the singleton counts are computed
#'     after the representative-row construction and can differ from
#'     \code{reghdfe}'s pre-collapse counts.
#'   \item \emph{Combined fixed effects.} \code{f1^f2} (like
#'     \code{reghdfe}'s canonicalized categorical \code{##}) creates only
#'     the joint fixed effect; list \code{f1 + f2 + f1^f2} for main effects
#'     plus interaction.
#'   \item \emph{Recovered fixed effects are contributions}, not group ids,
#'     and may not be separately identified in all designs.
#'   \item \emph{Non-convergence.} An exhausted iteration budget or failed
#'     numerical certificate raises an informative error without new estimates.
#' }
#'
#' @return An object of class \code{"xhdfe"}: a list whose fields are the R
#' analogue of Stata's stored results (the corresponding \code{e()} names
#' are given where applicable).
#'
#' \strong{Coefficients and inference}
#' \describe{
#'   \item{\code{coefficients}}{named numeric vector of point estimates
#'     (\code{e(b)}). With absorbed fixed effects a reghdfe-compatible
#'     \code{"(Intercept)"} is appended after the regressors; IV
#'     coefficients follow the exogenous ones.}
#'   \item{\code{se}, \code{tvalues}, \code{pvalues}}{standard errors,
#'     t-statistics, and p-values aligned with \code{coefficients}
#'     (from \code{e(V)} and \code{e(df_r)}).}
#'   \item{\code{conf_int}}{two-column matrix of confidence bounds at
#'     \code{level} (columns labelled e.g. \code{"2.5 \%"} and
#'     \code{"97.5 \%"}).}
#'   \item{\code{vcov}}{variance-covariance matrix of the estimates
#'     (\code{e(V)}).}
#'   \item{\code{omitted}}{named integer codes per coefficient
#'     (\code{e(omit_reason)}): 0 kept, 1 collinear with the absorbed fixed
#'     effects, 2 other collinearity.}
#'   \item{\code{se_type}}{\code{"unadjusted"}, \code{"robust"}, or
#'     \code{"cluster"} (cf. \code{e(vce)}).}
#'   \item{\code{level}}{confidence level in percent.}
#' }
#'
#' \strong{Sample and observation counts}
#' \describe{
#'   \item{\code{residuals}}{full-length residual vector (\code{n_input}
#'     entries) with \code{NA} on rows outside the estimation sample; in
#'     grouped fits the residuals are at the group level instead.}
#'   \item{\code{sample}}{integer indices of the input rows used in
#'     estimation, after \code{subset}, missing-value filtering, and
#'     singleton dropping -- the analogue of \code{e(sample)}. Empty in
#'     grouped fits.}
#'   \item{\code{nobs}}{number of observations used (\code{e(N)}).}
#'   \item{\code{nobs_full}}{observations before singleton dropping
#'     (\code{e(N_full)}).}
#'   \item{\code{num_singletons}}{singleton observations dropped
#'     (\code{e(num_singletons)}).}
#'   \item{\code{nobs_effective}, \code{nobs_full_effective},
#'     \code{num_singletons_effective}}{frequency-weight effective counts:
#'     with \code{weights_type = "frequency"} these are sums of weights
#'     (replicated-rows semantics); otherwise they equal the row counts.}
#'   \item{\code{sumweights}}{sum of weights, or \code{nobs} if unweighted
#'     (\code{e(sumweights)}).}
#'   \item{\code{n_input}}{number of rows of the input data before any
#'     filtering.}
#'   \item{\code{grouped_fit}}{\code{TRUE} for \code{group}/
#'     \code{individual} collapsed fits.}
#' }
#'
#' \strong{Degrees of freedom}
#' \describe{
#'   \item{\code{df_r}}{residual degrees of freedom after small-sample
#'     corrections, used for t-statistics, p-values, and confidence
#'     intervals (\code{e(df_r)}).}
#'   \item{\code{df_r_unadj}}{unadjusted residual degrees of freedom,
#'     N - k - df_a (\code{e(df_r_unadj)}).}
#'   \item{\code{df_m}}{model degrees of freedom (\code{e(df_m)}).}
#'   \item{\code{rank}}{effective model rank, omitted coefficients excluded
#'     (\code{e(rank)}).}
#'   \item{\code{df_a}}{absorbed degrees of freedom under the selected
#'     convention (\code{e(df_a)}); inspect \code{fe_inexact} for approximate counts.}
#'   \item{\code{df_a_levels}}{absorbed levels (\code{e(df_a_levels)}).}
#'   \item{\code{df_a_exact}}{absorbed levels adjusted for collinearity
#'     (\code{e(df_a_exact)}).}
#'   \item{\code{df_a_nested}}{absorbed levels nested within clusters, if
#'     any (\code{e(df_a_nested)}).}
#'   \item{\code{df_a_initial}}{absorbed levels before redundancy
#'     adjustments (\code{e(df_a_initial)}).}
#'   \item{\code{df_a_redundant}}{redundant absorbed degrees of freedom
#'     (\code{e(df_a_redundant)}).}
#' }
#'
#' \strong{Fit statistics}
#' \describe{
#'   \item{\code{r2}, \code{r2_within}}{overall and within R-squared
#'     (\code{e(r2)}, \code{e(r2_within)}).}
#'   \item{\code{r2_a}, \code{r2_a_within}}{adjusted (within) R-squared,
#'     computed with the unadjusted residual degrees of freedom, as in
#'     \code{reghdfe} (\code{e(r2_a)}, \code{e(r2_a_within)}); forced to 1
#'     in saturated fits.}
#'   \item{\code{rss}, \code{tss}, \code{tss_within}, \code{mss}}{residual,
#'     total, within-total, and model (tss - rss) sums of squares
#'     (\code{e(rss)}, \code{e(tss)}, \code{e(tss_within)}, \code{e(mss)}).
#'     When the fixed-effect part contains only slope terms
#'     (\code{fe[[x]]}, no level dimension), the model has no intercept and
#'     \code{tss}/\code{r2} use the \emph{uncentered} total sum of squares,
#'     matching \code{reghdfe} and \code{regress, noconstant}.}
#'   \item{\code{sigma2}}{estimated residual variance (\code{e(sigma2)}).}
#'   \item{\code{rmse}}{root mean squared error,
#'     sqrt(rss / df_r_unadj-style denominator), matching \code{reghdfe}
#'     (\code{e(rmse)}).}
#'   \item{\code{F_stat}, \code{F_p}}{model F-statistic and p-value
#'     (\code{e(F)}, \code{e(p)}): a Wald test that all kept non-intercept
#'     coefficients are zero, using a generalized inverse of their
#'     covariance block.}
#'   \item{\code{ll}, \code{ll_0}}{log-likelihood and log-likelihood at
#'     zeroed regressors, within (\code{e(ll)}, \code{e(ll_0)}).}
#'   \item{\code{saturated}}{1 if the fitted design is saturated /
#'     perfect-fit, 0 otherwise (\code{e(saturated)}).}
#'   \item{\code{has_intercept}}{whether a constant is reported
#'     (\code{e(report_constant)}).}
#' }
#'
#' \strong{Absorbed-fixed-effect diagnostics} (one entry per absorbed
#' dimension, mirroring \code{reghdfe}'s degrees-of-freedom footnote table,
#' \code{e(dof_table)})
#' \describe{
#'   \item{\code{fe_num_levels}}{number of categories after singleton
#'     dropping.}
#'   \item{\code{fe_base_levels}}{raw number of levels before adjustments.}
#'   \item{\code{fe_base_redundant}}{redundancies attributed to the
#'     intercept part of each absorbed dimension before heterogeneous-slope
#'     adjustments.}
#'   \item{\code{fe_redundant}}{redundant coefficients detected in the
#'     dimension.}
#'   \item{\code{fe_num_coefs}}{number of coefficients contributed by the
#'     dimension.}
#'   \item{\code{fe_inexact}}{flag: the redundancy count is an inexact
#'     (pairwise) estimate.}
#'   \item{\code{fe_nested}}{flag: the dimension is nested within a cluster
#'     variable.}
#'   \item{\code{fe_labels}}{labels of the absorbed dimensions (deparsed
#'     fixed-effect terms; cf. \code{e(absorb_labels)}).}
#' }
#'
#' \strong{Solver and backend diagnostics}
#' \describe{
#'   \item{\code{iterations}}{absorber iterations (\code{e(iterations)}).}
#'   \item{\code{converged}}{1 if converged, 0 otherwise
#'     (\code{e(converged)}).}
#'   \item{\code{abs_residual}, \code{abs_residual_rel}}{explicit absolute and
#'     relative normal-equation residuals verified after absorption.}
#'   \item{\code{krylov_internal_tolerance},
#'     \code{krylov_max_final_backward_error},
#'     \code{krylov_max_condition}, and
#'     \code{krylov_max_condition_times_backward_error}}{ordinary no-slope
#'     LSMR/MLSMR solve tolerance and deterministic maxima across right-hand
#'     sides; \code{krylov_max_condition} is the maximum running condition
#'     estimate. These fields are zero when that Krylov path was not used.}
#'   \item{Krylov-PCG scope}{The separate PCG path is not covered by this
#'     parity floor and reports zeros; a PCG floor remains future reviewed work.
#'     The reduced-system tier is a different conjugate-gradient solver with
#'     the stopping rule described under \code{absorption_method}; it leaves
#'     these four fields at zero itself.}
#'   \item{\code{precision_certified}}{whether the verified relative residual
#'     meets the numerical certificate limit. In the combined
#'     \code{group}/\code{individual} path this check is authoritative:
#'     additional certification sweeps are included in \code{iterations}, and
#'     \code{converged} is true only when this field is also true.}
#'   \item{\code{absorption_method_used}}{name of the method effectively
#'     used (\code{"auto"}, \code{"gauss-seidel"},
#'     \code{"symmetric-gauss-seidel"}, \code{"jacobi"}, \code{"schwarz"},
#'     \code{"lsmr"}, \code{"mlsmr"}, \code{"auto-mlsmr"},
#'     \code{"reduced-pcg"} when the reduced-system tier published the fit, or
#'     \code{"krylov-pcg"} when the forced Krylov-PCG route did).}
#'   \item{\code{absorption_method_code}}{numeric code with the same table
#'     as Stata's \code{e(absorption_method_used)}: 0 auto, 1 gauss-seidel,
#'     2 symmetric-gauss-seidel, 3 jacobi, 4 schwarz, 5 lsmr, 6 mlsmr,
#'     7 auto-mlsmr, 8 reduced-pcg, 9 krylov-pcg.}
#'   \item{\code{reduced_pcg_status}, \code{reduced_pcg_reason},
#'     \code{reduced_pcg_discarded_iterations}}{the reduced-system tier (see
#'     \code{absorption_method}): status 0 not applicable (off, ineligible,
#'     not reached, or another route's transform read from the absorption
#'     cache), 1 the tier published the fit (fresh or read back from the
#'     cache), 2 the attempt declined and the route ran from the original
#'     data; the reason (\code{"none"} when published, otherwise the
#'     ineligibility or decline reason, such as \code{"weights"} or
#'     \code{"stall"}, or \code{"off"}, \code{"not_reached"} or
#'     \code{"cache"}); and the iterations of a declined attempt, 0 otherwise.
#'     With status 1, \code{iterations} counts the tier's iterations (plus
#'     those of a normal-equation correction, should one follow)
#'     (\code{e(reduced_pcg_status)}, \code{e(reduced_pcg_reason)},
#'     \code{e(reduced_pcg_discarded_iterations)}).}
#'   \item{\code{reduced_pcg_fine_request}, \code{reduced_pcg_fine_source},
#'     \code{reduced_pcg_fine_used}, \code{reduced_pcg_fine_parts},
#'     \code{reduced_pcg_hinted_applies}, \code{reduced_pcg_fine_alloc_failed},
#'     \code{reduced_pcg_fine_retry}, \code{reduced_pcg_fine_retry_factor},
#'     \code{reduced_pcg_fine_retry_parts},
#'     \code{reduced_pcg_fine_retry_iters},
#'     \code{reduced_pcg_cache_hit}}{the finer blocks of the tier's segment
#'     pass (see \code{reduced_pcg_apply_fine}): the request in force
#'     (\code{"auto"} or \code{"1"} to \code{"8"}) and its source
#'     (\code{"request"}, \code{"environment"} or \code{"built-in"}); the
#'     factor the attempt chose (1 the coarse blocks; 0 when no attempt on the
#'     CPU reached that choice) and its blocks; the applications of the
#'     operator through the kernel; whether the finer blocks could not be
#'     allocated; whether the attempt was repeated on the coarse blocks after a
#'     memory decline, with the factor, blocks and iterations of the discarded
#'     first attempt; and whether the absorption came from the absorption cache
#'     (\code{e(reduced_pcg_fine_request)} and the other \code{e()} results of
#'     the same names). Read the factor and the applications together: the
#'     factor and its blocks say which blocks the attempt chose, not that the
#'     kernel ran on them; \code{reduced_pcg_hinted_applies} is 0 when the chosen
#'     blocks were applied in none.}
#'   \item{\code{slope_solver_request}, \code{slope_solver_source},
#'     \code{slope_solver_status}, \code{slope_solver_reason},
#'     \code{slope_solver_used}}{effective request, origin, outcome, reason and
#'     mode of the published slope solver (\code{"none"} when unused). The
#'     status is \code{"off"}, \code{"ineligible"}, \code{"declined"} or
#'     \code{"accepted"}.}
#'   \item{\code{slope_solver_discarded_iters}, \code{slope_solver_scores_used},
#'     \code{slope_solver_csr_owner_used}}{discarded iterations, whether the
#'     published inference used the scores, and whether the owner assembly
#'     ran successfully (including before a subsequent solver decline).}
#'   \item{\code{threads_requested}, \code{threads_effective}}{raw request
#'     (0 means auto) and the request after runtime/automatic limits.}
#'   \item{\code{threads_used}}{largest OpenMP team observed executing a real
#'     xhdfe loop.}
#'   \item{\code{parallel_workers_active}}{largest number of distinct workers
#'     processing useful work in one observed region.}
#'   \item{\code{thread_capacity}, \code{openmp_enabled},
#'     \code{thread_limit_code}, \code{thread_limit_reason}}{runtime-visible
#'     capacity, build capability, and any applied limit.}
#'   \item{\code{tolerance_mode}}{tolerance mode used
#'     (\code{e(tolerance_mode)}).}
#'   \item{\code{gpu_used}}{1 if the GPU backend was effectively used, 0 if
#'     the CPU path was used (\code{e(gpu_used)}).}
#'   \item{\code{gpu_status_code}, \code{gpu_status}}{status code 0-5 or 7 and
#'     its label (\code{e(gpu_status_code)}, \code{e(gpu_status)}); see the
#'     \emph{GPU backends} section for the taxonomy.}
#'   \item{\code{gpu_attempted}}{1 if GPU absorption was attempted
#'     (\code{e(gpu_attempted)}).}
#'   \item{\code{gpu_absorption_converged},
#'     \code{gpu_absorption_iterations}}{convergence flag and iteration
#'     count of the attempted GPU absorption; missing if not attempted
#'     (\code{e(gpu_absorption_converged)},
#'     \code{e(gpu_absorption_iterations)}).}
#'   \item{\code{cuda_tail_code}, \code{cuda_tail}}{how the CUDA path
#'     completed the projection of an unweighted Comparable fit with three
#'     fixed effects: 0 \code{"none"} (no completion ran, or the restart
#'     after a conjugate-gradient stage stayed on the GPU, as in 2.30.1), 1
#'     \code{"device-lsmr"} (on the GPU), 2 \code{"host-mlsmr"} (on the CPU
#'     with MLSMR, after the GPU sweeps, or from the original data when a
#'     conjugate-gradient stage stopped without converging; \code{gpu_used}
#'     stays 1; \code{iterations} then counts every GPU and CPU iteration
#'     within one \code{maxiter} budget; a conjugate-gradient stage that
#'     converges counts only its own iterations, on the CPU and the GPU)
#'     (\code{e(cuda_tail_code)}, \code{e(cuda_tail)}).}
#'   \item{\code{backend_requested}}{the \code{backend} argument value
#'     (cf. \code{e(gpu_backend_requested)}).}
#' }
#'
#' \strong{Fixed-effect recovery} (populated with \code{save_fe = TRUE})
#' \describe{
#'   \item{\code{fe_effects}}{named list with one numeric vector of
#'     per-observation fixed-effect contributions per absorbed dimension,
#'     on the estimation sample; use \code{fixef()} for full-length,
#'     NA-padded vectors.}
#'   \item{\code{fe_recovery_converged}, \code{fe_recovery_iterations},
#'     \code{fe_recovery_max_delta}}{recovery convergence flag, iteration
#'     count, and maximum change in the final recovery sweep
#'     (\code{e(fe_recovery_converged)}, \code{e(fe_recovery_iterations)},
#'     \code{e(fe_recovery_max_delta)}).}
#'   \item{\code{groupvar}}{with \code{groupvar = TRUE}: 1-based ids of the
#'     first mobility group (connected component), the analogue of Stata's
#'     \code{groupvar(newvar)}; otherwise \code{NULL}.}
#' }
#'
#' \strong{Cluster diagnostics} (populated when clustered)
#' \describe{
#'   \item{\code{num_clusters}}{minimum number of clusters across
#'     dimensions (\code{e(N_clust)}).}
#'   \item{\code{cluster_counts}}{cluster counts by dimension
#'     (\code{e(N_clust#)}).}
#'   \item{\code{cluster_combo_counts}}{counts for each cluster combination
#'     in bitmask order (\code{e(cluster_diag)}).}
#'   \item{\code{cluster_scale}}{cluster scaling factor from the
#'     small-sample corrections (\code{e(cluster_scale)}).}
#'   \item{\code{cluster_names}}{names of the cluster dimensions
#'     (\code{e(clustvar)}).}
#'   \item{\code{vcv_psd_fixed}}{1 if the multiway-cluster variance matrix
#'     required the Cameron-Gelbach-Miller positive-semi-definite
#'     adjustment (\code{e(vcv_psd_fixed)}); a warning is printed, matching
#'     \code{reghdfe}.}
#' }
#'
#' \strong{Prediction caches and bookkeeping}
#' \describe{
#'   \item{\code{xb_cache}, \code{y_cache}, \code{stdp_cache}}{full-length
#'     caches (NA off-sample) of the linear prediction, the outcome, and
#'     the standard error of the linear prediction; they back
#'     \code{predict()} and \code{fitted()} and are absent in grouped
#'     fits.}
#'   \item{\code{call}}{the matched call.}
#'   \item{\code{version}}{the package version string (\code{e(version)}).}
#' }
#'
#' \strong{Formula-interface extras} (set by \code{xhdfe()}, not by
#' \code{xhdfe_fit()})
#' \describe{
#'   \item{\code{fml}}{the model formula.}
#'   \item{\code{terms}}{the \code{terms} object of the regressor part
#'     (used by \code{predict(..., newdata = )}).}
#'   \item{\code{terms_endo}}{the \code{terms} object of the endogenous
#'     part for IV fits (\code{NULL} otherwise); \code{predict} uses it to
#'     rebuild the endogenous columns on new data.}
#'   \item{\code{xlevels}, \code{contrasts}}{factor levels and contrasts
#'     recorded at fit time so \code{predict(..., newdata = )} expands
#'     factors exactly as during estimation.}
#'   \item{\code{data_name}}{deparsed name of the \code{data} argument.}
#'   \item{\code{weights_type}}{\code{"analytic"}, \code{"frequency"},
#'     \code{"importance"}, or \code{"probability"}
#'     when weights were supplied, otherwise \code{NULL}.}
#'   \item{\code{group_name}, \code{individual_name},
#'     \code{aggregation}}{deparsed group/individual arguments and the
#'     aggregation method when group mode is used (\code{e(group)},
#'     \code{e(individual)}, \code{e(aggregation)}).}
#' }
#'
#' @references
#' Portela, Miguel, and Tiago Tavares. 2026. "xhdfe: High-dimensional fixed
#' effects regression via a C++ backend." Version 2.35.1.
#' \url{https://github.com/reisportela/xhdfe-xfe}
#'
#' Correia, Sergio. 2016. "reghdfe: Estimating linear models with multi-way
#' fixed effects." 2016 Stata Conference. RePEc:boc:scon16:24.
#'
#' Gaure, Simen. 2013. "OLS with multiple high dimensional category
#' variables." Computational Statistics & Data Analysis 66: 8-18.
#' \doi{10.1016/j.csda.2013.03.024}
#'
#' Guimaraes, Paulo, and Pedro Portugal. 2010. "A simple feasible procedure
#' to fit models with high-dimensional fixed effects." Stata Journal 10(4):
#' 628-649. \doi{10.1177/1536867X1101000406}
#'
#' Berge, Laurent, Kyle Butts, and Grant McDermott. 2026. "Fast and
#' user-friendly econometrics estimations: The R package fixest."
#' arXiv:2601.21749.
#'
#' Schmieder, Johannes. 2026. "fereg: Fast high-dimensional fixed-effects
#' regressions in Stata." CEPR Discussion Paper No. 22170. CEPR Press, Paris
#' & London. \url{https://cepr.org/publications/dp22170}
#'
#' See \code{\link{xhdfe-package}} for the complete reference list.
#'
#' @seealso \code{\link{xhdfe_fit}} for the matrix interface;
#'   \code{\link{xhdfe_examples}} for public-data examples;
#'   \code{xhdfe_demean()} for stand-alone demeaning;
#'   \code{xhdfe_group_fes()} for group-level fixed-effect aggregation;
#'   \code{xhdfe_info()} for version/build information; \code{fixef()} for
#'   recovered fixed effects; \code{predict()} (types \code{xb},
#'   \code{xbd}, \code{d}, \code{residuals}, \code{dresiduals},
#'   \code{score}, \code{stdp}) for Stata-compatible predictions. In the
#'   wider ecosystem: \code{fixest::feols}, \code{lfe::felm}, Stata's
#'   \code{reghdfe}, Python's \code{pyfixest}, and Julia's
#'   \code{FixedEffectModels.jl}.
#'
#' @author Miguel Portela (\email{miguel.portela@@eeg.uminho.pt}) and
#'   Tiago Tavares (\email{tgstavares@@eeg.uminho.pt}).
#'
#' @examples
#' ## A small synthetic worker-firm panel ------------------------------------
#' set.seed(2026)
#' n <- 600
#' d <- data.frame(
#'   worker = sample(80, n, replace = TRUE),
#'   firm   = sample(30, n, replace = TRUE),
#'   year   = sample(2015:2020, n, replace = TRUE),
#'   x1     = rnorm(n),
#'   x2     = rnorm(n),
#'   w      = runif(n, 0.5, 1.5)
#' )
#' d$z  <- rnorm(n)                            # instrument
#' d$xe <- 0.6 * d$z + 0.3 * d$x1 + rnorm(n)   # endogenous regressor
#' d$y  <- 1 + 0.5 * d$x1 - 0.2 * d$x2 + 0.7 * d$xe +
#'   0.05 * d$worker + 0.03 * d$firm + 0.1 * (d$year - 2015) + rnorm(n)
#'
#' ## 1. One absorbed fixed effect (Stata: xhdfe y x1 x2, absorb(firm))
#' m1 <- xhdfe(y ~ x1 + x2 | firm, data = d)
#' summary(m1)
#'
#' ## 2. Clustered standard errors (Stata: ..., vce(cluster firm))
#' m2 <- xhdfe(y ~ x1 + x2 | firm + year, data = d, cluster = ~ firm)
#' ## equivalent: vcov = ~ firm, cluster = "firm", or cluster = d$firm
#'
#' ## 3. Three-way fixed effects
#' m3 <- xhdfe(y ~ x1 + x2 | worker + firm + year, data = d)
#'
#' ## 4. Fixed-effect recovery (Stata: absorb(..., savefe))
#' m4 <- xhdfe(y ~ x1 + x2 | firm + year, data = d, save_fe = TRUE)
#' alpha <- fixef(m4)   # list: one full-length vector per dimension
#' head(alpha$firm)
#'
#' ## 5. Residuals and predictions (Stata: predict, xb / xbd / d / stdp)
#' head(residuals(m1))
#' head(predict(m1, type = "xb"))
#' head(predict(m1, type = "xbd"))   # xb + absorbed effects
#' head(predict(m1, type = "d"))     # absorbed effects only
#' head(predict(m1, type = "stdp"))  # SE of the linear prediction
#'
#' ## 6. Heterogeneous slopes (Stata: absorb(firm##c.x2 year))
#' m5 <- xhdfe(y ~ x1 | firm[x2] + year, data = d)
#' ## slopes only, no firm intercepts (Stata: absorb(firm#c.x2 year)):
#' m6 <- xhdfe(y ~ x1 | firm[[x2]] + year, data = d)
#'
#' ## 7. Analytic weights (Stata: [aw = w])
#' m7 <- xhdfe(y ~ x1 + x2 | firm, data = d, weights = ~ w)
#'
#' ## 8. IV/2SLS (Stata: ..., endogenous(xe) instruments(z))
#' m8 <- xhdfe(y ~ x1 | firm + year | xe ~ z, data = d)
#'
#' ## 9. Combined fixed effect (Stata: absorb(firm#year))
#' m9 <- xhdfe(y ~ x1 + x2 | firm^year, data = d)
#'
#' ## 10. Group-level outcomes with individual fixed effects
#' ## (Stata: xhdfe citations funding, absorb(inventor_id)
#' ##         group(patent_id) individual(inventor_id))
#' pat <- data.frame(patent = rep(1:20, each = 2))
#' pat$inventor <- ((pat$patent +
#'   ave(pat$patent, pat$patent, FUN = seq_along)) %% 10) + 1
#' pat$year <- 2020 + pat$patent %% 3
#' pat$funding <- pat$patent %% 2
#' pat$citations <- 5 + 0.4 * pat$funding + pat$patent / 10
#' g1 <- xhdfe(citations ~ funding | inventor, data = pat,
#'             group = ~ patent, individual = ~ inventor)
#' g2 <- xhdfe(citations ~ funding | inventor, data = pat,
#'             group = ~ patent, individual = ~ inventor,
#'             aggregation = "sum")
#' g3 <- xhdfe(citations ~ funding | year, data = pat, group = ~ patent)
#'
#' \donttest{
#' ## 11. Side-by-side with fixest (coefficients agree to reghdfe-level
#' ## precision under the default tolerance mode)
#' if (requireNamespace("fixest", quietly = TRUE)) {
#'   mf <- fixest::feols(y ~ x1 + x2 | firm + year, data = d)
#'   mx <- xhdfe(y ~ x1 + x2 | firm + year, data = d, cluster = ~ firm)
#'   print(cbind(fixest = coef(mf), xhdfe = coef(mx)[c("x1", "x2")]))
#' }
#' }
#'
#' \dontrun{
#' ## 12. CUDA GPU absorption (requires a CUDA build of the package; the
#' ## request fails closed instead of silently falling back to the CPU)
#' mg <- xhdfe(y ~ x1 + x2 | worker + firm, data = d, backend = "cuda")
#' stopifnot(mg$gpu_used == 1, mg$gpu_status == "used")
#' }
#'
#' @name xhdfe
NULL

# ---------------------------------------------------------------------------
# Matrix interface: xhdfe_fit()
# ---------------------------------------------------------------------------

#' Matrix interface to the xhdfe estimator
#'
#' @description
#' \code{xhdfe_fit()} is the low-level matrix interface to the xhdfe C++
#' backend, mirroring the Python package's
#' \code{HdfeRegressor().fit(y, X, fes, ...)} call. It takes the outcome,
#' design matrix, and id vectors directly -- no formula, no
#' \code{data.frame} evaluation -- and returns exactly the same
#' \code{"xhdfe"} object as \code{\link{xhdfe}}. Use it when the design is
#' already materialized (simulations, benchmark harnesses, code ported from
#' Python) or when formula processing overhead matters.
#'
#' Unlike \code{\link{xhdfe}}, this interface performs \strong{no missing
#' value handling}: any \code{NA} in \code{y} or \code{X} is an error, and
#' no sample marking against an original data frame takes place (filter
#' beforehand, or use the formula interface). There are also no
#' \code{data}, \code{subset}, or \code{na.action} arguments.
#'
#' @usage
#' xhdfe_fit(y, X, fes = NULL,
#'           weights = NULL, weights_type = c("analytic", "frequency", "importance", "probability"),
#'           cluster = NULL, vcov = NULL,
#'           instruments = NULL, endogenous = NULL,
#'           slopes = NULL,
#'           group = NULL, individual = NULL, aggregation = "mean",
#'           save_fe = FALSE, groupvar = FALSE,
#'           tol = 1e-8, maxiter = 100000,
#'           tolerance_mode = "reghdfe-comparable",
#'           convergence = "auto", check_interval = 1,
#'           absorption_method = "auto", symmetric_sweep = FALSE,
#'           jacobi_relaxation = 0,
#'           fit_intercept = TRUE,
#'           fe_tolerance = 1e-6, fe_recovery_method = "hybrid",
#'           drop_singletons = TRUE, keep_singletons = NULL,
#'           dof = NULL, ssc = NULL, stats_style = "reghdfe",
#'           level = 95,
#'           threads = 0, default_threads = 0, max_threads = 0,
#'           min_parallel_rows = 20000, target_rows_per_thread = 0,
#'           backend = c("default", "cpu", "cuda", "metal"),
#'           reduced_pcg = NULL, reduced_pcg_cuda = NULL,
#'           weighted_cpu_route = FALSE, reduced_pcg_apply_fine = NULL,
#'           slope_solver = NULL, slope_scores = NULL, slope_csr_owner = NULL)
#'
#' @param y numeric outcome vector (no \code{NA}s).
#' @param X numeric design matrix (or \code{data.frame}/vector coerced to
#'   one) with one row per observation and no \code{NA}s. Column names
#'   become the coefficient names (defaults \code{x1}, \code{x2}, ... when
#'   absent). Do \emph{not} include an intercept column; the constant is
#'   controlled by \code{fit_intercept}. Endogenous regressors (IV) are
#'   columns of \code{X} flagged through \code{endogenous}.
#' @param fes the absorbed fixed effects: a list with one id vector per
#'   absorbed dimension (list names become the fixed-effect labels used in
#'   \code{fe_labels} / \code{fixef()}), a matrix (one dimension per
#'   column), or a single vector. Ids are encoded like in
#'   \code{\link{xhdfe}}: integer vectors pass through verbatim, factors
#'   use their level codes, and character/logical/non-integral numeric
#'   vectors are encoded by first appearance. \code{NULL} means no absorbed
#'   fixed effects (plain OLS).
#' @param weights optional numeric weight vector, one entry per
#'   observation; interpreted according to \code{weights_type}.
#' @param weights_type \code{"analytic"} (Stata \code{aweight}),
#'   \code{"frequency"} (Stata \code{fweight}, exact replicated-rows semantics),
#'   \code{"importance"} (\code{iweight}) or \code{"probability"} (\code{pweight}).
#'   See \code{\link{xhdfe}} for their inference conventions.
#' @param cluster the cluster dimensions: a vector, a matrix (one dimension
#'   per column), a \code{data.frame}, or a list of vectors; several
#'   dimensions request multiway clustering. No formula form here (there is
#'   no \code{data} to evaluate it in). Supplying \code{cluster} without
#'   \code{vcov} implies \code{vcov = "cluster"}.
#' @param vcov \code{NULL}, \code{"unadjusted"} (aliases \code{"iid"},
#'   \code{"ols"}, \code{"homoskedastic"}, \code{"classical"},
#'   \code{"unadj"}), \code{"robust"} (aliases \code{"hc1"},
#'   \code{"heteroskedastic"}), or \code{"cluster"} (alias
#'   \code{"clustered"}); see \code{\link{xhdfe}}.
#' @param instruments numeric matrix of instruments (one row per
#'   observation); requires \code{endogenous}. The instrument count must be
#'   at least the number of endogenous regressors.
#' @param endogenous which columns of \code{X} are endogenous: a vector of
#'   1-based column positions or of column names. Required together with
#'   \code{instruments}; supplying it without \code{instruments} is an
#'   error. (In the formula interface the endogenous variables instead
#'   form the third formula part and are appended to the design
#'   automatically.)
#' @param slopes heterogeneous (group-specific) slope specifications: a
#'   list of entries, each itself a list with elements
#'   \describe{
#'     \item{\code{fe}}{1-based index into \code{fes} naming the carrier
#'       dimension (alias \code{fe_index}).}
#'     \item{\code{values}}{the numeric slope variable, one entry per
#'       observation (alias \code{x}).}
#'     \item{\code{include_intercept}}{logical (alias \code{intercept};
#'       default \code{FALSE}): \code{TRUE} absorbs the carrier's
#'       intercepts as well (Stata \code{fe##c.x}); \code{FALSE} absorbs
#'       the slopes only (Stata \code{fe#c.x}).}
#'   }
#'   A single specification may be passed unwrapped (a plain
#'   \code{list(fe = , values = )}). The core absorbs at most one slope per
#'   carrier dimension: to attach several slope variables to the same ids,
#'   repeat the id vector as separate entries of \code{fes} and point one
#'   slope entry at each, letting the intercept ride on the first -- the
#'   same expansion the formula interface performs for
#'   \code{fe[x1, x2]} and Stata performs for
#'   \code{absorb(fe##c.x1 fe#c.x2)}.
#' @param group,individual,aggregation group-level-outcome machinery, as in
#'   \code{\link{xhdfe}} but with plain id vectors (no formula or column
#'   name forms). \code{individual} requires \code{group} and is appended
#'   to \code{fes} automatically when not already present.
#' @param save_fe logical; recover fixed-effect contributions (Stata
#'   \code{savefe}); see \code{\link{xhdfe}}.
#' @param groupvar logical; store first-mobility-group ids; see
#'   \code{\link{xhdfe}}.
#' @param tol,maxiter,tolerance_mode absorber tolerance, iteration cap, and
#'   tolerance mode; see \code{\link{xhdfe}} and its \emph{Tolerance modes}
#'   section.
#' @param convergence heterogeneous-slope stopping rule (\code{"auto"},
#'   \code{"normchange"}, \code{"reghdfe"}, \code{"both"}); see
#'   \code{\link{xhdfe}}.
#' @param check_interval iterations between convergence checks; see
#'   \code{\link{xhdfe}}.
#' @param absorption_method absorption method (\code{"auto"},
#'   \code{"gauss-seidel"}, \code{"symmetric-gauss-seidel"},
#'   \code{"jacobi"}, \code{"schwarz"}, \code{"lsmr"}, \code{"mlsmr"},
#'   \code{"auto-mlsmr"}, with aliases); see \code{\link{xhdfe}}.
#' @param symmetric_sweep forward-plus-backward Gauss-Seidel sweeps; see
#'   \code{\link{xhdfe}}.
#' @param jacobi_relaxation Jacobi relaxation parameter; see
#'   \code{\link{xhdfe}}.
#' @param fit_intercept logical (default \code{TRUE}): report the
#'   reghdfe-style constant (and, without fixed effects, include an
#'   intercept in the regression). \code{FALSE} is the analogue of Stata's
#'   \code{noconstant}; the formula interface controls this with \code{0 +}
#'   in the regressor part instead.
#' @param fe_tolerance,fe_recovery_method fixed-effect recovery controls
#'   for \code{save_fe}; see \code{\link{xhdfe}}.
#' @param drop_singletons,keep_singletons singleton handling (reghdfe
#'   semantics); see \code{\link{xhdfe}}.
#' @param dof degrees-of-freedom adjustment tokens (\code{"all"},
#'   \code{"none"}, \code{"firstpair"}, \code{"pairwise"},
#'   \code{"clusters"}, \code{"continuous"}); see \code{\link{xhdfe}}.
#' @param ssc small-sample corrections (named list or Stata-style string);
#'   see \code{\link{xhdfe}}.
#' @param stats_style \code{"reghdfe"} (default) or \code{"legacy"}; see
#'   \code{\link{xhdfe}}.
#' @param level confidence level in percent or as a fraction; see
#'   \code{\link{xhdfe}}.
#' @param threads,default_threads,max_threads number of absorber threads
#'   and auto-threading bounds; see \code{\link{xhdfe}}.
#' @param min_parallel_rows,target_rows_per_thread parallel-absorption
#'   heuristics; see \code{\link{xhdfe}}.
#' @param backend \code{"default"}, \code{"cpu"}, \code{"cuda"}, or
#'   \code{"metal"}, with the same fail-closed GPU contract as
#'   \code{\link{xhdfe}}; see its \emph{GPU backends} section.
#' @param reduced_pcg \code{NULL} (default), \code{TRUE} or \code{FALSE}: the
#'   reduced-system tier for this fit; see \code{\link{xhdfe}}.
#' @param reduced_pcg_cuda \code{NULL} (default), \code{TRUE} or \code{FALSE}:
#'   the experimental CUDA variant of that tier for this fit, on CUDA fits
#'   only; see \code{\link{xhdfe}}.
#' @param reduced_pcg_apply_fine \code{NULL} (default), \code{"auto"} or an
#'   integer from 1 to 8: the finer blocks of that tier's segment pass for this
#'   fit; see \code{\link{xhdfe}}.
#' @param slope_solver \code{NULL}, \code{"off"}, \code{"schur"},
#'   \code{"network"} or \code{"direct"}; see \code{\link{xhdfe}}.
#' @param slope_scores optional logical for cluster score reuse;
#'   see \code{\link{xhdfe}}.
#' @param slope_csr_owner optional logical for parallel sparse assembly;
#'   see \code{\link{xhdfe}}.
#'
#' @return The same \code{"xhdfe"} object documented in
#'   \code{\link{xhdfe}} (see its \emph{Value} section for every field),
#'   with two differences: the formula-interface extras (\code{fml},
#'   \code{terms}, \code{data_name}, \code{group_name},
#'   \code{individual_name}, \code{aggregation}) are absent, and
#'   consequently \code{predict(..., newdata = )} is unavailable (the
#'   cache-based prediction types \code{xb}, \code{xbd}, \code{d},
#'   \code{residuals}, \code{dresiduals}, \code{score}, and \code{stdp}
#'   still work for non-grouped fits). The \code{sample} field indexes into
#'   the rows of \code{y}/\code{X}.
#'
#' @seealso \code{\link{xhdfe}} for the formula interface and the full
#'   documentation of the shared arguments, sections, and returned object;
#'   \code{xhdfe_info()} for version/build information.
#'
#' @author Miguel Portela (\email{miguel.portela@@eeg.uminho.pt}) and
#'   Tiago Tavares (\email{tgstavares@@eeg.uminho.pt}).
#'
#' @examples
#' set.seed(1)
#' n <- 300
#' X <- cbind(x1 = rnorm(n), x2 = rnorm(n))
#' firm <- sample(25, n, replace = TRUE)
#' year <- sample(6, n, replace = TRUE)
#' y <- 0.5 * X[, 1] - 0.2 * X[, 2] + 0.1 * firm + 0.2 * year + rnorm(n)
#'
#' ## Two-way fixed effects with clustered standard errors
#' m <- xhdfe_fit(y, X, fes = list(firm = firm, year = year),
#'                cluster = firm)
#' coef(m)
#'
#' ## Heterogeneous slope: firm intercepts + firm-specific slopes on z
#' ## (Stata: absorb(firm##c.z year))
#' z <- rnorm(n)
#' m2 <- xhdfe_fit(y, X, fes = list(firm = firm, year = year),
#'                 slopes = list(list(fe = 1, values = z,
#'                                    include_intercept = TRUE)))
#'
#' ## IV/2SLS: the "xe" column of X is endogenous, instrumented by zi
#' zi <- rnorm(n)
#' xe <- 0.6 * zi + rnorm(n)
#' Xiv <- cbind(X, xe = xe)
#' yiv <- y + 0.7 * xe
#' miv <- xhdfe_fit(yiv, Xiv, fes = list(firm = firm),
#'                  endogenous = "xe", instruments = cbind(z1 = zi))
#' coef(miv)
#'
#' @name xhdfe_fit
NULL
