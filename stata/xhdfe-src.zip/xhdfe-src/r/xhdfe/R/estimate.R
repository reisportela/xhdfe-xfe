# Internal estimation engine shared by xhdfe() and xhdfe_fit().

# Assemble the options list handed to the C++ binding. `se_type` is resolved
# beforehand; everything else arrives via the user-facing arguments.
build_opts <- function(se_type, tol, maxiter, check_interval, convergence,
                       fit_intercept, threads, default_threads, max_threads,
                       min_parallel_rows, target_rows_per_thread,
                       drop_singletons, keep_singletons, save_fe,
                       symmetric_sweep, absorption_method, jacobi_relaxation,
                       level, dof, ssc, tolerance_mode, fe_tolerance,
                       fe_recovery_method, stats_style, weights_type,
                       groupvar, reduced_pcg = NULL, reduced_pcg_cuda = NULL,
                       weighted_cpu_route = FALSE, reduced_pcg_apply_fine = NULL,
                       slope_solver = NULL, slope_scores = NULL, slope_csr_owner = NULL) {
  thread_values <- c(threads, default_threads, max_threads)
  if (any(lengths(list(threads, default_threads, max_threads)) != 1L) ||
      any(!is.finite(thread_values)) || any(thread_values < 0) ||
      any(thread_values != floor(thread_values))) {
    stop("threads, default_threads, and max_threads must be nonnegative integers",
         call. = FALSE)
  }
  if (length(min_parallel_rows) != 1L || !is.finite(min_parallel_rows) ||
      min_parallel_rows <= 0 ||
      min_parallel_rows != floor(min_parallel_rows)) {
    stop("min_parallel_rows must be a positive integer", call. = FALSE)
  }
  # 0 selects the automatic rows per thread.
  if (length(target_rows_per_thread) != 1L ||
      !is.finite(target_rows_per_thread) || target_rows_per_thread < 0 ||
      target_rows_per_thread != floor(target_rows_per_thread)) {
    stop("target_rows_per_thread must be a nonnegative integer", call. = FALSE)
  }
  ssc <- parse_ssc(ssc)
  opts <- list(
    se_type = se_type,
    tol = tol,
    max_iter = as.integer(maxiter),
    check_interval = as.integer(check_interval),
    convergence = convergence,
    fit_intercept = isTRUE(fit_intercept),
    num_threads = as.integer(threads),
    default_threads = as.integer(default_threads),
    max_threads = as.integer(max_threads),
    min_parallel_rows = as.integer(min_parallel_rows),
    target_rows_per_thread = as.integer(target_rows_per_thread),
    drop_singletons = isTRUE(drop_singletons),
    retain_fes = isTRUE(save_fe),
    symmetric_sweep = isTRUE(symmetric_sweep),
    absorption_method = absorption_method,
    jacobi_relaxation = jacobi_relaxation,
    level = level,
    tolerance_mode = tolerance_mode,
    fe_tolerance = fe_tolerance,
    fe_recovery_method = fe_recovery_method,
    stats_style = stats_style,
    weights_are_frequencies = identical(weights_type, "frequency"),
    weights_are_importance = identical(weights_type, "importance"),
    groupvar = isTRUE(groupvar)
  )
  # The reduced-system tier for this fit: NULL follows the process default
  # (XHDFE_REDUCED_PCG), TRUE and FALSE override it.
  if (!is.null(reduced_pcg)) {
    if (!is.logical(reduced_pcg) || length(reduced_pcg) != 1L || is.na(reduced_pcg)) {
      stop("reduced_pcg must be NULL, TRUE or FALSE", call. = FALSE)
    }
    opts$reduced_pcg <- reduced_pcg
  }
  # The experimental CUDA variant of the tier for this fit: NULL follows the
  # process default (XHDFE_REDUCED_PCG_CUDA), TRUE and FALSE override it.
  if (!is.null(reduced_pcg_cuda)) {
    if (!is.logical(reduced_pcg_cuda) || length(reduced_pcg_cuda) != 1L ||
        is.na(reduced_pcg_cuda)) {
      stop("reduced_pcg_cuda must be NULL, TRUE or FALSE", call. = FALSE)
    }
    opts$reduced_pcg_cuda <- reduced_pcg_cuda
  }
  # The finer blocks of the tier's segment pass for this fit (package D): NULL
  # follows the process value (XHDFE_REDUCED_PCG_APPLY_FINE, else the built-in
  # value), "auto" the automatic rule of the data, an integer from 1 to 8 that
  # factor (1: the blocks of 2.34.2). Passed as -1 for "auto".
  if (!is.null(reduced_pcg_apply_fine)) {
    fine_message <- "reduced_pcg_apply_fine must be NULL, \"auto\" or an integer from 1 to 8"
    if (is.character(reduced_pcg_apply_fine)) {
      if (length(reduced_pcg_apply_fine) != 1L || is.na(reduced_pcg_apply_fine) ||
          reduced_pcg_apply_fine != "auto") {
        stop(fine_message, call. = FALSE)
      }
      opts$reduced_pcg_apply_fine <- -1L
    } else if (is.numeric(reduced_pcg_apply_fine) && length(reduced_pcg_apply_fine) == 1L) {
      # Convert first, then validate the integer that will be passed (round 11):
      # an object whose as.integer() method returns another value is judged by
      # that value, and its plain number must equal it (no fraction).
      fine <- suppressWarnings(as.integer(reduced_pcg_apply_fine))
      raw <- unclass(reduced_pcg_apply_fine)
      if (!is.integer(fine) || length(fine) != 1L || is.na(fine) || fine < 1L || fine > 8L ||
          !is.numeric(raw) || length(raw) != 1L || is.na(raw) || raw != fine) {
        stop(fine_message, call. = FALSE)
      }
      opts$reduced_pcg_apply_fine <- fine
    } else {
      stop(fine_message, call. = FALSE)
    }
  }
  if (!is.logical(weighted_cpu_route) || length(weighted_cpu_route) != 1L ||
      is.na(weighted_cpu_route)) {
    stop("weighted_cpu_route must be TRUE or FALSE", call. = FALSE)
  }
  if (weighted_cpu_route) opts$weighted_cpu_route <- TRUE
  if (!is.null(slope_solver)) {
    if (!is.character(slope_solver) || length(slope_solver) != 1L || !is.null(dim(slope_solver)) ||
        is.na(slope_solver) || !(slope_solver %in% c("off", "schur", "network", "direct"))) {
      stop("slope_solver must be NULL, 'off', 'schur', 'network' or 'direct'", call. = FALSE)
    }
    opts$slope_solver <- slope_solver
  }
  slope_helpers <- list(slope_scores = slope_scores, slope_csr_owner = slope_csr_owner)
  for (name in names(slope_helpers)) {
    value <- slope_helpers[[name]]
    if (is.null(value)) next
    if (!is.logical(value) || length(value) != 1L || !is.null(dim(value)) || is.na(value)) {
      stop(name, " must be NULL, TRUE or FALSE", call. = FALSE)
    }
    opts[[name]] <- value
  }
  if (!is.null(keep_singletons)) opts$keepsingletons <- isTRUE(keep_singletons)
  if (!is.null(dof)) opts$dofadjustments <- as.character(dof)
  opts[names(ssc)] <- ssc
  opts
}

# Parse fixest/Stata-style small-sample-correction spec into ssc_* options.
# Accepts a named list (ssc_k_adj = TRUE, ...) or a Stata-style string such
# as "K.adj=1 K.fixef=nonnested G.df=min".
parse_ssc <- function(ssc) {
  if (is.null(ssc)) return(list())
  if (is.list(ssc)) {
    allowed <- c("ssc_k_adj", "ssc_k_fixef", "ssc_k_exact", "ssc_g_adj",
                 "ssc_g_df", "ssc_t_df")
    bad <- setdiff(names(ssc), allowed)
    if (length(bad)) {
      stop("Unknown ssc entries: ", paste(bad, collapse = ", "), call. = FALSE)
    }
    return(ssc)
  }
  if (!is.character(ssc) || length(ssc) != 1L) {
    stop("`ssc` must be a named list or a single string", call. = FALSE)
  }
  out <- list()
  tokens <- strsplit(gsub(",", " ", ssc), "\\s+")[[1L]]
  tokens <- tokens[nzchar(tokens)]
  as_flag <- function(v) {
    if (v %in% c("", "1", "true", "yes")) TRUE
    else if (v %in% c("0", "false", "no")) FALSE
    else stop("Invalid ssc flag value: ", v, call. = FALSE)
  }
  for (tok in tokens) {
    kv <- strsplit(tok, "=", fixed = TRUE)[[1L]]
    key <- tolower(kv[1L])
    val <- if (length(kv) > 1L) tolower(kv[2L]) else ""
    if (key == "k.adj") out$ssc_k_adj <- as_flag(val)
    else if (key == "k.fixef") {
      out$ssc_k_fixef <- if (val %in% c("true", "yes")) "full"
                         else if (val %in% c("false", "no")) "none" else val
    }
    else if (key == "k.exact") out$ssc_k_exact <- as_flag(val)
    else if (key == "g.adj") out$ssc_g_adj <- as_flag(val)
    else if (key == "g.df") out$ssc_g_df <- val
    else if (key == "t.df") {
      out$ssc_t_df <- suppressWarnings(as.numeric(val))
      if (is.na(out$ssc_t_df)) {
        stop("t.df must be numeric in the R interface (min/conventional are ",
             "resolved by the core via G.df)", call. = FALSE)
      }
    }
    else stop("Unknown ssc token: ", tok, call. = FALSE)
  }
  out
}

# Run the fit with a task-local native backend override and fail-closed GPU
# semantics (mirrors Stata's error 498 contract for gpubackend(cuda|metal)): a
# CUDA request that ends without the GPU stops, except status 7
# (weighted_cpu_route), a weighted fit with two or more absorbed effects that
# the core ran on the CPU by design and reports as such.
run_with_backend <- function(backend, fun) {
  backend <- match.arg(backend, c("default", "cpu", "cuda", "metal"))
  res <- .xhdfe_cpp_run_with_backend(backend, fun)
  if (backend %in% c("cuda", "metal") && !isTRUE(res$gpu_used) &&
      !identical(as.integer(res$gpu_status_code), 7L)) {
    stop("backend = \"", backend, "\" was requested but the GPU was not used (status: ",
         gpu_status_label(res$gpu_status_code),
         "). xhdfe refuses to return silent CPU-fallback results; rebuild the ",
         "package with XHDFE_ENABLE_CUDA=ON and ensure a CUDA device is ",
         "available, or drop the backend request.", call. = FALSE)
  }
  res
}

# Post-process the raw C++ result list into the user-facing "xhdfe" object.
finalize_xhdfe <- function(res, coef_names, n_input, rows_used, call, level,
                           backend, se_type, cluster_names, fe_labels,
                           tolerance_mode, stats_style, model_has_cons = NULL,
                           weights_sum = NULL,
                           X_used = NULL, y_used = NULL, grouped_fit = FALSE) {
  if (!isTRUE(res$converged) || !isTRUE(res$precision_certified) ||
      identical(res$fe_recovery_converged, FALSE)) {
    stop("xhdfe: convergence or precision certification failed; iterations=",
         res$num_iterations, "; relative residual=", res$abs_residual_rel,
         ". No estimates returned.", call. = FALSE)
  }
  k <- length(coef_names)
  # A recovered constant is reported only when the model contains one (an
  # explicit intercept, or one spanned by the absorbed effects). Otherwise the
  # trailing slot the core returns is dropped, as the Stata ado does, and the
  # fit statistics are those of a model without a constant.
  if (identical(res$model_has_constant, FALSE) &&
      length(res$coefficients) == k + 1L) {
    keep <- seq_len(k)
    res$coefficients <- res$coefficients[keep]
    res$se <- res$se[keep]
    res$tvalues <- res$tvalues[keep]
    res$pvalues <- res$pvalues[keep]
    res$conf_int <- res$conf_int[keep, , drop = FALSE]
    res$covariance <- res$covariance[keep, keep, drop = FALSE]
    if (length(res$omitted_reason) == k + 1L) {
      res$omitted_reason <- res$omitted_reason[keep]
    }
    model_has_cons <- FALSE
  }
  ncoef <- length(res$coefficients)
  has_cons <- FALSE
  if (ncoef == k + 1L) {
    coef_names <- c(coef_names, "(Intercept)")
    has_cons <- TRUE
  } else if (ncoef != k) {
    stop(sprintf("internal error: %d coefficients for %d regressors", ncoef, k),
         call. = FALSE)
  }
  if (is.null(model_has_cons)) model_has_cons <- has_cons

  coefficients <- stats::setNames(res$coefficients, coef_names)
  se <- stats::setNames(res$se, coef_names)
  tvalues <- stats::setNames(res$tvalues, coef_names)
  pvalues <- stats::setNames(res$pvalues, coef_names)
  conf_int <- res$conf_int
  dimnames(conf_int) <- list(coef_names,
                             c(sprintf("%g %%", (100 - res_level(level)) / 2),
                               sprintf("%g %%", 100 - (100 - res_level(level)) / 2)))
  covariance <- res$covariance
  dimnames(covariance) <- list(coef_names, coef_names)

  omitted <- res$omitted_reason
  if (length(omitted) == k && has_cons) omitted <- c(omitted, 0L)
  if (length(omitted) == length(coef_names)) {
    omitted <- stats::setNames(as.integer(omitted), coef_names)
  } else {
    omitted <- stats::setNames(integer(length(coef_names)), coef_names)
  }

  # Compose the core selection with NA/subset filtering. Grouped indices
  # identify representative input rows, including after singleton pruning.
  if (length(res$sample_index0) != res$nobs ||
      length(res$residuals) != res$nobs || anyNA(res$sample_index0) ||
      any(res$sample_index0 < 0L | res$sample_index0 >= length(rows_used)) ||
      anyDuplicated(res$sample_index0)) {
    stop("xhdfe: estimation sample mapping is incomplete or invalid; no estimates returned",
         call. = FALSE)
  }
  sample_rows <- rows_used[res$sample_index0 + 1L]
  residuals_full <- rep(NA_real_, n_input)
  residuals_full[sample_rows] <- res$residuals

  # Observation counts follow the effective (weight-total) count, as Stata's
  # e(N) does. The effective count equals the row count unless frequency
  # weights are active, and in that case the row count's integer type is kept
  # so that unweighted and analytic-weight results are unchanged bit for bit,
  # type included.
  .xhdfe_effective_count <- function(effective, rows) {
    if (is.null(effective) || !is.finite(effective) || effective == rows) {
      return(rows)
    }
    if (effective <= .Machine$integer.max) as.integer(effective) else effective
  }

  nobs <- res$nobs
  df_r <- res$df_resid
  df_m <- res$df_m
  # Effective N (weighted): the Stata command uses the plugin's effective
  # count for r2_a/ll; identical to nobs when unweighted or aweighted.
  n_eff <- if (!is.null(res$nobs_effective) && res$nobs_effective > 0) {
    res$nobs_effective
  } else {
    nobs
  }

  # Derived statistics, mirroring stata/xhdfe.ado.
  mss <- res$tss - res$rss
  reghdfe_stats <- identical(stats_style, "reghdfe")
  used_df_r <- res$df_resid_unadj
  if (reghdfe_stats) used_df_r <- used_df_r - res$df_a_nested
  rmse <- NA_real_
  if (is.finite(used_df_r) && used_df_r > 0 && res$rss >= 0) {
    rmse <- sqrt(res$rss / used_df_r)
  } else if (reghdfe_stats && is.finite(used_df_r) &&
             used_df_r == 0 && res$rss >= 0) {
    rmse <- sqrt(res$rss)
  } else if (!reghdfe_stats && res$rss >= 0) {
    # Preserve the legacy R fallback for non-positive residual degrees of freedom.
    rmse <- sqrt(res$rss)
  }
  r2_a <- r2_a_within <- NA_real_
  if (res$tss > 0 && is.finite(used_df_r) && used_df_r > 0) {
    r2_a <- 1 - (res$rss / used_df_r) /
      (res$tss / max(n_eff - as.integer(isTRUE(model_has_cons)), 1))
  }
  if (res$tss_within > 0 && is.finite(used_df_r) &&
      used_df_r > 0 && used_df_r + df_m > 0) {
    r2_a_within <- 1 - (res$rss / used_df_r) /
      (res$tss_within / (used_df_r + df_m))
  }
  canonical_saturated <- reghdfe_stats &&
    is.finite(used_df_r) && used_df_r <= 0 && is.finite(df_r) && df_r <= 0 &&
    res$tss > 0 && res$rss >= 0 && res$rss <= 1e-8 * res$tss
  if (!reghdfe_stats && isTRUE(res$saturated)) {
    r2_a <- 1
    r2_a_within <- 1
  } else if (canonical_saturated) {
    r2_a <- 1
    if (res$tss_within > 0) r2_a_within <- 1
  }
  ll <- ll0 <- NA_real_
  if (res$rss > 0 && n_eff > 0) {
    ll <- -0.5 * n_eff * (log(2 * pi) + log(res$rss / n_eff) + 1)
  }
  if (res$tss_within > 0 && n_eff > 0) {
    ll0 <- -0.5 * n_eff * (log(2 * pi) + log(res$tss_within / n_eff) + 1)
  }

  # Model F statistic (Wald on kept, non-intercept coefficients).
  f_stat <- f_p <- NA_real_
  keep <- which(omitted == 0L & coef_names != "(Intercept)" &
                  is.finite(se) & se > 0)
  if (length(keep) > 0 && is.finite(df_r) && df_r > 0 &&
      (!reghdfe_stats || (is.finite(used_df_r) && used_df_r > 0))) {
    V1 <- covariance[keep, keep, drop = FALSE]
    b1 <- coefficients[keep]
    g <- sym_ginv(V1)
    if (g$rank > 0) {
      f_stat <- drop(t(b1) %*% g$inv %*% b1) / g$rank
      f_p <- stats::pf(f_stat, g$rank, df_r, lower.tail = FALSE)
    }
  }

  fe_effects <- res$fe_effects
  if (length(fe_effects) && length(fe_labels) == length(fe_effects)) {
    names(fe_effects) <- fe_labels
  }

  out <- list(
    coefficients = coefficients,
    se = se,
    tvalues = tvalues,
    pvalues = pvalues,
    conf_int = conf_int,
    vcov = covariance,
    residuals = residuals_full,
    omitted = omitted,
    # N follows the effective count, as Stata's e(N) does and as this
    # package's own documentation states ("observation counts, degrees of
    # freedom, and the *_effective count fields use the sum of the weights").
    # Returning the row count here left df_r larger than nobs under frequency
    # weights (04aug2026 audit). The effective counts equal the row counts
    # whenever frequency weights are inactive, so nothing else changes.
    nobs = .xhdfe_effective_count(n_eff, nobs),
    nobs_full = .xhdfe_effective_count(res$nobs_full_effective,
                                       res$nobs_full),
    num_singletons = .xhdfe_effective_count(res$num_singletons_effective,
                                            res$num_singletons),
    # Row counts; pair these with sample_index, which indexes rows.
    nobs_rows = res$nobs,
    nobs_full_rows = res$nobs_full,
    num_singletons_rows = res$num_singletons,
    nobs_effective = res$nobs_effective,
    nobs_full_effective = res$nobs_full_effective,
    num_singletons_effective = res$num_singletons_effective,
    sample = sample_rows,
    df_r = df_r,
    df_r_unadj = res$df_resid_unadj,
    df_m = df_m,
    rank = df_m,
    df_a = res$df_a,
    df_a_levels = res$df_a_levels,
    df_a_exact = res$df_a_exact,
    df_a_nested = res$df_a_nested,
    df_a_initial = res$df_a_levels,
    df_a_redundant = max(res$df_a_levels - res$df_a, 0),
    r2 = res$r2,
    r2_within = res$r2_within,
    r2_a = r2_a,
    r2_a_within = r2_a_within,
    rss = res$rss,
    tss = res$tss,
    tss_within = res$tss_within,
    mss = mss,
    sigma2 = res$sigma2,
    rmse = rmse,
    F_stat = f_stat,
    F_p = f_p,
    ll = ll,
    ll_0 = ll0,
    saturated = res$saturated,
    fe_num_levels = res$fe_num_levels,
    fe_base_levels = res$fe_base_levels,
    fe_base_redundant = res$fe_base_redundant,
    fe_redundant = res$fe_redundant,
    fe_num_coefs = res$fe_num_coefs,
    fe_inexact = res$fe_inexact,
    fe_nested = res$fe_nested,
    fe_labels = fe_labels,
    iterations = res$num_iterations,
    converged = res$converged,
    abs_residual = res$abs_residual,
    abs_residual_rel = res$abs_residual_rel,
    krylov_internal_tolerance = res$krylov_internal_tolerance,
    krylov_max_final_backward_error = res$krylov_max_final_backward_error,
    krylov_max_condition = res$krylov_max_condition,
    krylov_max_condition_times_backward_error =
      res$krylov_max_condition_times_backward_error,
    auto_routing_retry_policy_enabled =
      res$auto_routing_retry_policy_enabled,
    auto_routing_retry_eligible = res$auto_routing_retry_eligible,
    auto_routing_retry_fired = res$auto_routing_retry_fired,
    auto_routing_retry_status = res$auto_routing_retry_status,
    auto_routing_retry_primary_method =
      res$auto_routing_retry_primary_method,
    auto_routing_retry_primary_iterations =
      res$auto_routing_retry_primary_iterations,
    auto_routing_retry_primary_abs_residual_rel =
      res$auto_routing_retry_primary_abs_residual_rel,
    auto_routing_retry_iterations = res$auto_routing_retry_iterations,
    auto_routing_retry_abs_residual_rel =
      res$auto_routing_retry_abs_residual_rel,
    auto_routing_retry_elapsed_seconds =
      res$auto_routing_retry_elapsed_seconds,
    slope_block_checked = res$slope_block_checked,
    slope_block_residual_rel = res$slope_block_residual_rel,
    slope_block_frobenius_rel = res$slope_block_frobenius_rel,
    slope_block_rms_rel = res$slope_block_rms_rel,
    slope_block_max_rel = res$slope_block_max_rel,
    slope_block_skipped_max_rel = res$slope_block_skipped_max_rel,
    slope_certificate_worst_fe = res$slope_certificate_worst_fe,
    slope_certificate_worst_moment = res$slope_certificate_worst_moment,
    slope_accuracy_retry_stages = res$slope_accuracy_retry_stages,
    slope_accuracy_retry_iterations = res$slope_accuracy_retry_iterations,
    slope_internal_tolerance = res$slope_internal_tolerance,
    precision_certified = res$precision_certified,
    absorption_method_used = res$absorption_method_used,
    absorption_method_code = res$absorption_method_code,
    reduced_pcg_status = res$reduced_pcg_status,
    reduced_pcg_reason = res$reduced_pcg_reason,
    reduced_pcg_discarded_iterations = res$reduced_pcg_discarded_iterations,
    reduced_pcg_fine_request = res$reduced_pcg_fine_request,
    reduced_pcg_fine_source = res$reduced_pcg_fine_source,
    slope_solver_request = res$slope_solver_request,
    slope_solver_source = res$slope_solver_source,
    slope_solver_used = res$slope_solver_used,
    slope_solver_status = res$slope_solver_status,
    slope_solver_reason = res$slope_solver_reason,
    slope_solver_discarded_iters = res$slope_solver_discarded_iters,
    slope_solver_scores_used = res$slope_solver_scores_used,
    slope_solver_csr_owner_used = res$slope_solver_csr_owner_used,
    reduced_pcg_fine_used = res$reduced_pcg_fine_used,
    reduced_pcg_fine_parts = res$reduced_pcg_fine_parts,
    reduced_pcg_hinted_applies = res$reduced_pcg_hinted_applies,
    reduced_pcg_fine_alloc_failed = res$reduced_pcg_fine_alloc_failed,
    reduced_pcg_fine_retry = res$reduced_pcg_fine_retry,
    reduced_pcg_fine_retry_factor = res$reduced_pcg_fine_retry_factor,
    reduced_pcg_fine_retry_parts = res$reduced_pcg_fine_retry_parts,
    reduced_pcg_fine_retry_iters = res$reduced_pcg_fine_retry_iters,
    reduced_pcg_cache_hit = res$reduced_pcg_cache_hit,
    threads_used = res$threads_used,
    threads_requested = res$threads_requested,
    threads_effective = res$threads_effective,
    parallel_workers_active = res$parallel_workers_active,
    thread_capacity = res$thread_capacity,
    openmp_enabled = res$openmp_enabled,
    thread_limit_code = res$thread_limit_code,
    thread_limit_reason = res$thread_limit_reason,
    gpu_used = res$gpu_used,
    gpu_status_code = res$gpu_status_code,
    gpu_status = gpu_status_label(res$gpu_status_code),
    gpu_attempted = res$gpu_attempted,
    gpu_absorption_converged = res$gpu_absorption_converged,
    gpu_absorption_iterations = res$gpu_absorption_iterations,
    cuda_tail_code = res$cuda_tail_code,
    cuda_tail = res$cuda_tail,
    backend_requested = backend,
    fe_effects = fe_effects,
    fe_recovery_iterations = res$fe_recovery_iterations,
    fe_recovery_max_delta = res$fe_recovery_max_delta,
    fe_recovery_converged = res$fe_recovery_converged,
    groupvar = if (length(res$groupvar)) res$groupvar else NULL,
    num_clusters = res$num_clusters,
    cluster_counts = res$cluster_counts,
    cluster_combo_counts = res$cluster_combo_counts,
    cluster_scale = res$cluster_scale,
    cluster_names = cluster_names,
    vcv_psd_fixed = res$vcv_psd_fixed,
    se_type = se_type,
    level = res_level(level),
    tolerance_mode = tolerance_mode,
    stats_style = stats_style,
    has_intercept = has_cons,
    model_has_constant = isTRUE(model_has_cons),
    sumweights = if (is.null(weights_sum)) nobs else weights_sum,
    n_input = n_input,
    call = call,
    version = as.character(utils::packageVersion("xhdfe"))
  )

  out$grouped_fit <- grouped_fit

  # Prediction caches (n-vectors; the full design is not retained).
  if (!is.null(X_used) && !is.null(y_used)) {
    kept <- res$sample_index0 + 1L
    Xs <- X_used[kept, , drop = FALSE]
    b_slopes <- coefficients[seq_len(ncol(Xs))]
    b_slopes[!is.finite(b_slopes)] <- 0
    xb <- if (ncol(Xs) > 0) drop(Xs %*% b_slopes) else numeric(length(kept))
    if (has_cons) xb <- xb + coefficients[["(Intercept)"]]
    xb_full <- y_full <- stdp_full <- rep(NA_real_, n_input)
    xb_full[sample_rows] <- xb
    y_full[sample_rows] <- y_used[kept]
    Vok <- covariance
    Vok[!is.finite(Vok)] <- 0
    design <- if (has_cons) cbind(Xs, 1) else Xs
    vv <- rowSums((design %*% Vok) * design)
    stdp_full[sample_rows] <- sqrt(pmax(vv, 0))
    out$xb_cache <- xb_full
    out$y_cache <- y_full
    out$stdp_cache <- stdp_full
  }
  class(out) <- "xhdfe"

  if (isTRUE(res$vcv_psd_fixed)) {
    warning("the multiway-cluster VCV required the Cameron-Gelbach-Miller ",
            "positive-semi-definite adjustment (as in reghdfe)", call. = FALSE)
  }
  if (isTRUE(res$saturated)) {
    message("note: the absorbed model fits the data perfectly (saturated ",
            "design); standard errors are not identified")
  }
  out
}

# Normalize a level given either as percent (95) or fraction (0.95).
res_level <- function(level) {
  if (level > 0 && level <= 1) level * 100 else level
}
