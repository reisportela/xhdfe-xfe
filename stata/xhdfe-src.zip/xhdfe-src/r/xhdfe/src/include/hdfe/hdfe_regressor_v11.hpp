#ifndef HDFE_REGRESSOR_V11_HPP
#define HDFE_REGRESSOR_V11_HPP

#include <Eigen/Dense>

#include <cstdint>
#include <memory>
#include <string>
#include <vector>

#include "fe_absorption.hpp"
#include "hdfe/hdfe_regressor.hpp"
#include "ols.hpp"

namespace hdfe {
namespace detail {
class AutoTeamRegistration;
}  // namespace detail

namespace v11 {

class BindingAttemptGuard;

enum class GroupAggregation { Mean, Sum };

// Package D (23nov2026): the finer blocks of the reduced-system tier's segment
// pass in one fit, read-only, reset at the start of every fit and restored when
// a projection with saved effects is abandoned. request: the request in force
// (kReducedPcgApplyFineAuto or a factor from 1 to 8; the fit's own, else the
// process value); source: 1 the fit's request, 2 the environment variable, 3
// the built-in value. The rest describe the CPU tier's attempt that ran its
// solver (0 or false when none did, a CUDA tier attempt and an absorption read
// from the cache included): the factor it chose (1 = the coarse blocks), their
// number, the applications of the operator that went through the kernel of the
// segment pass, whether the reservation of the finer blocks failed so that the
// coarse ones ran, and whether the attempt was repeated on the coarse blocks
// after a memory decline (then the factor, blocks and iterations of the
// discarded first attempt). cache_hit: the fit's absorption came from the
// absorption cache.
struct ReducedPcgFineDiagnostics {
    int request = 1;
    int source = 0;
    int used = 0;
    int parts = 0;
    long long hinted_applies = 0;
    bool alloc_failed = false;
    bool retry = false;
    int retry_factor = 0;
    int retry_parts = 0;
    int retry_iterations = 0;
    bool cache_hit = false;
};

struct ThreadingOptions {
    int default_threads = 0;       // 0 = hardware concurrency
    int max_threads = 0;           // 0 = no cap
    int min_parallel_rows = 20000;
    int target_rows_per_thread = 0;  // 0 = automatic (see resolve_threads)
    bool symmetric_sweep = false;
};

struct GroupIndividualFeOptions {
    double tol_main = 1e-9;     // tolm in extractfes
    double tol_start = 1e-3;    // toli in extractfes
    double tol_final = 1e-9;    // tolf in extractfes
    int max_iter_main = 100000; // maxiter1 in extractfes
    int max_iter_solver = 1000; // maxiter2 in extractfes
    int verbose = 0;            // 0 = silent
    int accel = 2;              // 0 = none, 1 = linear, 2 = geometric
    int start_accel = 5;        // staccel
    int every_accel = 5;        // evaccel
    double factor = 1.0;        // tighten solver tol if mse < factor * tol
    double a1p1 = 0.75;         // linear acceleration parameter
    double a2p1 = 1e-8;         // geometric acceleration safeguard
    int a2p2 = 5;               // geometric acceleration exponent
};

struct GroupIndividualFeEstimates {
    Eigen::VectorXi individual_ids;
    Eigen::VectorXd individual_effects;
    std::vector<Eigen::VectorXi> fe_level_ids;
    std::vector<Eigen::VectorXd> fe_level_effects;
    int iterations = 0;
    bool converged = true;
    double mse = 0.0;
    int threads_requested = 0;
    int threads_effective = 1;
    int threads_used = 1;
    int parallel_workers_active = 1;
    int thread_capacity = 1;
    bool openmp_enabled = false;
    int thread_limit_code = 0;
    std::string thread_limit_reason = "none";
};

/**
 * \brief Exact connected-component summary for the first pair of FE dimensions.
 *
 * These are the mobility groups used by the Component-style FE normalization
 * and by reghdfe-compatible groupvar()/first-pair DoF accounting. Observation
 * counts always refer to physical rows. The weight share uses the supplied
 * positive weights and is therefore scale invariant.
 */
struct FeComponentStats {
    int num_components = 0;
    long long largest_component_n_obs = 0;
    double largest_component_obs_share = 0.0;
    double largest_component_weight_share = 0.0;
};

FeComponentStats compute_first_pair_component_stats(
    const Eigen::VectorXi& first_fe,
    const Eigen::VectorXi& second_fe,
    const Eigen::VectorXd* weights = nullptr);

class HdfeRegressorV11 {
public:
    explicit HdfeRegressorV11(HdfeOptions options = HdfeOptions{},
                              ThreadingOptions threading = ThreadingOptions{});
    HdfeRegressorV11(const HdfeRegressorV11& other);
    HdfeRegressorV11& operator=(const HdfeRegressorV11& other);
    HdfeRegressorV11(HdfeRegressorV11&& other) noexcept;
    HdfeRegressorV11& operator=(HdfeRegressorV11&& other) noexcept;

    void fit(const Eigen::Ref<const Eigen::VectorXd>& y,
             const Eigen::Ref<const Eigen::MatrixXd>& X,
             const std::vector<Eigen::VectorXi>& fes = {},
             const Eigen::VectorXd* weights = nullptr,
             const std::vector<Eigen::VectorXi>* clusters = nullptr,
             const Eigen::MatrixXd* instruments = nullptr,
             const std::vector<int>& endogenous_idx = {},
             const std::vector<detail::HeterogeneousSlopeTerm>* slopes = nullptr);

    // Compute within-transformed y and X after absorbing fixed effects, without running the
    // post-absorption regression step. This is the building block for hdfe-style partialling-out.
    detail::AbsorptionResult partial_out(
        const Eigen::Ref<const Eigen::VectorXd>& y,
        const Eigen::Ref<const Eigen::MatrixXd>& X,
        const std::vector<Eigen::VectorXi>& fes = {},
        const Eigen::VectorXd* weights = nullptr,
        const std::vector<Eigen::VectorXi>* clusters = nullptr,
        const std::vector<detail::HeterogeneousSlopeTerm>* slopes = nullptr);

    void fit_grouped(const Eigen::Ref<const Eigen::VectorXd>& y,
                     const Eigen::Ref<const Eigen::MatrixXd>& X,
                     const std::vector<Eigen::VectorXi>& fes,
                     const Eigen::VectorXi& group_ids,
                     const Eigen::VectorXi* individual_ids = nullptr,
                     GroupAggregation aggregation = GroupAggregation::Mean,
                     const Eigen::VectorXd* weights = nullptr,
                     const std::vector<Eigen::VectorXi>* clusters = nullptr);

    GroupIndividualFeEstimates extract_group_individual_fes(
        const Eigen::Ref<const Eigen::VectorXd>& y,
        const Eigen::Ref<const Eigen::MatrixXd>& X,
        const std::vector<Eigen::VectorXi>& fes,
        const Eigen::VectorXi& group_ids,
        const Eigen::VectorXi& individual_ids,
        GroupAggregation aggregation = GroupAggregation::Mean,
        const Eigen::VectorXd* weights = nullptr,
        const GroupIndividualFeOptions& options = GroupIndividualFeOptions{}) const;

    // Bindings whose weight semantics are selected per call must set this
    // explicitly before fit()/fit_grouped(). The Python binding resets it on
    // every fit call, so a previous fweight fit cannot leak into a later call.
    void set_weights_are_frequencies(bool value) noexcept;

    // Package D (round 09, E.4): the request of the finer blocks of the reduced
    // tier for the following fits of this regressor (kReducedPcgApplyFineUnset,
    // kReducedPcgApplyFineAuto, or 1 to 8; std::invalid_argument otherwise, as in
    // the constructor), so that a binding can reuse one regressor across
    // requests; call it between fits.
    void set_reduced_pcg_apply_fine(int request);
    int reduced_pcg_apply_fine_request() const noexcept { return options_.reduced_pcg_apply_fine; }
    void set_slope_solver(SlopeSolverRequest request);
    SlopeSolverRequest slope_solver_request() const noexcept { return options_.slope_solver; }
    const SlopeSolverDiagnostics& slope_solver_diagnostics() const noexcept { return slope_solver_diagnostics_; }

    // Language adapters call this with the exact weights of the completed fit
    // to apply Stata's importance-weight reporting and inference convention.
    void apply_importance_weights(const Eigen::Ref<const Eigen::VectorXd>& weights);

    const HdfeResults& results() const noexcept { return results_; }
    const char* lifecycle_state_name() const noexcept;
    std::uint64_t generation() const noexcept { return generation_; }
    bool has_estimation_result() const noexcept;
    bool has_partial_result() const noexcept;
    int threads_used() const noexcept { return threads_used_; }
    int threads_requested() const noexcept { return threads_requested_; }
    int threads_effective() const noexcept { return threads_effective_; }
    int parallel_workers_active() const noexcept { return parallel_workers_active_; }
    int thread_capacity() const noexcept { return thread_capacity_; }
    bool openmp_enabled() const noexcept { return openmp_enabled_; }
    int thread_limit_code() const noexcept { return thread_limit_code_; }
    const std::string& thread_limit_reason() const noexcept {
        return thread_limit_reason_;
    }
    // The team resolve_threads() gives a pass over n_rows observations with
    // num_fes fixed-effect dimensions under this regressor's options and
    // threading (its `effective` count; throws where resolve_threads()
    // throws). A language adapter uses it to size parallel work done before
    // fit(), such as reading the data, under the same switches as the fit.
    int resolved_thread_count(int n_rows, int num_fes) const;
    // ReducedPcg when the reduced-system tier published the fit, KrylovPcg when
    // the fit's route was forced to the Krylov-PCG absorber and that absorber
    // produced the published transform, otherwise the route's method.
    AbsorptionMethod absorption_method_used() const noexcept {
        if (reduced_pcg_status_ == 1) return AbsorptionMethod::ReducedPcg;
        return krylov_pcg_published_ ? AbsorptionMethod::KrylovPcg : method_used_;
    }
    // The reduced-system tier in this fit: status 0 not applicable (tier off,
    // ineligible, not reached), 1 accepted (the tier published the fit, fresh
    // or read back from the absorption cache), 2 declined (the route's chain
    // ran from the original data); the reason ("none" when accepted, the
    // decline or ineligibility reason otherwise, "off" with
    // XHDFE_REDUCED_PCG=0, "cache" when another transform came from the
    // absorption cache); the iterations spent in an attempt that was not
    // published.
    int reduced_pcg_status() const noexcept { return reduced_pcg_status_; }
    const std::string& reduced_pcg_reason() const noexcept { return reduced_pcg_reason_; }
    int reduced_pcg_discarded_iterations() const noexcept { return reduced_pcg_discarded_iterations_; }
    // Package D: the finer blocks of the fit (ReducedPcgFineDiagnostics).
    const ReducedPcgFineDiagnostics& reduced_pcg_fine() const noexcept { return reduced_pcg_fine_; }
    bool gpu_used() const noexcept { return gpu_used_; }
    int gpu_status_code() const noexcept { return gpu_status_code_; }
    bool gpu_attempted() const noexcept { return gpu_attempted_; }
    bool gpu_absorption_converged() const noexcept { return gpu_absorption_converged_; }
    int gpu_absorption_iterations() const noexcept { return gpu_absorption_iterations_; }
    // How the three-FE Comparable CUDA completion ran (detail::kCudaTail*):
    // 0 none, 1 device LSMR, 2 host MLSMR; cuda_tail_name() is its label.
    int cuda_tail_code() const noexcept { return cuda_tail_code_; }
    const char* cuda_tail_name() const noexcept {
        return detail::cuda_tail_name(cuda_tail_code_);
    }
    const FeComponentStats& first_pair_component_stats() const noexcept {
        return first_pair_component_stats_;
    }

    // Package B (17nov2026): the per-call mark of a front end that collapses
    // group() itself and then calls fit() (the Stata plugin without
    // individual()). Set for that one call by this guard and restored on every
    // exit, an exception included. Read only by the scope of the strict-residual
    // CUDA acceptance; it changes no number, route, cache key or diagnostic.
    class GroupedCallMark {
    public:
        explicit GroupedCallMark(HdfeRegressorV11& regressor) noexcept
            : regressor_(regressor), previous_(regressor.grouped_call_mark_) {
            regressor_.grouped_call_mark_ = true;
        }
        ~GroupedCallMark() noexcept { regressor_.grouped_call_mark_ = previous_; }
        GroupedCallMark(const GroupedCallMark&) = delete;
        GroupedCallMark& operator=(const GroupedCallMark&) = delete;

    private:
        HdfeRegressorV11& regressor_;
        bool previous_;
    };

private:
    enum class LifecycleState {
        Empty,
        InProgress,
        Failed,
        PartialReady,
        StandardReady,
        GroupedReady,
    };

    class AttemptTransaction;
    friend class BindingAttemptGuard;

    struct ThreadResolution {
        int requested = 0;
        int effective = 1;
        int capacity = 1;
        bool openmp_enabled = false;
        int limit_code = 0;
        std::string limit_reason = "none";
    };

    // legacy_density: size an automatic team with the 2.30.1 density (one
    // thread per 500 000 rows) on every path; the floor of team coordination.
    ThreadResolution resolve_threads(int n_rows, int num_fes,
                                     bool legacy_density = false) const;
    // Records `resolution` in the per-user team registry (an intent at the
    // start of a fit, a lease when its absorption starts) and returns it with
    // the granted team; see hdfe/auto_team_registry.hpp.
    ThreadResolution coordinate_auto_team(
        ThreadResolution resolution, int n_rows, int num_fes,
        detail::AutoTeamRegistration& registration, bool lease) const;
    void begin_parallel_observation(const ThreadResolution& resolution);
    void end_parallel_observation();
    void clear_consumable_state() noexcept;
    void begin_attempt();
    void fail_attempt() noexcept;
    void commit_attempt(LifecycleState ready_state) noexcept;
    void invalidate_semantics() noexcept;
    void reset_moved_from() noexcept;
    AbsorptionMethod select_method(std::size_t num_fes) const;
    // The method an absorption-cache record stores: absorption_method_used()
    // without KrylovPcg, which is reported, never stored (a hit on such a
    // transform reports the stored sweep method, as before code 9 existed).
    AbsorptionMethod cached_method_used() const noexcept {
        return reduced_pcg_status_ == 1 ? AbsorptionMethod::ReducedPcg : method_used_;
    }
    void apply_common_postprocessing(const Eigen::Ref<const Eigen::VectorXd>& y,
                                     const Eigen::Ref<const Eigen::MatrixXd>& X,
                                     const Eigen::VectorXd* weights,
                                     const std::vector<int>& fe_levels,
                                     const detail::OlsResult& ols_result);

    HdfeOptions options_;
    ThreadingOptions threading_;
    HdfeResults results_;
    int threads_used_ = 1;
    int threads_requested_ = 0;
    int threads_effective_ = 1;
    int parallel_workers_active_ = 1;
    int thread_capacity_ = 1;
    bool openmp_enabled_ = false;
    int thread_limit_code_ = 0;
    std::string thread_limit_reason_ = "none";
    std::shared_ptr<detail::ParallelWorkObserver> parallel_observer_;
    bool suppress_auto_routing_retry_ = false;
    // Package B: set only by GroupedCallMark (not copied, not moved).
    bool grouped_call_mark_ = false;
    AbsorptionMethod method_used_ = AbsorptionMethod::GaussSeidel;
    LifecycleState lifecycle_state_ = LifecycleState::Empty;
    std::uint64_t generation_ = 0;
    std::uint64_t grouped_signature_1_ = 0;
    std::uint64_t grouped_signature_2_ = 0;
    bool grouped_signature_valid_ = false;
    bool gpu_used_ = false;
    int gpu_status_code_ = 0;
    bool gpu_attempted_ = false;
    bool gpu_absorption_converged_ = false;
    int gpu_absorption_iterations_ = 0;
    int cuda_tail_code_ = 0;
    FeComponentStats first_pair_component_stats_;
    int reduced_pcg_status_ = 0;
    std::string reduced_pcg_reason_ = "not_reached";
    int reduced_pcg_discarded_iterations_ = 0;
    ReducedPcgFineDiagnostics reduced_pcg_fine_;
    // Package D: a transient memory fallback of the tier ran in this fit (the
    // finer blocks not allocated, the repetition on the coarse blocks, or a
    // decline for memory that left the fit to the chain), so the fit writes no
    // absorption-cache entry. Reset with every fit; not restored with the
    // diagnostics.
    bool reduced_pcg_transient_fallback_ = false;
    // Point 14 (17nov2026): the published transform came from the Krylov-PCG
    // absorber under a forced Krylov route (absorption_method_used reports
    // KrylovPcg). Reset with every fit; read by nothing else.
    bool krylov_pcg_published_ = false;
    SlopeSolverDiagnostics slope_solver_diagnostics_;
    bool slope_scores_enabled_ = false;
    bool slope_csr_owner_enabled_ = false;
};

}  // namespace v11
}  // namespace hdfe

#endif  // HDFE_REGRESSOR_V11_HPP
