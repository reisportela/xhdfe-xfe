#ifndef HDFE_OLS_HPP
#define HDFE_OLS_HPP

#include <Eigen/Dense>

#include <memory>
#include <vector>

#include "hdfe/hdfe_regressor.hpp"

namespace hdfe {
namespace detail {

struct N1NormalEvidence;
struct OlsWideCovariance;

// Unscaled time-cluster influences from the existing wide IV factorisation.
// The recovered constant is formed before conversion to binary64.
struct DkraayInfluences {
    Eigen::VectorXi time_ids;
    Eigen::MatrixXd values;
};

struct OlsResult {
    Eigen::VectorXd coefficients;
    Eigen::VectorXd std_errors;
    Eigen::VectorXd tvalues;
    Eigen::VectorXd pvalues;
    Eigen::MatrixXd conf_int;
    Eigen::VectorXd residuals;
    Eigen::MatrixXd covariance;
    Eigen::MatrixXd xtx_inv;      // (X'X)^{-1} from the core solve (for post-processing).
    Eigen::VectorXd cluster_ux;   // Sum_g (sum_i w_i u_i) * (sum_i w_i x_i u_i) (cluster only).
    double cluster_u2 = 0.0;      // Sum_g (sum_i w_i u_i)^2 (cluster only).
    double cov_scale = 1.0;       // Finite-sample scale applied to `covariance`.
    double df_resid = 0.0;
    double rss = 0.0;
    double tss = 0.0;
    double within_tss = 0.0;
    double r2 = 0.0;
    double r2_within = 0.0;
    double sigma2 = 0.0;
    int nobs = 0;
    int num_clusters = 0;
    std::shared_ptr<N1NormalEvidence> n1_normal;
    // Sign of the augmented IV meat before the ill-conditioned bread and
    // binary64 output transport. False also covers unclassified/singular cases.
    bool augmented_meat_positive_definite = false;
};

// Phase 5b of the Stata-path plan: the passes of a multi-way clustered fit shared
// inside the fit (one carrier per pass of the fit's N1 loop, never longer). The OLS
// stage produces it (run_ols_multiway*): the number of clusters of every mask, which
// its meats return anyway (mask_counts[mask - 1], masks ascending), and, when
// want_pair is set, the pair of the two dimensions (combine_clusters(*source,
// {0, 1})), moved out of the stage instead of freed. The pending state is local to
// the stage and moved in only after its last range check (ready); a failed attempt
// leaves the carrier as it was. The intercept's meats and the reconstruction read it
// (const) only when it is ready, comes from the list they were given and has the
// right sizes; otherwise they run today's code. XHDFE_CLUSTER_SHARED_PASSES=0, read
// once per process (cluster_shared_passes_enabled()), keeps today's code everywhere.
struct MixedNetworkScores;
struct ClusterPasses {
    MixedNetworkScores* network = nullptr;
    const std::vector<Eigen::VectorXi>* source = nullptr;
    bool want_pair = false;
    bool ready = false;
    std::vector<int> mask_counts;
    Eigen::VectorXi pair;
};

bool cluster_shared_passes_enabled();

// X_for_residuals: when set (2SLS), the coefficients are solved on X (the
// instrumented second-stage design) but residuals/rss/sigma2/R2 and the robust
// or clustered meat use u = y - X_for_residuals * beta (the actual regressors),
// as required for valid 2SLS inference.
OlsResult run_ols(const Eigen::VectorXd& y,
                  const Eigen::Ref<const Eigen::MatrixXd>& X,
                  const Eigen::VectorXd* weights,
                  const Eigen::VectorXi* clusters,
                  StandardErrorType se_type,
                  double total_sum_squares,
                  double within_sum_squares,
                  double n_effective = -1.0,
                  bool weights_are_frequencies = false,
                  const Eigen::MatrixXd* X_for_residuals = nullptr,
                  bool num_threads_explicit = false,
                  ParallelWorkObserver* parallel_observer = nullptr);

OlsResult run_ols_fast_from_xtx(const Eigen::VectorXd& y,
                                const Eigen::Ref<const Eigen::MatrixXd>& X,
                                const Eigen::VectorXd* weights,
                                StandardErrorType se_type,
                                double total_sum_squares,
                                double within_sum_squares,
                                const Eigen::MatrixXd& xtx,
                                const Eigen::VectorXd& xty,
                                double n_effective = -1.0,
                                bool weights_are_frequencies = false,
                                bool num_threads_explicit = false,
                                ParallelWorkObserver* parallel_observer = nullptr);

// Raw multiway-cluster sandwich bread * [inclusion-exclusion meat] * bread
// with optional per-component cluster corrections (the caller maps any common
// scale from an already-scaled slope block). `scores` is the unweighted score
// design (reghdfe restores the original means and appends the constant
// column); weights fold in as sqrt(w) on both scores and residuals.
Eigen::MatrixXd multiway_cluster_sandwich(
    const Eigen::MatrixXd& bread,
    const Eigen::Ref<const Eigen::MatrixXd>& scores,
    const Eigen::VectorXd& residuals,
    const Eigen::VectorXd* weights,
    const std::vector<Eigen::VectorXi>& clusters,
    ClusterDofMethod g_df = ClusterDofMethod::Min,
    bool g_adj = false,
    const ClusterPasses* passes = nullptr);

// Low-memory package L3.1-C, C2: the same rebuild for the scores [regressors | 1]
// without forming them. The regressors are read where they are and the column of
// ones is taken implicitly; every sum gets the same doubles in the same order as
// multiway_cluster_sandwich on the materialized matrix. The bread is (p+1) x (p+1).
Eigen::MatrixXd multiway_cluster_sandwich_with_constant(
    const Eigen::MatrixXd& bread,
    const Eigen::Ref<const Eigen::MatrixXd>& regressors,
    const Eigen::VectorXd& residuals,
    const Eigen::VectorXd* weights,
    const std::vector<Eigen::VectorXi>& clusters,
    ClusterDofMethod g_df = ClusterDofMethod::Min,
    bool g_adj = false,
    const ClusterPasses* passes = nullptr);

// XHDFE_MULTIWAY_SCORES_COPY=1 (C2's switch, read once per process): the callers build
// the n x (p+1) scores with the appended column of ones, as before.
bool multiway_scores_copy_enabled();

OlsResult run_ols_multiway(const Eigen::VectorXd& y,
                           const Eigen::Ref<const Eigen::MatrixXd>& X,
                           const Eigen::VectorXd* weights,
                           const std::vector<Eigen::VectorXi>* clusters,
                           StandardErrorType se_type,
                           double total_sum_squares,
                           double within_sum_squares,
                           ClusterDofMethod g_df = ClusterDofMethod::Conventional,
                           bool g_adj = true,
                           double n_effective = -1.0,
                           const Eigen::MatrixXd* X_for_residuals = nullptr,
                           bool num_threads_explicit = false,
                           ParallelWorkObserver* parallel_observer = nullptr,
                           ClusterPasses* passes = nullptr);

OlsResult run_ols_with_score_low(const Eigen::VectorXd& y,
    const Eigen::Ref<const Eigen::MatrixXd>& X, const Eigen::VectorXd* weights,
    const Eigen::VectorXi* clusters, StandardErrorType se_type,
    double total_sum_squares, double within_sum_squares, double n_effective,
    bool weights_are_frequencies, const Eigen::Ref<const Eigen::MatrixXd>* X_for_residuals,
    bool num_threads_explicit, ParallelWorkObserver* parallel_observer,
    const Eigen::MatrixXd* score_low,
    const Eigen::VectorXd* normalization_means = nullptr,
    Eigen::VectorXd* intercept_covariance = nullptr,
    DkraayInfluences* dkraay_influences = nullptr);

OlsResult run_ols_multiway_with_score_low(const Eigen::VectorXd& y,
    const Eigen::Ref<const Eigen::MatrixXd>& X, const Eigen::VectorXd* weights,
    const std::vector<Eigen::VectorXi>* clusters, StandardErrorType se_type,
    double total_sum_squares, double within_sum_squares, ClusterDofMethod g_df,
    bool g_adj, double n_effective, const Eigen::Ref<const Eigen::MatrixXd>* X_for_residuals,
    bool num_threads_explicit, ParallelWorkObserver* parallel_observer,
    const Eigen::MatrixXd* score_low,
    const Eigen::VectorXd* normalization_means = nullptr,
    Eigen::VectorXd* intercept_covariance = nullptr,
    OlsWideCovariance* covariance_wide = nullptr,
    ClusterPasses* passes = nullptr);

}  // namespace detail
}  // namespace hdfe

#endif  // HDFE_OLS_HPP
