#include "hdfe/hdfe_regressor_v11.hpp"
#include "mixed_network.hpp"
#include "audit/ordinary_certification.hpp"

#include <algorithm>
#include <array>
#include <atomic>
#include <cctype>
#include <chrono>
#include <cmath>
#include <cstdint>
#include <cstring>
#include <cstdlib>
#include <cstdio>
#include <deque>
#include <exception>
#include <fstream>
#include <functional>
#ifdef __APPLE__
#include <limits.h>
#else
#include <filesystem>
#endif
#include <iomanip>
#include <iostream>
#include <limits>
#include <memory>
#include <numeric>
#include <optional>
#include <random>
#include <sstream>
#include <stdexcept>
#include <string>
#include <unordered_map>
#include <vector>

#include <fcntl.h>
#include <sys/stat.h>
#ifdef _WIN32
#include <io.h>
#else
#include <unistd.h>
#endif

#include "fe_absorption.hpp"
#include "fe_absorption_cuda.hpp"
#include "reduced_schur_pcg_entry.hpp"
#ifdef HDFE_USE_CUDA
#include "reduced_schur_pcg_cuda.hpp"  // the CUDA tier's error type: its fatal kind propagates
#endif
#include "group_exact_rank.hpp"
#include "group_forward_certificate.hpp"
#include "cache_digest.hpp"
#include "wide_float.hpp"
#include "wide_covariance.hpp"
#include <type_traits>
#include "fe_recovery_scale.hpp"
#include "n1_checks.hpp"
#include "n1_continuation.hpp"
#include "hdfe/auto_team_registry.hpp"
#include "hdfe/deterministic_parallel.hpp"
#include "hdfe/ieee_bits.hpp"
#include "hdfe/parallel_work_observer.hpp"
#include "hdfe/student_t_detail.hpp"
#include "hdfe/x87_precision.hpp"
#include "sparse_rank.hpp"
#include "iv.hpp"
#include "iv_input.hpp"
#include "ols.hpp"
#include "ols_precision.hpp"
#include "dkraay_covariance.hpp"
#include "additive_cell_projection.hpp"
#include "audit/ordinary_post_ols.hpp"

#ifdef HDFE_USE_OPENMP
#include <omp.h>
#endif

namespace hdfe {
namespace v11 {
namespace {

class ScopedBoolOverride final {
public:
    ScopedBoolOverride(bool& target, bool value) noexcept
        : target_(target), original_(target) {
        target_ = value;
    }

    ~ScopedBoolOverride() noexcept { target_ = original_; }

    ScopedBoolOverride(const ScopedBoolOverride&) = delete;
    ScopedBoolOverride& operator=(const ScopedBoolOverride&) = delete;

private:
    bool& target_;
    bool original_;
};

void require_finite_vector(
    const Eigen::Ref<const Eigen::VectorXd>& values,
    const char* label,
    int threads = 1) {
    const double* data = values.data();
    const Eigen::Index size = values.size();
    std::uint64_t invalid = 0;
#ifdef HDFE_USE_OPENMP
#pragma omp parallel for schedule(static) if(threads > 1) num_threads(threads) reduction(| : invalid)
#else
    (void)threads;
#endif
    for (Eigen::Index i = 0; i < size; ++i) {
        invalid |= static_cast<std::uint64_t>(
            !hdfe::detail::ieee_finite(data[i]));
    }
    if (invalid == 0) {
        return;
    }
    for (Eigen::Index i = 0; i < size; ++i) {
        if (!hdfe::detail::ieee_finite(data[i])) {
            std::ostringstream message;
            message << label << " must contain only finite values (row "
                    << i << ")";
            throw std::runtime_error(message.str());
        }
    }
}

void require_finite_matrix(
    const Eigen::Ref<const Eigen::MatrixXd>& values,
    const char* label,
    int threads = 1) {
    const double* data = values.data();
    const Eigen::Index size = values.size();
    std::uint64_t invalid = 0;
#ifdef HDFE_USE_OPENMP
#pragma omp parallel for schedule(static) if(threads > 1) num_threads(threads) reduction(| : invalid)
#else
    (void)threads;
#endif
    for (Eigen::Index i = 0; i < size; ++i) {
        invalid |= static_cast<std::uint64_t>(
            !hdfe::detail::ieee_finite(data[i]));
    }
    if (invalid == 0) {
        return;
    }
    for (Eigen::Index i = 0; i < size; ++i) {
        if (!hdfe::detail::ieee_finite(data[i])) {
            const Eigen::Index row = i % values.rows();
            const Eigen::Index col = i / values.rows();
            std::ostringstream message;
            message << label << " must contain only finite values (row "
                    << row << ", column " << col << ")";
            throw std::runtime_error(message.str());
        }
    }
}

void require_nonnegative_ids(
    const Eigen::Ref<const Eigen::VectorXi>& ids,
    const char* label,
    int threads = 1) {
    const int* data = ids.data();
    const Eigen::Index size = ids.size();
    std::uint64_t invalid = 0;
#ifdef HDFE_USE_OPENMP
#pragma omp parallel for schedule(static) if(threads > 1) num_threads(threads) reduction(| : invalid)
#else
    (void)threads;
#endif
    for (Eigen::Index i = 0; i < size; ++i) {
        invalid |= static_cast<std::uint64_t>(data[i] < 0);
    }
    if (invalid == 0) {
        return;
    }
    for (Eigen::Index i = 0; i < size; ++i) {
        if (data[i] < 0) {
            std::ostringstream message;
            message << label << " must contain only nonnegative IDs (row "
                    << i
                    << "); pandas.factorize() uses -1 for missing categories";
            throw std::runtime_error(message.str());
        }
    }
}

std::int64_t checked_frequency_weight_value(double raw) {
    constexpr double kMaxSafeInt64AsDouble =
        9223372036854774784.0;
    if (!hdfe::detail::ieee_finite(raw) || !(raw > 0.0) ||
        raw > kMaxSafeInt64AsDouble ||
        std::floor(raw) != raw) {
        throw std::runtime_error(
            "Frequency weights must be positive integers "
            "representable as int64");
    }
    const std::int64_t value = static_cast<std::int64_t>(raw);
    if (value <= 0) {
        throw std::runtime_error(
            "Frequency weights must be positive integers "
            "representable as int64");
    }
    return value;
}

void validate_frequency_weight_values(
    const Eigen::Ref<const Eigen::VectorXd>& weights) {
    for (Eigen::Index i = 0; i < weights.size(); ++i) {
        (void)checked_frequency_weight_value(weights[i]);
    }
}

std::int64_t checked_frequency_weight_sum(
    const Eigen::Ref<const Eigen::VectorXd>& weights,
    std::vector<std::int64_t>* integer_weights = nullptr) {
    if (integer_weights != nullptr) {
        integer_weights->resize(static_cast<std::size_t>(weights.size()));
    }
    std::int64_t total = 0;
    for (Eigen::Index i = 0; i < weights.size(); ++i) {
        const std::int64_t value =
            checked_frequency_weight_value(weights[i]);
        if (value > std::numeric_limits<std::int64_t>::max() - total) {
            throw std::runtime_error(
                "Total frequency weight exceeds the supported int64 range");
        }
        if (integer_weights != nullptr) {
            (*integer_weights)[static_cast<std::size_t>(i)] = value;
        }
        total += value;
    }
    return total;
}

inline int deterministic_moment_chunk_count(Eigen::Index n) {
    return detail::deterministic_parallel_chunk_count(n);
}

inline Eigen::Index deterministic_moment_chunk_begin(
    Eigen::Index n, int chunk, int chunks) {
    return detail::deterministic_parallel_chunk_begin(
        n, chunk, chunks);
}

inline Eigen::Index deterministic_moment_chunk_end(
    Eigen::Index n, int chunk, int chunks) {
    return detail::deterministic_parallel_chunk_end(
        n, chunk, chunks);
}

struct KahanSum {
    long double sum = 0.0L;
    long double c = 0.0L;
    void add(long double value) {
        const long double y = value - c;
        const long double t = sum + y;
        c = (t - sum) - y;
        sum = t;
    }
};

#ifdef HDFE_USE_OPENMP
// Rows per thread when target_rows_per_thread is 0 (automatic). Fixed effects
// absorbed without being retained use the denser value, still bounded by the
// problem-size cap in resolve_threads; every other path keeps one thread per
// 500 000 rows.
constexpr int kAutoRowsPerThreadAbsorb = 25000;
constexpr int kAutoRowsPerThreadUncapped = 500000;

// XHDFE_AUTO_ROWS_PER_THREAD=<positive integer> replaces
// kAutoRowsPerThreadAbsorb for the whole process; other values are ignored.
int auto_rows_per_thread_absorb() {
    static const int value = [] {
        const char* raw = std::getenv("XHDFE_AUTO_ROWS_PER_THREAD");
        if (raw == nullptr || *raw == '\0') {
            return kAutoRowsPerThreadAbsorb;
        }
        char* end = nullptr;
        const long long parsed = std::strtoll(raw, &end, 10);
        if (end == raw || *end != '\0' || parsed <= 0 ||
            parsed > std::numeric_limits<int>::max()) {
            return kAutoRowsPerThreadAbsorb;
        }
        return static_cast<int>(parsed);
    }();
    return value;
}
#endif

bool savefe_profile_enabled() {
    static const bool enabled = [] {
        const char* raw = std::getenv("XHDFE_PROFILE_SAVEFE");
        return raw != nullptr && *raw != '\0' && *raw != '0';
    }();
    return enabled;
}

void savefe_profile_log(const std::string& msg) {
    if (!savefe_profile_enabled()) {
        return;
    }
    std::cerr << "savefe_profile " << msg << '\n';
}

bool cpu_profile_enabled() {
    static const bool enabled = [] {
        const char* raw = std::getenv("XHDFE_PROFILE_CPU");
        return raw != nullptr && *raw != '\0' && *raw != '0';
    }();
    return enabled;
}

// P8 (CPU-W; design note section 3): the bounded MLSMR retry after a certified
// sweep primary is open to weighted fits (a weights vector, the vector of ones
// included) with the public Comparable intent, the Auto method and criterion
// and at most three FEs; every other retry condition is unchanged (tol 1e-8,
// trigger 1e-11, CPU). Early routing stays unweighted (its D1 calibration is).
// XHDFE_P8_CPU_WEIGHTED_RETRY=0 restores the unweighted-only retry.
bool cpu_weighted_retry_enabled() {
    static const bool enabled = [] {
        const char* e = std::getenv("XHDFE_P8_CPU_WEIGHTED_RETRY");
        return !(e != nullptr && e[0] == '0');
    }();
    return enabled;
}

// P8 (CPU-W, its accounting): a weighted retry runs within what the primary
// left of max_iter (nothing left: no retry, the primary stands), and the
// published iterations count the primary and the retry, the discarded retry
// included; the per-stage counters (auto_routing_retry_*) keep their meaning.
// An unweighted retry keeps the base accounting. XHDFE_P8_CPU_RETRY_ACCOUNTING=0
// restores the base accounting of the weighted retry (read once per process).
bool cpu_retry_accounting_enabled() {
    static const bool enabled = [] {
        const char* e = std::getenv("XHDFE_P8_CPU_RETRY_ACCOUNTING");
        return !(e != nullptr && e[0] == '0');
    }();
    return enabled;
}

// E1 (16nov2026; Verifications/low_memory_20261116/briefs/
// E1_SAVEFE_COMPARABLE_PROJECTION_FIRST.md): with saved effects in public
// reghdfe-comparable, a certified effect-capturing sweep that stopped above
// the floor of the mode is followed by the projection of the mode without
// capture, which then supplies the coefficients, covariance and residuals
// (fit(), publish_savefe_projection).
// XHDFE_SAVEFE_ACCURATE_PROJECTION=0 restores the capturing sweep's
// publication (read once per process).
bool savefe_accurate_projection_enabled() {
    static const bool enabled = [] {
        const char* e = std::getenv("XHDFE_SAVEFE_ACCURATE_PROJECTION");
        return !(e != nullptr && e[0] == '0' && e[1] == '\0');
    }();
    return enabled;
}

// XHDFE_TEST_SAVEFE_PROJECTION_ABANDON=1 (tests only, package D, round 09 E.2;
// read once per process): E1's projection is computed and then treated as not
// published, so that a test sees the fit publish the capturing primary with the
// tier's diagnostics, the finer blocks' included, restored.
bool savefe_projection_abandon_test() {
    static const bool on = [] {
        const char* e = std::getenv("XHDFE_TEST_SAVEFE_PROJECTION_ABANDON");
        return e != nullptr && e[0] == '1' && e[1] == '\0';
    }();
    return on;
}

// Package B (17nov2026; Verifications/corrigir_erros_20261117/briefs/B_STRICT_CUDA.md,
// b/RESPOSTA_DESENHO_B.md): a strict-residual fit on CUDA with the automatic
// method and criterion, no weights, no saved effects and no group() takes the
// route of a reghdfe-comparable request and is accepted on the largest absolute
// group mean of its delivered residual, D(e) <= tol. XHDFE_STRICT_CUDA_LEGACY_ACCEPTANCE=1
// restores today's branch and stored vector for those fits (read once per process).
bool strict_cuda_legacy_acceptance() {
    static const bool legacy = [] {
        const char* e = std::getenv("XHDFE_STRICT_CUDA_LEGACY_ACCEPTANCE");
        return e != nullptr && e[0] == '1' && e[1] == '\0';
    }();
    return legacy;
}

// Package B: XHDFE_STRICT_ACCEPT_TRACE=1 prints the acceptance of each fit in
// that scope (strict_accept_trace lines); off, nothing is computed for it.
// Stage 2a'': =2 also prints every fresh reading of the sweep-exit step and of the
// continuation (read once per process).
int strict_accept_trace_level() {
    static const int level = [] {
        const char* e = std::getenv("XHDFE_STRICT_ACCEPT_TRACE");
        if (e == nullptr || e[0] == '\0' || e[1] != '\0') return 0;
        return e[0] == '1' ? 1 : (e[0] == '2' ? 2 : 0);
    }();
    return level;
}

bool strict_accept_trace_on() {
    return strict_accept_trace_level() >= 1;
}

// Package B, stage 2b (b/RESPOSTA_2A3_B.md): the frozen stop of the direct sweep-exit
// step. XHDFE_STRICT_FROZEN_STOP = 0 (stage 2a' exactly) or anything else, unset
// included (step, the default: the step hands its state over when its last three
// power-of-two readings are bit for bit the same); read once per process. Stage 2c
// (b/RESPOSTA_2B_B_ADENDA.md) removed the value `all`, which now means the default: the
// continuation has no frozen exit (StrictContinuationReport::exit). Returns 1 or 0.
int strict_frozen_stop() {
    static const int mode = [] {
        const char* e = std::getenv("XHDFE_STRICT_FROZEN_STOP");
        if (e != nullptr && std::strcmp(e, "0") == 0) return 0;
        return 1;
    }();
    return mode;
}

const char* strict_frozen_stop_name(int mode) {
    return mode == 0 ? "0" : "step";
}

void cpu_profile_log_elapsed(
    const char* label,
    const std::chrono::steady_clock::time_point& start) {
    if (!cpu_profile_enabled()) {
        return;
    }
    const auto end = std::chrono::steady_clock::now();
    const std::chrono::duration<double, std::milli> elapsed = end - start;
    std::cerr << "cpu_profile label=" << label << " ms=" << elapsed.count() << '\n';
}

class SavefeTimer {
public:
    explicit SavefeTimer(const char* label)
        : label_(label), enabled_(savefe_profile_enabled()) {
        if (enabled_) {
            start_ = std::chrono::steady_clock::now();
        }
    }

    ~SavefeTimer() {
        if (!enabled_) {
            return;
        }
        const auto end = std::chrono::steady_clock::now();
        const std::chrono::duration<double, std::milli> elapsed = end - start_;
        std::cerr << "savefe_profile label=" << label_
                  << " ms=" << elapsed.count() << '\n';
    }

private:
    const char* label_;
    bool enabled_;
    std::chrono::steady_clock::time_point start_;
};

// XHDFE_TEST_DETERMINISTIC_CAPACITY=k (tests only, package D, 3.1; read once per
// process; off when unset or not an integer from 1 to 4096): the processors the
// deterministic partitions of a fit follow, in place of those visible to the
// process, so that a test on this host can give two processes base blocks that
// differ beyond the floor of 48. It changes no thread count.
int test_deterministic_capacity(int runtime_capacity) {
    static const int forced = [] {
        const char* e = std::getenv("XHDFE_TEST_DETERMINISTIC_CAPACITY");
        if (e == nullptr || e[0] == '\0') return 0;
        char* end = nullptr;
        const long value = std::strtol(e, &end, 10);
        return end != e && *end == '\0' && value >= 1 && value <= 4096 ? static_cast<int>(value) : 0;
    }();
    return forced > 0 ? forced : runtime_capacity;
}

class ScopedParallelRuntime {
public:
    ScopedParallelRuntime(int threads, int runtime_capacity)
        : deterministic_capacity_(test_deterministic_capacity(runtime_capacity)) {
#ifdef HDFE_USE_OPENMP
        previous_dynamic_ = omp_get_dynamic();
        previous_threads_ = omp_get_max_threads();
        omp_set_dynamic(0);
        omp_set_num_threads(std::max(1, threads));
#else
        (void)threads;
#endif
    }

    ~ScopedParallelRuntime() {
#ifdef HDFE_USE_OPENMP
        omp_set_num_threads(previous_threads_);
        omp_set_dynamic(previous_dynamic_);
#endif
    }

    ScopedParallelRuntime(const ScopedParallelRuntime&) = delete;
    ScopedParallelRuntime& operator=(const ScopedParallelRuntime&) = delete;

private:
    detail::ScopedDeterministicParallelCapacity deterministic_capacity_;
#ifdef HDFE_USE_OPENMP
    int previous_dynamic_ = 0;
    int previous_threads_ = 1;
#endif
};

// A serial computation that the calling thread used to run may run on a worker
// of a team and give the same bits only under the same floating-point controls,
// which belong to each thread: the x87 control word (x87_precision.hpp) and
// MXCSR (rounding, flush-to-zero, denormals-are-zero). A task loads the
// controls of the thread that opened the region and restores its own on exit.
// Other targets keep these reductions on the calling thread.
#if defined(HDFE_USE_OPENMP) && defined(__x86_64__) && defined(XHDFE_X87_PRECISION_CONTROL)
struct FpControls {
    unsigned short x87 = 0;
    unsigned int mxcsr = 0;

    bool traps_masked() const noexcept {
        return (x87 & 0x3fu) == 0x3fu && (mxcsr & 0x1f80u) == 0x1f80u;
    }
};

FpControls current_fp_controls() noexcept {
    FpControls controls;
    controls.x87 = detail::x87::control_word();
    __asm__ __volatile__("stmxcsr %0" : "=m"(controls.mxcsr) : : "memory");
    return controls;
}

void load_fp_controls(const FpControls& controls) noexcept {
    detail::x87::load_control_word(controls.x87);
    __asm__ __volatile__("ldmxcsr %0" : : "m"(controls.mxcsr) : "memory");
}

class ScopedFpControls {
public:
    explicit ScopedFpControls(const FpControls& wanted) noexcept
        : saved_(current_fp_controls()) {
        changed_ = saved_.x87 != wanted.x87 || saved_.mxcsr != wanted.mxcsr;
        if (changed_) {
            load_fp_controls(wanted);
        }
    }
    ~ScopedFpControls() {
        if (changed_) {
            load_fp_controls(saved_);
        }
    }
    ScopedFpControls(const ScopedFpControls&) = delete;
    ScopedFpControls& operator=(const ScopedFpControls&) = delete;

private:
    FpControls saved_;
    bool changed_ = false;
};
#endif

// Runs task(0), ..., task(count - 1), each one whole serial computation that
// writes only its own outputs, on a team of up to `threads` (task 0 is taken
// first: callers give it the longest chain). With one thread they run in that
// order on the calling thread. A task's exception is rethrown after the region,
// the lowest task's first, as the serial order would have met it.
template <class Task>
void run_serial_tasks_on_team(std::size_t count, const Task& task, int threads,
                              detail::ParallelWorkObserver& observer) {
#if defined(HDFE_USE_OPENMP) && defined(__x86_64__) && defined(XHDFE_X87_PRECISION_CONTROL)
    if (threads > 1 && count > 1 && !omp_in_parallel()) {
        const FpControls controls = current_fp_controls();
        // Keep a caller with unmasked FP traps on its original thread.
        if (controls.traps_masked()) {
            const int team = static_cast<int>(std::min(count, static_cast<std::size_t>(threads)));
            detail::InlineOrDynamicBuffer<std::exception_ptr> failed(count);
            observer.begin_region(team);
#pragma omp parallel for schedule(dynamic, 1) num_threads(team)
            for (std::size_t t = 0; t < count; ++t) {
                observer.observe_work();
                const ScopedFpControls scope(controls);
                try {
                    task(t);
                } catch (...) {
                    failed[t] = std::current_exception();
                }
            }
            observer.end_region();
            for (std::size_t t = 0; t < count; ++t) {
                if (failed[t]) {
                    std::rethrow_exception(failed[t]);
                }
            }
            return;
        }
    }
#else
    (void)threads;
    (void)observer;
#endif
    for (std::size_t t = 0; t < count; ++t) {
        task(t);
    }
}

// dst = src, element for element, copied by fixed blocks on a team, so that
// neither the first touch of a fresh dst nor the copy runs on one thread. A
// plain assignment below kAssignByBlocksMinElements or with one thread.
constexpr Eigen::Index kAssignByBlocksMinElements = Eigen::Index(1) << 20;
constexpr Eigen::Index kAssignByBlocksBlock = Eigen::Index(1) << 18;

template <class Vector>
void assign_by_blocks(Vector& dst, const Vector& src, int threads,
                      detail::ParallelWorkObserver& observer) {
    const Eigen::Index n = src.size();
    const Eigen::Index blocks = n / kAssignByBlocksBlock + (n % kAssignByBlocksBlock != 0);
    int team = 1;
#ifdef HDFE_USE_OPENMP
    if (!omp_in_parallel() && n >= kAssignByBlocksMinElements) {
        team = static_cast<int>(std::min<Eigen::Index>(std::max(1, threads), blocks));
    }
#else
    (void)threads;
#endif
    if (team <= 1 || &dst == &src) {
        dst = src;
        return;
    }
    dst.resize(n);
    using Scalar = typename Vector::Scalar;
    const Scalar* const from = src.data();
    Scalar* const to = dst.data();
    observer.begin_region(team);
#ifdef HDFE_USE_OPENMP
#pragma omp parallel for schedule(static) num_threads(team)
#endif
    for (Eigen::Index b = 0; b < blocks; ++b) {
        const Eigen::Index lo = b * kAssignByBlocksBlock;
        const Eigen::Index count = std::min(n - lo, kAssignByBlocksBlock);
        observer.observe_work();
        std::memcpy(to + lo, from + lo, static_cast<std::size_t>(count) * sizeof(Scalar));
    }
    observer.end_region();
}


double weighted_sum_of_squares(const Eigen::Ref<const Eigen::VectorXd>& values,
                               const Eigen::VectorXd* weights) {
    const int n = static_cast<int>(values.size());
    if (n == 0) {
        return 0.0;
    }
    const double* v = values.data();
    KahanSum sum;
    if (!weights) {
        for (int i = 0; i < n; ++i) {
            const long double vi = static_cast<long double>(v[i]);
            sum.add(vi * vi);
        }
        return static_cast<double>(sum.sum);
    }
    const double* w = weights->data();
    for (int i = 0; i < n; ++i) {
        const long double vi = static_cast<long double>(v[i]);
        sum.add(vi * vi * static_cast<long double>(w[i]));
    }
    return static_cast<double>(sum.sum);
}

double weighted_mean(const Eigen::Ref<const Eigen::VectorXd>& values,
                     const Eigen::VectorXd* weights,
                     double* sum_weights_out = nullptr) {
    const int n = static_cast<int>(values.size());
    if (n == 0) {
        if (sum_weights_out) {
            *sum_weights_out = 0.0;
        }
        return 0.0;
    }
    const double* v = values.data();
    if (!weights) {
        if (sum_weights_out) {
            *sum_weights_out = static_cast<double>(n);
        }
        KahanSum sum;
        for (int i = 0; i < n; ++i) {
            sum.add(static_cast<long double>(v[i]));
        }
        return static_cast<double>(sum.sum / static_cast<long double>(n));
    }
    const double* w = weights->data();
    KahanSum sum_w;
    KahanSum sum_yw;
    for (int i = 0; i < n; ++i) {
        const long double wi = static_cast<long double>(w[i]);
        sum_w.add(wi);
        sum_yw.add(static_cast<long double>(v[i]) * wi);
    }
    const long double denom = sum_w.sum;
    if (!(denom > 0.0L)) {
        throw std::runtime_error("Weights must sum to a positive value");
    }
    if (sum_weights_out) {
        *sum_weights_out = static_cast<double>(denom);
    }
    return static_cast<double>(sum_yw.sum / denom);
}

double centered_sum_of_squares(const Eigen::Ref<const Eigen::VectorXd>& x);

double psd_scale_sample_standard_deviation(
    const Eigen::Ref<const Eigen::VectorXd>& values,
    const Eigen::VectorXd* weights,
    bool weights_are_frequencies) {
    const double n_rows = static_cast<double>(values.size());
    if (!weights || !weights_are_frequencies) {
        if (n_rows <= 1.0) {
            return 0.0;
        }
        return std::sqrt(centered_sum_of_squares(values) / (n_rows - 1.0));
    }

    const double* value_ptr = values.data();
    const double* weight_ptr = weights->data();
    KahanSum sum_weights;
    KahanSum weighted_sum;
    const long double origin = values.size() ? static_cast<long double>(values[0]) : 0.0L;
    for (Eigen::Index i = 0; i < values.size(); ++i) {
        const long double value = static_cast<long double>(value_ptr[i]) - origin;
        const long double weight = static_cast<long double>(weight_ptr[i]);
        sum_weights.add(weight);
        weighted_sum.add(weight * value);
    }
    const long double expanded_n = sum_weights.sum;
    if (!(expanded_n > 1.0L)) {
        return 0.0;
    }
    const long double mean = weighted_sum.sum / expanded_n;
    KahanSum centered_sum_squares;
    for (Eigen::Index i = 0; i < values.size(); ++i) {
        const long double value = static_cast<long double>(value_ptr[i]) - origin - mean;
        centered_sum_squares.add(static_cast<long double>(weight_ptr[i]) * value * value);
    }
    const long double variance =
        std::max(0.0L, centered_sum_squares.sum / (expanded_n - 1.0L));
    return std::sqrt(static_cast<double>(variance));
}

double fixed_chunk_weighted_mean(
    const Eigen::Ref<const Eigen::VectorXd>& values,
    const Eigen::VectorXd* weights,
    int requested_threads = 0,
    double* sum_weights_out = nullptr,
    detail::ParallelWorkObserver* observer = nullptr) {
    const Eigen::Index n = values.size();
    if (n == 0) {
        if (sum_weights_out) {
            *sum_weights_out = 0.0;
        }
        return 0.0;
    }
    const int chunks = deterministic_moment_chunk_count(n);
    detail::InlineOrDynamicBuffer<long double> numerator(
        static_cast<std::size_t>(chunks));
    detail::InlineOrDynamicBuffer<long double> denominator(
        static_cast<std::size_t>(chunks));
    const double* value_ptr = values.data();
    const double* weight_ptr = weights ? weights->data() : nullptr;
    int threads = 1;
#ifdef HDFE_USE_OPENMP
    threads = requested_threads > 0 ? requested_threads : omp_get_max_threads();
    threads = std::max(1, threads);
#else
    (void)requested_threads;
#endif

    if (observer) {
        observer->begin_region(threads);
    }
#ifdef HDFE_USE_OPENMP
#pragma omp parallel for schedule(static, 1) num_threads(threads)
#endif
    for (int chunk = 0; chunk < chunks; ++chunk) {
        if (observer) {
            observer->observe_work();
        }
        const Eigen::Index begin =
            deterministic_moment_chunk_begin(n, chunk, chunks);
        const Eigen::Index end =
            deterministic_moment_chunk_end(n, chunk, chunks);
        KahanSum num;
        KahanSum den;
        if (weight_ptr) {
            for (Eigen::Index i = begin; i < end; ++i) {
                const long double w = static_cast<long double>(weight_ptr[i]);
                den.add(w);
                num.add(static_cast<long double>(value_ptr[i]) * w);
            }
        } else {
            for (Eigen::Index i = begin; i < end; ++i) {
                num.add(static_cast<long double>(value_ptr[i]));
            }
            den.sum = static_cast<long double>(end - begin);
        }
        numerator[static_cast<std::size_t>(chunk)] = num.sum;
        denominator[static_cast<std::size_t>(chunk)] = den.sum;
    }
    if (observer) {
        observer->end_region();
    }

    KahanSum num_total;
    KahanSum den_total;
    for (int chunk = 0; chunk < chunks; ++chunk) {
        num_total.add(numerator[static_cast<std::size_t>(chunk)]);
        den_total.add(denominator[static_cast<std::size_t>(chunk)]);
    }
    if (!(den_total.sum > 0.0L)) {
        throw std::runtime_error("Weights must sum to a positive value");
    }
    if (sum_weights_out) {
        *sum_weights_out = static_cast<double>(den_total.sum);
    }
    return static_cast<double>(num_total.sum / den_total.sum);
}

enum class FeNormalizeStyle { Reghdfe, Component };

FeNormalizeStyle resolve_fe_normalize_style(StatsStyle stats_style) {
    (void)stats_style;
    const char* raw = std::getenv("XHDFE_FE_NORMALIZE");
    if (!raw || !*raw) {
        return FeNormalizeStyle::Component;
    }
    std::string value(raw);
    std::transform(value.begin(), value.end(), value.begin(), [](unsigned char c) {
        return static_cast<char>(std::tolower(c));
    });
    if (value == "reghdfe" || value == "mean" || value == "mean_only") {
        return FeNormalizeStyle::Reghdfe;
    }
    if (value == "component" || value == "components") {
        return FeNormalizeStyle::Component;
    }
    return FeNormalizeStyle::Component;
}

struct FeDiagStats {
    double mean = 0.0;
    double min = 0.0;
    double max = 0.0;
    double absmax = 0.0;
};

FeDiagStats summarize_vector(const Eigen::Ref<const Eigen::VectorXd>& values,
                             const Eigen::VectorXd* weights) {
    FeDiagStats stats;
    const int n = static_cast<int>(values.size());
    if (n == 0) {
        return stats;
    }
    const double* v = values.data();
    double min_val = v[0];
    double max_val = v[0];
    double abs_max = std::abs(v[0]);
    for (int i = 1; i < n; ++i) {
        const double val = v[i];
        min_val = std::min(min_val, val);
        max_val = std::max(max_val, val);
        abs_max = std::max(abs_max, std::abs(val));
    }
    stats.mean = weighted_mean(values, weights);
    stats.min = min_val;
    stats.max = max_val;
    stats.absmax = abs_max;
    return stats;
}

double max_abs_diff(const Eigen::Ref<const Eigen::VectorXd>& a,
                    const Eigen::Ref<const Eigen::VectorXd>& b) {
    const int n = static_cast<int>(a.size());
    if (n == 0 || b.size() != n) {
        return 0.0;
    }
    const double* ap = a.data();
    const double* bp = b.data();
    double max_diff = 0.0;
    for (int i = 0; i < n; ++i) {
        max_diff = std::max(max_diff, std::abs(ap[i] - bp[i]));
    }
    return max_diff;
}

void maybe_write_fe_diagnostics(const Eigen::Ref<const Eigen::VectorXd>& y,
                                const Eigen::Ref<const Eigen::MatrixXd>& X,
                                const Eigen::VectorXd& coefficients,
                                const std::vector<Eigen::VectorXd>& fe_effects,
                                bool fit_intercept,
                                const Eigen::VectorXd* weights,
                                const Eigen::Ref<const Eigen::VectorXd>& residuals,
                                int abs_iter,
                                int fe_recovery_iter,
                                bool fe_recovery_converged,
                                double fe_recovery_max_delta,
                                const char* fe_recovery_method) {
    const char* path = std::getenv("XHDFE_FE_DIAG_FILE");
    if (!path || *path == '\0') {
        return;
    }
    if (fe_effects.empty()) {
        return;
    }
    std::ofstream out(path, std::ios::app);
    if (!out) {
        return;
    }
    out << std::setprecision(17);
    const auto now = std::chrono::system_clock::now().time_since_epoch();
    const auto stamp =
        std::chrono::duration_cast<std::chrono::milliseconds>(now).count();

    const int n = static_cast<int>(y.size());
    const int total_coefs = static_cast<int>(coefficients.size());
    const int slope_cols = fit_intercept ? std::max(0, total_coefs - 1) : total_coefs;
    Eigen::VectorXd fitted = Eigen::VectorXd::Zero(n);
    if (slope_cols > 0) {
        fitted.noalias() = X * coefficients.head(slope_cols);
    }
    if (fit_intercept && total_coefs > slope_cols) {
        fitted.array() += coefficients(slope_cols);
    }
    Eigen::VectorXd partial = y - fitted;

    Eigen::VectorXd fe_total = Eigen::VectorXd::Zero(n);
    for (const auto& fe_vec : fe_effects) {
        if (fe_vec.size() == n) {
            fe_total.noalias() += fe_vec;
        }
    }

    Eigen::VectorXd residual_calc = partial - fe_total;
    const double resid_diff = max_abs_diff(residual_calc, residuals);

    const FeDiagStats partial_stats = summarize_vector(partial, weights);
    const FeDiagStats fe_total_stats = summarize_vector(fe_total, weights);
    const FeDiagStats resid_stats = summarize_vector(residual_calc, weights);

    out << "run_id_ms=" << stamp
        << " nobs=" << n
        << " nfe=" << fe_effects.size()
        << " fit_intercept=" << (fit_intercept ? 1 : 0)
        << " weighted=" << (weights ? 1 : 0)
        << " abs_iter=" << abs_iter
        << " fe_recovery_iter=" << fe_recovery_iter
        << " fe_recovery_converged=" << (fe_recovery_converged ? 1 : 0)
        << " fe_recovery_max_delta=" << fe_recovery_max_delta
        << " fe_recovery_method=" << (fe_recovery_method ? fe_recovery_method : "unknown")
        << '\n';
    out << "partial mean=" << partial_stats.mean
        << " min=" << partial_stats.min
        << " max=" << partial_stats.max
        << " absmax=" << partial_stats.absmax
        << '\n';
    out << "fe_total mean=" << fe_total_stats.mean
        << " min=" << fe_total_stats.min
        << " max=" << fe_total_stats.max
        << " absmax=" << fe_total_stats.absmax
        << '\n';
    out << "residual mean=" << resid_stats.mean
        << " min=" << resid_stats.min
        << " max=" << resid_stats.max
        << " absmax=" << resid_stats.absmax
        << '\n';
    out << "residual_diff_absmax=" << resid_diff << '\n';
    for (std::size_t d = 0; d < fe_effects.size(); ++d) {
        const FeDiagStats fe_stats = summarize_vector(fe_effects[d], weights);
        out << "fe_dim=" << d
            << " mean=" << fe_stats.mean
            << " min=" << fe_stats.min
            << " max=" << fe_stats.max
            << " absmax=" << fe_stats.absmax
            << '\n';
    }
    out << "----" << '\n';
}

double compute_total_sum_of_squares(const Eigen::Ref<const Eigen::VectorXd>& y,
                                    const Eigen::VectorXd* weights,
                                    double* sum_weights_out = nullptr) {
    const int n = static_cast<int>(y.size());
    if (n == 0) {
        if (sum_weights_out) {
            *sum_weights_out = 0.0;
        }
        return 0.0;
    }
    const double mean = weighted_mean(y, weights, sum_weights_out);
    const double* y_ptr = y.data();
    KahanSum sum;
    if (!weights) {
        for (int i = 0; i < n; ++i) {
            const long double diff = static_cast<long double>(y_ptr[i] - mean);
            sum.add(diff * diff);
        }
        return static_cast<double>(sum.sum);
    }
    const double* w = weights->data();
    for (int i = 0; i < n; ++i) {
        const long double diff = static_cast<long double>(y_ptr[i] - mean);
        sum.add(diff * diff * static_cast<long double>(w[i]));
    }
    return static_cast<double>(sum.sum);
}

void normalize_nonfrequency_weighted_fit_stats(HdfeResults& results,
                                               bool weights_are_frequencies,
                                               const Eigen::VectorXd* weights,
                                               double sum_weights_hint) {
    if (!weights || weights_are_frequencies) {
        return;
    }
    const double nobs = static_cast<double>(results.nobs);
    if (!(nobs > 0.0)) {
        return;
    }
    double sum_w = sum_weights_hint;
    if (!(sum_w > 0.0) || !hdfe::detail::ieee_finite(sum_w)) {
        sum_w = weights->sum();
    }
    if (!(sum_w > 0.0) || !hdfe::detail::ieee_finite(sum_w)) {
        return;
    }
    if (std::abs(sum_w - nobs) <= 1e-12 * std::max(1.0, nobs)) {
        return;
    }
    const double scale = nobs / sum_w;
    if (!(scale > 0.0) || !hdfe::detail::ieee_finite(scale)) {
        return;
    }
    results.rss *= scale;
    results.tss *= scale;
    results.tss_within *= scale;
    results.sigma2 *= scale;
}

Eigen::MatrixXd maybe_add_intercept(const Eigen::Ref<const Eigen::MatrixXd>& X, bool fit_intercept) {
    if (!fit_intercept) {
        return X;
    }
    Eigen::MatrixXd design(X.rows(), X.cols() + 1);
    if (X.size() > 0) {
        design.block(0, 0, X.rows(), X.cols()) = X;
    }
    design.col(X.cols()).setOnes();
    return design;
}

Eigen::MatrixXd append_matrix(const Eigen::Ref<const Eigen::MatrixXd>& left,
                              const Eigen::MatrixXd* right) {
    if (!right || right->cols() == 0) {
        return left;
    }
    if (right->rows() != left.rows()) {
        throw std::runtime_error("Instrument matrix must have the same number of rows as X");
    }
    Eigen::MatrixXd combined(left.rows(), left.cols() + right->cols());
    if (left.cols() > 0) {
        combined.block(0, 0, left.rows(), left.cols()) = left;
    }
    combined.block(0, left.cols(), right->rows(), right->cols()) = *right;
    return combined;
}

bool fix_psd(Eigen::MatrixXd& V) {
    if (V.rows() == 0 || V.cols() == 0) {
        return false;
    }
    V = (0.5 * (V + V.transpose())).eval();
    double largest = 0.0;
    double smallest = std::numeric_limits<double>::infinity();
    for (Eigen::Index j = 0; j < V.rows(); ++j) {
        const double magnitude = std::abs(V(j,j));
        if (magnitude > 0.0) {
            largest = std::max(largest, magnitude);
            smallest = std::min(smallest, magnitude);
        }
    }
    if (hdfe::detail::ieee_finite(largest) && smallest > 0.0 &&
        largest / smallest > 16777216.0) {
        using WideMatrix = Eigen::Matrix<detail::OlsWide, Eigen::Dynamic, Eigen::Dynamic>;
        const WideMatrix wide = V.cast<detail::OlsWide>();
        Eigen::SelfAdjointEigenSolver<WideMatrix> solver(wide);
        if (solver.info() != Eigen::Success)
            throw std::runtime_error("Multiway covariance PSD projection did not converge; no estimates returned");
        auto values = solver.eigenvalues().eval();
        bool changed = false;
        for (Eigen::Index j = 0; j < values.size(); ++j) {
            if (values[j] < detail::OlsWide(0.0)) {
                values[j] = detail::OlsWide(0.0);
                changed = true;
            }
        }
        if (changed) {
            const WideMatrix projected =
                solver.eigenvectors() * values.asDiagonal() * solver.eigenvectors().transpose();
            V = projected.cast<double>();
        }
        return changed;
    }
    Eigen::SelfAdjointEigenSolver<Eigen::MatrixXd> es(V);
    if (es.info() != Eigen::Success) {
        return false;
    }
    Eigen::VectorXd lambda = es.eigenvalues();
    const double min_lambda = lambda.minCoeff();
    if (min_lambda >= 0.0) {
        return false;
    }
    lambda = lambda.cwiseMax(0.0);
    V = es.eigenvectors() * lambda.asDiagonal() * es.eigenvectors().transpose();
    return true;
}

// CovMatrix/BlockMatrix are Eigen::MatrixXd (ordinary path) or the OlsWide
// matrix retained by the wide IV solve; Real selects the repair arithmetic.
template <typename Real, typename CovMatrix, typename BlockMatrix>
void repair_intercept_covariance_spectral(
    CovMatrix& covariance, const BlockMatrix& original_scaled_slopes,
    const Eigen::VectorXd& scale) {
    using Matrix = Eigen::Matrix<Real, Eigen::Dynamic, Eigen::Dynamic>;
    using Vector = Eigen::Matrix<Real, Eigen::Dynamic, 1>;
    using Scalar = typename CovMatrix::Scalar;
    auto scalar_finite = [](const Scalar& value) {
        if constexpr (std::is_same_v<Scalar, double>) return hdfe::detail::ieee_finite(value);
        else return value.finite();
    };
    const int slopes = static_cast<int>(original_scaled_slopes.rows());
    const Matrix block = original_scaled_slopes.template cast<Real>();
    Eigen::SelfAdjointEigenSolver<Matrix> solver(block);
    if (solver.info() != Eigen::Success)
        throw std::runtime_error("Intercept covariance PSD repair did not converge; no estimates returned");
    Vector cross(slopes);
    for (int j = 0; j < slopes; ++j)
        cross[j] = Real(scale[j]) * Real(covariance(j, slopes)) * Real(scale[slopes]);
    const Vector coordinates = solver.eigenvectors().transpose() * cross;
    Vector projected = Vector::Zero(slopes);
    Real required = Real(0.0);
    for (int j = 0; j < slopes; ++j) {
        const Real eigenvalue = solver.eigenvalues()[j];
        // Keep exactly the positive spectrum used by the original PSD cut.
        // Re-diagonalising its rounded reconstruction could invent tiny ranks.
        if (eigenvalue > Real(0.0)) {
            projected += solver.eigenvectors().col(j) * coordinates[j];
            const double coordinate_magnitude = std::abs(
                Eigen::internal::cast<Real, double>(coordinates[j]));
            const double eigenvalue_magnitude =
                Eigen::internal::cast<Real, double>(eigenvalue);
            // Only reorder when the square risks losing range and division
            // first moves away from that risk. In a wide spectrum, dividing
            // first unconditionally can overflow a representable Schur term.
            if ((coordinate_magnitude > 0.0 && coordinate_magnitude < 0x1p-511 &&
                 eigenvalue_magnitude < 1.0) ||
                (coordinate_magnitude > 0x1p511 && eigenvalue_magnitude > 1.0)) {
                if constexpr (std::is_same_v<Real, double>) {
                    required += detail::OlsWide::mul(coordinates[j],
                        detail::OlsWide::div(coordinates[j], eigenvalue));
                } else {
                    required += coordinates[j] * (coordinates[j] / eigenvalue);
                }
            } else {
                required += coordinates[j] * coordinates[j] / eigenvalue;
            }
        }
    }
    const Real intercept_scale = Real(scale[slopes]);
    const Real previous = Real(covariance(slopes, slopes)) *
                          intercept_scale * intercept_scale;
    const Scalar variance = Eigen::internal::cast<Real, Scalar>(
        (required > previous ? required : previous) /
        (intercept_scale * intercept_scale));
    if (!scalar_finite(variance))
        throw std::runtime_error("Intercept covariance PSD repair exceeded numeric range; no estimates returned");
    for (int j = 0; j < slopes; ++j) {
        const Scalar value = Eigen::internal::cast<Real, Scalar>(
            projected[j] / (Real(scale[j]) * intercept_scale));
        if (!scalar_finite(value))
            throw std::runtime_error("Intercept covariance PSD repair exceeded numeric range; no estimates returned");
        covariance(j, slopes) = covariance(slopes, j) = value;
    }
    covariance(slopes, slopes) = variance;
}

// Same policy on the covariance retained in OlsWide by the wide IV solve:
// the clip and the repair then share one arithmetic, before any rounding.
void repair_intercept_covariance_wide(
    detail::OlsWideCovariance::Matrix& covariance,
    const detail::OlsWideCovariance::Matrix& original_slopes,
    const Eigen::VectorXd& scale) {
    const int slopes = static_cast<int>(original_slopes.rows());
    if (slopes == 0) return;
    detail::OlsWideCovariance::Matrix block(slopes, slopes);
    for (int i = 0; i < slopes; ++i)
        for (int j = 0; j < slopes; ++j)
            block(i, j) = detail::OlsWide(scale[i]) *
                ((original_slopes(i, j) + original_slopes(j, i)) * detail::OlsWide(0.5)) *
                detail::OlsWide(scale[j]);
    repair_intercept_covariance_spectral<detail::OlsWide>(covariance, block, scale);
}

void repair_intercept_covariance(
    Eigen::MatrixXd& covariance, const Eigen::MatrixXd& original_slopes,
    const Eigen::VectorXd& scale) {
    const int slopes = static_cast<int>(original_slopes.rows());
    if (slopes == 0) return;
    Eigen::MatrixXd block = scale.head(slopes).asDiagonal() * original_slopes *
                            scale.head(slopes).asDiagonal();
    block = (0.5 * (block + block.transpose())).eval();
    double largest = 0.0;
    double smallest = std::numeric_limits<double>::infinity();
    for (int j = 0; j < slopes; ++j) {
        const double magnitude = std::abs(block(j, j));
        if (magnitude > 0.0) {
            largest = std::max(largest, magnitude);
            smallest = std::min(smallest, magnitude);
        }
    }
    // Match fix_psd's arithmetic for the same original slope block.
    if (hdfe::detail::ieee_finite(largest) && smallest > 0.0 &&
        largest / smallest > 16777216.0) {
        repair_intercept_covariance_spectral<detail::OlsWide>(covariance, block, scale);
    } else {
        repair_intercept_covariance_spectral<double>(covariance, block, scale);
    }
}

struct ClusterInterceptMeat {
    Eigen::VectorXd cross;
    double alpha = 0.0;
    double u_t = 0.0;
    int num_clusters = 0;
};

ClusterInterceptMeat compute_cluster_intercept_meat(
    const Eigen::Ref<const Eigen::MatrixXd>& X,
    const Eigen::Ref<const Eigen::VectorXd>& residuals,
    const Eigen::VectorXd* weights,
    const Eigen::Ref<const Eigen::VectorXd>& c,
    const Eigen::VectorXi& clusters) {
    const int n = static_cast<int>(X.rows());
    const int p = static_cast<int>(X.cols());
    if (clusters.size() != n || residuals.size() != n || c.size() != n) {
        throw std::runtime_error("Intercept meat inputs must have matching lengths");
    }

    ClusterInterceptMeat out;
    out.cross = Eigen::VectorXd::Zero(p);
    out.alpha = 0.0;
    out.u_t = 0.0;
    out.num_clusters = 0;
    if (n == 0) {
        return out;
    }

    int min_id = clusters(0);
    int max_id = clusters(0);
    for (int i = 1; i < n; ++i) {
        const int v = clusters(i);
        min_id = std::min(min_id, v);
        max_id = std::max(max_id, v);
    }
    const long long range_ll =
        static_cast<long long>(max_id) - static_cast<long long>(min_id) + 1LL;
    constexpr long long kDenseRangeCap = 50000000LL;
    const bool dense_ok =
        min_id >= 0 && range_ll > 0 && range_ll <= kDenseRangeCap &&
        range_ll <= static_cast<long long>(n) * 2LL;
    const int range = dense_ok ? static_cast<int>(range_ll) : 0;

    std::vector<double> aggregated_s;
    std::vector<double> aggregated_t;
    std::vector<double> aggregated_u;
    int next_cluster = 0;
    if (dense_ok) {
        aggregated_s.assign(static_cast<std::size_t>(range) * static_cast<std::size_t>(p), 0.0);
        aggregated_t.assign(static_cast<std::size_t>(range), 0.0);
        aggregated_u.assign(static_cast<std::size_t>(range), 0.0);
        std::vector<uint8_t> seen(static_cast<std::size_t>(range), 0);
        for (int i = 0; i < n; ++i) {
            const int idx = clusters(i) - min_id;
            if (!seen[static_cast<std::size_t>(idx)]) {
                seen[static_cast<std::size_t>(idx)] = 1;
                ++next_cluster;
            }
            const double wi = weights ? (*weights)(i) : 1.0;
            const double ui = residuals(i);
            const double score_u = wi * ui;
            if (p > 0) {
                double* score = aggregated_s.data() +
                                static_cast<std::size_t>(idx) * static_cast<std::size_t>(p);
                for (int j = 0; j < p; ++j) {
                    score[static_cast<std::size_t>(j)] += X(i, j) * score_u;
                }
            }
            aggregated_t[static_cast<std::size_t>(idx)] += c(i) * ui;
            aggregated_u[static_cast<std::size_t>(idx)] += score_u;
        }
        for (int g = 0; g < range; ++g) {
            if (!seen[static_cast<std::size_t>(g)]) {
                continue;
            }
            const double ug = aggregated_u[static_cast<std::size_t>(g)];
            const double tg = aggregated_t[static_cast<std::size_t>(g)];
            out.alpha += tg * tg;
            out.u_t += ug * tg;
            if (p > 0) {
                const Eigen::Map<const Eigen::VectorXd> score(
                    aggregated_s.data() + static_cast<std::size_t>(g) * static_cast<std::size_t>(p), p);
                out.cross.noalias() += score * tg;
            }
        }
        out.num_clusters = next_cluster;
        return out;
    }

    std::unordered_map<int, int> cluster_map;
    cluster_map.reserve(static_cast<std::size_t>(n));
    aggregated_s.reserve(static_cast<std::size_t>(n) * static_cast<std::size_t>(p) /
                         static_cast<std::size_t>(8));
    aggregated_t.reserve(static_cast<std::size_t>(n) / static_cast<std::size_t>(8));
    aggregated_u.reserve(static_cast<std::size_t>(n) / static_cast<std::size_t>(8));
    for (int i = 0; i < n; ++i) {
        const int raw_id = clusters(i);
        auto it = cluster_map.find(raw_id);
        int cluster_idx;
        if (it == cluster_map.end()) {
            cluster_idx = next_cluster;
            ++next_cluster;
            cluster_map.emplace(raw_id, cluster_idx);
            aggregated_s.resize(static_cast<std::size_t>(next_cluster) * static_cast<std::size_t>(p),
                                0.0);
            aggregated_t.resize(static_cast<std::size_t>(next_cluster), 0.0);
            aggregated_u.resize(static_cast<std::size_t>(next_cluster), 0.0);
        } else {
            cluster_idx = it->second;
        }
        const double wi = weights ? (*weights)(i) : 1.0;
        const double ui = residuals(i);
        const double score_u = wi * ui;
        if (p > 0) {
            double* score = aggregated_s.data() +
                            static_cast<std::size_t>(cluster_idx) * static_cast<std::size_t>(p);
            for (int j = 0; j < p; ++j) {
                score[static_cast<std::size_t>(j)] += X(i, j) * score_u;
            }
        }
        aggregated_t[static_cast<std::size_t>(cluster_idx)] += c(i) * ui;
        aggregated_u[static_cast<std::size_t>(cluster_idx)] += score_u;
    }
    for (int g = 0; g < next_cluster; ++g) {
        const double ug = aggregated_u[static_cast<std::size_t>(g)];
        const double tg = aggregated_t[static_cast<std::size_t>(g)];
        out.alpha += tg * tg;
        out.u_t += ug * tg;
        if (p > 0) {
            const Eigen::Map<const Eigen::VectorXd> score(
                aggregated_s.data() + static_cast<std::size_t>(g) * static_cast<std::size_t>(p), p);
            out.cross.noalias() += score * tg;
        }
    }
    out.num_clusters = next_cluster;
    return out;
}

Eigen::VectorXi combine_clusters(const std::vector<Eigen::VectorXi>& clusters,
                                 const std::vector<int>& dims);

ClusterInterceptMeat compute_multiway_intercept_meat(
    const Eigen::Ref<const Eigen::MatrixXd>& X,
    const Eigen::Ref<const Eigen::VectorXd>& residuals,
    const Eigen::VectorXd* weights,
    const Eigen::Ref<const Eigen::VectorXd>& c,
    const std::vector<Eigen::VectorXi>& clusters,
    ClusterDofMethod g_df,
    bool g_adj,
    double df_resid,
    double n_effective,
    const detail::ClusterPasses* passes = nullptr) {
    const int m = static_cast<int>(clusters.size());
    if (m <= 0) {
        throw std::runtime_error("At least one cluster dimension is required");
    }
    if (m > 20) {
        throw std::runtime_error("Multi-way clustering supports up to 20 cluster dimensions");
    }
    const int n = static_cast<int>(residuals.size());
    for (const auto& cvec : clusters) {
        if (cvec.size() != n) {
            throw std::runtime_error("Cluster vector length must equal the number of observations");
        }
    }

    // Phase 5b: a ready carrier from this list (a constant consumer) replaces the
    // count pass with the G of the meats of one dimension, which run anyway, and
    // lends the OLS stage's pair to mask 3; anything else gives today's code.
    if (!detail::cluster_shared_passes_enabled()) passes = nullptr;
    const std::size_t masks = (static_cast<std::size_t>(1) << m) - 1;
    const bool consuming = passes && passes->ready && passes->source == &clusters &&
                           passes->mask_counts.size() == masks;
    const bool lend_pair = consuming && m == 2 && passes->pair.size() == n;
    int min_clusters = std::numeric_limits<int>::max();
    if (!consuming) {
        for (const auto& cvec : clusters) {
            std::unordered_map<int, int> uniq;
            uniq.reserve(static_cast<std::size_t>(n));
            for (int i = 0; i < n; ++i) {
                uniq.emplace(cvec(i), 1);
            }
            min_clusters = std::min(min_clusters, static_cast<int>(uniq.size()));
        }
    }

    ClusterInterceptMeat total;
    total.cross = Eigen::VectorXd::Zero(X.cols());
    total.alpha = 0.0;
    total.u_t = 0.0;
    total.num_clusters = (min_clusters == std::numeric_limits<int>::max()) ? 0 : min_clusters;

    const std::uint64_t max_mask = (static_cast<std::uint64_t>(1) << m);
    std::vector<int> dims;
    dims.reserve(static_cast<std::size_t>(m));
    for (std::uint64_t mask = 1; mask < max_mask; ++mask) {
        dims.clear();
        for (int j = 0; j < m; ++j) {
            if (mask & (static_cast<std::uint64_t>(1) << j)) {
                dims.push_back(j);
            }
        }
        const Eigen::VectorXi* lent = (lend_pair && mask == 3) ? &passes->pair : nullptr;
        Eigen::VectorXi combined;
        if (!lent) combined = combine_clusters(clusters, dims);
        ClusterInterceptMeat meat =
            compute_cluster_intercept_meat(X, residuals, weights, c, lent ? *lent : combined);
        if (consuming && dims.size() == 1) {
            min_clusters = std::min(min_clusters, meat.num_clusters);
        }
        double scale = 1.0;
        if (g_df == ClusterDofMethod::Conventional && g_adj && meat.num_clusters > 1) {
            scale = static_cast<double>(meat.num_clusters) /
                    static_cast<double>(meat.num_clusters - 1);
        }
        const double sign = (dims.size() % 2 == 1) ? 1.0 : -1.0;
        total.cross.noalias() += sign * scale * meat.cross;
        total.alpha += sign * scale * meat.alpha;
        total.u_t += sign * scale * meat.u_t;
    }
    if (consuming) {
        // The final assignment: today's minimum, from the meats of one dimension.
        total.num_clusters = (min_clusters == std::numeric_limits<int>::max()) ? 0 : min_clusters;
    }
    if (cpu_profile_enabled()) {
        std::cerr << "cpu_profile label=cluster_passes site=intercept counts="
                  << (consuming ? "carrier" : "recount") << " pair=" << (lend_pair ? "shared" : "built") << '\n';
    }

    double scale = 1.0;
    if (df_resid > 0.0) {
        scale *= (n_effective - 1.0) / df_resid;
    }
    if (g_df == ClusterDofMethod::Min && g_adj && min_clusters > 1) {
        scale *= static_cast<double>(min_clusters) /
                 static_cast<double>(min_clusters - 1);
    }
    total.cross *= scale;
    total.alpha *= scale;
    total.u_t *= scale;
    return total;
}

// Phase 5b: the OLS stage's cluster_passes line (the stage prints none; its catch
// prints the wide route): carrier when it published the carrier, else recount.
void log_cluster_passes_ols(const detail::ClusterPasses* passes) {
    if (!cpu_profile_enabled()) return;
    std::cerr << "cpu_profile label=cluster_passes site=ols counts="
              << (passes && passes->ready ? "carrier" : "recount") << " pair=built\n";
}

bool update_intercept_covariance(
    HdfeResults& results,
    const Eigen::Ref<const Eigen::MatrixXd>& X_used,
    const Eigen::Ref<const Eigen::MatrixXd>& score_X_tilde,
    const Eigen::Ref<const Eigen::VectorXd>& residuals,
    const Eigen::VectorXd* weights,
    const std::vector<int>& kept_slope_cols,
    const detail::OlsResult& ols_result,
    StandardErrorType se_type,
    const std::vector<Eigen::VectorXi>* clusters,
    ClusterDofMethod g_df,
    bool g_adj,
    double sigma2,
    double robust_scale,
    double cluster_ratio,
    bool weights_are_frequencies,
    bool cluster_residual_sums_zero = false,
    const detail::ClusterPasses* passes = nullptr,
    bool* entered_multiway_intercept_fallback = nullptr) {
    if (entered_multiway_intercept_fallback) {
        *entered_multiway_intercept_fallback = false;
    }
    const int intercept_idx = static_cast<int>(results.coefficients.size()) - 1;
    if (intercept_idx < 0) {
        return false;
    }
    const int slope_cols_full = intercept_idx;
    if (slope_cols_full < 0 ||
        results.std_errors.size() != results.coefficients.size() ||
        results.covariance.rows() != results.covariance.cols() ||
        results.covariance.rows() != results.coefficients.size()) {
        return false;
    }

    const int n = static_cast<int>(score_X_tilde.rows());
    if (residuals.size() != n) {
        return false;
    }
    const int k_active = static_cast<int>(kept_slope_cols.size());
    if (k_active != score_X_tilde.cols()) {
        return false;
    }

    double sum_w = 0.0;
    const double residual_mean =
        fixed_chunk_weighted_mean(residuals, weights, 0, &sum_w);
    (void)residual_mean;
    if (!(sum_w > 0.0)) {
        return false;
    }

    Eigen::VectorXd xbar = Eigen::VectorXd::Zero(k_active);
    if (k_active > 0) {
        for (int pos = 0; pos < k_active; ++pos) {
            const int col = kept_slope_cols[static_cast<std::size_t>(pos)];
            xbar(pos) = fixed_chunk_weighted_mean(X_used.col(col), weights);
        }
    }

    Eigen::VectorXd cov_beta_alpha = Eigen::VectorXd::Zero(k_active);
    Eigen::VectorXd B = Eigen::VectorXd::Zero(k_active);
    long double var_alpha = 0.0L;
    if (se_type == StandardErrorType::Homoskedastic) {
        if (k_active > 0) {
            if (ols_result.xtx_inv.rows() != k_active || ols_result.xtx_inv.cols() != k_active) {
                return false;
            }
            const Eigen::MatrixXd cov_beta = sigma2 * ols_result.xtx_inv;
            var_alpha = static_cast<long double>(sigma2 / sum_w);
            const double quad = xbar.dot(cov_beta * xbar);
            var_alpha += static_cast<long double>(quad);
            cov_beta_alpha = -cov_beta * xbar;
        } else {
            var_alpha = static_cast<long double>(sigma2 / sum_w);
        }
    } else {
        bool used_cached_cluster_intercept = false;
        if (cluster_residual_sums_zero && se_type == StandardErrorType::Cluster &&
            clusters && clusters->size() == 1 &&
            ols_result.covariance.rows() == k_active &&
            ols_result.covariance.cols() == k_active) {
            // Every cluster is a union of FE levels, hence its residual score
            // is exactly zero. Do not turn the remaining projection roundoff
            // into inference on the recovered constant.
            const Eigen::VectorXd cov_xbar =
                (ols_result.covariance * xbar) * cluster_ratio;
            cov_beta_alpha = -cov_xbar;
            for (int j = 0; j < k_active; ++j)
                var_alpha += static_cast<long double>(xbar[j]) * cov_xbar[j];
            used_cached_cluster_intercept = true;
        }
        if (!used_cached_cluster_intercept && k_active > 0 && se_type == StandardErrorType::Cluster && clusters && clusters->size() == 1 &&
            !weights && ols_result.cluster_ux.size() == k_active &&
            hdfe::detail::ieee_finite(ols_result.cluster_u2) &&
            ols_result.cov_scale > 0.0 && hdfe::detail::ieee_finite(ols_result.cov_scale) &&
            ols_result.covariance.rows() == k_active &&
            ols_result.covariance.cols() == k_active) {
            const double inv_n = 1.0 / static_cast<double>(n);
            const double scale = ols_result.cov_scale * cluster_ratio;
            const Eigen::MatrixXd cov_unscaled =
                ols_result.covariance / ols_result.cov_scale;
            if (k_active > 0) {
                if (ols_result.xtx_inv.rows() != k_active ||
                    ols_result.xtx_inv.cols() != k_active) {
                    return false;
                }
                B = ols_result.xtx_inv * xbar;
                const Eigen::VectorXd cov_xbar = cov_unscaled * xbar;
                cov_beta_alpha =
                    inv_n * (ols_result.xtx_inv * ols_result.cluster_ux) - cov_xbar;
                const double alpha_base =
                    inv_n * inv_n * ols_result.cluster_u2 -
                    2.0 * inv_n * B.dot(ols_result.cluster_ux) +
                    xbar.dot(cov_xbar);
                var_alpha = static_cast<long double>(alpha_base);
            } else {
                var_alpha =
                    static_cast<long double>(inv_n * inv_n * ols_result.cluster_u2);
            }
            cov_beta_alpha *= scale;
            var_alpha *= static_cast<long double>(scale);
            used_cached_cluster_intercept = true;
        }

        if (!used_cached_cluster_intercept) {
        Eigen::VectorXd c_vec = Eigen::VectorXd::Zero(n);
        if (k_active > 0) {
            if (ols_result.xtx_inv.rows() != k_active || ols_result.xtx_inv.cols() != k_active) {
                return false;
            }
            B = ols_result.xtx_inv * xbar;
            const Eigen::VectorXd r = score_X_tilde * B;
            if (weights) {
                const double inv_sum_w = 1.0 / sum_w;
                c_vec = weights->array() * (inv_sum_w - r.array());
            } else {
                const double inv_n = 1.0 / static_cast<double>(n);
                c_vec = Eigen::VectorXd::Constant(n, inv_n) - r;
            }
        } else {
            if (weights) {
                c_vec = weights->array() * (1.0 / sum_w);
            } else {
                const double inv_n = 1.0 / static_cast<double>(n);
                c_vec = Eigen::VectorXd::Constant(n, inv_n);
            }
        }

        if (se_type == StandardErrorType::Robust) {
            const Eigen::ArrayXd u = residuals.array();
            const Eigen::ArrayXd c = c_vec.array();
            if (weights && weights_are_frequencies) {
                // fweight (replication): c_vec already carries one factor of w, so the
                // robust intercept variance is Sum (c*u)^2 / w and the cov meat is
                // Sum c*u^2*x (linear w), matching Stata/areg/reghdfe. aweight/pweight
                // keep the w^2 form in the else-branch.
                const Eigen::ArrayXd wv = weights->array();
                var_alpha = static_cast<long double>(((c * u).square() / wv).sum());
                if (k_active > 0) {
                    const Eigen::VectorXd vec =
                        score_X_tilde.transpose() * (u.square() * c).matrix();
                    cov_beta_alpha = ols_result.xtx_inv * vec;
                }
            } else {
                var_alpha = static_cast<long double>((c * u).square().sum());
                if (k_active > 0) {
                    Eigen::ArrayXd w = Eigen::ArrayXd::Ones(n);
                    if (weights) {
                        w = weights->array();
                    }
                    const Eigen::VectorXd vec =
                        score_X_tilde.transpose() * (w * u.square() * c).matrix();
                    cov_beta_alpha = ols_result.xtx_inv * vec;
                }
            }
            cov_beta_alpha *= robust_scale;
            var_alpha *= static_cast<long double>(robust_scale);
        } else if (se_type == StandardErrorType::Cluster && clusters && !clusters->empty()) {
            if (clusters->size() == 1) {
                const ClusterInterceptMeat meat = compute_cluster_intercept_meat(
                    score_X_tilde, residuals, weights, c_vec, (*clusters)[0]);
                if (k_active > 0) {
                    cov_beta_alpha = ols_result.xtx_inv * meat.cross;
                }
                var_alpha = static_cast<long double>(meat.alpha);
                double scale = ols_result.cov_scale * cluster_ratio;
                cov_beta_alpha *= scale;
                var_alpha *= static_cast<long double>(scale);
            } else {
                const ClusterInterceptMeat meat = compute_multiway_intercept_meat(
                    score_X_tilde, residuals, weights, c_vec, *clusters, g_df, g_adj,
                    ols_result.df_resid,
                    weights && weights_are_frequencies ? sum_w : static_cast<double>(n), passes);
                if (k_active > 0) {
                    cov_beta_alpha = ols_result.xtx_inv * meat.cross;
                }
                var_alpha = static_cast<long double>(meat.alpha);
                cov_beta_alpha *= cluster_ratio;
                var_alpha *= static_cast<long double>(cluster_ratio);
            }
        } else {
            return false;
        }
        }
    }

    double var_alpha_d = static_cast<double>(var_alpha);
    if (!hdfe::detail::ieee_finite(var_alpha_d) || var_alpha_d < 0.0) {
        var_alpha_d = 0.0;
    }
    auto active_slope_covariance = [&]() {
        Eigen::MatrixXd covariance(k_active, k_active);
        for (int i = 0; i < k_active; ++i) {
            for (int j = 0; j < k_active; ++j) {
                covariance(i, j) = results.covariance(
                    kept_slope_cols[static_cast<std::size_t>(i)],
                    kept_slope_cols[static_cast<std::size_t>(j)]);
            }
        }
        return covariance;
    };
    bool used_multiway_fallback = false;
    if (se_type == StandardErrorType::Cluster && clusters && clusters->size() > 1 &&
        k_active > 0 && (!(var_alpha_d > 0.0) || !hdfe::detail::ieee_finite(var_alpha_d))) {
        if (entered_multiway_intercept_fallback) {
            *entered_multiway_intercept_fallback = true;
        }
        Eigen::MatrixXd Vtmp = results.covariance;
        for (int j = 0; j < slope_cols_full; ++j) {
            Vtmp(intercept_idx, j) = 0.0;
            Vtmp(j, intercept_idx) = 0.0;
        }
        Vtmp(intercept_idx, intercept_idx) = var_alpha_d;
        for (int pos = 0; pos < k_active; ++pos) {
            const int col = kept_slope_cols[static_cast<std::size_t>(pos)];
            if (col >= 0 && col < slope_cols_full) {
                Vtmp(intercept_idx, col) = cov_beta_alpha(pos);
                Vtmp(col, intercept_idx) = cov_beta_alpha(pos);
            }
        }

        if (fix_psd(Vtmp)) {
            const double var_psd = Vtmp(intercept_idx, intercept_idx);
            if (hdfe::detail::ieee_finite(var_psd) && var_psd > 0.0) {
                var_alpha_d = var_psd;
                used_multiway_fallback = true;
                for (int pos = 0; pos < k_active; ++pos) {
                    const int col = kept_slope_cols[static_cast<std::size_t>(pos)];
                    if (col >= 0 && col < slope_cols_full) {
                        cov_beta_alpha(pos) = Vtmp(intercept_idx, col);
                    }
                }
            }
        }

        if (!(var_alpha_d > 0.0) || !hdfe::detail::ieee_finite(var_alpha_d)) {
            const Eigen::MatrixXd cov_beta = active_slope_covariance();
            const Eigen::VectorXd cov_fb = -cov_beta * xbar;
            const double var_fb = xbar.dot(cov_beta * xbar);
            if (hdfe::detail::ieee_finite(var_fb) && var_fb > 0.0) {
                cov_beta_alpha = cov_fb;
                var_alpha_d = var_fb;
                used_multiway_fallback = true;
            }
        }
    }
    if (used_multiway_fallback) {
        const Eigen::MatrixXd cov_beta = active_slope_covariance();
        const Eigen::CompleteOrthogonalDecomposition<Eigen::MatrixXd> cod(cov_beta);
        const Eigen::VectorXd z = cod.solve(cov_beta_alpha);
        const double schur_lb = cov_beta_alpha.dot(z);
        if (hdfe::detail::ieee_finite(schur_lb) && var_alpha_d < schur_lb) {
            var_alpha_d = schur_lb;
        }
    }

    for (int j = 0; j < slope_cols_full; ++j) {
        results.covariance(intercept_idx, j) = 0.0;
        results.covariance(j, intercept_idx) = 0.0;
    }
    results.covariance(intercept_idx, intercept_idx) = var_alpha_d;
    for (int pos = 0; pos < k_active; ++pos) {
        const int col = kept_slope_cols[static_cast<std::size_t>(pos)];
        if (col >= 0 && col < slope_cols_full) {
            results.covariance(intercept_idx, col) = cov_beta_alpha(pos);
            results.covariance(col, intercept_idx) = cov_beta_alpha(pos);
        }
    }
    results.std_errors(intercept_idx) =
        (var_alpha_d >= 0.0)
            ? std::sqrt(var_alpha_d)
            : std::numeric_limits<double>::quiet_NaN();
    return true;
}

std::vector<int> sanitize_endogenous_idx(const std::vector<int>& indices, int num_cols) {
    std::vector<int> cleaned = indices;
    std::sort(cleaned.begin(), cleaned.end());
    cleaned.erase(std::unique(cleaned.begin(), cleaned.end()), cleaned.end());
    for (const int idx : cleaned) {
        if (idx < 0 || idx >= num_cols) {
            throw std::runtime_error("Endogenous index out of bounds");
        }
    }
    return cleaned;
}

Eigen::MatrixXd select_columns(const Eigen::Ref<const Eigen::MatrixXd>& X,
                               const std::vector<int>& columns) {
    Eigen::MatrixXd out(X.rows(), static_cast<int>(columns.size()));
    for (int i = 0; i < static_cast<int>(columns.size()); ++i) {
        out.col(i) = X.col(columns[i]);
    }
    return out;
}

Eigen::MatrixXd drop_columns(const Eigen::Ref<const Eigen::MatrixXd>& X,
                             const std::vector<int>& columns) {
    if (columns.empty()) {
        return X;
    }
    std::vector<bool> is_endog(static_cast<std::size_t>(X.cols()), false);
    for (const int idx : columns) {
        is_endog[static_cast<std::size_t>(idx)] = true;
    }
    const int keep = static_cast<int>(X.cols()) - static_cast<int>(columns.size());
    Eigen::MatrixXd out(X.rows(), keep);
    int cursor = 0;
    for (int j = 0; j < X.cols(); ++j) {
        if (!is_endog[static_cast<std::size_t>(j)]) {
            out.col(cursor++) = X.col(j);
        }
    }
    return out;
}

// Rows (phase 1 of the Stata-path plan): the sparse branch on a team keeps,
// for every row of the vector it was built from, the code that index() of the
// Sparse branch would give that row's identifier (order of first
// appearance). It is read by row (at()), only on the rows of its own vector.
enum class FeLookupMode { Dense, DenseMap, Sparse, Rows };

struct FeLookup {
    FeLookupMode mode = FeLookupMode::Sparse;
    int min_id = 0;
    int num_groups = 0;
    std::vector<int> dense_map;
    std::unordered_map<int, int> mapping;
    std::vector<int> row_codes;

    // The code of row `row`, whose identifier is `raw`.
    int at(int row, int raw) const {
        return mode == FeLookupMode::Rows
                   ? row_codes[static_cast<std::size_t>(row)]
                   : index(raw);
    }

    int index(int raw) const {
        if (mode == FeLookupMode::Dense) {
            return raw - min_id;
        }
        if (mode == FeLookupMode::DenseMap) {
            const int idx = raw - min_id;
            if (idx < 0 || idx >= static_cast<int>(dense_map.size())) {
                throw std::runtime_error("FE lookup missing key");
            }
            const int mapped = dense_map[static_cast<std::size_t>(idx)];
            if (mapped < 0) {
                throw std::runtime_error("FE lookup missing key");
            }
            return mapped;
        }
        if (mode == FeLookupMode::Rows) {
            throw std::logic_error("FE lookup in row mode is read by row");
        }
        auto it = mapping.find(raw);
        if (it == mapping.end()) {
            throw std::runtime_error("FE lookup missing key");
        }
        return it->second;
    }
};

FeLookup build_lookup(const Eigen::VectorXi& raw_ids) {
    FeLookup lookup;
    if (raw_ids.size() == 0) {
        return lookup;
    }

    int min_id = raw_ids(0);
    int max_id = raw_ids(0);
    for (int i = 1; i < raw_ids.size(); ++i) {
        const int v = raw_ids(i);
        if (v < min_id) {
            min_id = v;
        } else if (v > max_id) {
            max_id = v;
        }
    }
    const long long range =
        static_cast<long long>(max_id) - static_cast<long long>(min_id) + 1LL;
    constexpr long long kDenseRangeCap = 50000000LL;
    if (min_id >= 0 && range > 0 && range <= kDenseRangeCap &&
        range <= static_cast<long long>(raw_ids.size()) * 2LL) {
        lookup.mode = FeLookupMode::Dense;
        lookup.min_id = min_id;
        lookup.num_groups = static_cast<int>(range);
        return lookup;
    }

    lookup.mode = FeLookupMode::Sparse;
    lookup.min_id = 0;
    std::unordered_map<int, int> mapping;
    constexpr std::size_t kMaxReserve = 5000000ULL;
    const long long approx_range =
        range > 0 && range <= static_cast<long long>(kMaxReserve) ? range : 0LL;
    const std::size_t reserve =
        approx_range > 0 ? static_cast<std::size_t>(approx_range)
                         : std::min<std::size_t>(static_cast<std::size_t>(raw_ids.size()),
                                                 kMaxReserve);
    if (reserve > 0) {
        mapping.reserve(reserve);
    }

    int next_id = 0;
    for (int i = 0; i < raw_ids.size(); ++i) {
        const int key = raw_ids(i);
        auto it = mapping.find(key);
        if (it == mapping.end()) {
            mapping.emplace(key, next_id);
            ++next_id;
        }
    }
    lookup.mapping = std::move(mapping);
    lookup.num_groups = next_id;
    return lookup;
}

FeLookup build_lookup_compact(const Eigen::VectorXi& raw_ids, int expected_levels) {
    FeLookup lookup;
    if (raw_ids.size() == 0) {
        return lookup;
    }

    int min_id = raw_ids(0);
    int max_id = raw_ids(0);
    for (int i = 1; i < raw_ids.size(); ++i) {
        const int v = raw_ids(i);
        if (v < min_id) {
            min_id = v;
        } else if (v > max_id) {
            max_id = v;
        }
    }
    const long long range =
        static_cast<long long>(max_id) - static_cast<long long>(min_id) + 1LL;
    constexpr long long kDenseRangeCap = 50000000LL;
    if (min_id >= 0 && range > 0 && range <= kDenseRangeCap &&
        range <= static_cast<long long>(raw_ids.size()) * 2LL) {
        if (expected_levels > 0 && expected_levels == range) {
            lookup.mode = FeLookupMode::Dense;
            lookup.min_id = min_id;
            lookup.num_groups = static_cast<int>(range);
            return lookup;
        }
        lookup.mode = FeLookupMode::DenseMap;
        lookup.min_id = min_id;
        lookup.dense_map.assign(static_cast<std::size_t>(range), -1);
        int next_id = 0;
        for (int i = 0; i < raw_ids.size(); ++i) {
            const int idx = raw_ids(i) - min_id;
            int& slot = lookup.dense_map[static_cast<std::size_t>(idx)];
            if (slot < 0) {
                slot = next_id++;
            }
        }
        lookup.num_groups = next_id;
        return lookup;
    }

    lookup.mode = FeLookupMode::Sparse;
    lookup.min_id = 0;
    std::unordered_map<int, int> mapping;
    constexpr std::size_t kMaxReserve = 5000000ULL;
    const std::size_t reserve =
        std::min<std::size_t>(static_cast<std::size_t>(raw_ids.size()), kMaxReserve);
    if (reserve > 0) {
        mapping.reserve(reserve);
    }
    int next_id = 0;
    for (int i = 0; i < raw_ids.size(); ++i) {
        const int key = raw_ids(i);
        auto it = mapping.find(key);
        if (it == mapping.end()) {
            mapping.emplace(key, next_id);
            ++next_id;
        }
    }
    lookup.mapping = std::move(mapping);
    lookup.num_groups = next_id;
    return lookup;
}

struct FeIndexerLite {
    std::vector<int> group_ids;
    int num_groups = 0;
};

FeIndexerLite build_indexer_lite(const Eigen::VectorXi& raw_ids) {
    FeIndexerLite idx;
    idx.group_ids.resize(static_cast<std::size_t>(raw_ids.size()));
    if (raw_ids.size() == 0) {
        idx.num_groups = 0;
        return idx;
    }

    int min_id = raw_ids(0);
    int max_id = raw_ids(0);
    for (int i = 1; i < raw_ids.size(); ++i) {
        const int v = raw_ids(i);
        if (v < min_id) {
            min_id = v;
        } else if (v > max_id) {
            max_id = v;
        }
    }

    const long long range =
        static_cast<long long>(max_id) - static_cast<long long>(min_id) + 1LL;
    constexpr long long kDenseRangeCap = 50000000LL;
    if (min_id >= 0 && range > 0 && range <= kDenseRangeCap &&
        range <= static_cast<long long>(raw_ids.size()) * 2LL) {
        std::vector<int> dense_map(static_cast<std::size_t>(range), -1);
        int next_id = 0;
        for (int i = 0; i < raw_ids.size(); ++i) {
            const int mapped = raw_ids(i) - min_id;
            int& slot = dense_map[static_cast<std::size_t>(mapped)];
            if (slot < 0) {
                slot = next_id++;
            }
            idx.group_ids[static_cast<std::size_t>(i)] = slot;
        }
        idx.num_groups = next_id;
        return idx;
    }

    std::unordered_map<int, int> mapping;
    constexpr std::size_t kMaxReserve = 5000000ULL;
    const std::size_t reserve =
        range > 0 && range <= static_cast<long long>(kMaxReserve)
            ? static_cast<std::size_t>(range)
            : std::min<std::size_t>(static_cast<std::size_t>(raw_ids.size()), kMaxReserve);
    if (reserve > 0) {
        mapping.reserve(reserve);
    }

    int next_id = 0;
    for (int i = 0; i < raw_ids.size(); ++i) {
        const int key = raw_ids(i);
        auto it = mapping.find(key);
        int normalized = 0;
        if (it == mapping.end()) {
            normalized = next_id;
            mapping.emplace(key, next_id);
            ++next_id;
        } else {
            normalized = it->second;
        }
        idx.group_ids[static_cast<std::size_t>(i)] = normalized;
    }
    idx.num_groups = next_id;
    return idx;
}

#ifdef HDFE_USE_OPENMP
// The sparse branch of build_indexer_lite() on a team (phase 1 of the
// Stata-path plan, src/sparse_rank.hpp): the ascending ranks of the bitmap
// index, turned into the order of first appearance that the hash map of the
// serial branch gives. False when the switch is off or the index does not fit
// its budget; the caller then keeps the serial branch.
bool build_indexer_lite_sparse_rank(const Eigen::VectorXi& raw_ids,
                                    int min_id,
                                    int max_id,
                                    int threads,
                                    detail::ParallelWorkObserver* observer,
                                    FeIndexerLite& idx,
                                    const char* site) {
    if (!detail::sparse_rank::enabled()) {
        return false;
    }
    const int n = static_cast<int>(raw_ids.size());
    const detail::sparse_rank::OmpRun run{threads, observer};
    detail::sparse_rank::Index index;
    if (!detail::sparse_rank::build_index(raw_ids.data(), n, min_id, max_id, run, index)) {
        return false;
    }
    idx.group_ids.resize(static_cast<std::size_t>(n));
    detail::sparse_rank::map_ranks(raw_ids.data(), n, index, idx.group_ids.data(), run);
    const int levels = index.levels;
    index.clear();
    detail::sparse_rank::first_appearance_in_place(idx.group_ids.data(), n, levels, run);
    idx.num_groups = levels;
    if (detail::sparse_rank::verify_enabled()) {
        const FeIndexerLite ref = build_indexer_lite(raw_ids);
        detail::sparse_rank::verify_check(ref.group_ids == idx.group_ids, site, "group_ids");
        detail::sparse_rank::verify_check(ref.num_groups == idx.num_groups, site, "num_groups");
        detail::sparse_rank::verify_ok(site);
    }
    return true;
}

// build_indexer_lite() on a team, for identifiers in a compact range: the
// same dense ranks by order of first appearance. The first row of every
// identifier is a minimum, the rank of an identifier is the number of first
// rows before its own, and both are exact whatever the team. Other inputs go
// to the sparse branch on the team (build_indexer_lite_sparse_rank()) or to
// build_indexer_lite().
FeIndexerLite build_indexer_lite_team(const Eigen::VectorXi& raw_ids,
                                      int threads,
                                      detail::ParallelWorkObserver* observer) {
    const int n = static_cast<int>(raw_ids.size());
    if (n == 0 || threads <= 1) {
        return build_indexer_lite(raw_ids);
    }
    const int* const raw = raw_ids.data();
    const int blocks = detail::deterministic_parallel_chunk_count(n);
    std::vector<int> block_min(static_cast<std::size_t>(blocks), raw[0]);
    std::vector<int> block_max(static_cast<std::size_t>(blocks), raw[0]);
    if (observer) {
        observer->begin_region(threads);
    }
#pragma omp parallel num_threads(threads)
    {
        bool observed_work = false;
#pragma omp for schedule(static)
        for (int block = 0; block < blocks; ++block) {
            if (observer && !observed_work) {
                observer->observe_work();
                observed_work = true;
            }
            const int first = detail::deterministic_parallel_chunk_begin(n, block, blocks);
            const int last = detail::deterministic_parallel_chunk_end(n, block, blocks);
            int low = raw[first];
            int high = raw[first];
            for (int i = first + 1; i < last; ++i) {
                low = std::min(low, raw[i]);
                high = std::max(high, raw[i]);
            }
            block_min[static_cast<std::size_t>(block)] = low;
            block_max[static_cast<std::size_t>(block)] = high;
        }
    }
    if (observer) {
        observer->end_region();
    }
    const int min_id = *std::min_element(block_min.begin(), block_min.end());
    const int max_id = *std::max_element(block_max.begin(), block_max.end());
    const long long range =
        static_cast<long long>(max_id) - static_cast<long long>(min_id) + 1LL;
    constexpr long long kDenseRangeCap = 50000000LL;
    if (!(min_id >= 0 && range > 0 && range <= kDenseRangeCap &&
          range <= static_cast<long long>(n) * 2LL)) {
        const auto sparse_t0 = std::chrono::steady_clock::now();
        FeIndexerLite sparse;
        if (build_indexer_lite_sparse_rank(raw_ids, min_id, max_id, threads, observer,
                                           sparse, "indexer_lite")) {
            detail::sparse_rank::profile_line("indexer_lite", "bitmap", "index", n, min_id,
                                              max_id, sparse.num_groups, threads, sparse_t0);
            return sparse;
        }
        sparse = build_indexer_lite(raw_ids);
        detail::sparse_rank::profile_line("indexer_lite", "serial",
                                          detail::sparse_rank::serial_reason(), n, min_id,
                                          max_id, sparse.num_groups, 1, sparse_t0);
        return sparse;
    }

    const std::size_t levels = static_cast<std::size_t>(range);
    const std::unique_ptr<std::atomic<int>[]> first_row(new std::atomic<int>[levels]);
    std::vector<int> dense_map(levels);
    std::vector<int> block_begin(static_cast<std::size_t>(blocks) + 1U, 0);
    FeIndexerLite idx;
    idx.group_ids.resize(static_cast<std::size_t>(n));
    int* const group_ids = idx.group_ids.data();
#pragma omp parallel num_threads(threads)
    {
#pragma omp for schedule(static)
        for (std::ptrdiff_t level = 0; level < static_cast<std::ptrdiff_t>(levels);
             ++level) {
            first_row[static_cast<std::size_t>(level)].store(
                std::numeric_limits<int>::max(), std::memory_order_relaxed);
        }
#pragma omp for schedule(static)
        for (int block = 0; block < blocks; ++block) {
            const int first = detail::deterministic_parallel_chunk_begin(n, block, blocks);
            const int last = detail::deterministic_parallel_chunk_end(n, block, blocks);
            for (int i = first; i < last; ++i) {
                std::atomic<int>& slot =
                    first_row[static_cast<std::size_t>(raw[i] - min_id)];
                int seen = slot.load(std::memory_order_relaxed);
                while (i < seen &&
                       !slot.compare_exchange_weak(seen, i, std::memory_order_relaxed)) {
                }
            }
        }
#pragma omp for schedule(static)
        for (int block = 0; block < blocks; ++block) {
            const int first = detail::deterministic_parallel_chunk_begin(n, block, blocks);
            const int last = detail::deterministic_parallel_chunk_end(n, block, blocks);
            int firsts = 0;
            for (int i = first; i < last; ++i) {
                firsts += first_row[static_cast<std::size_t>(raw[i] - min_id)].load(
                              std::memory_order_relaxed) == i
                              ? 1
                              : 0;
            }
            block_begin[static_cast<std::size_t>(block) + 1U] = firsts;
        }
#pragma omp single
        {
            for (int block = 0; block < blocks; ++block) {
                block_begin[static_cast<std::size_t>(block) + 1U] +=
                    block_begin[static_cast<std::size_t>(block)];
            }
        }
#pragma omp for schedule(static)
        for (int block = 0; block < blocks; ++block) {
            const int first = detail::deterministic_parallel_chunk_begin(n, block, blocks);
            const int last = detail::deterministic_parallel_chunk_end(n, block, blocks);
            int rank = block_begin[static_cast<std::size_t>(block)];
            for (int i = first; i < last; ++i) {
                const std::size_t level = static_cast<std::size_t>(raw[i] - min_id);
                if (first_row[level].load(std::memory_order_relaxed) == i) {
                    dense_map[level] = rank++;
                }
            }
        }
#pragma omp for schedule(static)
        for (int i = 0; i < n; ++i) {
            group_ids[i] = dense_map[static_cast<std::size_t>(raw[i] - min_id)];
        }
    }
    idx.num_groups = block_begin[static_cast<std::size_t>(blocks)];
    return idx;
}
#endif

#ifdef HDFE_USE_OPENMP
// The sparse branch of build_lookup_compact() on a team (phase 1 of the
// Stata-path plan): a Rows lookup that holds, for each row, the code that
// index() of the Sparse branch gives its identifier (order of first
// appearance), from the bitmap index of src/sparse_rank.hpp. The sparse
// branch does not use expected_levels, nor does this one. False when the
// switch is off or the index does not fit its budget; the caller then keeps
// the serial branch.
bool build_lookup_rows_sparse_rank(const Eigen::VectorXi& raw_ids,
                                   int expected_levels,
                                   int min_id,
                                   int max_id,
                                   int threads,
                                   FeLookup& lookup) {
    if (!detail::sparse_rank::enabled()) {
        return false;
    }
    const int n = static_cast<int>(raw_ids.size());
    const detail::sparse_rank::OmpRun run{threads, nullptr};
    detail::sparse_rank::Index index;
    if (!detail::sparse_rank::build_index(raw_ids.data(), n, min_id, max_id, run, index)) {
        return false;
    }
    lookup.mode = FeLookupMode::Rows;
    lookup.min_id = 0;
    lookup.row_codes.resize(static_cast<std::size_t>(n));
    detail::sparse_rank::map_ranks(raw_ids.data(), n, index, lookup.row_codes.data(), run);
    const int levels = index.levels;
    index.clear();
    detail::sparse_rank::first_appearance_in_place(lookup.row_codes.data(), n, levels, run);
    lookup.num_groups = levels;
    if (detail::sparse_rank::verify_enabled()) {
        // Today's branch: index() of the serial lookup, row by row.
        const FeLookup ref = build_lookup_compact(raw_ids, expected_levels);
        detail::sparse_rank::verify_check(ref.num_groups == lookup.num_groups, "lookup",
                                          "num_groups");
        for (int i = 0; i < n; ++i) {
            if (ref.index(raw_ids(i)) != lookup.row_codes[static_cast<std::size_t>(i)]) {
                detail::sparse_rank::verify_fail("lookup", "row_codes");
                break;
            }
        }
        detail::sparse_rank::verify_ok("lookup");
    }
    return true;
}

// build_lookup_compact() on the team of the caller, for identifiers in a
// compact range: the same ranks by order of first appearance. Other inputs
// give a Rows lookup on the team (build_lookup_rows_sparse_rank()) or go to
// build_lookup_compact().
FeLookup build_lookup_compact_team(const Eigen::VectorXi& raw_ids,
                                   int expected_levels,
                                   int threads,
                                   bool explicit_threads) {
    const int n = static_cast<int>(raw_ids.size());
    constexpr int kTeamMinRows = 1048576;
    if ((n < kTeamMinRows && !explicit_threads) ||
        threads <= 1 || omp_in_parallel()) {
        return build_lookup_compact(raw_ids, expected_levels);
    }
    const int* const raw = raw_ids.data();
    const int blocks = detail::deterministic_parallel_chunk_count(n);
    std::vector<int> block_min(static_cast<std::size_t>(blocks), raw[0]);
    std::vector<int> block_max(static_cast<std::size_t>(blocks), raw[0]);
#pragma omp parallel for schedule(static) num_threads(threads)
    for (int block = 0; block < blocks; ++block) {
        const int first = detail::deterministic_parallel_chunk_begin(n, block, blocks);
        const int last = detail::deterministic_parallel_chunk_end(n, block, blocks);
        int low = raw[first];
        int high = raw[first];
        for (int i = first + 1; i < last; ++i) {
            low = std::min(low, raw[i]);
            high = std::max(high, raw[i]);
        }
        block_min[static_cast<std::size_t>(block)] = low;
        block_max[static_cast<std::size_t>(block)] = high;
    }
    const int min_id = *std::min_element(block_min.begin(), block_min.end());
    const int max_id = *std::max_element(block_max.begin(), block_max.end());
    const long long range =
        static_cast<long long>(max_id) - static_cast<long long>(min_id) + 1LL;
    constexpr long long kDenseRangeCap = 50000000LL;
    if (!(min_id >= 0 && range > 0 && range <= kDenseRangeCap &&
          range <= static_cast<long long>(n) * 2LL)) {
        const auto sparse_t0 = std::chrono::steady_clock::now();
        FeLookup sparse;
        if (build_lookup_rows_sparse_rank(raw_ids, expected_levels, min_id, max_id, threads,
                                          sparse)) {
            detail::sparse_rank::profile_line("lookup", "bitmap", "index", n, min_id, max_id,
                                              sparse.num_groups, threads, sparse_t0);
            return sparse;
        }
        sparse = build_lookup_compact(raw_ids, expected_levels);
        detail::sparse_rank::profile_line("lookup", "serial",
                                          detail::sparse_rank::serial_reason(), n, min_id,
                                          max_id, sparse.num_groups, 1, sparse_t0);
        return sparse;
    }
    FeLookup lookup;
    lookup.min_id = min_id;
    if (expected_levels > 0 && expected_levels == range) {
        lookup.mode = FeLookupMode::Dense;
        lookup.num_groups = static_cast<int>(range);
        return lookup;
    }
    lookup.mode = FeLookupMode::DenseMap;
    const std::size_t levels = static_cast<std::size_t>(range);
    const std::unique_ptr<std::atomic<int>[]> first_row(new std::atomic<int>[levels]);
    lookup.dense_map.assign(levels, -1);
    int* const dense_map = lookup.dense_map.data();
    std::vector<int> block_begin(static_cast<std::size_t>(blocks) + 1U, 0);
#pragma omp parallel num_threads(threads)
    {
#pragma omp for schedule(static)
        for (std::ptrdiff_t level = 0; level < static_cast<std::ptrdiff_t>(levels);
             ++level) {
            first_row[static_cast<std::size_t>(level)].store(
                std::numeric_limits<int>::max(), std::memory_order_relaxed);
        }
#pragma omp for schedule(static)
        for (int block = 0; block < blocks; ++block) {
            const int first = detail::deterministic_parallel_chunk_begin(n, block, blocks);
            const int last = detail::deterministic_parallel_chunk_end(n, block, blocks);
            for (int i = first; i < last; ++i) {
                std::atomic<int>& slot =
                    first_row[static_cast<std::size_t>(raw[i] - min_id)];
                int seen = slot.load(std::memory_order_relaxed);
                while (i < seen &&
                       !slot.compare_exchange_weak(seen, i, std::memory_order_relaxed)) {
                }
            }
        }
#pragma omp for schedule(static)
        for (int block = 0; block < blocks; ++block) {
            const int first = detail::deterministic_parallel_chunk_begin(n, block, blocks);
            const int last = detail::deterministic_parallel_chunk_end(n, block, blocks);
            int firsts = 0;
            for (int i = first; i < last; ++i) {
                firsts += first_row[static_cast<std::size_t>(raw[i] - min_id)].load(
                              std::memory_order_relaxed) == i
                              ? 1
                              : 0;
            }
            block_begin[static_cast<std::size_t>(block) + 1U] = firsts;
        }
#pragma omp single
        {
            for (int block = 0; block < blocks; ++block) {
                block_begin[static_cast<std::size_t>(block) + 1U] +=
                    block_begin[static_cast<std::size_t>(block)];
            }
        }
#pragma omp for schedule(static)
        for (int block = 0; block < blocks; ++block) {
            const int first = detail::deterministic_parallel_chunk_begin(n, block, blocks);
            const int last = detail::deterministic_parallel_chunk_end(n, block, blocks);
            int rank = block_begin[static_cast<std::size_t>(block)];
            for (int i = first; i < last; ++i) {
                const std::size_t level = static_cast<std::size_t>(raw[i] - min_id);
                if (first_row[level].load(std::memory_order_relaxed) == i) {
                    dense_map[level] = rank++;
                }
            }
        }
    }
    lookup.num_groups = block_begin[static_cast<std::size_t>(blocks)];
    return lookup;
}
#endif

int count_unique_ids(const Eigen::VectorXi& ids) {
    std::unordered_map<int, int> uniq;
    uniq.reserve(static_cast<std::size_t>(ids.size()));
    for (int i = 0; i < ids.size(); ++i) {
        uniq.emplace(ids(i), 1);
    }
    return static_cast<int>(uniq.size());
}

Eigen::VectorXi combine_clusters(const std::vector<Eigen::VectorXi>& clusters,
                                 const std::vector<int>& dims) {
    if (dims.empty()) {
        throw std::runtime_error("Cannot combine an empty set of cluster dimensions");
    }
    const int n = clusters[static_cast<std::size_t>(dims[0])].size();
    for (const int d : dims) {
        if (clusters[static_cast<std::size_t>(d)].size() != n) {
            throw std::runtime_error("All cluster vectors must have the same length");
        }
    }
    if (dims.size() == 1) {
        return clusters[static_cast<std::size_t>(dims[0])];
    }

    Eigen::VectorXi current = clusters[static_cast<std::size_t>(dims[0])];
    for (std::size_t pos = 1; pos < dims.size(); ++pos) {
        const Eigen::VectorXi& next = clusters[static_cast<std::size_t>(dims[pos])];
        std::unordered_map<std::uint64_t, int> map;
        map.reserve(static_cast<std::size_t>(n));
        Eigen::VectorXi combined(n);
        int next_id = 0;
        for (int i = 0; i < n; ++i) {
            const std::uint32_t a = static_cast<std::uint32_t>(current(i));
            const std::uint32_t b = static_cast<std::uint32_t>(next(i));
            const std::uint64_t key = (static_cast<std::uint64_t>(a) << 32) | b;
            auto it = map.find(key);
            if (it == map.end()) {
                map.emplace(key, next_id);
                combined(i) = next_id;
                ++next_id;
            } else {
                combined(i) = it->second;
            }
        }
        current = std::move(combined);
    }
    return current;
}

std::vector<int> compute_cluster_counts(const std::vector<Eigen::VectorXi>& clusters) {
    std::vector<int> counts;
    counts.reserve(clusters.size());
    for (const auto& c : clusters) {
        counts.push_back(count_unique_ids(c));
    }
    return counts;
}

std::vector<int> compute_cluster_combo_counts(const std::vector<Eigen::VectorXi>& clusters) {
    std::vector<int> counts;
    const int m = static_cast<int>(clusters.size());
    if (m <= 0) {
        return counts;
    }
    if (m == 1) {
        counts.reserve(1);
        counts.push_back(count_unique_ids(clusters[0]));
        return counts;
    }
    const std::uint64_t max_mask = (static_cast<std::uint64_t>(1) << m);
    std::vector<int> dims;
    dims.reserve(static_cast<std::size_t>(m));
    counts.reserve(static_cast<std::size_t>(max_mask - 1));
    for (std::uint64_t mask = 1; mask < max_mask; ++mask) {
        dims.clear();
        for (int j = 0; j < m; ++j) {
            if (mask & (static_cast<std::uint64_t>(1) << j)) {
                dims.push_back(j);
            }
        }
        const Eigen::VectorXi combined = combine_clusters(clusters, dims);
        counts.push_back(count_unique_ids(combined));
    }
    return counts;
}

struct FeDofInfo {
    std::vector<int> levels;
    std::vector<int> redundant;
    std::vector<int> num_coefs;
    std::vector<int> inexact;
    // Package E, E3: sums over the effects, in 64 bits (each term fits an int,
    // the sum need not), down to their consumers, which publish them as doubles.
    std::int64_t df_a = 0;
    std::int64_t df_a_levels = 0;
    std::int64_t df_a_exact = 0;
};

FeDofInfo compute_grouped_dof_exact(
    const std::vector<Eigen::VectorXi>& standard_fes,
    const detail::GroupIndividualStructure& gi,
    GroupAggregation aggregation,
    const Eigen::VectorXd* weights) {
    // Bound the optional algebraic calculation independently of FE absorption.
    constexpr std::int64_t max_cells = 25000000;
    const int n = gi.num_groups;
    FeDofInfo info;
    std::vector<std::unordered_map<int, int>> levels;
    std::int64_t columns = gi.num_individuals;
    for (const auto& fe : standard_fes) {
        std::unordered_map<int, int> ids;
        for (int row = 0; row < n; ++row) {
            const int next = static_cast<int>(ids.size());
            ids.emplace(fe[row], next);
        }
        info.levels.push_back(static_cast<int>(ids.size()));
        columns += static_cast<std::int64_t>(ids.size());
        levels.push_back(std::move(ids));
    }
    info.levels.push_back(gi.num_individuals);
    if (n <= 0 || columns <= 0 || columns > max_cells ||
        static_cast<std::int64_t>(n) > max_cells / columns) {
        std::ostringstream message;
        message << "dofadjustments(exact): group FE design has " << n << " rows and "
                << columns << " columns; the exact rank design limit is " << max_cells
                << " matrix elements. No estimates returned; no approximate DoF fallback.";
        throw std::runtime_error(message.str());
    }
    detail::ExactRankBudget budget;
    auto rank_of = [&](std::size_t ordinary_count, bool with_individual) {
        detail::ExactRankAccumulator accumulator(budget);
        for (int row = 0; row < n; ++row) {
            if (weights && !((*weights)[row] > 0.0)) continue;
            detail::ExactRankAccumulator::Row values;
            int offset = 0;
            if (with_individual) {
                for (int edge = gi.group_ptr[row]; edge < gi.group_ptr[row + 1]; ++edge) {
                    accumulator.insert(values, gi.group_individual[edge], 1);
                }
                offset = gi.num_individuals;
            }
            // Multiplying a mean-aggregation row by its team size clears all
            // denominators and preserves rank. Positive weights preserve it too.
            const int scale = with_individual && aggregation == GroupAggregation::Mean
                ? gi.group_ptr[row + 1] - gi.group_ptr[row] : 1;
            for (std::size_t dim = 0; dim < ordinary_count; ++dim) {
                accumulator.insert(values, offset + levels[dim].at(standard_fes[dim][row]), scale);
                offset += info.levels[dim];
            }
            accumulator.append(std::move(values));
        }
        return accumulator.rank();
    };
    int previous_rank = 0;
    for (std::size_t dim = 0; dim < info.levels.size(); ++dim) {
        const int count = info.levels[dim];
        const bool full = dim == standard_fes.size();
        const int rank = rank_of(full ? standard_fes.size() : dim + 1, full);
        if (rank < previous_rank || rank - previous_rank > count) {
            throw std::runtime_error(
                "dofadjustments(exact): rational rank failed its dimension invariant; "
                "no estimates returned and no approximate rank fallback");
        }
        const int increment = rank - previous_rank;
        info.num_coefs.push_back(increment);
        info.redundant.push_back(count - increment);
        info.inexact.push_back(0);
        previous_rank = rank;
    }
    info.df_a_levels = columns;
    info.df_a_exact = previous_rank;
    info.df_a = previous_rank;
    return info;
}

struct UnionFind {
    std::vector<int> parent;
    std::vector<uint8_t> rank;

    explicit UnionFind(int n) : parent(static_cast<std::size_t>(n)), rank(static_cast<std::size_t>(n), 0) {
        std::iota(parent.begin(), parent.end(), 0);
    }

    int find(int x) {
        while (parent[static_cast<std::size_t>(x)] != x) {
            parent[static_cast<std::size_t>(x)] =
                parent[static_cast<std::size_t>(parent[static_cast<std::size_t>(x)])];
            x = parent[static_cast<std::size_t>(x)];
        }
        return x;
    }

    void unite(int a, int b) {
        int ra = find(a);
        int rb = find(b);
        if (ra == rb) {
            return;
        }
        const std::size_t rra = static_cast<std::size_t>(ra);
        const std::size_t rrb = static_cast<std::size_t>(rb);
        if (rank[rra] < rank[rrb]) {
            parent[rra] = rb;
        } else if (rank[rra] > rank[rrb]) {
            parent[rrb] = ra;
        } else {
            parent[rrb] = ra;
            rank[rra] += 1;
        }
    }
};

constexpr const char* kMobilityProfileDefaultPath = "xhdfe_mobility_profile.txt";
constexpr std::uint64_t kFnvOffset64 = 1469598103934665603ULL;
constexpr std::uint64_t kFnvPrime64 = 1099511628211ULL;

struct MobilityProfileConfig {
    std::string path;
    std::string mode;  // off, auto, read, write
    bool allow_auto_write = false;
};

struct AbsorptionCacheConfig {
    std::string path;
    std::string mode;  // off, auto, read, write
    bool allow_auto_write = false;
    bool mode_set = false;
};

struct FeStructureCacheConfig {
    std::string path;
    std::string mode;  // off, auto, read, write
    bool allow_auto_write = false;
};

struct MobilityProfile {
    int format_version = 0;
    std::string profile_kind;
    std::uint64_t signature = 0;
    std::uint64_t signature_sample = 0;
    bool has_signature_sample = false;
    std::uint64_t signature_canon = 0;
    std::uint64_t signature_sample_canon = 0;
    bool has_signature_canon = false;
    bool has_signature_sample_canon = false;
    int nobs = 0;
    int nobs_full = 0;
    int num_singletons = 0;
    int nfe = 0;
    std::vector<int> fe_levels;
    int num_components = 0;
    int largest_component = 0;
    double largest_component_share = 0.0;
    std::string mobility_class;
    std::vector<int> sweep_order;
    bool suggest_symmetric = false;
    AbsorptionMethod suggest_method = AbsorptionMethod::Auto;
    bool suggest_use_sparse = false;
    bool suggest_use_krylov = false;
};

struct MobilityHint {
    std::vector<int> sweep_order;
    bool force_symmetric = false;
    AbsorptionMethod preferred_method = AbsorptionMethod::Auto;
    bool has_method = false;
    bool use_sparse = false;
    bool use_krylov = false;
};

std::string to_lower_ascii(const std::string& s) {
    std::string out;
    out.reserve(s.size());
    for (unsigned char c : s) {
        out.push_back(static_cast<char>(std::tolower(c)));
    }
    return out;
}

std::string trim_ascii(const std::string& s) {
    std::size_t start = 0;
    while (start < s.size() &&
           std::isspace(static_cast<unsigned char>(s[start]))) {
        ++start;
    }
    std::size_t end = s.size();
    while (end > start &&
           std::isspace(static_cast<unsigned char>(s[end - 1]))) {
        --end;
    }
    return s.substr(start, end - start);
}

bool gpu_backend_env_requested() {
    if (detail::has_thread_gpu_backend_override()) {
        return detail::thread_gpu_backend_override() !=
               detail::GpuBackend::Cpu;
    }
    const char* raw = std::getenv("XHDFE_GPU_BACKEND");
    if (!raw || *raw == '\0') {
        return false;
    }
    const std::string value = to_lower_ascii(trim_ascii(raw));
    return value == "cuda" || value == "metal";
}

bool cuda_backend_env_requested() {
    if (detail::has_thread_gpu_backend_override()) {
        return detail::thread_gpu_backend_override() ==
               detail::GpuBackend::Cuda;
    }
    const char* raw = std::getenv("XHDFE_GPU_BACKEND");
    if (!raw || *raw == '\0') {
        return false;
    }
    return to_lower_ascii(trim_ascii(raw)) == "cuda";
}

bool require_cuda_compatible_method(const HdfeOptions& options,
                                    std::size_t fe_dimensions) {
    const bool required = cuda_backend_env_requested();
    if (!required && gpu_backend_env_requested()) {
        throw std::runtime_error(
            "The requested Metal backend is not implemented; select CPU or CUDA. "
            "No estimates returned.");
    }
    if (required && fe_dimensions == 0) {
        throw std::runtime_error(
            "CUDA absorption requires at least one fixed-effect dimension; "
            "select CPU for ordinary least squares. No estimates returned.");
    }
    if (required &&
        (options.absorption_method == AbsorptionMethod::Lsmr ||
         options.absorption_method == AbsorptionMethod::Mlsmr)) {
        throw std::runtime_error(
            "absorptionmethod(lsmr/mlsmr) is CPU-only; "
            "choose CPU explicitly or a CUDA-compatible absorption method");
    }
    if (required && !detail::cuda_backend_available()) {
        throw std::runtime_error(
            "Requested GPU backend is unavailable; CPU fallback is disabled");
    }
    return required;
}

// An explicitly opted-in fit with a weights vector (including all ones or zeros) and two
// or more absorbed effect dimensions as received, in reghdfe-comparable or
// strict-residual mode, whose effective backend (the absorbers' reading, recorded
// at the entry) is CUDA, runs as the CPU call. A group() call without individual()
// is the collapsed weighted fit and is routed too (c/RESPOSTA_2_C.md); fit_grouped
// with individual() does not pass through fit. Evaluated by fit only: the partial-out
// entry keeps the device route. `required` means that the explicit CUDA
// request has passed validation, including the device check. Check the
// resolved backend before routing, including for explicit requests.
bool weighted_cpu_route_applies(const HdfeOptions& options,
                                const Eigen::VectorXd* weights,
                                std::size_t fe_dimensions,
                                bool required) {
    if (weights == nullptr || fe_dimensions < 2) {
        return false;
    }
    if (options.tolerance_mode != ToleranceMode::ReghdfeComparable &&
        options.tolerance_mode != ToleranceMode::StrictResidual) {
        return false;
    }
    if (detail::effective_gpu_backend() != detail::GpuBackend::Cuda) {
        return false;
    }
    return required || detail::cuda_backend_available();
}

// The Krylov absorber of a result with mlsmr_used: the device LSMR when the GPU
// produced the transform, the host MLSMR otherwise, including the host
// completion of a CUDA three-FE tail (F2-A). The reported method also routes
// the later re-absorptions of the same fit (stored residuals, N1 refinement).
AbsorptionMethod krylov_method_used(const detail::AbsorptionResult& result) {
    return result.gpu_used && result.cuda_tail != detail::kCudaTailHostMlsmr
               ? AbsorptionMethod::Lsmr
               : AbsorptionMethod::Mlsmr;
}

void require_cuda_execution(bool required, const detail::AbsorptionResult& result) {
    if (required && !result.gpu_used) {
        throw std::runtime_error(
            "Requested CUDA backend was not used; refusing a CPU absorption result");
    }
}

void require_accepted_absorption(const HdfeOptions& options,
                                 const detail::AbsorptionResult& result,
                                 const char* phase,
                                 const std::string& measured_criteria = {}) {
    if (result.converged && result.precision_certified && result.cuda_projection_moments_met &&
        result.weighted_gs_moments_met && result.strict_cpu_max_abs_mean <= options.tol) return;
    const bool slope_continuation = result.slope_accuracy_retry_stages > 0;
    std::ostringstream message;
    if (result.gpu_status_code == 2) {
        message << "Requested GPU backend was unavailable during ";
    } else if (result.gpu_status_code == 3) {
        message << (slope_continuation
            ? "Requested GPU backend did not satisfy absorption acceptance during "
            : "Requested GPU backend did not converge during ");
    } else if (result.gpu_status_code == 4) {
        message << "Requested GPU backend failed during ";
    } else if (result.gpu_status_code == 5) {
        message << "Requested GPU backend was bypassed by CPU cache/profile state during ";
    }
    message << phase;
    if (slope_continuation) {
        message << ": heterogeneous-slope acceptance criteria not met after continuation";
    } else if (result.fast_repair_target > 0.0) {
        // P3-fix (C): a converged, publicly certified repair short of its target.
        message << ": the CUDA repair converged and passed the public certificate but "
                   "missed the bounded xhdfe-fast repair target (relative residual <= "
                << std::scientific << result.fast_repair_target << ')';
        if (result.cuda_fast_cg_restarts > 0) {
            message << " after " << result.cuda_fast_cg_restarts
                    << " cold restart(s) of its broken CG stage"
                    << (result.cuda_fast_lsmr_restart ? " and the device LSMR" : "");
        }
    } else {
        message << (result.converged ? ": precision certification failed" : ": did not converge");
    }
    if (result.strict_cpu_max_abs_mean > options.tol) {
        message << "; strict-residual max absolute group mean=" << std::scientific
                << result.strict_cpu_max_abs_mean;
    }
    if (!result.weighted_gs_moments_met) {
        message << "; weighted Gauss-Seidel fixed-effect moments exceed the comparable limit";
    }
    if (!result.cuda_projection_moments_met) {
        message << "; CUDA projection fixed-effect moments exceed the comparable limit";
    }
    message << "; iterations=" << result.iterations << "/" << options.max_iter
            << "; requested tolerance=" << std::scientific << options.tol
            << "; relative residual=" << result.abs_residual_rel << measured_criteria;
    if (slope_continuation) {
        // Report the existing limits; final flags do not retain the last solve's state.
        const double effective_tol =
            options.tolerance_mode == ToleranceMode::ReghdfeComparable
                ? std::min(options.tol, 1.0e-9) : options.tol;
        const double arithmetic_floor = 64.0 * std::numeric_limits<double>::epsilon();
        if (options.tolerance_mode == ToleranceMode::XhdfeFast) {
            message << "; aggregate certificate limit="
                    << std::max(8.0 * std::max(0.0, effective_tol), arithmetic_floor)
                    << "; slope block check=not performed";
        } else {
            message << "; slope block residual=" << result.slope_block_residual_rel
                    << "; block certificate limit="
                    << std::max(8.0 * std::max(0.0, effective_tol), arithmetic_floor)
                    << "; continuation target=" << std::max(effective_tol, arithmetic_floor);
        }
        message << "; continuation stages=" << result.slope_accuracy_retry_stages
                << "; last internal tolerance=" << result.slope_internal_tolerance;
    }
    message << ". No estimates returned.";
    if (result.iterations >= options.max_iter) {
        message << " The iteration limit was reached; increase max_iter/maxiter() and retry.";
    } else if (slope_continuation) {
        message << " The continuation sequence was exhausted with iteration budget remaining.";
    } else {
        message << " Check variable scaling and model identification; do not treat a solver stop as a precision certificate.";
    }
    throw std::runtime_error(message.str());
}

std::string group_failure_criteria(
    const Eigen::VectorXd& y, const Eigen::MatrixXd& X,
    const std::vector<Eigen::VectorXi>& fes,
    const detail::GroupIndividualStructure& gi,
    const Eigen::VectorXd* weights, const HdfeOptions& options,
    const detail::AbsorptionResult& result) {
    if (result.y_tilde.size() != y.size() || result.X_tilde.rows() != y.size() ||
        result.X_tilde.cols() != X.cols()) return "; final residual dimensions are invalid";
    if (!hdfe::detail::ieee_all_finite(result.y_tilde) ||
        !hdfe::detail::ieee_all_finite(result.X_tilde)) return "; final projected values are not finite";
    const int n = static_cast<int>(y.size());
    const int rhs_count = static_cast<int>(X.cols()) + 1;
    std::vector<long double> moment_norm_sq(rhs_count, 0.0L);
    long double max_mean = 0.0L;
    int active_columns = 0;
    auto residual = [&](int row, int rhs) -> long double {
        return rhs ? result.X_tilde(row, rhs - 1) : result.y_tilde[row];
    };
    auto collect = [&](const std::vector<long double>& diagonal,
                       const Eigen::Matrix<long double, Eigen::Dynamic, Eigen::Dynamic>& moments) {
        for (int column = 0; column < static_cast<int>(diagonal.size()); ++column) {
            if (!(diagonal[column] > 0.0L)) continue;
            ++active_columns;
            for (int rhs = 0; rhs < rhs_count; ++rhs) {
                const long double value = moments(column, rhs);
                moment_norm_sq[rhs] += value * value / diagonal[column];
                max_mean = std::max(max_mean, std::abs(value / diagonal[column]));
            }
        }
    };
    for (const auto& fe : fes) {
        std::unordered_map<int, int> ids;
        for (int row = 0; row < n; ++row) ids.emplace(fe[row], static_cast<int>(ids.size()));
        std::vector<long double> diagonal(ids.size(), 0.0L);
        Eigen::Matrix<long double, Eigen::Dynamic, Eigen::Dynamic> moments =
            Eigen::Matrix<long double, Eigen::Dynamic, Eigen::Dynamic>::Zero(ids.size(), rhs_count);
        for (int row = 0; row < n; ++row) {
            const int id = ids.at(fe[row]);
            const long double weight = weights ? (*weights)[row] : 1.0L;
            diagonal[id] += weight;
            for (int rhs = 0; rhs < rhs_count; ++rhs) moments(id, rhs) += weight * residual(row, rhs);
        }
        collect(diagonal, moments);
    }
    std::vector<long double> diagonal(gi.num_individuals, 0.0L);
    Eigen::Matrix<long double, Eigen::Dynamic, Eigen::Dynamic> moments =
        Eigen::Matrix<long double, Eigen::Dynamic, Eigen::Dynamic>::Zero(gi.num_individuals, rhs_count);
    for (int row = 0; row < n; ++row) {
        const long double weight = weights ? (*weights)[row] : 1.0L;
        const long double scale = gi.group_scale[row];
        for (int edge = gi.group_ptr[row]; edge < gi.group_ptr[row + 1]; ++edge) {
            const int id = gi.group_individual[edge];
            diagonal[id] += weight * scale * scale;
            for (int rhs = 0; rhs < rhs_count; ++rhs) moments(id, rhs) += weight * scale * residual(row, rhs);
        }
    }
    collect(diagonal, moments);
    long double canonical = 0.0L;
    for (int rhs = 0; rhs < rhs_count; ++rhs) {
        long double norm_original = 0.0L, norm_residual = 0.0L;
        for (int row = 0; row < n; ++row) {
            const long double weight = weights ? (*weights)[row] : 1.0L;
            const long double original = rhs ? X(row, rhs - 1) : y[row];
            norm_original += weight * original * original;
            norm_residual += weight * residual(row, rhs) * residual(row, rhs);
        }
        const long double consistent = norm_original > 0.0L ? std::sqrt(norm_residual / norm_original)
            : (norm_residual > 0.0L ? std::numeric_limits<long double>::infinity() : 0.0L);
        const long double ls = norm_residual > 0.0L && active_columns > 0
            ? std::sqrt(moment_norm_sq[rhs] / (active_columns * norm_residual))
            : (moment_norm_sq[rhs] > 0.0L ? std::numeric_limits<long double>::infinity() : 0.0L);
        canonical = std::max(canonical, std::min(consistent, ls));
    }
    std::ostringstream message;
    const double effective_tolerance = options.tolerance_mode == ToleranceMode::ReghdfeComparable
        ? std::min(options.tol, 1.0e-9) : options.tol;
    message << std::scientific << "; recomputed group certificate=" << static_cast<double>(canonical)
            << "; group certificate limit="
            << std::max(effective_tolerance, 512.0 * std::numeric_limits<double>::epsilon());
    if (options.tolerance_mode == ToleranceMode::StrictResidual) {
        message << "; strict max weighted FE mean=" << static_cast<double>(max_mean)
                << "; strict limit=" << std::max(options.tol, 64.0 * std::numeric_limits<double>::epsilon());
    }
    message << "; these are measured stopping criteria, not coefficient-error bounds";
    if (result.krylov_max_condition > 0.0) {
        message << "; LSMR condition estimate (lower bound)=" << result.krylov_max_condition
                << "; forward projection error bound (condition x dual residual)="
                << result.krylov_max_condition_times_backward_error
                << "; forward target=" << detail::group_forward_tolerance(options);
        if (result.krylov_max_condition_times_backward_error >
            detail::group_forward_tolerance(options)) {
            message << "; the group/individual incidence design is too ill-conditioned for the"
                       " FP64 Krylov solver to certify this tolerance (nearly null FE directions)";
        }
    }
    if (detail::ordinary_audit_enabled()) {
        const auto forward = detail::certify_group_forward_space(y, X, fes, gi, weights, options, result);
        if (forward.eligible) {
            message << "; FE-space orthogonality bound / allowed error=" << forward.worst_ratio
                    << "; full certification also checks affine reconstruction and residual error against the original data";
            if (!forward.unavailable.empty()) message << "; forward check unavailable: " << forward.unavailable;
        }
    }
    return message.str();
}

std::uint64_t mobility_backend_tag() {
    if (detail::has_thread_gpu_backend_override()) {
        switch (detail::thread_gpu_backend_override()) {
            case detail::GpuBackend::Cuda:
                return 1ULL;
            case detail::GpuBackend::Metal:
                return 2ULL;
            case detail::GpuBackend::Cpu:
            default:
                return 0ULL;
        }
    }
    const char* raw = std::getenv("XHDFE_GPU_BACKEND");
    if (!raw || *raw == '\0') {
#ifndef HDFE_GPU_BACKEND_DEFAULT
#define HDFE_GPU_BACKEND_DEFAULT "cpu"
#endif
        raw = HDFE_GPU_BACKEND_DEFAULT;
    }
    const std::string value = to_lower_ascii(trim_ascii(raw));
    if (value == "cuda") {
        return 1ULL;
    }
    if (value == "metal") {
        return 2ULL;
    }
    return 0ULL;
}

bool mobility_gpu_backend_selected() {
    return mobility_backend_tag() != 0ULL;
}

std::optional<bool> read_env_bool(const char* name) {
    const char* raw = std::getenv(name);
    if (!raw || *raw == '\0') {
        return std::nullopt;
    }
    const std::string value = to_lower_ascii(trim_ascii(raw));
    if (value == "1" || value == "true" || value == "yes" || value == "on") {
        return true;
    }
    if (value == "0" || value == "false" || value == "no" || value == "off") {
        return false;
    }
    return std::nullopt;
}

// XHDFE_EARLY_ROUTING_TRACE=1 (measurement for package D1, read once per
// process): the regressor adds to the absorber's trace one line before the
// primary solve, one before a conjugate-gradient restart and one with the
// outcome of the ordinary routing retry. It changes nothing else.
bool early_routing_trace_on() {
    static const bool on = []() {
        const char* e = std::getenv("XHDFE_EARLY_ROUTING_TRACE");
        return e != nullptr && e[0] == '1' && e[1] == '\0';
    }();
    return on;
}

int read_env_int(const char* name, int default_value, int min_value) {
    const char* raw = std::getenv(name);
    if (!raw || *raw == '\0') {
        return default_value;
    }
    char* end = nullptr;
    const long parsed = std::strtol(raw, &end, 10);
    if (end == raw || parsed < static_cast<long>(min_value)) {
        return default_value;
    }
    if (parsed > static_cast<long>(std::numeric_limits<int>::max())) {
        return std::numeric_limits<int>::max();
    }
    return static_cast<int>(parsed);
}

double read_env_double(const char* name,
                       double default_value,
                       double min_value,
                       double max_value) {
    const char* raw = std::getenv(name);
    if (!raw || *raw == '\0') {
        return default_value;
    }
    char* end = nullptr;
    const double parsed = std::strtod(raw, &end);
    if (end == raw || !hdfe::detail::ieee_finite(parsed) || parsed < min_value ||
        parsed > max_value) {
        return default_value;
    }
    return parsed;
}

bool file_exists(const std::string& path) {
    if (path.empty()) {
        return false;
    }
    std::ifstream in(path);
    return static_cast<bool>(in);
}

std::uint64_t fnv1a_update(std::uint64_t hash, std::uint64_t value) {
    hash ^= value;
    hash *= kFnvPrime64;
    return hash;
}

std::uint64_t hash_fe_signature(const std::vector<Eigen::VectorXi>& fes,
                                bool drop_singletons) {
    std::uint64_t hash = kFnvOffset64;
    hash = fnv1a_update(hash, static_cast<std::uint64_t>(fes.size()));
    const std::uint64_t nobs = fes.empty() ? 0ULL : static_cast<std::uint64_t>(fes[0].size());
    hash = fnv1a_update(hash, nobs);
    hash = fnv1a_update(hash, drop_singletons ? 1ULL : 0ULL);
    for (const auto& fe : fes) {
        hash = fnv1a_update(hash, static_cast<std::uint64_t>(fe.size()));
        for (int i = 0; i < fe.size(); ++i) {
            const std::int64_t v = static_cast<std::int64_t>(fe(i));
            hash = fnv1a_update(hash, static_cast<std::uint64_t>(v));
        }
    }
    return hash;
}

std::uint64_t hash_fe_signature_sample(const std::vector<Eigen::VectorXi>& fes,
                                       bool drop_singletons) {
    std::uint64_t hash = kFnvOffset64;
    hash = fnv1a_update(hash, static_cast<std::uint64_t>(fes.size()));
    const int nobs = fes.empty() ? 0 : static_cast<int>(fes[0].size());
    hash = fnv1a_update(hash, static_cast<std::uint64_t>(nobs));
    hash = fnv1a_update(hash, drop_singletons ? 1ULL : 0ULL);
    if (nobs <= 0) {
        return hash;
    }
    const int max_samples = 4096;
    const int sample_count = std::min(nobs, max_samples);
    const int stride = std::max(1, nobs / sample_count);
    std::vector<int> sample_idx;
    sample_idx.reserve(static_cast<std::size_t>(sample_count));
    for (int i = 0; i < nobs && static_cast<int>(sample_idx.size()) < sample_count; i += stride) {
        sample_idx.push_back(i);
    }
    for (const auto& fe : fes) {
        hash = fnv1a_update(hash, static_cast<std::uint64_t>(fe.size()));
        for (int idx : sample_idx) {
            hash = fnv1a_update(hash, static_cast<std::uint64_t>(idx));
            const std::int64_t v = static_cast<std::int64_t>(fe(idx));
            hash = fnv1a_update(hash, static_cast<std::uint64_t>(v));
        }
    }
    return hash;
}

std::uint64_t hash_fe_signature_filtered(const std::vector<Eigen::VectorXi>& fes,
                                         const std::vector<int>* kept_idx,
                                         bool drop_singletons) {
    std::uint64_t hash = kFnvOffset64;
    hash = fnv1a_update(hash, static_cast<std::uint64_t>(fes.size()));
    const std::uint64_t nobs = kept_idx
                                   ? static_cast<std::uint64_t>(kept_idx->size())
                                   : (fes.empty() ? 0ULL
                                                  : static_cast<std::uint64_t>(fes[0].size()));
    hash = fnv1a_update(hash, nobs);
    hash = fnv1a_update(hash, drop_singletons ? 1ULL : 0ULL);
    for (const auto& fe : fes) {
        hash = fnv1a_update(hash, nobs);
        if (kept_idx) {
            for (int idx : *kept_idx) {
                const std::int64_t v = static_cast<std::int64_t>(fe(idx));
                hash = fnv1a_update(hash, static_cast<std::uint64_t>(v));
            }
        } else {
            for (int i = 0; i < fe.size(); ++i) {
                const std::int64_t v = static_cast<std::int64_t>(fe(i));
                hash = fnv1a_update(hash, static_cast<std::uint64_t>(v));
            }
        }
    }
    return hash;
}

std::uint64_t hash_fe_signature_sample_filtered(const std::vector<Eigen::VectorXi>& fes,
                                                const std::vector<int>* kept_idx,
                                                bool drop_singletons) {
    std::uint64_t hash = kFnvOffset64;
    hash = fnv1a_update(hash, static_cast<std::uint64_t>(fes.size()));
    const int nobs = kept_idx
                         ? static_cast<int>(kept_idx->size())
                         : (fes.empty() ? 0 : static_cast<int>(fes[0].size()));
    hash = fnv1a_update(hash, static_cast<std::uint64_t>(nobs));
    hash = fnv1a_update(hash, drop_singletons ? 1ULL : 0ULL);
    if (nobs <= 0) {
        return hash;
    }
    const int max_samples = 4096;
    const int sample_count = std::min(nobs, max_samples);
    const int stride = std::max(1, nobs / sample_count);
    std::vector<int> sample_idx;
    sample_idx.reserve(static_cast<std::size_t>(sample_count));
    for (int i = 0; i < nobs && static_cast<int>(sample_idx.size()) < sample_count; i += stride) {
        sample_idx.push_back(i);
    }
    for (const auto& fe : fes) {
        hash = fnv1a_update(hash, static_cast<std::uint64_t>(nobs));
        for (int pos : sample_idx) {
            hash = fnv1a_update(hash, static_cast<std::uint64_t>(pos));
            const int raw_idx = kept_idx ? (*kept_idx)[static_cast<std::size_t>(pos)] : pos;
            const std::int64_t v = static_cast<std::int64_t>(fe(raw_idx));
            hash = fnv1a_update(hash, static_cast<std::uint64_t>(v));
        }
    }
    return hash;
}

std::uint64_t hash_fe_signature_from_indexers(const std::vector<FeIndexerLite>& indexers,
                                              int nobs,
                                              bool drop_singletons) {
    std::uint64_t hash = kFnvOffset64;
    hash = fnv1a_update(hash, static_cast<std::uint64_t>(indexers.size()));
    hash = fnv1a_update(hash, static_cast<std::uint64_t>(std::max(0, nobs)));
    hash = fnv1a_update(hash, drop_singletons ? 1ULL : 0ULL);
    for (const auto& idx : indexers) {
        hash = fnv1a_update(hash, static_cast<std::uint64_t>(idx.group_ids.size()));
        for (int v : idx.group_ids) {
            hash = fnv1a_update(hash, static_cast<std::uint64_t>(static_cast<std::int64_t>(v)));
        }
    }
    return hash;
}

std::uint64_t hash_fe_signature_sample_from_indexers(const std::vector<FeIndexerLite>& indexers,
                                                     int nobs,
                                                     bool drop_singletons) {
    std::uint64_t hash = kFnvOffset64;
    hash = fnv1a_update(hash, static_cast<std::uint64_t>(indexers.size()));
    hash = fnv1a_update(hash, static_cast<std::uint64_t>(std::max(0, nobs)));
    hash = fnv1a_update(hash, drop_singletons ? 1ULL : 0ULL);
    if (nobs <= 0) {
        return hash;
    }
    const int max_samples = 4096;
    const int sample_count = std::min(nobs, max_samples);
    const int stride = std::max(1, nobs / sample_count);
    std::vector<int> sample_idx;
    sample_idx.reserve(static_cast<std::size_t>(sample_count));
    for (int i = 0; i < nobs && static_cast<int>(sample_idx.size()) < sample_count; i += stride) {
        sample_idx.push_back(i);
    }
    for (const auto& idx : indexers) {
        hash = fnv1a_update(hash, static_cast<std::uint64_t>(idx.group_ids.size()));
        for (int pos : sample_idx) {
            hash = fnv1a_update(hash, static_cast<std::uint64_t>(pos));
            const std::int64_t v =
                static_cast<std::int64_t>(idx.group_ids[static_cast<std::size_t>(pos)]);
            hash = fnv1a_update(hash, static_cast<std::uint64_t>(v));
        }
    }
    return hash;
}

using FeStructureDigest = std::array<std::uint8_t, 32>;

FeStructureDigest hash_fe_structure_cache_signature(const std::vector<Eigen::VectorXi>& fes,
                                                const Eigen::VectorXd* weights,
                                                bool drop_singletons,
                                                bool weights_are_frequencies,
                                                int threads,
                                                detail::ParallelWorkObserver* observer) {
    detail::CacheDigestBuilder hash(UINT64_C(0x4645535452554332));
    hash.word(drop_singletons);
    hash.word(weights_are_frequencies);
    hash.word(fes.size());
    for (const auto& fe : fes) hash.data(fe.data(), fe.size() * sizeof(int));
    if (drop_singletons && weights_are_frequencies && weights) {
        hash.data(weights->data(), weights->size() * sizeof(double));
    }
    return hash.finish(threads, observer);
}

constexpr const char* kAbsorptionCacheMagicV5 = "xhdfe_absorption_cache_v5";
constexpr const char* kAbsorptionCacheMagicV6 = "xhdfe_absorption_cache_v6";
constexpr std::size_t kAbsorptionCacheMagicSize = 32;
constexpr std::uint64_t kAbsorptionCacheSalt = 0x9e3779b97f4a7c15ULL;
// Invalidate transforms certified before the xhdfe-fast CUDA CG restart and the
// strict-residual recovery sequence of a broken CUDA CG stage (P3-fix (3'),
// rounds 20-21 and scope addendum 2).
// P8 (lean 2.31.0): invalidate transforms certified before the weighted CPU
// retry and its cumulative budget, previously 0x22624841443f.
constexpr std::uint64_t kAbsorptionSolveContractGeneration = 0x2262484144c1ULL;
// Separate ordinary weighted four-effect CPU fits from their old shared
// cache, and from each other: plain, captured, and captured with E1.
constexpr std::uint64_t kWeightedFourFeCpuCacheGeneration = 0x2262484144c2ULL;
constexpr std::uint64_t kWeightedThreeFeIvCpuCacheGeneration = 0x2262484144c5ULL;
constexpr std::uint64_t kCpuStrictRepairCacheGeneration = 0x2262484144c8ULL;
constexpr std::uint64_t kWeightedPartialOutRepairCacheGeneration = 0x2262484144c9ULL;
constexpr std::uint64_t kAkmRelativeFwlCacheGeneration = 0x2262484144caULL;
constexpr std::uint64_t kEffectiveBackendCacheProvenance = 0x2262484144cbULL;
constexpr std::int32_t kAbsorptionCacheConverged = 1;
constexpr std::int32_t kAbsorptionCachePublishedSavefe = 2;
constexpr std::int32_t kAbsorptionCacheCpuRefined = 4;
// 2: early routing (status 4) and its switch in the key.
constexpr std::uint64_t kOrdinaryAutoRoutingRetryPolicyVersion = 2ULL;
// The verified abs_residual_rel above which a certified sweep primary is
// re-solved with MLSMR; also the acceptance trigger of the R1 tier.
constexpr double kOrdinaryAutoRoutingRetryTrigger = 1.0e-11;
// The reduced-system tier: mixed into the absorption cache key while the tier
// is on for the fit (its effective switch: the fit's request, else the process
// default, on unless XHDFE_REDUCED_PCG=0). "C232_RPC", replacing
// R1's "R1_REDPC" (0x52315f5245445043), so that no entry an R1 binary wrote
// (with its method stored as the internal route) is ever read.
constexpr std::uint64_t kReducedPcgCacheTag = 0x433233325f525043ULL;
// D10: an entry whose tier stopped on the confirmed chat ("D10_CHAT") never
// serves a fit under the rule before D10, and the reverse; with D10 not applying
// (switch off, or a tolerance whose certificate is stricter than the trigger)
// the key is the key before D10, word for word.
constexpr std::uint64_t kReducedPcgChatStopCacheTag = 0x4431305f43484154ULL;
// Package D, 3.1 (23nov2026): the partition of the CPU tier's segment pass
// ("PARTITN1"), then the policy (the effective factor from 1 to 8, or "AUTO_APP"
// and the signature of the automatic rule) and the base blocks, wherever the
// CPU tier is effective for the fit. It replaces package A's "FINE_APP" word
// (0x46494e455f415050), so that no entry written by package A or by 2.34.2
// with the tier on, whose partition the key cannot identify, is ever read.
constexpr std::uint64_t kReducedPcgPartitionCacheTag = 0x5041525449544e31ULL;
constexpr std::uint64_t kReducedPcgApplyFineAutoCacheWord = 0x4155544f5f415050ULL;

struct AbsorptionCacheKey {
    std::uint64_t sig1 = 0;
    std::uint64_t sig2 = 0;
    std::array<std::uint64_t,2> tail{};
    int hash_threads = 1;
    detail::ParallelWorkObserver* hash_observer = nullptr;
    bool legacy_v5 = false;
    bool capture = false;
    bool require_cpu_refined = false;
};

struct CachedSavefeEffect {
    // The first occurrence identifies the level without depending on its raw
    // or recoded label. An empty index vector denotes exact per-row values.
    std::vector<int> first_rows;
    Eigen::VectorXd values;
};

struct CachedSavefePublication {
    // The coefficients at the recovery entry, including the pre-recovery
    // intercept if present, and the structural columns in their fitted order.
    Eigen::VectorXd beta;
    std::vector<int> kept_columns;
    FeStructureDigest ols_residual_digest{};
    double intercept = 0.0;
    Eigen::VectorXd residuals;
    std::vector<CachedSavefeEffect> effects;
    int recovery_iterations = 0;
    double recovery_max_delta = 0.0;
    int hybrid_recovery = 0;
    int internal_method = 0;
    int tuned_method = 0;
    unsigned int route_flags = 0;
    int tier_status = 0;
    std::string tier_reason;
    int tier_discarded = 0;
    ReducedPcgFineDiagnostics tier_fine;
    double abs_residual = 0.0;
    double abs_residual_rel = 0.0;
};

struct SavefeCacheMiss {};

struct AbsorptionCacheRecord {
    AbsorptionMethod method = AbsorptionMethod::Auto;
    int design_cols = 0;
    int nobs = 0;
    int cols = 0;
    int iterations = 0;
    bool converged = true;
    bool savefe_projection_published = false;
    bool cpu_projection_refined = false;
    double krylov_internal_tolerance = 0.0;
    double krylov_max_final_backward_error = 0.0;
    double krylov_max_condition = 0.0;
    double krylov_max_condition_times_backward_error = 0.0;
    bool auto_routing_retry_policy_enabled = false;
    bool auto_routing_retry_eligible = false;
    bool auto_routing_retry_fired = false;
    int auto_routing_retry_status = 0;
    int auto_routing_retry_primary_method = -1;
    int auto_routing_retry_primary_iterations = 0;
    double auto_routing_retry_primary_abs_residual_rel = 0.0;
    int auto_routing_retry_iterations = 0;
    double auto_routing_retry_abs_residual_rel = 0.0;
    double auto_routing_retry_elapsed_seconds = 0.0;
    std::vector<int> fe_levels;
    std::vector<int> sweep_order;
    Eigen::VectorXd y_tilde;
    Eigen::MatrixXd X_tilde;
    std::optional<CachedSavefePublication> savefe;
};

std::uint64_t hash_double_bits(double value) {
    std::uint64_t bits = 0;
    std::memcpy(&bits, &value, sizeof(bits));
    return bits;
}

std::uint64_t cache_hash_update(std::uint64_t hash, std::uint64_t value) {
    // Mix high bits down before the rolling update. In particular, a sign-bit
    // change must not remain a toggle of the hash's top bit.
    value ^= value >> 33;
    value *= UINT64_C(0xff51afd7ed558ccd);
    value ^= value >> 33;
    value *= UINT64_C(0xc4ceb9fe1a85ec53);
    value ^= value >> 33;
    return fnv1a_update(hash, value);
}

void hash_update_double(std::uint64_t& hash, double value) {
    hash = cache_hash_update(hash, hash_double_bits(value));
}

// Package D, round 09 (B) and round 11: the fits whose key carries the
// partition of the CPU tier's segment pass are those the tier can take by their
// options: the conditions of the tier's entry in fit() that both key sites know
// for certain ("method", "criterion", "tolerance_mode", "tol", "gpu", "weights",
// "groupvar", "fe_count", "parity_floor", "forced_solver"), and "iv", which fit()
// states and partial_out() (no instruments) passes as false. At the snapshot both
// sites hash (the tuned options before the solve) these fields equal what the
// entry reads: nothing writes them between the snapshot and the entry. The set
// errs on the side of the words: a fit the tier then refuses for a reason known
// only later (slopes, whose fits use no cache; saved effects without a
// projection; the group retry; a profile write; a nested region) keeps them,
// which can only cost a miss; a fit outside the set (the fast mode, a weighted
// fit, a GPU fit, an IV fit, a forced solver, the parity floor off, the tier off)
// keeps the key of 2.34.2 word for word.
bool reduced_pcg_partition_keyed(const HdfeOptions& options, const Eigen::VectorXd* weights,
                                 std::size_t effects, bool instrumented) {
    return detail::reduced_pcg_effective(options) && !gpu_backend_env_requested() &&
           options.absorption_method == AbsorptionMethod::Auto &&
           options.convergence_criterion == ConvergenceCriterion::Auto &&
           options.tolerance_mode == ToleranceMode::ReghdfeComparable && options.tol > 0.0 &&
           weights == nullptr && !options.save_groupvar && effects >= 2 && effects <= 5 &&
           options.ordinary_krylov_parity_floor && !options.use_krylov && !options.use_sparse_solver &&
           !instrumented;
}

AbsorptionCacheKey hash_absorption_signature(const Eigen::Ref<const Eigen::VectorXd>& y,
                                             const Eigen::Ref<const Eigen::MatrixXd>& X,
                                             const std::vector<Eigen::VectorXi>& fes,
                                             const Eigen::VectorXd* weights,
                                             const HdfeOptions& options,
                                             std::uint64_t solve_contract_generation,
                                             const FeStructureDigest* input_fe_structure = nullptr,
                                             bool instrumented = false,
                                             bool capture = false,
                                             bool e1_enabled = false,
                                             bool require_cpu_refined = false) {
    // Separate the combined-cache key from historical keys that hash each FE.
    detail::CacheDigestBuilder hash(input_fe_structure ? UINT64_C(0x5848444645434f4d)
                                                       : UINT64_C(0x5848444645494e50));
    auto update = [&](std::uint64_t value) {
        hash.word(value);
    };

    update(static_cast<std::uint64_t>(y.size()));
    update(static_cast<std::uint64_t>(X.rows()));
    update(static_cast<std::uint64_t>(X.cols()));
    update(static_cast<std::uint64_t>(fes.size()));
    update(solve_contract_generation);
    // These historical generations could only be written by the commands'
    // no-capture branches. Keep their v5 keys and bodies interoperable.
    const bool legacy_v5 = !capture &&
        (require_cpu_refined || solve_contract_generation == kWeightedFourFeCpuCacheGeneration ||
         solve_contract_generation == kWeightedThreeFeIvCpuCacheGeneration ||
         solve_contract_generation == kCpuStrictRepairCacheGeneration ||
         solve_contract_generation == kWeightedPartialOutRepairCacheGeneration);
    if (!legacy_v5) {
        update(UINT64_C(0x5848444645563600));  // "XHDFEV6"
        update(capture);
        update(e1_enabled);
        if (capture) {
            update(hash_double_bits(options.fe_tolerance));
            update(static_cast<std::uint64_t>(options.fe_recovery_method));
            update(static_cast<std::uint64_t>(options.savefe_fastpath_max_cols));
            update(static_cast<std::uint64_t>(resolve_fe_normalize_style(options.stats_style)));
            update(options.weights_are_frequencies);
            update(detail::reduced_pcg_apply_fine_request(options));
            update(detail::reduced_pcg_apply_fine_source(options));
            update(detail::deterministic_parallel_chunk_count(std::max<Eigen::Index>(1, y.size())));
        }
    }
    update(hdfe::detail::ordinary_audit_enabled() ? 1ULL : 0ULL);
    update(options.ordinary_krylov_parity_floor ? 1ULL : 0ULL);
    update(kOrdinaryAutoRoutingRetryPolicyVersion);
    update(options.ordinary_auto_routing_retry ? 1ULL : 0ULL);
    update(options.ordinary_auto_early_routing ? 1ULL : 0ULL);
    // R1: with the tier off the key is the base key, word for word. The tag
    // follows the effective switch of the fit (2.32 session switch), so an
    // entry written with the tier never serves a fit without it, and the reverse.
    if (detail::reduced_pcg_effective(options)) update(kReducedPcgCacheTag);
    if (detail::reduced_pcg_effective(options) &&
        detail::reduced_pcg_chat_stop_applies(options, kOrdinaryAutoRoutingRetryTrigger))
        update(kReducedPcgChatStopCacheTag);
    // Package D, 3.1 (23nov2026) and round 09 (B): for a fit the CPU tier can
    // take by its options (reduced_pcg_partition_keyed: its switch on, no GPU
    // requested, the comparable mode, unweighted, ...), the key identifies the
    // partition of the tier's segment pass: the policy in force (the effective
    // request of the fit, its own or the process value, where it can take
    // effect, else 1; or the automatic rule with its version) and the base
    // blocks that partition is built from (the deterministic chunks of the rows,
    // which follow the processors visible to the process above the floor of 48).
    // No entry written without these words is read by such a fit: those of
    // 2.34.2 and of package A among them. Every other fit (the fast mode, a
    // weighted fit, a GPU fit, the tier off) keeps the key of 2.34.2, word for word.
    if (reduced_pcg_partition_keyed(options, weights, fes.size(), instrumented)) {
        const int apply_fine = detail::reduced_pcg_apply_fine_effective(options);
        update(kReducedPcgPartitionCacheTag);
        if (apply_fine == kReducedPcgApplyFineAuto) {
            update(kReducedPcgApplyFineAutoCacheWord);
            update(detail::reduced_pcg_apply_fine_auto_rule());
        } else {
            update(static_cast<std::uint64_t>(apply_fine));
        }
        update(static_cast<std::uint64_t>(
            detail::deterministic_parallel_chunk_count(std::max<Eigen::Index>(1, y.size()))));
    }
    // P8: the switches of the weighted CPU retry and of its accounting, which
    // change a weighted transform; constant within a process, so a process with
    // one of them off never shares an entry with one that has it on.
    update((cpu_weighted_retry_enabled() ? 1ULL : 0ULL) |
           (cpu_retry_accounting_enabled() ? 2ULL : 0ULL));
    update(weights ? 1ULL : 0ULL);
    update(options.fit_intercept ? 1ULL : 0ULL);
    update(options.drop_singletons ? 1ULL : 0ULL);
    update(static_cast<std::uint64_t>(options.dof_method));
    update(options.dof_mobility_groups ? 1ULL : 0ULL);
    update(options.dof_adjust_clusters ? 1ULL : 0ULL);
    update(options.dof_adjust_continuous ? 1ULL : 0ULL);
    update(static_cast<std::uint64_t>(
        static_cast<std::uint32_t>(options.num_threads)));
    update(options.num_threads_explicit ? 1ULL : 0ULL);
    // CPU and accelerator transforms must never share a cache entry.  This
    // also makes a ScopedGpuBackendOverride(Cpu) in a nested estimator immune
    // to a previously certified-but-forward-different CUDA transform.
    // Older files cannot prove that a CPU tag was written on the CPU.
    update(kEffectiveBackendCacheProvenance);
    update(mobility_backend_tag());
    update(static_cast<std::uint64_t>(options.max_iter));
    update(static_cast<std::uint64_t>(static_cast<int>(options.tolerance_mode)));
    update(hash_double_bits(options.tol));

    // Solver-selection knobs that change the absorption transform or its
    // convergence path. Including them guarantees a cache entry computed under
    // one solver configuration is never reused for a different configuration
    // (e.g. forced method A vs B, symmetric sweep, Krylov/sparse, custom sweep
    // order). Computed once per fit(), outside all iteration loops.
    update(static_cast<std::uint64_t>(static_cast<int>(options.absorption_method)));
    update(static_cast<std::uint64_t>(static_cast<int>(options.convergence_criterion)));
    update(options.symmetric_sweep ? 1ULL : 0ULL);
    update(options.use_sparse_solver ? 1ULL : 0ULL);
    update(options.use_krylov ? 1ULL : 0ULL);
    update(static_cast<std::uint64_t>(static_cast<std::uint32_t>(options.convergence_check_interval)));
    update(hash_double_bits(options.krylov_lambda));
    update(hash_double_bits(options.jacobi_relaxation));
    update(hash_double_bits(options.sparse_threshold));
    update(static_cast<std::uint64_t>(options.sweep_order_override.size()));
    for (int so : options.sweep_order_override) {
        update(static_cast<std::uint64_t>(static_cast<std::int64_t>(so)));
    }

    if (input_fe_structure) {
        hash.data(input_fe_structure->data(), input_fe_structure->size());
    } else {
        for (const auto& fe : fes) {
            update(static_cast<std::uint64_t>(fe.size()));
            hash.data(fe.data(), static_cast<std::size_t>(fe.size()) * sizeof(int));
        }
    }

    hash.data(y.data(), static_cast<std::size_t>(y.size()) * sizeof(double));
    for (Eigen::Index j = 0; j < X.cols(); ++j) {
        hash.data(X.col(j).data(), static_cast<std::size_t>(X.rows()) * sizeof(double));
    }
    if (weights) {
        hash.data(weights->data(), static_cast<std::size_t>(weights->size()) * sizeof(double));
    }

    AbsorptionCacheKey key;
    key.legacy_v5 = legacy_v5;
    key.capture = capture;
    key.require_cpu_refined = require_cpu_refined;
    key.hash_threads = std::max(1, options.num_threads);
    key.hash_observer = options.parallel_observer;
    const auto digest = hash.finish(key.hash_threads, key.hash_observer);
    std::memcpy(&key.sig1, digest.data(), 8);
    std::memcpy(&key.sig2, digest.data()+8, 8);
    std::memcpy(key.tail.data(), digest.data()+16, 16);
    return key;
}

std::string absorption_cache_path(const std::string& profile_path) {
    if (profile_path.empty()) {
        return {};
    }
    return profile_path + ".absorption_cache";
}

// Cache publication is a same-directory replacement. A failed or interrupted
// writer leaves the previous entry available to concurrent readers.
class AtomicAbsorptionCacheFile {
    std::string target_, temporary_;
    std::FILE* file_ = nullptr;
    bool owned_ = false, good_ = true;
public:
    explicit AtomicAbsorptionCacheFile(const std::string& path) {
        try {
#ifdef __APPLE__
            // libc++ filesystem requires macOS 10.15; keep the 10.12 target.
            char resolved[PATH_MAX];
            if (::realpath(path.c_str(), resolved)) {
                target_ = resolved;
            } else {
                const auto slash = path.find_last_of('/');
                const std::string directory = slash == std::string::npos ? "." :
                    (slash == 0 ? "/" : path.substr(0, slash));
                if (!::realpath(directory.c_str(), resolved)) return;
                target_ = std::string(resolved) + "/" +
                    path.substr(slash == std::string::npos ? 0 : slash + 1);
            }
            const std::string parent = target_.substr(0, target_.find_last_of('/') + 1);
#else
            std::error_code error;
            target_ = std::filesystem::weakly_canonical(path, error).string();
            if (error) return;
            const auto parent = std::filesystem::path(target_).parent_path();
#endif
            std::random_device random;
            for (int attempt = 0; attempt < 16; ++attempt) {
#ifdef __APPLE__
                temporary_ = parent + ".xhdfe-cache-" + std::to_string(random()) +
                             "-" + std::to_string(random()) + ".tmp";
#else
                temporary_ = (parent / (".xhdfe-cache-" + std::to_string(random()) +
                                        "-" + std::to_string(random()) + ".tmp")).string();
#endif
#ifdef _WIN32
                const int fd = ::_open(temporary_.c_str(),
                    _O_WRONLY | _O_CREAT | _O_EXCL | _O_BINARY | _O_NOINHERIT,
                    _S_IREAD | _S_IWRITE);
                if (fd < 0) continue;
                owned_ = true;
                file_ = ::_fdopen(fd, "wb");
                if (!file_) ::_close(fd);
#else
                int flags = O_WRONLY | O_CREAT | O_EXCL;
#ifdef O_CLOEXEC
                flags |= O_CLOEXEC;
#endif
                const int fd = ::open(temporary_.c_str(), flags, 0666);
                if (fd < 0) continue;
                owned_ = true;
                struct stat previous{};
                if (::stat(target_.c_str(), &previous) == 0 &&
                    ::fchmod(fd, previous.st_mode & 0777) != 0) {
                    ::close(fd);
                    return;
                }
                file_ = ::fdopen(fd, "wb");
                if (!file_) ::close(fd);
#endif
                return;
            }
#ifndef __APPLE__
        } catch (const std::filesystem::filesystem_error&) {
            good_ = false;
#endif
        } catch (const std::system_error&) {
            good_ = false;
        }
    }
    AtomicAbsorptionCacheFile(const AtomicAbsorptionCacheFile&) = delete;
    AtomicAbsorptionCacheFile& operator=(const AtomicAbsorptionCacheFile&) = delete;
    ~AtomicAbsorptionCacheFile() {
        if (file_) std::fclose(file_);
        if (owned_) std::remove(temporary_.c_str());
    }
    explicit operator bool() const { return file_ && good_; }
    void write(const char* bytes, std::streamsize size) {
        if (!file_ || !good_ || size < 0) { good_ = false; return; }
        const auto count = static_cast<std::size_t>(size);
        if (std::fwrite(bytes, 1, count, file_) != count) good_ = false;
    }
    bool commit() {
        if (!static_cast<bool>(*this)) return false;
        const int closed = std::fclose(file_);
        file_ = nullptr;
        if (closed != 0) return false;
#ifdef __APPLE__
        if (std::rename(temporary_.c_str(), target_.c_str()) != 0) return false;
#else
        std::error_code error;
        std::filesystem::rename(temporary_, target_, error);
        if (error) return false;
#endif
        owned_ = false;
        return true;
    }
};

template <typename T, typename Output>
bool write_binary(Output& out, const T& value) {
    out.write(reinterpret_cast<const char*>(&value), sizeof(T));
    return static_cast<bool>(out);
}

template <typename T>
bool read_binary(std::ifstream& in, T& value) {
    in.read(reinterpret_cast<char*>(&value), sizeof(T));
    return static_cast<bool>(in);
}

bool may_read_refined_v5(const std::string& path, const AbsorptionCacheKey& key) {
    if (key.legacy_v5 || key.capture) return false;
    // Refined v5 records are from the explicit weighted Gauss-Seidel or
    // strict CPU repairs, both requiring a writer without capture. Inspect
    // their header before computing the extra historical input signature.
    std::ifstream in(path, std::ios::binary);
    char magic[kAbsorptionCacheMagicSize] = {};
    in.read(magic, sizeof(magic));
    if (!in || std::strncmp(magic, kAbsorptionCacheMagicV5, sizeof(magic)) != 0) return false;
    in.seekg(4 * sizeof(std::uint64_t) + 5 * sizeof(std::int32_t), std::ios::cur);
    std::int32_t flags = 0;
    return read_binary(in, flags) &&
           flags == (kAbsorptionCacheConverged | kAbsorptionCacheCpuRefined);
}

template <typename Output>
bool write_int_vector(Output& out, const std::vector<int>& values) {
    const std::int32_t count = static_cast<std::int32_t>(values.size());
    if (!write_binary(out, count)) {
        return false;
    }
    for (int v : values) {
        const std::int32_t entry = static_cast<std::int32_t>(v);
        if (!write_binary(out, entry)) {
            return false;
        }
    }
    return true;
}

bool read_int_vector(std::ifstream& in,
                     std::vector<int>& values,
                     std::int32_t max_count,
                     std::int32_t exact_count = -1) {
    std::int32_t count = 0;
    if (!read_binary(in, count)) {
        return false;
    }
    if (count < 0 || count > max_count ||
        (exact_count >= 0 && count != exact_count)) {
        return false;
    }
    values.assign(static_cast<std::size_t>(count), 0);
    for (std::int32_t i = 0; i < count; ++i) {
        std::int32_t entry = 0;
        if (!read_binary(in, entry)) {
            return false;
        }
        values[static_cast<std::size_t>(i)] = static_cast<int>(entry);
    }
    return true;
}

enum SavefeRouteFlag : unsigned int {
    kSavefeSymmetric = 1U,
    kSavefeUseSparse = 2U,
    kSavefeUseKrylov = 4U,
    kSavefeFromAuto = 8U,
    kSavefeMlsmr = 16U,
    kSavefeSchwarz = 32U,
    kSavefeKrylovPcg = 64U,
};
constexpr unsigned int kSavefeRouteMask = 127U;

bool savefe_cache_fault(const char* stage) {
    // Test the complete-fit fallback without exhausting the machine's memory.
    const char* configured = std::getenv("XHDFE_TEST_SAVEFE_CACHE_FAILURE");
    return configured && std::strcmp(configured, stage) == 0;
}

template <class Publication, class Field>
bool savefe_cache_fields(Publication& p, Field field) {
    // A common field order for the decoder, encoder and digest.
    return field(p.intercept) && field(p.recovery_iterations) &&
           field(p.recovery_max_delta) && field(p.hybrid_recovery) &&
           field(p.internal_method) && field(p.tuned_method) &&
           field(p.route_flags) && field(p.tier_status) && field(p.tier_discarded) &&
           field(p.tier_fine.request) && field(p.tier_fine.source) &&
           field(p.tier_fine.used) && field(p.tier_fine.parts) && field(p.tier_fine.hinted_applies) &&
           field(p.abs_residual) && field(p.abs_residual_rel);
}

bool write_cache_doubles(AtomicAbsorptionCacheFile& out, const Eigen::VectorXd& values) {
    if (values.size() > 0) {
        out.write(reinterpret_cast<const char*>(values.data()),
                  static_cast<std::streamsize>(values.size()) * sizeof(double));
    }
    return static_cast<bool>(out);
}

bool read_cache_doubles(std::istream& in, Eigen::Index count, Eigen::VectorXd& values) {
    values.resize(count);
    if (count > 0) {
        in.read(reinterpret_cast<char*>(values.data()),
                static_cast<std::streamsize>(count) * sizeof(double));
    }
    return in && detail::ieee_all_finite(values);
}

bool write_savefe_publication(AtomicAbsorptionCacheFile& out,
                              const CachedSavefePublication& p, const Eigen::VectorXd& residuals) {
    const auto reason_size = static_cast<std::int32_t>(p.tier_reason.size());
    const auto beta_size = static_cast<std::int32_t>(p.beta.size());
    if (!savefe_cache_fields(p, [&](const auto& x) { return write_binary(out, x); }) ||
        !write_binary(out, reason_size)) {
        return false;
    }
    out.write(p.tier_reason.data(), reason_size);
    if (!out || !write_binary(out, p.ols_residual_digest) ||
        !write_int_vector(out, p.kept_columns) || !write_binary(out, beta_size) ||
        !write_cache_doubles(out, p.beta) || !write_cache_doubles(out, residuals)) {
        return false;
    }
    for (const auto& effect : p.effects) {
        if (!write_int_vector(out, effect.first_rows) || !write_cache_doubles(out, effect.values)) {
            return false;
        }
    }
    return true;
}

bool read_savefe_publication(std::ifstream& in, int nobs, int design_cols,
                             const std::vector<int>& fe_levels, CachedSavefePublication& p) {
    auto valid_method = [](int method) {
        return method >= static_cast<int>(AbsorptionMethod::Auto) &&
               method <= static_cast<int>(AbsorptionMethod::ReducedPcg);
    };
    std::int32_t reason_size = 0;
    if (!savefe_cache_fields(p, [&](auto& x) { return read_binary(in, x); }) ||
        !valid_method(p.internal_method) || !valid_method(p.tuned_method) ||
        (p.route_flags & ~kSavefeRouteMask) != 0 ||
        p.recovery_iterations < 0 || p.hybrid_recovery < 0 || p.hybrid_recovery > 1 ||
        !detail::ieee_finite(p.recovery_max_delta) || p.recovery_max_delta < 0 ||
        !detail::ieee_finite(p.intercept) ||
        !detail::ieee_finite(p.abs_residual) || p.abs_residual < 0 ||
        !detail::ieee_finite(p.abs_residual_rel) || p.abs_residual_rel < 0 ||
        p.tier_status < 0 || p.tier_status > 2 || p.tier_discarded < 0 ||
        p.tier_fine.request < -1 || p.tier_fine.request > 8 || p.tier_fine.source < 0 ||
        p.tier_fine.source > 3 || p.tier_fine.used < 0 || p.tier_fine.used > 8 ||
        p.tier_fine.parts < 0 || p.tier_fine.hinted_applies < 0 ||
        !read_binary(in, reason_size) || reason_size <= 0 || reason_size > 64) {
        return false;
    }
    p.tier_reason.resize(static_cast<std::size_t>(reason_size));
    in.read(p.tier_reason.data(), reason_size);
    std::int32_t beta_size = 0;
    if (!in || !read_binary(in, p.ols_residual_digest) ||
        !read_int_vector(in, p.kept_columns, design_cols) ||
        !read_binary(in, beta_size) || beta_size < 0 ||
        static_cast<std::int64_t>(beta_size) > static_cast<std::int64_t>(design_cols) + 1 ||
        !read_cache_doubles(in, beta_size, p.beta) || !read_cache_doubles(in, nobs, p.residuals)) {
        return false;
    }
    p.effects.resize(fe_levels.size());
    for (std::size_t d = 0; d < p.effects.size(); ++d) {
        auto& effect = p.effects[d];
        const int levels = fe_levels[d];
        if (levels <= 0 || levels > nobs || !read_int_vector(in, effect.first_rows, levels)) {
            return false;
        }
        if (!effect.first_rows.empty() && static_cast<int>(effect.first_rows.size()) != levels) {
            return false;
        }
        if (!read_cache_doubles(in, effect.first_rows.empty() ? nobs : levels, effect.values)) {
            return false;
        }
    }
    return true;
}

FeStructureDigest hash_savefe_ols_residuals(const AbsorptionCacheKey& key,
                                          const Eigen::VectorXd& residuals) {
    detail::CacheDigestBuilder hash(UINT64_C(0x5341564546454f4c));  // "SAVEFEOL"
    hash.word(residuals.size());
    hash.data(residuals.data(), static_cast<std::size_t>(residuals.size()) * sizeof(double));
    return hash.finish(key.hash_threads, key.hash_observer);
}

bool compact_savefe_effects(const std::vector<Eigen::VectorXi>& fes,
                            const std::vector<int>& fe_levels,
                            const std::vector<Eigen::VectorXd>& published,
                            std::vector<CachedSavefeEffect>& stored) {
    if (fes.size() != published.size() || fes.size() != fe_levels.size()) {
        return false;
    }
    stored.resize(fes.size());
    for (std::size_t d = 0; d < fes.size(); ++d) {
        if (d == 1 && savefe_cache_fault("compact")) throw std::bad_alloc{};
        const auto& values = published[d];
        if (values.size() != fes[d].size() || !detail::ieee_all_finite(values)) {
            return false;
        }
        auto& effect = stored[d];
        const auto index = build_indexer_lite(fes[d]);
        if (index.num_groups <= 0 || index.num_groups != fe_levels[d]) {
            return false;
        }
        effect.first_rows.assign(static_cast<std::size_t>(index.num_groups), -1);
        effect.values.resize(index.num_groups);
        for (Eigen::Index i = 0; i < values.size(); ++i) {
            const int group = index.group_ids[static_cast<std::size_t>(i)];
            int& first_row = effect.first_rows[static_cast<std::size_t>(group)];
            if (first_row < 0) {
                first_row = static_cast<int>(i);
                effect.values[group] = values[i];
            } else if (hash_double_bits(effect.values[group]) != hash_double_bits(values[i])) {
                // A contribution that varies within a level still has an
                // exact representation. Never drop its row differences.
                effect.first_rows.clear();
                effect.values = values;
                break;
            }
        }
    }
    return true;
}

bool expand_savefe_effects(std::vector<CachedSavefeEffect>& stored,
                            const std::vector<Eigen::VectorXi>& fes,
                            std::vector<Eigen::VectorXd>& published) {
    published.resize(fes.size());
    for (std::size_t d = 0; d < fes.size(); ++d) {
        if (d == 1 && savefe_cache_fault("expand")) throw std::bad_alloc{};
        auto& effect = stored[d];
        if (effect.first_rows.empty()) {
            published[d] = std::move(effect.values);
            continue;
        }
        const auto index = build_indexer_lite(fes[d]);
        if (static_cast<std::size_t>(index.num_groups) != effect.first_rows.size()) {
            return false;
        }
        // Validate first occurrence and coverage as the values are expanded.
        auto& values = published[d];
        values.resize(fes[d].size());
        int next = 0;
        for (Eigen::Index i = 0; i < values.size(); ++i) {
            const int group = index.group_ids[static_cast<std::size_t>(i)];
            if (group == next) {
                if (effect.first_rows[static_cast<std::size_t>(group)] != i) {
                    return false;
                }
                ++next;
            }
            values[i] = effect.values[group];
        }
    }
    return true;
}

struct AbsorptionCacheDigest {
    std::uint64_t first = 0;
    std::uint64_t second = 0;
    std::uint64_t third = 0;
    std::uint64_t fourth = 0;
};

AbsorptionCacheDigest absorption_cache_digest(
    const AbsorptionCacheKey& key,
    int nobs,
    int cols,
    int design_cols,
    AbsorptionMethod method,
    int iterations,
    std::int32_t flags,
    double krylov_internal_tolerance,
    double krylov_max_final_backward_error,
    double krylov_max_condition,
    double krylov_max_condition_times_backward_error,
    bool auto_routing_retry_policy_enabled,
    bool auto_routing_retry_eligible,
    bool auto_routing_retry_fired,
    int auto_routing_retry_status,
    int auto_routing_retry_primary_method,
    int auto_routing_retry_primary_iterations,
    double auto_routing_retry_primary_abs_residual_rel,
    int auto_routing_retry_iterations,
    double auto_routing_retry_abs_residual_rel,
    double auto_routing_retry_elapsed_seconds,
    const std::vector<int>& fe_levels,
    const std::vector<int>& sweep_order,
    const Eigen::VectorXd& y_tilde,
    const Eigen::MatrixXd& X_tilde,
    const CachedSavefePublication* publication,
    const Eigen::VectorXd* published_residuals) {
    detail::CacheDigestBuilder hash(UINT64_C(0x58484446454f5554));
    auto update = [&](std::uint64_t value) {
        hash.word(value);
    };
    update(0x5848444645414253ULL);  // "XHDFEABS" domain separator.
    update(key.sig1);
    update(key.sig2);
    update(key.tail[0]);
    update(key.tail[1]);
    update(static_cast<std::uint64_t>(static_cast<std::int64_t>(nobs)));
    update(static_cast<std::uint64_t>(static_cast<std::int64_t>(cols)));
    update(static_cast<std::uint64_t>(static_cast<std::int64_t>(design_cols)));
    update(static_cast<std::uint64_t>(static_cast<int>(method)));
    update(static_cast<std::uint64_t>(static_cast<std::int64_t>(iterations)));
    update(static_cast<std::uint64_t>(flags));
    update(hash_double_bits(krylov_internal_tolerance));
    update(hash_double_bits(krylov_max_final_backward_error));
    update(hash_double_bits(krylov_max_condition));
    update(hash_double_bits(krylov_max_condition_times_backward_error));
    update(auto_routing_retry_policy_enabled ? 1ULL : 0ULL);
    update(auto_routing_retry_eligible ? 1ULL : 0ULL);
    update(auto_routing_retry_fired ? 1ULL : 0ULL);
    update(static_cast<std::uint64_t>(auto_routing_retry_status));
    update(static_cast<std::uint64_t>(static_cast<std::int64_t>(
        auto_routing_retry_primary_method)));
    update(static_cast<std::uint64_t>(static_cast<std::int64_t>(
        auto_routing_retry_primary_iterations)));
    update(hash_double_bits(auto_routing_retry_primary_abs_residual_rel));
    update(static_cast<std::uint64_t>(static_cast<std::int64_t>(
        auto_routing_retry_iterations)));
    update(hash_double_bits(auto_routing_retry_abs_residual_rel));
    update(hash_double_bits(auto_routing_retry_elapsed_seconds));
    update(static_cast<std::uint64_t>(fe_levels.size()));
    for (const int value : fe_levels) {
        update(static_cast<std::uint64_t>(static_cast<std::int64_t>(value)));
    }
    update(static_cast<std::uint64_t>(sweep_order.size()));
    for (const int value : sweep_order) {
        update(static_cast<std::uint64_t>(static_cast<std::int64_t>(value)));
    }
    update(static_cast<std::uint64_t>(y_tilde.size()));
    hash.data(y_tilde.data(), static_cast<std::size_t>(y_tilde.size()) * sizeof(double));
    update(static_cast<std::uint64_t>(X_tilde.rows()));
    update(static_cast<std::uint64_t>(X_tilde.cols()));
    update(static_cast<std::uint64_t>(X_tilde.size()));
    hash.data(X_tilde.data(), static_cast<std::size_t>(X_tilde.size()) * sizeof(double));
    if (!key.legacy_v5) {
        update(UINT64_C(0x5848444645563600));
        update(publication != nullptr);
    }
    if (publication) {
        const auto& p = *publication;
        savefe_cache_fields(p, [&](auto value) {
            if constexpr (std::is_same_v<decltype(value), double>) {
                update(hash_double_bits(value));
            } else {
                update(static_cast<std::uint64_t>(value));
            }
            return true;
        });
        auto hash_values = [&](const Eigen::VectorXd& values) {
            update(static_cast<std::uint64_t>(values.size()));
            hash.data(values.data(), static_cast<std::size_t>(values.size()) * sizeof(double));
        };
        auto hash_indices = [&](const std::vector<int>& values) {
            update(static_cast<std::uint64_t>(values.size()));
            for (const int value : values) update(static_cast<std::uint64_t>(value));
        };
        update(static_cast<std::uint64_t>(p.tier_reason.size()));
        hash.data(p.tier_reason.data(), p.tier_reason.size());
        hash.data(p.ols_residual_digest.data(), p.ols_residual_digest.size());
        hash_indices(p.kept_columns);
        hash_values(p.beta);
        hash_values(*published_residuals);
        update(static_cast<std::uint64_t>(p.effects.size()));
        for (const auto& effect : p.effects) {
            hash_indices(effect.first_rows);
            hash_values(effect.values);
        }
    }
    const auto bytes = hash.finish(key.hash_threads, key.hash_observer);
    AbsorptionCacheDigest digest;
    std::memcpy(&digest.first, bytes.data(), 8);
    std::memcpy(&digest.second, bytes.data()+8, 8);
    std::memcpy(&digest.third, bytes.data()+16, 8);
    std::memcpy(&digest.fourth, bytes.data()+24, 8);
    return digest;
}

bool write_absorption_cache(const std::string& path,
                            const AbsorptionCacheKey& key,
                            const Eigen::VectorXd& y_tilde,
                            const Eigen::MatrixXd& X_tilde,
                            const std::vector<int>& fe_levels,
                            const std::vector<int>& sweep_order,
                            int design_cols,
                            AbsorptionMethod method,
                            int iterations,
                            bool converged,
                            double krylov_internal_tolerance,
                            double krylov_max_final_backward_error,
                            double krylov_max_condition,
                            double krylov_max_condition_times_backward_error,
                            const detail::AbsorptionResult& retry_diagnostics,
                            bool savefe_projection_published = false,
                            bool cpu_projection_refined = false,
                            const CachedSavefePublication* publication = nullptr,
                            const Eigen::VectorXd* published_residuals = nullptr) {
    if (path.empty() || (publication != nullptr) != key.capture ||
        (publication != nullptr) != (published_residuals != nullptr) ||
        (publication && cpu_projection_refined) || (savefe_projection_published && !publication)) {
        return false;
    }
    AtomicAbsorptionCacheFile out(path);
    if (!out) {
        return false;
    }

    char magic[kAbsorptionCacheMagicSize] = {};
    std::strncpy(magic, key.legacy_v5 ? kAbsorptionCacheMagicV5 : kAbsorptionCacheMagicV6,
                 kAbsorptionCacheMagicSize - 1);
    out.write(magic, sizeof(magic));
    if (!write_binary(out, key.sig1) || !write_binary(out, key.sig2) ||
        !write_binary(out, key.tail[0]) || !write_binary(out, key.tail[1])) {
        return false;
    }

    const std::int32_t nobs = static_cast<std::int32_t>(y_tilde.size());
    const std::int32_t cols = static_cast<std::int32_t>(X_tilde.cols());
    const std::int32_t design_cols_out = static_cast<std::int32_t>(design_cols);
    const std::int32_t method_out = static_cast<std::int32_t>(method);
    const std::int32_t iterations_out = static_cast<std::int32_t>(iterations);
    const std::int32_t flags = (converged ? kAbsorptionCacheConverged : 0) |
        (savefe_projection_published ? kAbsorptionCachePublishedSavefe : 0) |
        (cpu_projection_refined ? kAbsorptionCacheCpuRefined : 0);
    if (!write_binary(out, nobs) || !write_binary(out, cols) ||
        !write_binary(out, design_cols_out) || !write_binary(out, method_out) ||
        !write_binary(out, iterations_out) || !write_binary(out, flags) ||
        !write_binary(out, krylov_internal_tolerance) ||
        !write_binary(out, krylov_max_final_backward_error) ||
        !write_binary(out, krylov_max_condition) ||
        !write_binary(out, krylov_max_condition_times_backward_error) ||
        !write_binary(out, retry_diagnostics.auto_routing_retry_policy_enabled) ||
        !write_binary(out, retry_diagnostics.auto_routing_retry_eligible) ||
        !write_binary(out, retry_diagnostics.auto_routing_retry_fired) ||
        !write_binary(out, retry_diagnostics.auto_routing_retry_status) ||
        !write_binary(out, retry_diagnostics.auto_routing_retry_primary_method) ||
        !write_binary(out, retry_diagnostics.auto_routing_retry_primary_iterations) ||
        !write_binary(out, retry_diagnostics.auto_routing_retry_primary_abs_residual_rel) ||
        !write_binary(out, retry_diagnostics.auto_routing_retry_iterations) ||
        !write_binary(out, retry_diagnostics.auto_routing_retry_abs_residual_rel) ||
        !write_binary(out, retry_diagnostics.auto_routing_retry_elapsed_seconds)) {
        return false;
    }
    if (!write_int_vector(out, fe_levels) || !write_int_vector(out, sweep_order)) {
        return false;
    }
    if (!write_binary(out, y_tilde.size())) {
        return false;
    }
    out.write(reinterpret_cast<const char*>(y_tilde.data()),
              static_cast<std::streamsize>(y_tilde.size() * sizeof(double)));
    if (!out) {
        return false;
    }
    const std::size_t x_size =
        static_cast<std::size_t>(X_tilde.size());
    if (!write_binary(out, x_size)) {
        return false;
    }
    out.write(reinterpret_cast<const char*>(X_tilde.data()),
              static_cast<std::streamsize>(x_size * sizeof(double)));
    if (!out) {
        return false;
    }
    if (publication && !write_savefe_publication(out, *publication, *published_residuals)) {
        return false;
    }
    const AbsorptionCacheDigest digest = absorption_cache_digest(
        key, static_cast<int>(nobs), static_cast<int>(cols), design_cols,
        method, iterations, flags, krylov_internal_tolerance,
        krylov_max_final_backward_error, krylov_max_condition,
        krylov_max_condition_times_backward_error,
        retry_diagnostics.auto_routing_retry_policy_enabled,
        retry_diagnostics.auto_routing_retry_eligible,
        retry_diagnostics.auto_routing_retry_fired,
        retry_diagnostics.auto_routing_retry_status,
        retry_diagnostics.auto_routing_retry_primary_method,
        retry_diagnostics.auto_routing_retry_primary_iterations,
        retry_diagnostics.auto_routing_retry_primary_abs_residual_rel,
        retry_diagnostics.auto_routing_retry_iterations,
        retry_diagnostics.auto_routing_retry_abs_residual_rel,
        retry_diagnostics.auto_routing_retry_elapsed_seconds,
        fe_levels, sweep_order,
        y_tilde, X_tilde, publication, published_residuals);
    return write_binary(out, digest.first) && write_binary(out, digest.second) &&
           write_binary(out, digest.third) && write_binary(out, digest.fourth) &&
           !(publication && savefe_cache_fault("commit")) && out.commit();
}

bool read_absorption_cache(const std::string& path,
                           const AbsorptionCacheKey& key,
                           int expected_nobs,
                           int expected_cols,
                           int expected_design_cols,
                           int expected_fe_count,
                           AbsorptionCacheRecord& record) try {
    if (path.empty()) {
        return false;
    }
    std::ifstream in(path, std::ios::binary);
    if (!in) {
        return false;
    }

    char magic[kAbsorptionCacheMagicSize] = {};
    in.read(magic, sizeof(magic));
    if (!in) {
        return false;
    }
    const char* expected_magic = key.legacy_v5 ? kAbsorptionCacheMagicV5 : kAbsorptionCacheMagicV6;
    if (std::strncmp(magic, expected_magic, sizeof(magic)) != 0) {
        return false;
    }

    std::uint64_t sig1 = 0;
    std::uint64_t sig2 = 0;
    std::array<std::uint64_t,2> tail{};
    if (!read_binary(in, sig1) || !read_binary(in, sig2) ||
        !read_binary(in, tail[0]) || !read_binary(in, tail[1])) {
        return false;
    }
    if (sig1 != key.sig1 || sig2 != key.sig2 || tail != key.tail) {
        return false;
    }

    std::int32_t nobs = 0;
    std::int32_t cols = 0;
    std::int32_t design_cols = 0;
    std::int32_t method = 0;
    std::int32_t iterations = 0;
    std::int32_t flags = 0;
    if (!read_binary(in, nobs) || !read_binary(in, cols) ||
        !read_binary(in, design_cols) || !read_binary(in, method) ||
        !read_binary(in, iterations) || !read_binary(in, flags) ||
        !read_binary(in, record.krylov_internal_tolerance) ||
        !read_binary(in, record.krylov_max_final_backward_error) ||
        !read_binary(in, record.krylov_max_condition) ||
        !read_binary(in, record.krylov_max_condition_times_backward_error) ||
        !read_binary(in, record.auto_routing_retry_policy_enabled) ||
        !read_binary(in, record.auto_routing_retry_eligible) ||
        !read_binary(in, record.auto_routing_retry_fired) ||
        !read_binary(in, record.auto_routing_retry_status) ||
        !read_binary(in, record.auto_routing_retry_primary_method) ||
        !read_binary(in, record.auto_routing_retry_primary_iterations) ||
        !read_binary(in, record.auto_routing_retry_primary_abs_residual_rel) ||
        !read_binary(in, record.auto_routing_retry_iterations) ||
        !read_binary(in, record.auto_routing_retry_abs_residual_rel) ||
        !read_binary(in, record.auto_routing_retry_elapsed_seconds)) {
        return false;
    }
    if (nobs != expected_nobs || cols != expected_cols ||
        design_cols != expected_design_cols || expected_fe_count < 0 ||
        method < static_cast<std::int32_t>(AbsorptionMethod::Auto) ||
        method > static_cast<std::int32_t>(AbsorptionMethod::ReducedPcg) ||
        iterations < 0 || (key.require_cpu_refined &&
            flags != (kAbsorptionCacheConverged | kAbsorptionCacheCpuRefined)) ||
        (flags != kAbsorptionCacheConverged &&
        flags != (kAbsorptionCacheConverged |
            (key.capture ? kAbsorptionCachePublishedSavefe : kAbsorptionCacheCpuRefined)))) {
        return false;
    }
    const double diagnostics[] = {
        record.krylov_internal_tolerance,
        record.krylov_max_final_backward_error,
        record.krylov_max_condition,
        record.krylov_max_condition_times_backward_error,
    };
    for (const double value : diagnostics) {
        if (!hdfe::detail::ieee_finite(value) || value < 0.0) {
            return false;
        }
    }
    if (record.auto_routing_retry_status < 0 ||
        record.auto_routing_retry_status > 4 ||
        record.auto_routing_retry_primary_method < -1 ||
        record.auto_routing_retry_primary_method >
            static_cast<int>(AbsorptionMethod::AutoMlsmr) ||
        record.auto_routing_retry_primary_iterations < 0 ||
        record.auto_routing_retry_iterations < 0 ||
        !hdfe::detail::ieee_finite(
            record.auto_routing_retry_primary_abs_residual_rel) ||
        record.auto_routing_retry_primary_abs_residual_rel < 0.0 ||
        !hdfe::detail::ieee_finite(
            record.auto_routing_retry_abs_residual_rel) ||
        record.auto_routing_retry_abs_residual_rel < 0.0 ||
        !hdfe::detail::ieee_finite(
            record.auto_routing_retry_elapsed_seconds) ||
        record.auto_routing_retry_elapsed_seconds < 0.0) {
        return false;
    }

    if (!read_int_vector(in, record.fe_levels, expected_fe_count,
                         expected_fe_count) ||
        !read_int_vector(in, record.sweep_order, expected_fe_count)) {
        return false;
    }

    Eigen::Index y_size = 0;
    if (!read_binary(in, y_size) || y_size < 0) {
        return false;
    }
    if (y_size != static_cast<Eigen::Index>(nobs)) {
        return false;
    }
    record.y_tilde.resize(y_size);
    in.read(reinterpret_cast<char*>(record.y_tilde.data()),
            static_cast<std::streamsize>(static_cast<std::size_t>(y_size) * sizeof(double)));
    if (!in) {
        return false;
    }
    for (Eigen::Index i = 0; i < record.y_tilde.size(); ++i) {
        if (!hdfe::detail::ieee_finite(record.y_tilde(i))) {
            return false;
        }
    }

    std::size_t x_size = 0;
    if (!read_binary(in, x_size)) {
        return false;
    }
    record.X_tilde.resize(nobs, cols);
    const std::size_t expected = static_cast<std::size_t>(nobs) *
                                 static_cast<std::size_t>(cols);
    if (x_size != expected) {
        return false;
    }
    in.read(reinterpret_cast<char*>(record.X_tilde.data()),
            static_cast<std::streamsize>(x_size * sizeof(double)));
    if (!in) {
        return false;
    }
    for (Eigen::Index i = 0; i < record.X_tilde.size(); ++i) {
        if (!hdfe::detail::ieee_finite(record.X_tilde.data()[i])) {
            return false;
        }
    }

    if (key.capture) {
        record.savefe.emplace();
        if (!read_savefe_publication(in, nobs, design_cols, record.fe_levels, *record.savefe)) {
            return false;
        }
    }
    std::uint64_t stored_first = 0;
    std::uint64_t stored_second = 0;
    std::uint64_t stored_third = 0;
    std::uint64_t stored_fourth = 0;
    if (!read_binary(in, stored_first) || !read_binary(in, stored_second) ||
        !read_binary(in, stored_third) || !read_binary(in, stored_fourth) ||
        in.peek() != std::ifstream::traits_type::eof()) {
        return false;
    }
    const AbsorptionCacheDigest expected_digest = absorption_cache_digest(
        key, nobs, cols, design_cols, static_cast<AbsorptionMethod>(method),
        iterations, flags, record.krylov_internal_tolerance,
        record.krylov_max_final_backward_error, record.krylov_max_condition,
        record.krylov_max_condition_times_backward_error,
        record.auto_routing_retry_policy_enabled,
        record.auto_routing_retry_eligible,
        record.auto_routing_retry_fired,
        record.auto_routing_retry_status,
        record.auto_routing_retry_primary_method,
        record.auto_routing_retry_primary_iterations,
        record.auto_routing_retry_primary_abs_residual_rel,
        record.auto_routing_retry_iterations,
        record.auto_routing_retry_abs_residual_rel,
        record.auto_routing_retry_elapsed_seconds, record.fe_levels,
        record.sweep_order, record.y_tilde, record.X_tilde,
        record.savefe ? &*record.savefe : nullptr,
        record.savefe ? &record.savefe->residuals : nullptr);
    if (stored_first != expected_digest.first ||
        stored_second != expected_digest.second ||
        stored_third != expected_digest.third || stored_fourth != expected_digest.fourth) {
        return false;
    }

    record.nobs = nobs;
    record.cols = cols;
    record.design_cols = design_cols;
    record.method = static_cast<AbsorptionMethod>(method);
    record.iterations = iterations;
    record.converged = (flags & kAbsorptionCacheConverged) != 0;
    record.savefe_projection_published = (flags & kAbsorptionCachePublishedSavefe) != 0;
    record.cpu_projection_refined = (flags & kAbsorptionCacheCpuRefined) != 0;
    return true;
} catch (const std::bad_alloc&) {
    // An optional cache that does not fit in memory is an ordinary miss.
    return false;
}

constexpr const char* kFeStructureCacheMagic = "xhdfe_fe_structure_cache_v2";
constexpr std::size_t kFeStructureCacheMagicSize = 32;

struct FeStructureCache {
    FeStructureDigest signature{};
    int nobs_full = 0;
    int nobs = 0;
    bool drop_singletons = false;
    std::vector<int> kept_idx;
    std::vector<int> num_groups;
    std::vector<Eigen::VectorXi> fe_group_ids;
};

FeStructureDigest fe_structure_payload_digest(
    const FeStructureDigest& signature, int nobs_full, bool drop_singletons,
    const std::vector<int>& kept_idx, const std::vector<int>& num_groups,
    const std::vector<Eigen::VectorXi>& fe_group_ids, int threads,
    detail::ParallelWorkObserver* observer) {
    detail::CacheDigestBuilder digest(UINT64_C(0x46455041594c4432));
    digest.data(signature.data(), signature.size());
    digest.word(nobs_full);
    digest.word(drop_singletons);
    digest.data(kept_idx.data(), kept_idx.size() * sizeof(int));
    digest.data(num_groups.data(), num_groups.size() * sizeof(int));
    digest.word(fe_group_ids.size());
    for (const auto& ids : fe_group_ids) digest.data(ids.data(), ids.size() * sizeof(int));
    return digest.finish(threads, observer);
}

bool write_fe_structure_cache(const std::string& path,
                              const FeStructureDigest& signature,
                              int nobs_full,
                              bool drop_singletons,
                              const std::vector<int>& kept_idx,
                              const std::vector<int>& num_groups,
                              const std::vector<Eigen::VectorXi>& fe_group_ids,
                              int threads, detail::ParallelWorkObserver* observer) {
    if (path.empty()) {
        return false;
    }
    AtomicAbsorptionCacheFile out(path);
    if (!out) {
        return false;
    }

    char magic[kFeStructureCacheMagicSize] = {};
    std::strncpy(magic, kFeStructureCacheMagic, kFeStructureCacheMagicSize - 1);
    out.write(magic, sizeof(magic));
    if (!write_binary(out, signature)) {
        return false;
    }

    const std::int32_t nobs_full_out = static_cast<std::int32_t>(nobs_full);
    const std::int32_t nobs_out =
        fe_group_ids.empty() ? nobs_full_out : static_cast<std::int32_t>(fe_group_ids[0].size());
    const std::int32_t nfe_out = static_cast<std::int32_t>(fe_group_ids.size());
    const std::int32_t drop_out = drop_singletons ? 1 : 0;
    if (!write_binary(out, nobs_full_out) || !write_binary(out, nobs_out) ||
        !write_binary(out, nfe_out) || !write_binary(out, drop_out)) {
        return false;
    }

    const std::int32_t keep_count = static_cast<std::int32_t>(kept_idx.size());
    if (!write_binary(out, keep_count)) {
        return false;
    }
    for (int idx : kept_idx) {
        const std::int32_t entry = static_cast<std::int32_t>(idx);
        if (!write_binary(out, entry)) {
            return false;
        }
    }

    for (std::size_t d = 0; d < fe_group_ids.size(); ++d) {
        const std::int32_t groups = static_cast<std::int32_t>(num_groups[d]);
        const std::int32_t len = static_cast<std::int32_t>(fe_group_ids[d].size());
        if (!write_binary(out, groups) || !write_binary(out, len)) {
            return false;
        }
        out.write(reinterpret_cast<const char*>(fe_group_ids[d].data()),
                  static_cast<std::streamsize>(len * sizeof(int)));
        if (!out) {
            return false;
        }
    }
    const auto digest = fe_structure_payload_digest(signature, nobs_full, drop_singletons,
        kept_idx, num_groups, fe_group_ids, threads, observer);
    return write_binary(out, digest) && out.commit();
}

bool read_fe_structure_cache(const std::string& path,
                             const FeStructureDigest& expected_signature,
                             int expected_nobs_full,
                             bool drop_singletons,
                             int expected_nfe,
                             FeStructureCache& cache,
                             int threads, detail::ParallelWorkObserver* observer) {
    if (path.empty()) {
        return false;
    }
    std::ifstream in(path, std::ios::binary);
    if (!in) {
        return false;
    }

    char magic[kFeStructureCacheMagicSize] = {};
    in.read(magic, sizeof(magic));
    if (!in) {
        return false;
    }
    if (std::strncmp(magic, kFeStructureCacheMagic, std::strlen(kFeStructureCacheMagic)) != 0) {
        return false;
    }

    FeStructureDigest signature{};
    if (!read_binary(in, signature)) {
        return false;
    }
    if (signature != expected_signature) {
        return false;
    }

    std::int32_t nobs_full = 0;
    std::int32_t nobs = 0;
    std::int32_t nfe = 0;
    std::int32_t drop_flag = 0;
    if (!read_binary(in, nobs_full) || !read_binary(in, nobs) ||
        !read_binary(in, nfe) || !read_binary(in, drop_flag)) {
        return false;
    }
    if (nobs_full < 0 || nobs < 0 || nobs > nobs_full || nfe < 0) {
        return false;
    }
    if (nobs_full != expected_nobs_full || nfe != expected_nfe) {
        return false;
    }
    if (drop_flag != static_cast<int>(drop_singletons)) {
        return false;
    }

    std::int32_t keep_count = 0;
    if (!read_binary(in, keep_count) || keep_count < 0 || keep_count > nobs) {
        return false;
    }
    std::vector<int> kept_idx;
    kept_idx.resize(static_cast<std::size_t>(keep_count));
    for (std::int32_t i = 0; i < keep_count; ++i) {
        std::int32_t entry = 0;
        if (!read_binary(in, entry)) {
            return false;
        }
        if (entry < 0 || entry >= nobs_full ||
            (i > 0 && entry <= kept_idx[static_cast<std::size_t>(i-1)])) return false;
        kept_idx[static_cast<std::size_t>(i)] = static_cast<int>(entry);
    }

    if (nobs == nobs_full && keep_count != 0) {
        return false;
    }
    if (nobs != nobs_full && keep_count != nobs) {
        return false;
    }

    std::vector<int> num_groups;
    std::vector<Eigen::VectorXi> fe_group_ids;
    num_groups.resize(static_cast<std::size_t>(nfe));
    fe_group_ids.resize(static_cast<std::size_t>(nfe));
    for (int d = 0; d < nfe; ++d) {
        std::int32_t groups = 0;
        std::int32_t len = 0;
        if (!read_binary(in, groups) || !read_binary(in, len)) {
            return false;
        }
        if (groups < 0 || groups > nobs || (nobs > 0 && groups == 0) || len != nobs) {
            return false;
        }
        num_groups[static_cast<std::size_t>(d)] = static_cast<int>(groups);
        fe_group_ids[static_cast<std::size_t>(d)].resize(len);
        in.read(reinterpret_cast<char*>(fe_group_ids[static_cast<std::size_t>(d)].data()),
                static_cast<std::streamsize>(len * sizeof(int)));
        if (!in) {
            return false;
        }
        for (int i = 0; i < len; ++i) {
            const int gid = fe_group_ids[static_cast<std::size_t>(d)](i);
            if (gid < 0 || gid >= groups) return false;
        }
    }

    FeStructureDigest stored_digest{};
    if (!read_binary(in, stored_digest) || in.peek() != std::char_traits<char>::eof() ||
        stored_digest != fe_structure_payload_digest(signature, nobs_full, drop_singletons,
            kept_idx, num_groups, fe_group_ids, threads, observer)) return false;

    cache.signature = signature;
    cache.nobs_full = nobs_full;
    cache.nobs = nobs;
    cache.drop_singletons = drop_singletons;
    cache.kept_idx = std::move(kept_idx);
    cache.num_groups = std::move(num_groups);
    cache.fe_group_ids = std::move(fe_group_ids);
    return true;
}

double combined_norm_sq(const Eigen::VectorXd& y, const Eigen::MatrixXd& X) {
    return y.squaredNorm() + X.squaredNorm();
}

struct PilotSample {
    Eigen::VectorXd y;
    Eigen::MatrixXd X;
    std::vector<Eigen::VectorXi> fes;
    std::optional<Eigen::VectorXd> weights;
};

PilotSample build_pilot_sample(const Eigen::Ref<const Eigen::VectorXd>& y,
                               const Eigen::Ref<const Eigen::MatrixXd>& X,
                               const std::vector<Eigen::VectorXi>& fes,
                               const Eigen::VectorXd* weights,
                               int max_rows) {
    PilotSample sample;
    const int n = static_cast<int>(y.size());
    const int cols = static_cast<int>(X.cols());
    if (n <= 0 || max_rows <= 0) {
        return sample;
    }
    const int sample_count = std::min(n, max_rows);
    const int stride = std::max(1, n / sample_count);
    std::vector<int> indices;
    indices.reserve(static_cast<std::size_t>(sample_count));
    for (int i = 0; i < n && static_cast<int>(indices.size()) < sample_count; i += stride) {
        indices.push_back(i);
    }
    sample.y.resize(static_cast<int>(indices.size()));
    sample.X.resize(static_cast<int>(indices.size()), cols);
    for (int i = 0; i < static_cast<int>(indices.size()); ++i) {
        const int idx = indices[static_cast<std::size_t>(i)];
        sample.y(i) = y(idx);
        if (cols > 0) {
            sample.X.row(i) = X.row(idx);
        }
    }
    sample.fes.reserve(fes.size());
    for (const auto& fe : fes) {
        Eigen::VectorXi fe_sample(static_cast<int>(indices.size()));
        for (int i = 0; i < static_cast<int>(indices.size()); ++i) {
            fe_sample(i) = fe(indices[static_cast<std::size_t>(i)]);
        }
        sample.fes.push_back(std::move(fe_sample));
    }
    if (weights) {
        Eigen::VectorXd w_sample(static_cast<int>(indices.size()));
        for (int i = 0; i < static_cast<int>(indices.size()); ++i) {
            w_sample(i) = (*weights)(indices[static_cast<std::size_t>(i)]);
        }
        sample.weights = std::move(w_sample);
    }
    return sample;
}

struct PilotScore {
    AbsorptionMethod method = AbsorptionMethod::Auto;
    double elapsed_ms = 0.0;
    double norm_ratio = 1.0;
    double score = std::numeric_limits<double>::infinity();
};

PilotScore run_pilot_candidate(const PilotSample& sample,
                               const HdfeOptions& options,
                               AbsorptionMethod method,
                               int iterations) {
    PilotScore result;
    result.method = method;
    if (sample.y.size() == 0) {
        return result;
    }
    const double norm_before = combined_norm_sq(sample.y, sample.X);

    HdfeOptions pilot_opts = options;
    pilot_opts.max_iter = std::max(1, iterations);
    pilot_opts.tol = 0.0;
    pilot_opts.convergence_check_interval = pilot_opts.max_iter;
    pilot_opts.retain_fixed_effects = false;
    pilot_opts.save_groupvar = false;
    pilot_opts.use_sparse_solver = false;
    pilot_opts.use_krylov = false;

    const Eigen::VectorXd* w_ptr = sample.weights ? &(*sample.weights) : nullptr;
    const auto t0 = std::chrono::steady_clock::now();
    const detail::AbsorptionResult absorption =
        detail::absorb_fixed_effects_v6(sample.y, sample.X, sample.fes, w_ptr, pilot_opts, method);
    const auto t1 = std::chrono::steady_clock::now();

    const double norm_after = combined_norm_sq(absorption.y_tilde, absorption.X_tilde);
    const double ratio = (norm_before > 0.0) ? (norm_after / norm_before) : 1.0;
    const double reduction = std::max(0.0, 1.0 - ratio);
    const double elapsed =
        std::chrono::duration<double, std::milli>(t1 - t0).count();

    result.elapsed_ms = elapsed;
    result.norm_ratio = ratio;
    if (reduction > 1e-9) {
        result.score = elapsed / reduction;
    }
    return result;
}

std::optional<AbsorptionMethod> select_method_pilot(
    const Eigen::Ref<const Eigen::VectorXd>& y,
    const Eigen::Ref<const Eigen::MatrixXd>& X,
    const std::vector<Eigen::VectorXi>& fes,
    const Eigen::VectorXd* weights,
    const HdfeOptions& options) {
    const int dims = static_cast<int>(fes.size());
    if (dims <= 1) {
        return AbsorptionMethod::GaussSeidel;
    }
    constexpr int kPilotMaxRows = 50000;
    constexpr int kPilotIterations = 2;
    PilotSample sample = build_pilot_sample(y, X, fes, weights, kPilotMaxRows);
    if (sample.y.size() == 0) {
        return std::nullopt;
    }

    std::vector<AbsorptionMethod> candidates;
    candidates.reserve(3);
    candidates.push_back(AbsorptionMethod::GaussSeidel);
    if (dims > 1) {
        candidates.push_back(AbsorptionMethod::SymmetricGaussSeidel);
    }
    if (options.num_threads >= 2 && dims > 1) {
        candidates.push_back(AbsorptionMethod::Jacobi);
    }

    std::vector<PilotScore> scores;
    scores.reserve(candidates.size());
    PilotScore best;
    bool have_score = false;
    for (const auto method : candidates) {
        PilotScore score = run_pilot_candidate(sample, options, method, kPilotIterations);
        scores.push_back(score);
        if (hdfe::detail::ieee_finite(score.score)) {
            if (!have_score || score.score < best.score) {
                best = score;
                have_score = true;
            }
        }
    }
    if (have_score) {
        return best.method;
    }
    AbsorptionMethod fastest = AbsorptionMethod::Auto;
    double fastest_time = std::numeric_limits<double>::infinity();
    for (const auto& score : scores) {
        if (score.elapsed_ms > 0.0 && score.elapsed_ms < fastest_time) {
            fastest_time = score.elapsed_ms;
            fastest = score.method;
        }
    }
    if (fastest != AbsorptionMethod::Auto) {
        return fastest;
    }
    return std::nullopt;
}

std::string method_name(AbsorptionMethod method) {
    switch (method) {
        case AbsorptionMethod::GaussSeidel:
            return "gauss-seidel";
        case AbsorptionMethod::SymmetricGaussSeidel:
            return "symmetric-gauss-seidel";
        case AbsorptionMethod::Jacobi:
            return "jacobi";
        case AbsorptionMethod::Schwarz:
            return "schwarz";
        case AbsorptionMethod::Lsmr:
            return "lsmr";
        case AbsorptionMethod::Mlsmr:
            return "mlsmr";
        case AbsorptionMethod::AutoMlsmr:
            return "auto-mlsmr";
        case AbsorptionMethod::ReducedPcg:
            return "reduced-pcg";
        case AbsorptionMethod::KrylovPcg:
            return "krylov-pcg";
        case AbsorptionMethod::Auto:
        default:
            return "auto";
    }
}


// ---- Auto-MLSMR convergence-rate probe (ported from Tiago branch 24jun2026) ----
// Decides MLSMR vs sweep by sampling <=200k rows and measuring per-sweep FE-mean
// contraction. Used by absorptionmethod(auto-mlsmr) AND the default-auto promotion.
struct AutoMlsmrProbeSample {
    std::vector<FeIndexerLite> indexers;
    Eigen::VectorXd weights;
    std::vector<int> original_rows;
    int n = 0;
    int total_levels = 0;
    bool weighted = false;
};

std::uint64_t splitmix64(std::uint64_t x) {
    x += 0x9e3779b97f4a7c15ULL;
    x = (x ^ (x >> 30)) * 0xbf58476d1ce4e5b9ULL;
    x = (x ^ (x >> 27)) * 0x94d049bb133111ebULL;
    return x ^ (x >> 31);
}

double deterministic_probe_value(int original_row) {
    const std::uint64_t bits =
        splitmix64(static_cast<std::uint64_t>(original_row) + 0x6a09e667f3bcc909ULL);
    const double unit =
        static_cast<double>(bits >> 11) * (1.0 / 9007199254740992.0);
    return unit - 0.5;
}

AutoMlsmrProbeSample build_auto_mlsmr_probe_sample(
    const std::vector<Eigen::VectorXi>& fes,
    const Eigen::VectorXd* weights,
    int max_rows) {
    AutoMlsmrProbeSample sample;
    if (fes.empty() || max_rows <= 0) {
        return sample;
    }
    const int n = static_cast<int>(fes[0].size());
    if (n <= 0) {
        return sample;
    }
    const int sample_count = std::min(n, max_rows);
    sample.original_rows.reserve(static_cast<std::size_t>(sample_count));
    if (sample_count == n) {
        for (int i = 0; i < n; ++i) {
            sample.original_rows.push_back(i);
        }
    } else {
        // Preserve local FE connectivity in sorted panels. A thin stride sample
        // can turn long worker spells into near-singletons and make the MAP
        // convergence probe falsely optimistic.
        const int block_count = std::min(4, sample_count);
        const int base_block = sample_count / block_count;
        const int remainder = sample_count % block_count;
        int added = 0;
        for (int b = 0; b < block_count; ++b) {
            const int block_size = base_block + (b < remainder ? 1 : 0);
            if (block_size <= 0) {
                continue;
            }
            const int max_start = std::max(0, n - block_size);
            const int start = block_count == 1
                                  ? 0
                                  : static_cast<int>(
                                        std::llround(static_cast<double>(max_start) *
                                                     static_cast<double>(b) /
                                                     static_cast<double>(block_count - 1)));
            for (int j = 0; j < block_size; ++j) {
                sample.original_rows.push_back(start + j);
                ++added;
            }
        }
        if (added < sample_count) {
            for (int i = 0; i < n && added < sample_count; ++i) {
                sample.original_rows.push_back(i);
                ++added;
            }
        }
        std::sort(sample.original_rows.begin(), sample.original_rows.end());
        sample.original_rows.erase(
            std::unique(sample.original_rows.begin(), sample.original_rows.end()),
            sample.original_rows.end());
        const std::vector<int> existing_rows = sample.original_rows;
        for (int i = 0; i < n &&
             static_cast<int>(sample.original_rows.size()) < sample_count;
             ++i) {
            if (!std::binary_search(existing_rows.begin(),
                                    existing_rows.end(),
                                    i)) {
                sample.original_rows.push_back(i);
            }
        }
        std::sort(sample.original_rows.begin(), sample.original_rows.end());
    }
    sample.n = static_cast<int>(sample.original_rows.size());
    if (sample.n <= 0) {
        return sample;
    }

    sample.indexers.reserve(fes.size());
    for (const auto& fe : fes) {
        Eigen::VectorXi fe_sample(sample.n);
        for (int i = 0; i < sample.n; ++i) {
            fe_sample(i) = fe(sample.original_rows[static_cast<std::size_t>(i)]);
        }
        sample.indexers.push_back(build_indexer_lite(fe_sample));
        sample.total_levels += sample.indexers.back().num_groups;
    }

    if (weights) {
        sample.weighted = true;
        sample.weights.resize(sample.n);
        for (int i = 0; i < sample.n; ++i) {
            sample.weights(i) = (*weights)(sample.original_rows[static_cast<std::size_t>(i)]);
        }
    }
    return sample;
}

Eigen::VectorXd make_auto_mlsmr_probe_vector(const AutoMlsmrProbeSample& sample) {
    Eigen::VectorXd v(sample.n);
    long double weighted_sum = 0.0L;
    long double weight_total = 0.0L;
    for (int i = 0; i < sample.n; ++i) {
        const double value =
            deterministic_probe_value(sample.original_rows[static_cast<std::size_t>(i)]);
        v(i) = value;
        const double weight = sample.weighted ? sample.weights(i) : 1.0;
        weighted_sum += static_cast<long double>(weight) * value;
        weight_total += static_cast<long double>(weight);
    }
    if (weight_total > 0.0L) {
        const double mean = static_cast<double>(weighted_sum / weight_total);
        v.array() -= mean;
    }
    return v;
}

void apply_probe_demean_dimension(Eigen::VectorXd& v,
                                  const FeIndexerLite& idx,
                                  const Eigen::VectorXd* weights) {
    if (idx.num_groups <= 0) {
        return;
    }
    std::vector<double> sums(static_cast<std::size_t>(idx.num_groups), 0.0);
    std::vector<double> denoms(static_cast<std::size_t>(idx.num_groups), 0.0);
    const int n = static_cast<int>(v.size());
    for (int i = 0; i < n; ++i) {
        const int g = idx.group_ids[static_cast<std::size_t>(i)];
        const double weight = weights ? (*weights)(i) : 1.0;
        sums[static_cast<std::size_t>(g)] += weight * v(i);
        denoms[static_cast<std::size_t>(g)] += weight;
    }
    for (int g = 0; g < idx.num_groups; ++g) {
        const double denom = denoms[static_cast<std::size_t>(g)];
        if (denom > 0.0) {
            sums[static_cast<std::size_t>(g)] /= denom;
        }
    }
    for (int i = 0; i < n; ++i) {
        const int g = idx.group_ids[static_cast<std::size_t>(i)];
        v(i) -= sums[static_cast<std::size_t>(g)];
    }
}

void apply_probe_sweep(Eigen::VectorXd& v,
                       const AutoMlsmrProbeSample& sample,
                       AbsorptionMethod sweep_method) {
    const Eigen::VectorXd* weights = sample.weighted ? &sample.weights : nullptr;
    for (const auto& idx : sample.indexers) {
        apply_probe_demean_dimension(v, idx, weights);
    }
    if (sweep_method == AbsorptionMethod::SymmetricGaussSeidel &&
        sample.indexers.size() > 1) {
        for (std::size_t pos = sample.indexers.size(); pos-- > 0;) {
            apply_probe_demean_dimension(v, sample.indexers[pos], weights);
        }
    }
}

double probe_fe_mean_norm(const Eigen::VectorXd& v,
                          const AutoMlsmrProbeSample& sample) {
    const Eigen::VectorXd* weights = sample.weighted ? &sample.weights : nullptr;
    long double total = 0.0L;
    long double denom_total = 0.0L;
    const int n = static_cast<int>(v.size());
    for (const auto& idx : sample.indexers) {
        if (idx.num_groups <= 0) {
            continue;
        }
        std::vector<double> sums(static_cast<std::size_t>(idx.num_groups), 0.0);
        std::vector<double> denoms(static_cast<std::size_t>(idx.num_groups), 0.0);
        for (int i = 0; i < n; ++i) {
            const int g = idx.group_ids[static_cast<std::size_t>(i)];
            const double weight = weights ? (*weights)(i) : 1.0;
            sums[static_cast<std::size_t>(g)] += weight * v(i);
            denoms[static_cast<std::size_t>(g)] += weight;
        }
        for (int g = 0; g < idx.num_groups; ++g) {
            const double denom = denoms[static_cast<std::size_t>(g)];
            if (denom <= 0.0) {
                continue;
            }
            const double mean = sums[static_cast<std::size_t>(g)] / denom;
            total += static_cast<long double>(denom) * mean * mean;
            denom_total += static_cast<long double>(denom);
        }
    }
    if (denom_total <= 0.0L) {
        return 0.0;
    }
    return std::sqrt(static_cast<double>(total / denom_total));
}

// ---- The block sample on data not sorted by identifier ----
// The four contiguous blocks represent a panel sorted by its largest
// identifier. When the rows are not sorted that way, almost every level of
// that identifier appears once in the sample, the sampled graph is far
// sparser than the data, and the contraction looks worse than it is. The
// representation of the sample is r = (sample rows / sample levels) /
// (rows / levels) of the identifier with the most levels in the full data:
// about 1 for a sorted panel, about 1/(observations per level) for rows in
// random order. When the block sample has chosen MLSMR on at least
// kAutoMlsmrFullProbeMinRows rows and r is below kAutoMlsmrRepresentationMin,
// the same probe runs on all rows with the team, and its contraction decides
// under the same thresholds. XHDFE_AUTO_MLSMR_FULL_PROBE=0 restores the
// block sample alone.
constexpr int kAutoMlsmrFullProbeMinRows = 1000000;
constexpr double kAutoMlsmrRepresentationMin = 0.25;
// Memory cap of the chunk-private level sums of the full probe.
constexpr std::size_t kAutoMlsmrProbeScratchBytes = 256ULL * 1024ULL * 1024ULL;

// The dense ranks of build_indexer_lite(), on the team when there is one.
FeIndexerLite build_probe_indexer(const Eigen::VectorXi& ids, int threads,
                                  detail::ParallelWorkObserver* observer) {
#ifdef HDFE_USE_OPENMP
    return build_indexer_lite_team(ids, threads, observer);
#else
    (void)threads;
    (void)observer;
    return build_indexer_lite(ids);
#endif
}

int popcount64(std::uint64_t x) {
    x = x - ((x >> 1) & 0x5555555555555555ULL);
    x = (x & 0x3333333333333333ULL) + ((x >> 2) & 0x3333333333333333ULL);
    x = (x + (x >> 4)) & 0x0f0f0f0f0f0f0f0fULL;
    return static_cast<int>((x * 0x0101010101010101ULL) >> 56);
}

// Exact number of distinct values of `ids`, the same for any team: each
// thread marks its rows in a bit set of its own over the id range, and the
// bit sets are merged once (an OR does not depend on order); the lite
// indexer when the range is sparse. Only a fallback: the selector receives
// the level counts of the singleton scan when it ran.
int count_levels_team(const Eigen::VectorXi& ids, int threads,
                      detail::ParallelWorkObserver* observer) {
    const int n = static_cast<int>(ids.size());
    if (n == 0) {
        return 0;
    }
    [[maybe_unused]] const int team = std::max(1, threads);
    const int* const raw = ids.data();
    const int chunks = detail::deterministic_parallel_chunk_count(n);
    std::vector<int> chunk_min(static_cast<std::size_t>(chunks), raw[0]);
    std::vector<int> chunk_max(static_cast<std::size_t>(chunks), raw[0]);
#ifdef HDFE_USE_OPENMP
#pragma omp parallel for schedule(static) num_threads(team) if (team > 1)
#endif
    for (int chunk = 0; chunk < chunks; ++chunk) {
        const int begin = detail::deterministic_parallel_chunk_begin(n, chunk, chunks);
        const int end = detail::deterministic_parallel_chunk_end(n, chunk, chunks);
        int low = raw[begin];
        int high = raw[begin];
        for (int i = begin + 1; i < end; ++i) {
            low = std::min(low, raw[i]);
            high = std::max(high, raw[i]);
        }
        chunk_min[static_cast<std::size_t>(chunk)] = low;
        chunk_max[static_cast<std::size_t>(chunk)] = high;
    }
    const int min_id = *std::min_element(chunk_min.begin(), chunk_min.end());
    const int max_id = *std::max_element(chunk_max.begin(), chunk_max.end());
    const long long range = static_cast<long long>(max_id) - static_cast<long long>(min_id) + 1LL;
    if (range <= 0 || range > 8LL * static_cast<long long>(n) + 64LL) {
        return build_probe_indexer(ids, threads, observer).num_groups;
    }
    const std::size_t words = static_cast<std::size_t>((range + 63LL) / 64LL);
    // One bit set per worker, within the scratch cap.
    const int marking_team = static_cast<int>(std::max<std::size_t>(
        1U, std::min<std::size_t>(static_cast<std::size_t>(team),
                                  kAutoMlsmrProbeScratchBytes /
                                      std::max<std::size_t>(1U, words * sizeof(std::uint64_t)))));
    std::vector<std::vector<std::uint64_t>> marks(static_cast<std::size_t>(marking_team));
#ifdef HDFE_USE_OPENMP
#pragma omp parallel num_threads(marking_team) if (marking_team > 1)
#endif
    {
        int worker = 0;
#ifdef HDFE_USE_OPENMP
        worker = omp_get_thread_num();
#endif
        std::vector<std::uint64_t>& mine = marks[static_cast<std::size_t>(worker)];
        mine.assign(words, 0ULL);
#ifdef HDFE_USE_OPENMP
#pragma omp for schedule(static)
#endif
        for (int chunk = 0; chunk < chunks; ++chunk) {
            const int begin = detail::deterministic_parallel_chunk_begin(n, chunk, chunks);
            const int end = detail::deterministic_parallel_chunk_end(n, chunk, chunks);
            for (int i = begin; i < end; ++i) {
                const std::uint64_t offset = static_cast<std::uint64_t>(
                    static_cast<long long>(raw[i]) - static_cast<long long>(min_id));
                mine[static_cast<std::size_t>(offset >> 6U)] |= 1ULL << (offset & 63U);
            }
        }
    }
    long long count = 0;
#ifdef HDFE_USE_OPENMP
#pragma omp parallel for schedule(static) reduction(+ : count) num_threads(team) if (team > 1)
#endif
    for (long long word = 0; word < static_cast<long long>(words); ++word) {
        std::uint64_t merged = 0ULL;
        for (const auto& mine : marks) {
            if (!mine.empty()) {
                merged |= mine[static_cast<std::size_t>(word)];
            }
        }
        count += popcount64(merged);
    }
    return static_cast<int>(count);
}

// Weighted level sums of one dimension over all rows, the same for any team:
// fixed row chunks (as many as the memory cap allows), each with its own
// partial sums, added in chunk order.
template <class Contribution>
void probe_level_sums_team(const FeIndexerLite& idx, int n, Contribution contribution,
                           int threads, std::vector<double>& sums,
                           std::vector<double>& scratch) {
    const std::size_t groups = static_cast<std::size_t>(std::max(0, idx.num_groups));
    sums.assign(groups, 0.0);
    if (groups == 0 || n <= 0) {
        return;
    }
    [[maybe_unused]] const int team = std::max(1, threads);
    const std::size_t by_memory =
        std::max<std::size_t>(1U, kAutoMlsmrProbeScratchBytes / (groups * sizeof(double)));
    const int chunks = static_cast<int>(std::min<std::size_t>(
        static_cast<std::size_t>(detail::deterministic_parallel_chunk_count(n)), by_memory));
    scratch.assign(groups * static_cast<std::size_t>(chunks), 0.0);
    const int* const group_ids = idx.group_ids.data();
#ifdef HDFE_USE_OPENMP
#pragma omp parallel for schedule(dynamic, 1) num_threads(team) if (team > 1)
#endif
    for (int chunk = 0; chunk < chunks; ++chunk) {
        double* const mine = scratch.data() + static_cast<std::size_t>(chunk) * groups;
        const int end = detail::deterministic_parallel_chunk_end(n, chunk, chunks);
        for (int i = detail::deterministic_parallel_chunk_begin(n, chunk, chunks); i < end; ++i) {
            mine[static_cast<std::size_t>(group_ids[i])] += contribution(i);
        }
    }
#ifdef HDFE_USE_OPENMP
#pragma omp parallel for schedule(static) num_threads(team) if (team > 1)
#endif
    for (long long g = 0; g < static_cast<long long>(groups); ++g) {
        double total = 0.0;
        for (int chunk = 0; chunk < chunks; ++chunk) {
            total += scratch[static_cast<std::size_t>(chunk) * groups + static_cast<std::size_t>(g)];
        }
        sums[static_cast<std::size_t>(g)] = total;
    }
}

// The block-sample probe (make_auto_mlsmr_probe_vector, apply_probe_sweep,
// probe_fe_mean_norm) on all rows, with the team and fixed partitions, so the
// contraction is bit-identical for any thread count. NaN when degenerate.
double full_data_probe_rho(const std::vector<Eigen::VectorXi>& fes,
                           const Eigen::VectorXd* weights,
                           AbsorptionMethod sweep_method,
                           int probe_sweeps,
                           int threads,
                           detail::ParallelWorkObserver* observer) {
    const double nan = std::numeric_limits<double>::quiet_NaN();
    const int n = fes.empty() ? 0 : static_cast<int>(fes[0].size());
    if (n <= 0 || probe_sweeps < 2) {
        return nan;
    }
    [[maybe_unused]] const int team = std::max(1, threads);
    std::vector<FeIndexerLite> indexers;
    indexers.reserve(fes.size());
    for (const auto& fe : fes) {
        indexers.push_back(build_probe_indexer(fe, team, observer));
    }
    auto weight = [&](int i) { return weights ? (*weights)(i) : 1.0; };

    // Probe vector: the same value per original row as the sample's,
    // centred with a chunked sum added in chunk order.
    Eigen::VectorXd v(n);
    const int chunks = detail::deterministic_parallel_chunk_count(n);
    std::vector<long double> chunk_sum(static_cast<std::size_t>(chunks), 0.0L);
    std::vector<long double> chunk_weight(static_cast<std::size_t>(chunks), 0.0L);
#ifdef HDFE_USE_OPENMP
#pragma omp parallel for schedule(static) num_threads(team) if (team > 1)
#endif
    for (int chunk = 0; chunk < chunks; ++chunk) {
        long double sum = 0.0L;
        long double total = 0.0L;
        const int end = detail::deterministic_parallel_chunk_end(n, chunk, chunks);
        for (int i = detail::deterministic_parallel_chunk_begin(n, chunk, chunks); i < end; ++i) {
            const double value = deterministic_probe_value(i);
            v(i) = value;
            sum += static_cast<long double>(weight(i)) * value;
            total += static_cast<long double>(weight(i));
        }
        chunk_sum[static_cast<std::size_t>(chunk)] = sum;
        chunk_weight[static_cast<std::size_t>(chunk)] = total;
    }
    long double weighted_sum = 0.0L;
    long double weight_total = 0.0L;
    for (int chunk = 0; chunk < chunks; ++chunk) {
        weighted_sum += chunk_sum[static_cast<std::size_t>(chunk)];
        weight_total += chunk_weight[static_cast<std::size_t>(chunk)];
    }
    if (weight_total > 0.0L) {
        const double mean = static_cast<double>(weighted_sum / weight_total);
#ifdef HDFE_USE_OPENMP
#pragma omp parallel for schedule(static) num_threads(team) if (team > 1)
#endif
        for (int i = 0; i < n; ++i) {
            v(i) -= mean;
        }
    }

    std::vector<std::vector<double>> denominators(indexers.size());
    std::vector<double> sums;
    std::vector<double> scratch;
    for (std::size_t d = 0; d < indexers.size(); ++d) {
        probe_level_sums_team(indexers[d], n, weight, team, denominators[d], scratch);
    }
    auto demean = [&](std::size_t d) {
        probe_level_sums_team(indexers[d], n, [&](int i) { return weight(i) * v(i); }, team,
                              sums, scratch);
        const std::vector<double>& denom = denominators[d];
        for (std::size_t g = 0; g < sums.size(); ++g) {
            if (denom[g] > 0.0) {
                sums[g] /= denom[g];
            }
        }
        const int* const group_ids = indexers[d].group_ids.data();
#ifdef HDFE_USE_OPENMP
#pragma omp parallel for schedule(static) num_threads(team) if (team > 1)
#endif
        for (int i = 0; i < n; ++i) {
            v(i) -= sums[static_cast<std::size_t>(group_ids[i])];
        }
    };
    auto sweep = [&]() {
        for (std::size_t d = 0; d < indexers.size(); ++d) {
            demean(d);
        }
        if (sweep_method == AbsorptionMethod::SymmetricGaussSeidel && indexers.size() > 1) {
            for (std::size_t d = indexers.size(); d-- > 0;) {
                demean(d);
            }
        }
    };
    auto violation = [&]() {
        long double total = 0.0L;
        long double denom_total = 0.0L;
        for (std::size_t d = 0; d < indexers.size(); ++d) {
            probe_level_sums_team(indexers[d], n, [&](int i) { return weight(i) * v(i); },
                                  team, sums, scratch);
            const std::vector<double>& denom = denominators[d];
            for (std::size_t g = 0; g < sums.size(); ++g) {
                if (denom[g] <= 0.0) {
                    continue;
                }
                const double mean = sums[g] / denom[g];
                total += static_cast<long double>(denom[g]) * mean * mean;
                denom_total += static_cast<long double>(denom[g]);
            }
        }
        return denom_total > 0.0L ? std::sqrt(static_cast<double>(total / denom_total)) : 0.0;
    };
    sweep();
    const double first = violation();
    if (!(first > 0.0) || !hdfe::detail::ieee_finite(first)) {
        return nan;
    }
    for (int s = 1; s < probe_sweeps; ++s) {
        sweep();
    }
    const double last = violation();
    if (!(last >= 0.0) || !hdfe::detail::ieee_finite(last)) {
        return nan;
    }
    return std::pow(std::max(0.0, last / std::max(first, 1.0e-300)),
                    1.0 / static_cast<double>(probe_sweeps - 1));
}

struct AutoMlsmrSelectionDiagnostics {
    bool evaluated = false;
    double per_sweep_rho = std::numeric_limits<double>::quiet_NaN();
};

AbsorptionMethod select_auto_mlsmr_method(
    const std::vector<Eigen::VectorXi>& fes,
    const Eigen::VectorXd* weights,
    const HdfeOptions& options,
    int rhs_count,
    AbsorptionMethod sweep_fallback,
    AutoMlsmrSelectionDiagnostics* diagnostics = nullptr,
    int threads = 1,
    detail::ParallelWorkObserver* observer = nullptr,
    const std::vector<int>* full_levels_hint = nullptr) {
    if (diagnostics != nullptr) {
        *diagnostics = AutoMlsmrSelectionDiagnostics{};
    }
    const bool trace = read_env_bool("XHDFE_AUTO_MLSMR_TRACE").value_or(false);
    auto trace_fallback = [&](const std::string& reason,
                              int n,
                              int sample_n,
                              int sample_levels,
                              double rho,
                              double threshold) {
        if (!trace) {
            return;
        }
        std::cerr << "auto_mlsmr"
                  << " n=" << n
                  << " sample_n=" << sample_n
                  << " sample_levels=" << sample_levels
                  << " rhs=" << rhs_count
                  << " fallback=" << method_name(sweep_fallback)
                  << " rho=" << rho
                  << " threshold=" << threshold
                  << " reason=" << reason
                  << " selected=" << method_name(sweep_fallback)
                  << '\n';
    };
    if (fes.size() < 2 || options.retain_fixed_effects || options.save_groupvar ||
        options.use_sparse_solver || options.use_krylov) {
        trace_fallback("ineligible_options", static_cast<int>(fes.empty() ? 0 : fes[0].size()),
                       0, 0, std::numeric_limits<double>::quiet_NaN(),
                       std::numeric_limits<double>::quiet_NaN());
        return sweep_fallback;
    }
    const int n = static_cast<int>(fes.empty() ? 0 : fes[0].size());
    const int min_rows =
        read_env_int("XHDFE_AUTO_MLSMR_MIN_ROWS", 200000, 1);
    const int min_rhs =
        read_env_int("XHDFE_AUTO_MLSMR_MIN_RHS", 2, 1);
    if (n < min_rows || rhs_count < min_rhs) {
        trace_fallback(n < min_rows ? "too_few_rows" : "too_few_rhs",
                       n, 0, 0, std::numeric_limits<double>::quiet_NaN(),
                       std::numeric_limits<double>::quiet_NaN());
        return sweep_fallback;
    }

    const int probe_rows =
        read_env_int("XHDFE_AUTO_MLSMR_PROBE_ROWS", 200000, 1000);
    const int probe_sweeps =
        read_env_int("XHDFE_AUTO_MLSMR_PROBE_SWEEPS", 4, 2);
    const int min_levels =
        read_env_int("XHDFE_AUTO_MLSMR_MIN_LEVELS", 4096, 1);
    const bool parity_grade_tolerance =
        options.tolerance_mode == ToleranceMode::ReghdfeComparable ||
        options.tolerance_mode == ToleranceMode::StrictResidual;
    const double default_rho_threshold = parity_grade_tolerance ? 0.645 : 0.80;
    const double rho_threshold =
        read_env_double("XHDFE_AUTO_MLSMR_RHO_THRESHOLD", default_rho_threshold, 0.0, 1.0);
    const bool fast_tolerance =
        options.tolerance_mode == ToleranceMode::XhdfeFast;
    const int fast_min_rows =
        read_env_int("XHDFE_AUTO_MLSMR_FAST_MIN_ROWS", 1000000, 1);
    const int fast_min_rhs =
        read_env_int("XHDFE_AUTO_MLSMR_FAST_MIN_RHS", 8, 1);
    const int fast_min_fes =
        read_env_int("XHDFE_AUTO_MLSMR_FAST_MIN_FES", 3, 1);
    const double fast_rho_min =
        read_env_double("XHDFE_AUTO_MLSMR_FAST_RHO_MIN", 0.60, 0.0, 1.0);
    const double fast_rho_max =
        read_env_double("XHDFE_AUTO_MLSMR_FAST_RHO_MAX", 0.675, 0.0, 1.0);
    const int parity_small_n_rows =
        read_env_int("XHDFE_AUTO_MLSMR_PARITY_SMALL_N_ROWS", 1000000, 1);
    const int parity_small_n_min_rhs =
        read_env_int("XHDFE_AUTO_MLSMR_PARITY_SMALL_N_MIN_RHS", 4, 1);
    const double parity_small_n_rho_threshold =
        read_env_double("XHDFE_AUTO_MLSMR_PARITY_SMALL_N_RHO_THRESHOLD", 0.735, 0.0, 1.0);
    const double precision_rho_threshold =
        read_env_double("XHDFE_AUTO_MLSMR_PRECISION_RHO_THRESHOLD", 0.62, 0.0, 1.0);

    const AutoMlsmrProbeSample sample =
        build_auto_mlsmr_probe_sample(fes, weights, probe_rows);
    if (sample.n <= 0 || sample.total_levels < min_levels) {
        trace_fallback(sample.n <= 0 ? "empty_sample" : "too_few_levels",
                       n, sample.n, sample.total_levels,
                       std::numeric_limits<double>::quiet_NaN(), rho_threshold);
        return sweep_fallback;
    }

    Eigen::VectorXd probe = make_auto_mlsmr_probe_vector(sample);
    apply_probe_sweep(probe, sample, sweep_fallback);
    const double first_violation = probe_fe_mean_norm(probe, sample);
    if (!(first_violation > 0.0) || !hdfe::detail::ieee_finite(first_violation)) {
        trace_fallback("degenerate_first_violation", n, sample.n, sample.total_levels,
                       std::numeric_limits<double>::quiet_NaN(), rho_threshold);
        return sweep_fallback;
    }
    for (int sweep = 1; sweep < probe_sweeps; ++sweep) {
        apply_probe_sweep(probe, sample, sweep_fallback);
    }
    const double last_violation = probe_fe_mean_norm(probe, sample);
    if (!(last_violation >= 0.0) || !hdfe::detail::ieee_finite(last_violation)) {
        trace_fallback("invalid_last_violation", n, sample.n, sample.total_levels,
                       std::numeric_limits<double>::quiet_NaN(), rho_threshold);
        return sweep_fallback;
    }
    const double ratio = last_violation / std::max(first_violation, 1.0e-300);
    const double sample_rho =
        std::pow(std::max(0.0, ratio), 1.0 / static_cast<double>(probe_sweeps - 1));
    const bool parity_small_low_rhs =
        parity_grade_tolerance &&
        n < parity_small_n_rows &&
        rhs_count < parity_small_n_min_rhs;
    const double effective_rho_threshold =
        parity_small_low_rhs
            ? std::max(rho_threshold, parity_small_n_rho_threshold)
            : rho_threshold;
    struct Decision {
        bool fast_large_rhs_band = false;
        bool low_rhs_precision_band = false;
        bool mlsmr = false;
    };
    auto decide = [&](double rho) {
        Decision decision;
        // Fast mode keeps the conservative rho threshold, but lets large,
        // many-RHS, multi-way designs enter the moderate-rho band where MLSMR won
        // the base-DGP difficult 1M/10M runs without catching Section 5 fast.
        decision.fast_large_rhs_band =
            fast_tolerance &&
            n >= fast_min_rows &&
            rhs_count >= fast_min_rhs &&
            static_cast<int>(fes.size()) >= fast_min_fes &&
            rho >= fast_rho_min &&
            rho <= fast_rho_max;
        // A moderate-contraction, low-RHS band is scientifically unsafe under the
        // short fast polish and pathologically slow under strict MAP.  The same
        // sampled contraction signal identifies all affected core designs; keep
        // comparable mode on its established, tighter sweep rule.
        decision.low_rhs_precision_band =
            (fast_tolerance ||
             options.tolerance_mode == ToleranceMode::StrictResidual) &&
            n >= min_rows && n < parity_small_n_rows &&
            rhs_count < parity_small_n_min_rhs && fes.size() >= 3 &&
            rho >= precision_rho_threshold;
        decision.mlsmr = rho >= effective_rho_threshold ||
                         decision.fast_large_rhs_band ||
                         decision.low_rhs_precision_band;
        return decision;
    };
    Decision decision = decide(sample_rho);
    double per_sweep_rho = sample_rho;

    // Representation of the block sample (see kAutoMlsmrFullProbeMinRows):
    // checked when the sample chose MLSMR on a large design; with the trace
    // on, also computed for every evaluated fit, as a diagnostic only.
    const bool full_probe_enabled =
        read_env_bool("XHDFE_AUTO_MLSMR_FULL_PROBE").value_or(true);
    const bool check_applies =
        full_probe_enabled && decision.mlsmr && n >= kAutoMlsmrFullProbeMinRows;
    std::vector<int> full_levels;
    int largest_fe = -1;
    double representation = std::numeric_limits<double>::quiet_NaN();
    double full_rho = std::numeric_limits<double>::quiet_NaN();
    double check_seconds = 0.0;
    double probe_seconds = 0.0;
    bool full_probe_ran = false;
    const int team = std::max(1, threads);
    // Level counts of the full data: those of the singleton scan when it ran
    // on these rows, otherwise counted here.
    const bool levels_from_scan =
        full_levels_hint != nullptr && full_levels_hint->size() == fes.size() &&
        std::all_of(full_levels_hint->begin(), full_levels_hint->end(),
                    [](int levels) { return levels > 0; });
    if (check_applies || trace) {
        const auto check_t0 = std::chrono::steady_clock::now();
        if (levels_from_scan) {
            full_levels = *full_levels_hint;
        } else {
            full_levels.reserve(fes.size());
            for (const auto& fe : fes) {
                full_levels.push_back(count_levels_team(fe, team, observer));
            }
        }
        largest_fe = static_cast<int>(
            std::max_element(full_levels.begin(), full_levels.end()) - full_levels.begin());
        const int sample_levels_largest =
            sample.indexers[static_cast<std::size_t>(largest_fe)].num_groups;
        const int full_levels_largest = full_levels[static_cast<std::size_t>(largest_fe)];
        if (sample_levels_largest > 0 && full_levels_largest > 0) {
            representation =
                (static_cast<double>(sample.n) / static_cast<double>(sample_levels_largest)) /
                (static_cast<double>(n) / static_cast<double>(full_levels_largest));
        }
        check_seconds = std::chrono::duration<double>(
            std::chrono::steady_clock::now() - check_t0).count();
    }
    if (check_applies && representation < kAutoMlsmrRepresentationMin) {
        const auto probe_t0 = std::chrono::steady_clock::now();
        full_rho = full_data_probe_rho(fes, weights, sweep_fallback, probe_sweeps, team,
                                       observer);
        probe_seconds = std::chrono::duration<double>(
            std::chrono::steady_clock::now() - probe_t0).count();
        full_probe_ran = true;
        if (hdfe::detail::ieee_finite(full_rho)) {
            per_sweep_rho = full_rho;
            decision = decide(full_rho);
        }
    }
    if (diagnostics != nullptr) {
        diagnostics->evaluated = true;
        diagnostics->per_sweep_rho = per_sweep_rho;
    }
    const bool fast_large_rhs_band = decision.fast_large_rhs_band;
    const bool low_rhs_precision_band = decision.low_rhs_precision_band;
    const bool choose_mlsmr = decision.mlsmr;
    if (trace) {
        std::cerr << "auto_mlsmr"
                  << " n=" << n
                  << " sample_n=" << sample.n
                  << " sample_levels=" << sample.total_levels
                  << " rhs=" << rhs_count
                  << " fallback=" << method_name(sweep_fallback)
                  << " rho=" << per_sweep_rho
                  << " threshold=" << rho_threshold
                  << " effective_threshold=" << effective_rho_threshold
                  << " tolerance_mode="
                  << (parity_grade_tolerance ? "parity" : "xhdfe-fast")
                  << " fast_large_rhs_band=" << (fast_large_rhs_band ? 1 : 0)
                  << " low_rhs_precision_band=" << (low_rhs_precision_band ? 1 : 0)
                  << " precision_rho_threshold=" << precision_rho_threshold
                  << " parity_small_low_rhs=" << (parity_small_low_rhs ? 1 : 0)
                  << " selected=" << (choose_mlsmr ? "mlsmr" : method_name(sweep_fallback));
        std::cerr << " largest_fe=" << largest_fe << " full_levels=";
        for (std::size_t d = 0; d < full_levels.size(); ++d) {
            std::cerr << (d ? "," : "") << full_levels[d];
        }
        std::cerr << " sample_fe_levels=";
        for (std::size_t d = 0; d < sample.indexers.size(); ++d) {
            std::cerr << (d ? "," : "") << sample.indexers[d].num_groups;
        }
        std::cerr << " levels_source=" << (levels_from_scan ? "singleton_scan" : "counted")
                  << " representation=" << representation
                  << " check=" << (check_applies ? "applied" : "trace_only")
                  << " full_probe=" << (full_probe_ran ? 1 : 0)
                  << " sample_rho=" << sample_rho << " full_rho=" << full_rho
                  << " full_rho_hex=" << std::hexfloat << full_rho << std::defaultfloat
                  << " check_s=" << check_seconds << " probe_s=" << probe_seconds << '\n';
    }
    return choose_mlsmr ? AbsorptionMethod::Mlsmr : sweep_fallback;
}

AbsorptionMethod auto_mlsmr_sweep_fallback(std::size_t num_fes,
                                           bool symmetric_sweep) {
    if (num_fes <= 1) {
        return AbsorptionMethod::GaussSeidel;
    }
    if (symmetric_sweep) {
        return AbsorptionMethod::SymmetricGaussSeidel;
    }
    return AbsorptionMethod::GaussSeidel;
}

std::optional<AbsorptionMethod> parse_method_hint(const std::string& raw) {
    const std::string name = to_lower_ascii(raw);
    if (name == "gauss-seidel" || name == "gauss_seidel" || name == "gs") {
        return AbsorptionMethod::GaussSeidel;
    }
    if (name == "symmetric-gauss-seidel" || name == "symmetric_gauss_seidel" ||
        name == "sym" || name == "symgs") {
        return AbsorptionMethod::SymmetricGaussSeidel;
    }
    if (name == "jacobi") {
        return AbsorptionMethod::Jacobi;
    }
    if (name == "schwarz") {
        return AbsorptionMethod::Schwarz;
    }
    if (name == "lsmr") {
        return AbsorptionMethod::Lsmr;
    }
    if (name == "mlsmr") {
        return AbsorptionMethod::Mlsmr;
    }
    if (name == "auto-mlsmr" || name == "auto_mlsmr") {
        return AbsorptionMethod::AutoMlsmr;
    }
    if (name == "auto") {
        return AbsorptionMethod::Auto;
    }
    return std::nullopt;
}

bool parse_uint64(const std::string& raw, std::uint64_t* out) {
    if (!out) {
        return false;
    }
    try {
        std::size_t idx = 0;
        const unsigned long long val = std::stoull(raw, &idx, 0);
        if (idx != raw.size()) {
            return false;
        }
        *out = static_cast<std::uint64_t>(val);
        return true;
    } catch (...) {
        return false;
    }
}

bool parse_int(const std::string& raw, int* out) {
    if (!out) {
        return false;
    }
    try {
        std::size_t idx = 0;
        const int val = std::stoi(raw, &idx);
        if (idx != raw.size()) {
            return false;
        }
        *out = val;
        return true;
    } catch (...) {
        return false;
    }
}

bool parse_double(const std::string& raw, double* out) {
    if (!out) {
        return false;
    }
    try {
        std::size_t idx = 0;
        const double val = std::stod(raw, &idx);
        if (idx != raw.size()) {
            return false;
        }
        *out = val;
        return true;
    } catch (...) {
        return false;
    }
}

bool parse_int_list(const std::string& raw, std::vector<int>& out) {
    out.clear();
    std::string token;
    auto flush = [&]() -> bool {
        if (token.empty()) {
            return true;
        }
        try {
            std::size_t idx = 0;
            const int val = std::stoi(token, &idx);
            if (idx != token.size()) {
                out.clear();
                return false;
            }
            out.push_back(val);
            token.clear();
            return true;
        } catch (...) {
            out.clear();
            return false;
        }
    };
    for (char c : raw) {
        if (c == ',' || std::isspace(static_cast<unsigned char>(c))) {
            if (!flush()) {
                return false;
            }
        } else {
            token.push_back(c);
        }
    }
    return flush();
}

std::optional<AbsorptionMethod> select_two_fe_auto_fastpath(
    const std::vector<Eigen::VectorXi>& fes,
    const Eigen::VectorXd* weights,
    const HdfeOptions& options,
    bool gpu_requested,
    bool has_instruments) {
    (void)gpu_requested;
    if (read_env_bool("XHDFE_AUTO_2FE_SHAPE").value_or(true) == false) {
        return std::nullopt;
    }
    if (fes.size() != 2 || weights != nullptr || has_instruments ||
        options.retain_fixed_effects || options.save_groupvar ||
        options.absorption_method != AbsorptionMethod::Auto ||
        options.symmetric_sweep || options.use_sparse_solver || options.use_krylov) {
        return std::nullopt;
    }

    const int n = static_cast<int>(fes[0].size());
    // Small two-FE panels benchmark faster with the single forward sweep path and
    // retain coefficient/SE parity on the Sergio suite.
    if (n < 50000) {
        return AbsorptionMethod::GaussSeidel;
    }
    // Larger 2-FE panels were benchmark-sensitive; keep them on the established
    // symmetric auto path unless the user explicitly requests another method.
    return std::nullopt;
}

MobilityProfileConfig load_mobility_profile_config() {
    MobilityProfileConfig cfg;
    const char* env_path = std::getenv("XHDFE_MOBILITY_PROFILE");
    const char* env_mode = std::getenv("XHDFE_MOBILITY_MODE");
    const bool have_env_path = (env_path && *env_path != '\0');
    const bool have_env_mode = (env_mode && *env_mode != '\0');
    if (have_env_path) {
        cfg.path = env_path;
    } else {
        cfg.path = kMobilityProfileDefaultPath;
    }
    cfg.allow_auto_write = have_env_path || have_env_mode;

    if (have_env_mode) {
        cfg.mode = to_lower_ascii(env_mode);
    } else if (have_env_path) {
        cfg.mode = "auto";
    } else if (file_exists(cfg.path)) {
        cfg.mode = "auto";
    } else {
        cfg.mode = "off";
    }

    if (cfg.mode != "off" && cfg.mode != "auto" &&
        cfg.mode != "read" && cfg.mode != "write") {
        cfg.mode = "off";
    }
    if (cfg.path.empty()) {
        cfg.path = kMobilityProfileDefaultPath;
    }
    return cfg;
}

AbsorptionCacheConfig load_absorption_cache_config() {
    AbsorptionCacheConfig cfg;
    const char* env_path = std::getenv("XHDFE_ABSORPTION_CACHE");
    const char* env_mode = std::getenv("XHDFE_ABSORPTION_CACHE_MODE");
    const bool have_env_path = (env_path && *env_path != '\0');
    const bool have_env_mode = (env_mode && *env_mode != '\0');
    if (have_env_path) {
        cfg.path = env_path;
    }
    cfg.allow_auto_write = have_env_path || have_env_mode;
    cfg.mode_set = have_env_mode;

    if (have_env_mode) {
        cfg.mode = to_lower_ascii(env_mode);
    } else if (have_env_path) {
        cfg.mode = "auto";
    } else {
        cfg.mode = "off";
    }

    if (cfg.mode != "off" && cfg.mode != "auto" &&
        cfg.mode != "read" && cfg.mode != "write") {
        cfg.mode = "off";
    }
    return cfg;
}

FeStructureCacheConfig load_fe_structure_cache_config() {
    FeStructureCacheConfig cfg;
    const char* env_path = std::getenv("XHDFE_FE_STRUCTURE_CACHE");
    const char* env_mode = std::getenv("XHDFE_FE_STRUCTURE_MODE");
    const bool have_env_path = (env_path && *env_path != '\0');
    const bool have_env_mode = (env_mode && *env_mode != '\0');
    if (have_env_path) {
        cfg.path = env_path;
    }
    cfg.allow_auto_write = have_env_path || have_env_mode;

    if (have_env_mode) {
        cfg.mode = to_lower_ascii(env_mode);
    } else if (have_env_path) {
        cfg.mode = "auto";
    } else {
        cfg.mode = "off";
    }

    if (cfg.mode != "off" && cfg.mode != "auto" &&
        cfg.mode != "read" && cfg.mode != "write") {
        cfg.mode = "off";
    }
    if (cfg.path.empty()) {
        cfg.mode = "off";
    }
    return cfg;
}

bool load_mobility_profile(const std::string& path, MobilityProfile& profile) {
    std::ifstream in(path);
    if (!in) {
        return false;
    }

    bool have_header = false;
    bool have_signature = false;
    bool have_signature_sample = false;
    bool have_signature_canon = false;
    bool have_signature_sample_canon = false;
    std::string line;
    while (std::getline(in, line)) {
        const std::string trimmed = trim_ascii(line);
        if (trimmed.empty() || trimmed[0] == '#') {
            continue;
        }
        if (!have_header) {
            if (trimmed == "xhdfe_mobility_profile_v2") {
                profile.format_version = 2;
            } else {
                return false;
            }
            have_header = true;
            continue;
        }
        if (trimmed.rfind("xhdfe_mobility_profile_v", 0) == 0) {
            return false;
        }
        const std::size_t eq = trimmed.find('=');
        if (eq == std::string::npos) {
            continue;
        }
        const std::string key = trim_ascii(trimmed.substr(0, eq));
        const std::string value = trim_ascii(trimmed.substr(eq + 1));
        if (key == "profile_kind") {
            profile.profile_kind = to_lower_ascii(value);
            continue;
        }
        if (key == "signature") {
            std::uint64_t sig = 0;
            if (parse_uint64(value, &sig)) {
                profile.signature = sig;
                have_signature = true;
            }
            continue;
        }
        if (key == "signature_sample") {
            std::uint64_t sig = 0;
            if (parse_uint64(value, &sig)) {
                profile.signature_sample = sig;
                profile.has_signature_sample = true;
                have_signature_sample = true;
            }
            continue;
        }
        if (key == "signature_canon") {
            std::uint64_t sig = 0;
            if (parse_uint64(value, &sig)) {
                profile.signature_canon = sig;
                profile.has_signature_canon = true;
                have_signature_canon = true;
            }
            continue;
        }
        if (key == "signature_sample_canon") {
            std::uint64_t sig = 0;
            if (parse_uint64(value, &sig)) {
                profile.signature_sample_canon = sig;
                profile.has_signature_sample_canon = true;
                have_signature_sample_canon = true;
            }
            continue;
        }
        if (key == "n_obs") {
            int val = 0;
            if (parse_int(value, &val)) {
                profile.nobs = val;
            }
            continue;
        }
        if (key == "n_obs_full") {
            int val = 0;
            if (parse_int(value, &val)) {
                profile.nobs_full = val;
            }
            continue;
        }
        if (key == "num_singletons") {
            int val = 0;
            if (parse_int(value, &val)) {
                profile.num_singletons = val;
            }
            continue;
        }
        if (key == "n_fe") {
            int val = 0;
            if (parse_int(value, &val)) {
                profile.nfe = val;
            }
            continue;
        }
        if (key == "fe_levels") {
            parse_int_list(value, profile.fe_levels);
            continue;
        }
        if (key == "num_components") {
            int val = 0;
            if (parse_int(value, &val)) {
                profile.num_components = val;
            }
            continue;
        }
        if (key == "largest_component") {
            int val = 0;
            if (parse_int(value, &val)) {
                profile.largest_component = val;
            }
            continue;
        }
        if (key == "largest_component_share") {
            double val = 0.0;
            if (parse_double(value, &val)) {
                profile.largest_component_share = val;
            }
            continue;
        }
        if (key == "mobility_class") {
            profile.mobility_class = value;
            continue;
        }
        if (key == "sweep_order") {
            parse_int_list(value, profile.sweep_order);
            continue;
        }
        if (key == "suggest_symmetric") {
            const std::string val = to_lower_ascii(value);
            profile.suggest_symmetric = (val == "1" || val == "true" || val == "yes");
            continue;
        }
        if (key == "suggest_method") {
            if (auto parsed = parse_method_hint(value)) {
                profile.suggest_method = *parsed;
            }
            continue;
        }
        if (key == "suggest_sparse") {
            const std::string val = to_lower_ascii(value);
            profile.suggest_use_sparse = (val == "1" || val == "true" || val == "yes");
            continue;
        }
        if (key == "suggest_krylov") {
            const std::string val = to_lower_ascii(value);
            profile.suggest_use_krylov = (val == "1" || val == "true" || val == "yes");
            continue;
        }
    }
    const bool known_kind =
        profile.format_version == 2 &&
        (profile.profile_kind == "standard" ||
         profile.profile_kind == "group_individual");
    return have_header && known_kind &&
           (have_signature || have_signature_sample ||
            have_signature_canon || have_signature_sample_canon);
}

bool write_mobility_profile(const std::string& path, const MobilityProfile& profile) {
    std::ofstream out(path);
    if (!out) {
        return false;
    }
    out << "xhdfe_mobility_profile_v2\n";
    out << "profile_kind="
        << (profile.profile_kind.empty() ? "standard" : profile.profile_kind)
        << "\n";
    out << "signature=0x" << std::hex << profile.signature << std::dec << "\n";
    if (profile.has_signature_sample) {
        out << "signature_sample=0x" << std::hex << profile.signature_sample << std::dec << "\n";
    }
    if (profile.has_signature_canon) {
        out << "signature_canon=0x" << std::hex << profile.signature_canon << std::dec << "\n";
    }
    if (profile.has_signature_sample_canon) {
        out << "signature_sample_canon=0x" << std::hex << profile.signature_sample_canon << std::dec << "\n";
    }
    out << "n_obs=" << profile.nobs << "\n";
    out << "n_obs_full=" << profile.nobs_full << "\n";
    out << "num_singletons=" << profile.num_singletons << "\n";
    out << "n_fe=" << profile.nfe << "\n";
    out << "fe_levels=";
    for (std::size_t i = 0; i < profile.fe_levels.size(); ++i) {
        if (i > 0) {
            out << ",";
        }
        out << profile.fe_levels[i];
    }
    out << "\n";
    out << "num_components=" << profile.num_components << "\n";
    out << "largest_component=" << profile.largest_component << "\n";
    out << "largest_component_share=" << profile.largest_component_share << "\n";
    out << "mobility_class=" << profile.mobility_class << "\n";
    out << "sweep_order=";
    for (std::size_t i = 0; i < profile.sweep_order.size(); ++i) {
        if (i > 0) {
            out << ",";
        }
        out << profile.sweep_order[i];
    }
    out << "\n";
    out << "suggest_symmetric=" << (profile.suggest_symmetric ? 1 : 0) << "\n";
    out << "suggest_method=" << method_name(profile.suggest_method) << "\n";
    out << "suggest_sparse=" << (profile.suggest_use_sparse ? 1 : 0) << "\n";
    out << "suggest_krylov=" << (profile.suggest_use_krylov ? 1 : 0) << "\n";
    return true;
}

std::string classify_mobility(double largest_share, int num_components) {
    if (num_components <= 1) {
        return (largest_share >= 0.95) ? "high" : "moderate";
    }
    if (largest_share >= 0.9) {
        return "high";
    }
    if (largest_share >= 0.7) {
        return "moderate";
    }
    return "low";
}

MobilityProfile compute_mobility_profile(const std::vector<Eigen::VectorXi>& fes,
                                         int nobs_full,
                                         int num_singletons,
                                         bool drop_singletons,
                                         const std::vector<int>& sweep_order_used) {
    MobilityProfile profile;
    profile.format_version = 2;
    profile.profile_kind = "standard";
    profile.nobs = fes.empty() ? 0 : static_cast<int>(fes[0].size());
    profile.nobs_full = nobs_full;
    profile.num_singletons = num_singletons;
    profile.nfe = static_cast<int>(fes.size());
    profile.sweep_order = sweep_order_used;
    profile.signature = hash_fe_signature(fes, drop_singletons);
    profile.signature_sample = hash_fe_signature_sample(fes, drop_singletons);
    profile.has_signature_sample = true;

    std::vector<FeIndexerLite> indexers;
    indexers.reserve(fes.size());
    profile.fe_levels.reserve(fes.size());
    for (const auto& fe : fes) {
        indexers.push_back(build_indexer_lite(fe));
        profile.fe_levels.push_back(indexers.back().num_groups);
    }
    profile.signature_canon =
        hash_fe_signature_from_indexers(indexers, profile.nobs, drop_singletons);
    profile.signature_sample_canon =
        hash_fe_signature_sample_from_indexers(indexers, profile.nobs, drop_singletons);
    profile.has_signature_canon = true;
    profile.has_signature_sample_canon = true;

    if (fes.empty() || profile.nobs == 0) {
        profile.num_components = (profile.nobs > 0) ? 1 : 0;
        profile.largest_component = profile.nobs;
        profile.largest_component_share = (profile.nobs > 0) ? 1.0 : 0.0;
        profile.mobility_class = "none";
        profile.suggest_symmetric = false;
        profile.suggest_method = AbsorptionMethod::GaussSeidel;
        return profile;
    }

    if (fes.size() == 1) {
        const int groups = indexers[0].num_groups;
        std::vector<int> counts(static_cast<std::size_t>(groups), 0);
        for (int i = 0; i < profile.nobs; ++i) {
            const int g = indexers[0].group_ids[static_cast<std::size_t>(i)];
            if (g >= 0 && g < groups) {
                counts[static_cast<std::size_t>(g)] += 1;
            }
        }
        int largest = 0;
        for (int c : counts) {
            largest = std::max(largest, c);
        }
        profile.num_components = groups;
        profile.largest_component = largest;
        profile.largest_component_share =
            profile.nobs > 0 ? static_cast<double>(largest) / static_cast<double>(profile.nobs) : 0.0;
        profile.mobility_class = classify_mobility(profile.largest_component_share, profile.num_components);
        profile.suggest_symmetric = false;
        profile.suggest_method = AbsorptionMethod::GaussSeidel;
        return profile;
    }

    const int total_nodes = detail::sparse_rank::checked_component_node_count(
        detail::sparse_rank::level_sum(profile.fe_levels));
    std::int64_t offset = 0;
    std::vector<int> offsets;
    offsets.reserve(indexers.size());
    for (const auto& idx : indexers) {
        offsets.push_back(static_cast<int>(offset));
        offset += idx.num_groups;
    }
    if (total_nodes <= 0) {
        profile.num_components = 0;
        profile.largest_component = 0;
        profile.largest_component_share = 0.0;
        profile.mobility_class = "none";
        profile.suggest_symmetric = false;
        profile.suggest_method = AbsorptionMethod::GaussSeidel;
        return profile;
    }

    UnionFind uf(total_nodes);
    for (int i = 0; i < profile.nobs; ++i) {
        const int root0 = offsets[0] + indexers[0].group_ids[static_cast<std::size_t>(i)];
        for (std::size_t d = 1; d < indexers.size(); ++d) {
            const int node = offsets[d] + indexers[d].group_ids[static_cast<std::size_t>(i)];
            uf.unite(root0, node);
        }
    }

    std::vector<int> counts(static_cast<std::size_t>(total_nodes), 0);
    for (int i = 0; i < profile.nobs; ++i) {
        const int root =
            uf.find(offsets[0] + indexers[0].group_ids[static_cast<std::size_t>(i)]);
        counts[static_cast<std::size_t>(root)] += 1;
    }

    int num_components = 0;
    int largest = 0;
    for (int c : counts) {
        if (c > 0) {
            ++num_components;
            largest = std::max(largest, c);
        }
    }

    profile.num_components = num_components;
    profile.largest_component = largest;
    profile.largest_component_share =
        profile.nobs > 0 ? static_cast<double>(largest) / static_cast<double>(profile.nobs) : 0.0;
    profile.mobility_class = classify_mobility(profile.largest_component_share, profile.num_components);
    profile.suggest_symmetric =
        (profile.nfe >= 2) && (profile.largest_component_share < 0.9 || profile.num_components > 1);
    profile.suggest_method = profile.suggest_symmetric ? AbsorptionMethod::SymmetricGaussSeidel
                                                       : AbsorptionMethod::GaussSeidel;
    return profile;
}

MobilityHint build_mobility_hint(const MobilityProfile& profile) {
    MobilityHint hint;
    hint.sweep_order = profile.sweep_order;
    if (profile.suggest_method != AbsorptionMethod::Auto) {
        hint.preferred_method = profile.suggest_method;
        hint.has_method = true;
        if (profile.suggest_method == AbsorptionMethod::SymmetricGaussSeidel) {
            hint.force_symmetric = true;
        }
    }
    hint.use_sparse = profile.suggest_use_sparse;
    hint.use_krylov = profile.suggest_use_krylov;
    return hint;
}

MobilityHint build_standard_mobility_hint(const MobilityProfile& profile) {
    MobilityHint hint = build_mobility_hint(profile);
    // Before v2, the standard-profile parser recognized only the three sweep
    // methods. Keep that behavior until standard profiles have their own
    // backend/RHS/thread-context signature. The extended parser is needed for
    // exact-context group/individual profiles, but must not widen the standard
    // profile's authority.
    if (hint.has_method &&
        hint.preferred_method != AbsorptionMethod::GaussSeidel &&
        hint.preferred_method != AbsorptionMethod::SymmetricGaussSeidel &&
        hint.preferred_method != AbsorptionMethod::Jacobi) {
        hint.preferred_method = AbsorptionMethod::Auto;
        hint.has_method = false;
        hint.force_symmetric = false;
    }
    return hint;
}

int count_bipartite_components_impl(const Eigen::VectorXi& base_raw,
                                    const Eigen::VectorXi& other_raw,
                                    const FeLookup& base,
                                    const FeLookup& other,
                                    Eigen::VectorXi* edge_components,
                                    FeComponentStats* component_stats,
                                    const Eigen::VectorXd* weights) {
    if (base.num_groups <= 0 || other.num_groups <= 0) {
        return 0;
    }
    if (base_raw.size() != other_raw.size()) {
        throw std::runtime_error("Bipartite FE vectors must have the same length");
    }
    if (weights != nullptr && weights->size() != base_raw.size()) {
        throw std::runtime_error(
            "Bipartite component weights must match the FE vectors");
    }
    if ((base.mode == FeLookupMode::Rows &&
         base.row_codes.size() != static_cast<std::size_t>(base_raw.size())) ||
        (other.mode == FeLookupMode::Rows &&
         other.row_codes.size() != static_cast<std::size_t>(other_raw.size()))) {
        throw std::logic_error("A row-coded FE lookup is read on another vector");
    }
    if (component_stats != nullptr) {
        *component_stats = FeComponentStats{};
    }
    const auto components_t0 = std::chrono::steady_clock::now();
    // Round 11 (E3): the sum of the levels of the pair in 64 bits; a pair above
    // INT_MAX nodes cannot be numbered by this union-find, and is refused.
    const std::int64_t wide_nodes = detail::sparse_rank::pair_node_count(base.num_groups, other.num_groups);
    if (wide_nodes > static_cast<std::int64_t>(std::numeric_limits<int>::max())) {
        throw std::length_error("xhdfe: the levels of a pair of absorbed effects exceed the range of int");
    }
    const int total_nodes = static_cast<int>(wide_nodes);
    UnionFind uf(total_nodes);
    // The components depend on the set of pairs of levels, not on the rows
    // that carry them nor on their order. When one bit per pair fits, the
    // rows mark their pair and the unions run over the marked pairs. Rows
    // lookups (phase 1 of the Stata-path plan) take this path too: they carry
    // the numbering of the Sparse ones, and neither the components, nor their
    // labels (the order of the smallest node of each, below), nor the
    // first-pair statistics depend on the order of the unions.
    bool united = false;
#ifdef HDFE_USE_OPENMP
    {
        const long long cells = static_cast<long long>(base.num_groups) *
                                static_cast<long long>(other.num_groups);
        constexpr long long kMaxCells = 1LL << 28;
        constexpr int kMinRows = 1048576;
        const int rows = static_cast<int>(base_raw.size());
        if (cells <= kMaxCells && rows >= kMinRows &&
            base.mode != FeLookupMode::Sparse &&
            other.mode != FeLookupMode::Sparse && !omp_in_parallel()) {
            const std::size_t words = static_cast<std::size_t>((cells + 63) / 64);
            const std::unique_ptr<std::atomic<std::uint64_t>[]> marks(
                new std::atomic<std::uint64_t>[words]);
            const int other_groups = other.num_groups;
            auto level = [](const FeLookup& lookup, int raw, int row) {
                if (lookup.mode == FeLookupMode::Rows) {
                    return lookup.row_codes[static_cast<std::size_t>(row)];
                }
                const int index = raw - lookup.min_id;
                if (lookup.mode == FeLookupMode::Dense) {
                    return index >= 0 && index < lookup.num_groups ? index : -1;
                }
                return index >= 0 &&
                               index < static_cast<int>(lookup.dense_map.size())
                           ? lookup.dense_map[static_cast<std::size_t>(index)]
                           : -1;
            };
            bool valid = true;
#pragma omp parallel
            {
#pragma omp for schedule(static)
                for (std::ptrdiff_t w = 0; w < static_cast<std::ptrdiff_t>(words); ++w) {
                    marks[static_cast<std::size_t>(w)].store(
                        0, std::memory_order_relaxed);
                }
#pragma omp for schedule(static) reduction(&& : valid)
                for (int i = 0; i < rows; ++i) {
                    const int a = level(base, base_raw(i), i);
                    const int b = level(other, other_raw(i), i);
                    if (a < 0 || b < 0) {
                        valid = false;
                        continue;
                    }
                    const std::size_t cell =
                        static_cast<std::size_t>(a) *
                            static_cast<std::size_t>(other_groups) +
                        static_cast<std::size_t>(b);
                    const std::uint64_t bit = std::uint64_t{1} << (cell & 63U);
                    std::atomic<std::uint64_t>& word = marks[cell >> 6U];
                    if (!(word.load(std::memory_order_relaxed) & bit)) {
                        word.fetch_or(bit, std::memory_order_relaxed);
                    }
                }
            }
            if (valid) {
                for (std::size_t w = 0; w < words; ++w) {
                    std::uint64_t pending =
                        marks[w].load(std::memory_order_relaxed);
                    while (pending != 0) {
                        const int offset = __builtin_ctzll(pending);
                        pending &= pending - 1U;
                        const std::size_t cell = (w << 6U) +
                                                 static_cast<std::size_t>(offset);
                        const int a = static_cast<int>(
                            cell / static_cast<std::size_t>(other_groups));
                        const int b = static_cast<int>(
                            cell % static_cast<std::size_t>(other_groups));
                        uf.unite(a, base.num_groups + b);
                    }
                }
                united = true;
            }
        }
    }
#endif
    if (!united) {
        // A row that repeats the pair of the row before it adds no edge; in
        // a panel sorted by unit that is most rows.
        int previous_a = std::numeric_limits<int>::min();
        int previous_b = std::numeric_limits<int>::min();
        for (int i = 0; i < base_raw.size(); ++i) {
            const int a = base.at(i, base_raw(i));
            const int b = other.at(i, other_raw(i));
            if (a == previous_a && b == previous_b) {
                continue;
            }
            previous_a = a;
            previous_b = b;
            uf.unite(a, base.num_groups + b);
        }
    }
    if (detail::sparse_rank::profile_enabled()) {
        auto mode_name = [](FeLookupMode mode) {
            switch (mode) {
                case FeLookupMode::Dense: return "dense";
                case FeLookupMode::DenseMap: return "densemap";
                case FeLookupMode::Rows: return "rows";
                case FeLookupMode::Sparse:
                default: return "sparse";
            }
        };
        detail::sparse_rank::components_line(
            united ? "marking" : "serial", mode_name(base.mode), mode_name(other.mode),
            static_cast<long long>(base_raw.size()),
            static_cast<long long>(base.num_groups) * static_cast<long long>(other.num_groups),
            components_t0);
    }

    if (edge_components == nullptr && component_stats == nullptr) {
        int components = 0;
        for (int node = 0; node < total_nodes; ++node) {
            if (uf.find(node) == node) {
                ++components;
            }
        }
        return components;
    }

    std::vector<int> root_to_component(
        static_cast<std::size_t>(total_nodes), -1);
    int components = 0;
    for (int node = 0; node < total_nodes; ++node) {
        const int root = uf.find(node);
        if (root_to_component[static_cast<std::size_t>(root)] < 0) {
            root_to_component[static_cast<std::size_t>(root)] = components++;
        }
    }

    std::vector<long long> counts;
    std::vector<long double> weight_sums;
    long double total_weight = 0.0L;
    if (component_stats != nullptr) {
        counts.assign(static_cast<std::size_t>(components), 0);
        if (weights != nullptr) {
            weight_sums.assign(
                static_cast<std::size_t>(components), 0.0L);
        }
    }
    if (edge_components != nullptr) {
        edge_components->resize(base_raw.size());
    }
    for (int i = 0; i < base_raw.size(); ++i) {
        const int root = uf.find(base.at(i, base_raw(i)));
        const int component =
            root_to_component[static_cast<std::size_t>(root)];
        if (edge_components != nullptr) {
            (*edge_components)(i) =
                component + 1;  // 1-based, like Stata's groupvar()
        }
        if (component_stats != nullptr) {
            const std::size_t index = static_cast<std::size_t>(component);
            counts[index] += 1;
            if (weights != nullptr) {
                const double weight = (*weights)(i);
                if (!(weight > 0.0) || !(weight < 1e300)) {
                    throw std::runtime_error(
                        "Bipartite component weights must be finite and "
                        "positive");
                }
                weight_sums[index] += static_cast<long double>(weight);
                total_weight += static_cast<long double>(weight);
            }
        }
    }
    if (component_stats != nullptr) {
        component_stats->num_components = components;
        long double largest_weight = 0.0L;
        for (std::size_t c = 0; c < counts.size(); ++c) {
            component_stats->largest_component_n_obs =
                std::max(
                    component_stats->largest_component_n_obs, counts[c]);
            if (weights != nullptr) {
                largest_weight = std::max(
                    largest_weight, weight_sums[c]);
            }
        }
        component_stats->largest_component_obs_share =
            static_cast<double>(
                component_stats->largest_component_n_obs) /
            static_cast<double>(base_raw.size());
        component_stats->largest_component_weight_share =
            weights == nullptr
                ? component_stats->largest_component_obs_share
                : static_cast<double>(largest_weight / total_weight);
    }
    return components;
}

// The components of a pair of effects (count_bipartite_components_impl()).
// Under XHDFE_SPARSE_RANK_VERIFY=1 (phase 1 tests), a pair with a Rows lookup is
// counted again with today's serial Sparse lookups on the serial path, and the
// count, the labels and the first-pair statistics must agree bit for bit.
int count_bipartite_components(const Eigen::VectorXi& base_raw,
                               const Eigen::VectorXi& other_raw,
                               const FeLookup& base,
                               const FeLookup& other,
                               Eigen::VectorXi* edge_components,
                               FeComponentStats* component_stats = nullptr,
                               const Eigen::VectorXd* weights = nullptr) {
    const int components = count_bipartite_components_impl(
        base_raw, other_raw, base, other, edge_components, component_stats, weights);
    if (!detail::sparse_rank::verify_enabled() ||
        (base.mode != FeLookupMode::Rows && other.mode != FeLookupMode::Rows)) {
        return components;
    }
    FeLookup base_sparse;
    FeLookup other_sparse;
    const FeLookup* base_ref = &base;
    const FeLookup* other_ref = &other;
    if (base.mode == FeLookupMode::Rows) {
        base_sparse = build_lookup_compact(base_raw, -1);
        base_ref = &base_sparse;
    }
    if (other.mode == FeLookupMode::Rows) {
        other_sparse = build_lookup_compact(other_raw, -1);
        other_ref = &other_sparse;
    }
    Eigen::VectorXi labels;
    FeComponentStats stats;
    const int expected = count_bipartite_components_impl(
        base_raw, other_raw, *base_ref, *other_ref,
        edge_components != nullptr ? &labels : nullptr,
        component_stats != nullptr ? &stats : nullptr, weights);
    detail::sparse_rank::verify_check(expected == components, "components", "count");
    if (edge_components != nullptr) {
        detail::sparse_rank::verify_check(
            labels.size() == edge_components->size() &&
                (labels.array() == edge_components->array()).all(),
            "components", "labels");
    }
    if (component_stats != nullptr) {
        const auto same_bits = [](double a, double b) {
            return std::memcmp(&a, &b, sizeof(double)) == 0;
        };
        detail::sparse_rank::verify_check(
            stats.num_components == component_stats->num_components &&
                stats.largest_component_n_obs == component_stats->largest_component_n_obs &&
                same_bits(stats.largest_component_obs_share,
                          component_stats->largest_component_obs_share) &&
                same_bits(stats.largest_component_weight_share,
                          component_stats->largest_component_weight_share),
            "components", "first_pair_statistics");
    }
    detail::sparse_rank::verify_ok("components");
    return components;
}

// The hash branch of fe_is_function_of_refined_fe(): every refined id meets a
// single coarse id.
bool refined_function_by_hash(const Eigen::VectorXi& coarse, const Eigen::VectorXi& refined) {
    const int n = coarse.size();
    std::unordered_map<int, int> mapping;
    mapping.reserve(static_cast<std::size_t>(n));
    for (int i = 0; i < n; ++i) {
        const int refined_id = refined(i);
        const int coarse_id = coarse(i);
        auto it = mapping.find(refined_id);
        if (it == mapping.end()) {
            mapping.emplace(refined_id, coarse_id);
        } else if (it->second != coarse_id) {
            return false;
        }
    }
    return true;
}

// refined_lookup, when given, is the lookup of `refined`. A Rows lookup
// (phase 1 of the Stata-path plan) only arises where the branch below would
// hash (its range is not compact), and its per-row codes are an injective
// coding of the refined levels, so the answer is the one of the hash.
bool fe_is_function_of_refined_fe(const Eigen::VectorXi& coarse,
                                  const Eigen::VectorXi& refined,
                                  const FeLookup* refined_lookup = nullptr) {
    if (coarse.size() != refined.size()) {
        return false;
    }
    const int n = coarse.size();
    if (n == 0) {
        return true;
    }
    if (refined_lookup != nullptr && refined_lookup->mode == FeLookupMode::Rows &&
        refined_lookup->row_codes.size() == static_cast<std::size_t>(n)) {
        const int levels = refined_lookup->num_groups;
        std::vector<int> mapping(static_cast<std::size_t>(levels), 0);
        std::vector<uint8_t> seen(static_cast<std::size_t>(levels), 0);
        bool function = true;
        for (int i = 0; i < n && function; ++i) {
            const std::size_t idx =
                static_cast<std::size_t>(refined_lookup->row_codes[static_cast<std::size_t>(i)]);
            const int coarse_id = coarse(i);
            if (!seen[idx]) {
                seen[idx] = 1;
                mapping[idx] = coarse_id;
            } else if (mapping[idx] != coarse_id) {
                function = false;
            }
        }
        if (detail::sparse_rank::verify_enabled()) {
            detail::sparse_rank::verify_check(
                refined_function_by_hash(coarse, refined) == function, "refined", "answer");
            detail::sparse_rank::verify_ok("refined");
        }
        return function;
    }

    int min_id = refined(0);
    int max_id = refined(0);
    for (int i = 1; i < n; ++i) {
        const int v = refined(i);
        min_id = std::min(min_id, v);
        max_id = std::max(max_id, v);
    }

    const long long range_ll =
        static_cast<long long>(max_id) - static_cast<long long>(min_id) + 1LL;
    constexpr long long kDenseRangeCap = 50000000LL;
    const bool dense_ok =
        min_id >= 0 && range_ll > 0 && range_ll <= kDenseRangeCap &&
        range_ll <= static_cast<long long>(n) * 2LL;
    if (dense_ok) {
        const int range = static_cast<int>(range_ll);
        std::vector<int> mapping(static_cast<std::size_t>(range), 0);
        std::vector<uint8_t> seen(static_cast<std::size_t>(range), 0);
        for (int i = 0; i < n; ++i) {
            const int idx = refined(i) - min_id;
            const int coarse_id = coarse(i);
            if (!seen[static_cast<std::size_t>(idx)]) {
                seen[static_cast<std::size_t>(idx)] = 1;
                mapping[static_cast<std::size_t>(idx)] = coarse_id;
            } else if (mapping[static_cast<std::size_t>(idx)] != coarse_id) {
                return false;
            }
        }
        return true;
    }

    return refined_function_by_hash(coarse, refined);
}

#ifdef HDFE_USE_OPENMP
// The root of x in a forest whose links always go to a smaller index, read
// while other threads link roots (team_unite). Halving is a plain store: it
// only ever moves a link of a node that is no longer a root to an ancestor of
// that node, so it neither creates a cycle nor undoes a link.
int team_root(std::atomic<int>* up, int x) {
    for (;;) {
        const int p = up[x].load(std::memory_order_relaxed);
        if (p == x) {
            return x;
        }
        const int gp = up[p].load(std::memory_order_relaxed);
        if (gp != p) {
            up[x].store(gp, std::memory_order_relaxed);
        }
        x = gp;
    }
}

// Unites the trees of x and y; true when it linked two roots. A root is
// linked under the smaller root by a compare-and-swap that fails only if
// another thread linked it first, and then the roots are read again.
bool team_unite(std::atomic<int>* up, int x, int y) {
    for (;;) {
        x = team_root(up, x);
        y = team_root(up, y);
        if (x == y) {
            return false;
        }
        if (x < y) {
            std::swap(x, y);
        }
        int expected = x;
        if (up[x].compare_exchange_strong(expected, y, std::memory_order_relaxed)) {
            return true;
        }
    }
}

// XHDFE_TEST_DOF_TEAM_ALLOC_FAIL=k (tests only; read once per process; off when
// unset or not an integer from 1 to 1000, or pairs): the k-th allocation of
// every team pass of the components (count_pairs_on_team) throws
// std::bad_alloc, so that a test sees each allocation of the pass fall back to
// today's loop; pairs (package E, E2) is k = 1 and dof_pairs_fail_test().
int dof_team_alloc_fail_at() {
    static const int at = [] {
        const char* e = std::getenv("XHDFE_TEST_DOF_TEAM_ALLOC_FAIL");
        if (e == nullptr || e[0] == '\0') {
            return 0;
        }
        if (std::strcmp(e, "pairs") == 0) {
            return 1;  // package E, E2: see dof_pairs_fail_test()
        }
        char* end = nullptr;
        const long value = std::strtol(e, &end, 10);
        return end != e && *end == '\0' && value >= 1 && value <= 1000 ? static_cast<int>(value) : 0;
    }();
    return at;
}

// XHDFE_TEST_DOF_TEAM_ALLOC_FAIL=pairs (tests only, package E, E2; read once per
// process): the team pass falls back at its first allocation, and in the loop
// that then counts the pairs on the team the thread of the second pair throws
// std::bad_alloc, as a UnionFind that cannot get its memory would there.
bool dof_pairs_fail_test() {
    static const bool on = [] {
        const char* e = std::getenv("XHDFE_TEST_DOF_TEAM_ALLOC_FAIL");
        return e != nullptr && std::strcmp(e, "pairs") == 0;
    }();
    return on;
}

// The pairwise loop of compute_fe_dof_reghdfe() with two or more pairs, on the
// fit's team (package A, item A3, 22nov2026). That loop gives each pair to one
// thread of its region, where count_bipartite_components_impl() can only scan
// the rows serially (omp_in_parallel()): on simulated_panel three pairs of
// 173 M rows took 2.0 to 2.5 s each, side by side. Here every thread scans its
// blocks of rows for every pair. Each level of the larger effect of a pair
// keeps the first level of the smaller effect that a row gives it (a
// compare-and-swap from -1), and every later partner is united with that one
// in a lock-free union-find over the smaller effect (team_unite). The pair
// then has as many components as the smaller effect has roots plus the levels
// of the larger effect that no row carries: the components of the graph that
// today's loop builds, which do not depend on the order of the unions. A pair
// whose count has fallen to 1 cannot change any more, and the rest of its rows
// are skipped. Integer results, whatever the team and the schedule.
// Memory: 4 bytes per level of the two effects of every pair, at most 8 bytes
// per row in all, plus the plan, one counter per pair and thread, and the
// counts. Pairs: any sequence of elements with members a and b (the caller's
// own), so that the pass copies nothing before it may fall back.
// Returns false, with `groups` untouched, wherever today's loop is to count
// instead: an active parallel region; fewer than two pairs or threads; fewer
// than 2^20 rows (the threshold of the marking path); a Sparse lookup; a lookup
// or vector of another length; an empty effect; more than 8 bytes per row of
// state; any failed allocation of the pass (every one is inside its try, the
// counts included, and they are published by a swap at the end); or a row whose
// level a lookup does not know, among the rows the pass reads. It does not read
// every row: once a pair's count is 1, the rest of that pair's rows are
// skipped, so such a row there goes unseen. The pass rests on its caller for
// that: compute_fe_dof_reghdfe() builds each lookup from the vector itself, or
// takes a Rows lookup of the same rows, so every row's level is known. (Where
// it replaces today's loop, on such a row that loop would: with a DenseMap
// lookup, compute raw - min_id before its range test (an int that overflows
// for extreme identifiers) and otherwise throw "FE lookup missing key" inside
// its parallel region; with a Dense lookup, take raw - min_id without a range
// check, an index outside the lookup; with a Rows lookup, read the row's own
// code, as the pass does.) Like today's loop, the region reports to no observer, so
// e(threads_used) and e(parallel_workers_active) are what the release publishes.
template <typename Pairs>
bool count_pairs_on_team(const std::vector<Eigen::VectorXi>& fes,
                         const std::vector<std::reference_wrapper<const FeLookup>>& lookups,
                         const Pairs& pairs,
                         int threads,
                         std::vector<int>& groups) {
    constexpr int kMinRows = 1048576;
    constexpr int kBlockRows = 16384;
    // Round 11 (E3): the count of pairs is an int index only where it fits one;
    // above INT_MAX the pass declines (today's loop counts the pairs).
    if (!detail::sparse_rank::pair_count_fits_int(pairs.size())) {
        return false;
    }
    const int npairs = static_cast<int>(pairs.size());
    if (npairs < 2 || threads < 2 || fes.empty() || omp_in_parallel()) {
        return false;
    }
    const int n = static_cast<int>(fes[0].size());
    if (n < kMinRows) {
        return false;
    }
    auto lookup_of = [&lookups](int d) -> const FeLookup& {
        return lookups[static_cast<std::size_t>(d)].get();
    };
    for (const auto& pair : pairs) {
        for (const int d : {pair.a, pair.b}) {
            const FeLookup& lookup = lookup_of(d);
            if (fes[static_cast<std::size_t>(d)].size() != n || lookup.num_groups <= 0 ||
                lookup.mode == FeLookupMode::Sparse ||
                (lookup.mode == FeLookupMode::Rows &&
                 lookup.row_codes.size() != static_cast<std::size_t>(n))) {
                return false;
            }
        }
    }
    int allocation = 0;
    const int fail_at = dof_team_alloc_fail_at();
    const auto allocating = [&allocation, fail_at]() {
        if (++allocation == fail_at) {
            throw std::bad_alloc();
        }
    };
    try {
        struct Plan {
            int big = 0;
            int small = 0;
            int big_levels = 0;
            int small_levels = 0;
            std::size_t first = 0;   // offset of the larger effect's partners
            std::size_t up = 0;      // offset of the smaller effect's forest
        };
        allocating();
        std::vector<Plan> plan(static_cast<std::size_t>(npairs));
        std::size_t firsts = 0;
        std::size_t ups = 0;
        for (int k = 0; k < npairs; ++k) {
            const int a = pairs[static_cast<std::size_t>(k)].a;
            const int b = pairs[static_cast<std::size_t>(k)].b;
            Plan& q = plan[static_cast<std::size_t>(k)];
            const bool a_big = lookup_of(a).num_groups >= lookup_of(b).num_groups;
            q.big = a_big ? a : b;
            q.small = a_big ? b : a;
            q.big_levels = lookup_of(q.big).num_groups;
            q.small_levels = lookup_of(q.small).num_groups;
            if (static_cast<long long>(q.big_levels) + q.small_levels >
                static_cast<long long>(std::numeric_limits<int>::max())) {
                return false;
            }
            q.first = firsts;
            q.up = ups;
            firsts += static_cast<std::size_t>(q.big_levels);
            ups += static_cast<std::size_t>(q.small_levels);
        }
        if (firsts + ups > 2U * static_cast<std::size_t>(n)) {
            return false;
        }
        allocating();
        std::unique_ptr<std::atomic<int>[]> first(new std::atomic<int>[firsts]);
        allocating();
        std::unique_ptr<std::atomic<int>[]> up(new std::atomic<int>[ups]);
        allocating();
        std::unique_ptr<std::atomic<long long>[]> open(
            new std::atomic<long long>[static_cast<std::size_t>(npairs)]);
        allocating();
        std::unique_ptr<std::atomic<int>[]> done(new std::atomic<int>[static_cast<std::size_t>(npairs)]);
        allocating();
        std::vector<long long> partial(static_cast<std::size_t>(threads) * static_cast<std::size_t>(npairs), 0);
        allocating();
        std::vector<int> counts(static_cast<std::size_t>(npairs), 0);
        for (int k = 0; k < npairs; ++k) {
            const Plan& q = plan[static_cast<std::size_t>(k)];
            open[static_cast<std::size_t>(k)].store(
                static_cast<long long>(q.big_levels) + q.small_levels, std::memory_order_relaxed);
            done[static_cast<std::size_t>(k)].store(0, std::memory_order_relaxed);
        }
        std::atomic<int> unknown{0};
        // The code of row `row` (raw = its identifier), or -1 when the lookup has none.
        const auto level = [](const FeLookup& lookup, const int* raw, int row) {
            if (lookup.mode == FeLookupMode::Rows) {
                return lookup.row_codes[static_cast<std::size_t>(row)];
            }
            const long long index =
                static_cast<long long>(raw[row]) - static_cast<long long>(lookup.min_id);
            if (lookup.mode == FeLookupMode::Dense) {
                return index >= 0 && index < lookup.num_groups ? static_cast<int>(index) : -1;
            }
            return index >= 0 && index < static_cast<long long>(lookup.dense_map.size())
                       ? lookup.dense_map[static_cast<std::size_t>(index)]
                       : -1;
        };
        const int blocks = detail::sparse_rank::row_block_count(n, kBlockRows);
        const auto t0 = std::chrono::steady_clock::now();
#pragma omp parallel num_threads(threads)
        {
#pragma omp for schedule(static)
            for (std::ptrdiff_t x = 0; x < static_cast<std::ptrdiff_t>(firsts); ++x) {
                first[static_cast<std::size_t>(x)].store(-1, std::memory_order_relaxed);
            }
            for (int k = 0; k < npairs; ++k) {
                const Plan& q = plan[static_cast<std::size_t>(k)];
#pragma omp for schedule(static) nowait
                for (int x = 0; x < q.small_levels; ++x) {
                    up[q.up + static_cast<std::size_t>(x)].store(x, std::memory_order_relaxed);
                }
            }
#pragma omp barrier
#pragma omp for schedule(static)
            for (int block = 0; block < blocks; ++block) {
                if (unknown.load(std::memory_order_relaxed) != 0) {
                    continue;
                }
                int i0 = 0;
                int i1 = 0;
                detail::sparse_rank::row_block_range(block, n, kBlockRows, &i0, &i1);
                for (int k = 0; k < npairs; ++k) {
                    if (done[static_cast<std::size_t>(k)].load(std::memory_order_relaxed) != 0) {
                        continue;
                    }
                    const Plan& q = plan[static_cast<std::size_t>(k)];
                    const FeLookup& big = lookup_of(q.big);
                    const FeLookup& small = lookup_of(q.small);
                    const int* big_raw = fes[static_cast<std::size_t>(q.big)].data();
                    const int* small_raw = fes[static_cast<std::size_t>(q.small)].data();
                    std::atomic<int>* partner = first.get() + q.first;
                    std::atomic<int>* forest = up.get() + q.up;
                    int last_a = -1;
                    int last_b = -1;
                    long long closed = 0;
                    for (int i = i0; i < i1; ++i) {
                        const int a = level(big, big_raw, i);
                        const int b = level(small, small_raw, i);
                        if (a < 0 || b < 0) {
                            unknown.store(1, std::memory_order_relaxed);
                            break;
                        }
                        if (a == last_a && b == last_b) {
                            continue;
                        }
                        last_a = a;
                        last_b = b;
                        int r = partner[a].load(std::memory_order_relaxed);
                        if (r == b) {
                            continue;
                        }
                        if (r < 0) {
                            if (partner[a].compare_exchange_strong(r, b, std::memory_order_relaxed)) {
                                ++closed;
                                continue;
                            }
                            if (r == b) {
                                continue;
                            }
                        }
                        if (team_unite(forest, r, b)) {
                            ++closed;
                        }
                    }
                    // The count is roots plus unseen levels; once it is 1 it is final.
                    if (closed != 0 &&
                        open[static_cast<std::size_t>(k)].fetch_sub(closed, std::memory_order_relaxed) -
                                closed == 1) {
                        done[static_cast<std::size_t>(k)].store(1, std::memory_order_relaxed);
                    }
                }
            }
            long long* mine = partial.data() +
                              static_cast<std::size_t>(omp_get_thread_num()) * static_cast<std::size_t>(npairs);
            for (int k = 0; k < npairs; ++k) {
                const Plan& q = plan[static_cast<std::size_t>(k)];
#pragma omp for schedule(static) nowait
                for (int x = 0; x < q.small_levels; ++x) {
                    mine[k] += up[q.up + static_cast<std::size_t>(x)].load(std::memory_order_relaxed) == x;
                }
#pragma omp for schedule(static) nowait
                for (int x = 0; x < q.big_levels; ++x) {
                    mine[k] += first[q.first + static_cast<std::size_t>(x)].load(std::memory_order_relaxed) < 0;
                }
            }
        }
        if (unknown.load(std::memory_order_relaxed) != 0) {
            return false;
        }
        for (int k = 0; k < npairs; ++k) {
            long long components = 0;
            for (int t = 0; t < threads; ++t) {
                components += partial[static_cast<std::size_t>(t) * static_cast<std::size_t>(npairs) +
                                      static_cast<std::size_t>(k)];
            }
            counts[static_cast<std::size_t>(k)] = static_cast<int>(components);
        }
        const auto t1 = std::chrono::steady_clock::now();
        // The recount first and the profile after, so that the components_pass
        // line is written only when nothing but the swap is left: it marks a pass
        // that counted.
        // XHDFE_SPARSE_RANK_VERIFY: every pair counted again by today's function,
        // outside the region, and the two counts must agree (a difference throws,
        // and is not a fallback).
        if (detail::sparse_rank::verify_enabled()) {
            for (int k = 0; k < npairs; ++k) {
                const int a = pairs[static_cast<std::size_t>(k)].a;
                const int b = pairs[static_cast<std::size_t>(k)].b;
                const int today = count_bipartite_components(
                    fes[static_cast<std::size_t>(a)], fes[static_cast<std::size_t>(b)],
                    lookup_of(a), lookup_of(b), nullptr);
                detail::sparse_rank::verify_check(today == counts[static_cast<std::size_t>(k)],
                                                  "components", "team_count");
            }
            detail::sparse_rank::verify_ok("components");
        }
        if (detail::sparse_rank::profile_enabled()) {
            auto mode_name = [](FeLookupMode mode) {
                switch (mode) {
                    case FeLookupMode::Dense: return "dense";
                    case FeLookupMode::DenseMap: return "densemap";
                    case FeLookupMode::Rows: return "rows";
                    case FeLookupMode::Sparse:
                    default: return "sparse";
                }
            };
            for (const auto& pair : pairs) {
                detail::sparse_rank::components_team_line(
                    mode_name(lookup_of(pair.a).mode), mode_name(lookup_of(pair.b).mode),
                    static_cast<long long>(n),
                    static_cast<long long>(lookup_of(pair.a).num_groups) *
                        static_cast<long long>(lookup_of(pair.b).num_groups));
            }
            detail::sparse_rank::components_pass_line(npairs, static_cast<long long>(n), t0, t1);
        }
        groups.swap(counts);
        return true;
    } catch (const std::bad_alloc&) {
        return false;
    }
}
#endif

// reuse (phase 1 of the Stata-path plan): lookups of the caller for the same
// vectors, position by position. Only Rows lookups are taken from it; they do
// not depend on fe_levels, so a rebuild would give the same codes. Every other
// lookup is built here as before.
FeDofInfo compute_fe_dof_reghdfe(const std::vector<Eigen::VectorXi>& fes,
                                 const std::vector<int>& fe_levels,
                                 DofAdjustmentMethod method,
                                 Eigen::VectorXi* groupvar,
                                 int threads,
                                 FeComponentStats* first_pair_stats = nullptr,
                                 const Eigen::VectorXd* weights = nullptr,
                                 bool explicit_threads = false,
                                 const std::vector<const FeLookup*>* reuse = nullptr) {
    FeDofInfo info;
    if (first_pair_stats != nullptr) {
        *first_pair_stats = FeComponentStats{};
    }
    if (fes.empty()) {
        return info;
    }
    const int dims = static_cast<int>(fes.size());
    info.levels = fe_levels;
    info.redundant.resize(static_cast<std::size_t>(dims), 0);
    info.num_coefs.resize(static_cast<std::size_t>(dims), 0);
    info.inexact.resize(static_cast<std::size_t>(dims), 0);

    auto dof_t0 = std::chrono::steady_clock::now();
    std::vector<FeLookup> owned_lookups(static_cast<std::size_t>(dims));
    std::vector<std::reference_wrapper<const FeLookup>> lookups;
    lookups.reserve(static_cast<std::size_t>(dims));
    for (int d = 0; d < dims; ++d) {
        const FeLookup* reused =
            reuse != nullptr && reuse->size() == static_cast<std::size_t>(dims)
                ? (*reuse)[static_cast<std::size_t>(d)]
                : nullptr;
        if (reused != nullptr && reused->mode == FeLookupMode::Rows) {
            lookups.push_back(std::cref(*reused));
            continue;
        }
        const int expected =
            (d < static_cast<int>(fe_levels.size())) ? fe_levels[static_cast<std::size_t>(d)] : -1;
        FeLookup& own = owned_lookups[static_cast<std::size_t>(d)];
#ifdef HDFE_USE_OPENMP
        own = build_lookup_compact_team(
            fes[static_cast<std::size_t>(d)], expected,
            std::max(1, threads), explicit_threads);
#else
        own = build_lookup_compact(fes[static_cast<std::size_t>(d)], expected);
#endif
        lookups.push_back(std::cref(own));
    }
    cpu_profile_log_elapsed("dof_lookups", dof_t0);
    dof_t0 = std::chrono::steady_clock::now();
    if (info.levels.size() != static_cast<std::size_t>(dims)) {
        info.levels.assign(static_cast<std::size_t>(dims), 0);
        for (int d = 0; d < dims; ++d) {
            info.levels[static_cast<std::size_t>(d)] =
                lookups[static_cast<std::size_t>(d)].get().num_groups;
        }
    }

    if (groupvar) {
        groupvar->resize(0);
    }
    if ((method == DofAdjustmentMethod::All || method == DofAdjustmentMethod::FirstPair ||
         method == DofAdjustmentMethod::Pairwise) &&
        dims < 2 && groupvar) {
        groupvar->resize(0);
    }
    if (groupvar && method == DofAdjustmentMethod::None) {
        throw std::runtime_error("groupvar() requires dofadjustments(all/firstpair/pairwise)");
    }

    if (method != DofAdjustmentMethod::None && dims >= 2) {
        std::vector<uint8_t> coarsened(static_cast<std::size_t>(dims), 0);
        bool any_coarsened = false;
        for (int d = 0; d < dims; ++d) {
            const int coarse_levels = info.levels[static_cast<std::size_t>(d)];
            for (int e = 0; e < dims; ++e) {
                if (d == e) {
                    continue;
                }
                const int refined_levels = info.levels[static_cast<std::size_t>(e)];
                if (refined_levels <= coarse_levels) {
                    continue;
                }
                if (fe_is_function_of_refined_fe(
                        fes[static_cast<std::size_t>(d)], fes[static_cast<std::size_t>(e)],
                        &lookups[static_cast<std::size_t>(e)].get())) {
                    coarsened[static_cast<std::size_t>(d)] = 1;
                    any_coarsened = true;
                    break;
                }
            }
        }

        if (any_coarsened) {
            std::vector<Eigen::VectorXi> effective_fes;
            std::vector<int> effective_levels;
            std::vector<int> effective_map;
            effective_fes.reserve(static_cast<std::size_t>(dims));
            effective_levels.reserve(static_cast<std::size_t>(dims));
            effective_map.reserve(static_cast<std::size_t>(dims));
            for (int d = 0; d < dims; ++d) {
                if (coarsened[static_cast<std::size_t>(d)]) {
                    continue;
                }
                effective_fes.push_back(fes[static_cast<std::size_t>(d)]);
                effective_levels.push_back(info.levels[static_cast<std::size_t>(d)]);
                effective_map.push_back(d);
            }

            if (!effective_fes.empty() && static_cast<int>(effective_fes.size()) < dims) {
                if ((groupvar != nullptr || first_pair_stats != nullptr) && dims >= 2) {
                    count_bipartite_components(
                        fes[0], fes[1], lookups[0], lookups[1], groupvar,
                        first_pair_stats, weights);
                }
                // The copies in effective_fes are the same vectors: their
                // Rows lookups are passed down instead of being built again.
                std::vector<const FeLookup*> effective_lookups;
                effective_lookups.reserve(effective_map.size());
                for (const int d : effective_map) {
                    effective_lookups.push_back(&lookups[static_cast<std::size_t>(d)].get());
                }
                FeDofInfo effective =
                    compute_fe_dof_reghdfe(effective_fes, effective_levels,
                                           method, nullptr, threads, nullptr,
                                           nullptr, explicit_threads, &effective_lookups);
                for (int d = 0; d < dims; ++d) {
                    if (coarsened[static_cast<std::size_t>(d)]) {
                        info.redundant[static_cast<std::size_t>(d)] =
                            info.levels[static_cast<std::size_t>(d)];
                        info.num_coefs[static_cast<std::size_t>(d)] = 0;
                        info.inexact[static_cast<std::size_t>(d)] = 0;
                    }
                }
                for (std::size_t pos = 0; pos < effective_map.size(); ++pos) {
                    const int orig = effective_map[pos];
                    info.redundant[static_cast<std::size_t>(orig)] = effective.redundant[pos];
                    info.num_coefs[static_cast<std::size_t>(orig)] = effective.num_coefs[pos];
                    info.inexact[static_cast<std::size_t>(orig)] = effective.inexact[pos];
                }

                info.df_a_levels = detail::sparse_rank::level_sum(info.levels);
                info.df_a_exact = detail::sparse_rank::level_sum(info.num_coefs);
                info.df_a = info.df_a_exact;
                return info;
            }
        }
    }

    cpu_profile_log_elapsed("dof_coarsening", dof_t0);
    dof_t0 = std::chrono::steady_clock::now();
    struct DofLap {
        std::chrono::steady_clock::time_point start;
        ~DofLap() { cpu_profile_log_elapsed("dof_components", start); }
    } dof_lap{dof_t0};
    if (method == DofAdjustmentMethod::None) {
        if (first_pair_stats != nullptr && dims >= 2) {
            count_bipartite_components(
                fes[0], fes[1], lookups[0], lookups[1], nullptr,
                first_pair_stats, weights);
        }
        for (int d = 0; d < dims; ++d) {
            info.redundant[static_cast<std::size_t>(d)] = 0;
            info.num_coefs[static_cast<std::size_t>(d)] = std::max(0, info.levels[static_cast<std::size_t>(d)]);
        }
    } else if (method == DofAdjustmentMethod::FirstPair) {
        info.redundant[0] = 0;
        info.num_coefs[0] = std::max(0, info.levels[0]);
        if (dims >= 2) {
            Eigen::VectorXi tmp;
            Eigen::VectorXi* out_ptr = groupvar ? &tmp : nullptr;
            const int mobility_groups =
                count_bipartite_components(
                    fes[0], fes[1], lookups[0], lookups[1], out_ptr,
                    first_pair_stats, weights);
            info.redundant[1] = mobility_groups;
            info.num_coefs[1] = std::max(0, info.levels[1] - mobility_groups);
            if (groupvar) {
                *groupvar = std::move(tmp);
            }
        }
        for (int d = 2; d < dims; ++d) {
            info.redundant[static_cast<std::size_t>(d)] = 0;
            info.num_coefs[static_cast<std::size_t>(d)] =
                std::max(0, info.levels[static_cast<std::size_t>(d)]);
        }
    } else {
        // Default: pairwise mobility-group checks (reghdfe "all" and "pairwise").
        info.redundant[0] = 0;
        info.num_coefs[0] = std::max(0, info.levels[0]);

        std::vector<std::vector<int>> pair_groups(
            static_cast<std::size_t>(dims), std::vector<int>(static_cast<std::size_t>(dims), 0));
        if (dims >= 2 && groupvar) {
            Eigen::VectorXi tmp;
            const int groups =
                count_bipartite_components(
                    fes[0], fes[1], lookups[0], lookups[1], &tmp,
                    first_pair_stats, weights);
            pair_groups[0][1] = groups;
            *groupvar = std::move(tmp);
        }

        struct PairIdx {
            int a = 0;
            int b = 0;
        };
        std::vector<PairIdx> pairs;
        pairs.reserve(detail::sparse_rank::effect_pair_count(dims));  // E3: widened before the product
        for (int a = 0; a < dims; ++a) {
            for (int b = a + 1; b < dims; ++b) {
                if (groupvar && a == 0 && b == 1) {
                    continue;
                }
                pairs.push_back({a, b});
            }
        }

        int use_threads = 1;
#ifdef HDFE_USE_OPENMP
        use_threads = std::max(1, threads);
#endif
        bool counted = false;
#ifdef HDFE_USE_OPENMP
        // Two or more pairs: one pass over the rows on the team
        // (count_pairs_on_team). Not when the first pair carries the
        // first-pair statistics, whose weighted sums follow the rows' order,
        // nor when today's function would reject the weights. Every lookup
        // above was built from its own vector or is a Rows lookup of the same
        // rows, so every row's level is known: the guarantee the pass rests on
        // for the rows it skips once a pair has closed.
        const bool stats_in_loop = first_pair_stats != nullptr && !pairs.empty() &&
                                   pairs.front().a == 0 && pairs.front().b == 1;
        if (pairs.size() > 1 && use_threads > 1 && !stats_in_loop &&
            (weights == nullptr || weights->size() == fes[0].size())) {
            std::vector<int> team_groups;
            if (count_pairs_on_team(fes, lookups, pairs, use_threads, team_groups)) {
                for (std::size_t idx = 0; idx < pairs.size(); ++idx) {
                    pair_groups[static_cast<std::size_t>(pairs[idx].a)]
                               [static_cast<std::size_t>(pairs[idx].b)] = team_groups[idx];
                }
                counted = true;
            }
        }
#endif
        // One pair alone keeps the team for its own rows.
        if (!counted && pairs.size() > 1 && use_threads > 1) {
            // Package E, E2 (23nov2026): an exception inside the region (a
            // UnionFind that cannot get its memory, a lookup that throws) is
            // caught in its thread; the pairs not yet started are skipped, the
            // region ends, and the first exception is rethrown here. No count of
            // the region is published: they go to region_groups first.
            std::vector<int> region_groups(pairs.size(), 0);
            std::exception_ptr region_error;
            std::atomic<bool> region_failed{false};
#ifdef HDFE_USE_OPENMP
            const bool fail_second_pair = dof_pairs_fail_test();
#pragma omp parallel for schedule(static) num_threads(use_threads)
#else
            constexpr bool fail_second_pair = false;
#endif
            for (std::size_t idx = 0; idx < pairs.size(); ++idx) {
                if (region_failed.load(std::memory_order_relaxed)) {
                    continue;
                }
                try {
                    const int a = pairs[idx].a;
                    const int b = pairs[idx].b;
                    if (fail_second_pair && idx == 1) {
                        throw std::bad_alloc();  // XHDFE_TEST_DOF_TEAM_ALLOC_FAIL=pairs
                    }
                    region_groups[idx] = count_bipartite_components(
                        fes[static_cast<std::size_t>(a)],
                        fes[static_cast<std::size_t>(b)],
                        lookups[static_cast<std::size_t>(a)],
                        lookups[static_cast<std::size_t>(b)],
                        nullptr,
                        (a == 0 && b == 1) ? first_pair_stats : nullptr,
                        (a == 0 && b == 1) ? weights : nullptr);
                } catch (...) {
#ifdef HDFE_USE_OPENMP
#pragma omp critical(xhdfe_dof_pairs_error)
#endif
                    {
                        if (!region_error) {
                            region_error = std::current_exception();
                        }
                    }
                    region_failed.store(true, std::memory_order_relaxed);
                }
            }
            if (region_error) {
                std::rethrow_exception(region_error);
            }
            for (std::size_t idx = 0; idx < pairs.size(); ++idx) {
                pair_groups[static_cast<std::size_t>(pairs[idx].a)]
                           [static_cast<std::size_t>(pairs[idx].b)] = region_groups[idx];
            }
            // XHDFE_SPARSE_RANK_VERIFY: a difference found inside the region.
            detail::sparse_rank::verify_rethrow();
        } else if (!counted) {
            for (const auto& pair : pairs) {
                const int groups = count_bipartite_components(
                    fes[static_cast<std::size_t>(pair.a)],
                    fes[static_cast<std::size_t>(pair.b)],
                    lookups[static_cast<std::size_t>(pair.a)],
                    lookups[static_cast<std::size_t>(pair.b)],
                    nullptr,
                    (pair.a == 0 && pair.b == 1)
                        ? first_pair_stats
                        : nullptr,
                    (pair.a == 0 && pair.b == 1) ? weights : nullptr);
                pair_groups[static_cast<std::size_t>(pair.a)][static_cast<std::size_t>(pair.b)] = groups;
            }
        }

        for (int d = 1; d < dims; ++d) {
            int max_groups = 0;
            for (int j = 0; j < d; ++j) {
                const int groups = pair_groups[static_cast<std::size_t>(j)][static_cast<std::size_t>(d)];
                max_groups = std::max(max_groups, groups);
            }
            info.redundant[static_cast<std::size_t>(d)] = max_groups;
            info.num_coefs[static_cast<std::size_t>(d)] =
                std::max(0, info.levels[static_cast<std::size_t>(d)] - max_groups);
        }
    }

    info.df_a_levels = detail::sparse_rank::level_sum(info.levels);
    info.df_a_exact = detail::sparse_rank::level_sum(info.num_coefs);
    info.df_a = info.df_a_exact;
    return info;
}

FeDofInfo compute_fe_dof_for_intercept_dims(
    const std::vector<Eigen::VectorXi>& fes,
    const std::vector<int>& fe_levels,
    DofAdjustmentMethod method,
    const std::vector<uint8_t>& slope_only_flags,
    Eigen::VectorXi* groupvar,
    int threads,
    FeComponentStats* first_pair_stats = nullptr,
    const Eigen::VectorXd* weights = nullptr,
    bool explicit_threads = false) {
    const std::size_t dims = fes.size();
    bool has_slope_only = false;
    for (std::size_t d = 0; d < dims && d < slope_only_flags.size(); ++d) {
        has_slope_only = has_slope_only || slope_only_flags[d] != 0;
    }
    if (!has_slope_only) {
        return compute_fe_dof_reghdfe(
            fes, fe_levels, method, groupvar, threads, first_pair_stats,
            weights, explicit_threads);
    }

    FeDofInfo info;
    info.levels = fe_levels;
    if (info.levels.size() < dims) {
        info.levels.resize(dims, 0);
    }
    info.redundant.assign(dims, 0);
    info.num_coefs.assign(dims, 0);
    info.inexact.assign(dims, 0);
    std::vector<Eigen::VectorXi> intercept_fes;
    std::vector<int> intercept_levels;
    std::vector<std::size_t> intercept_map;
    intercept_fes.reserve(dims);
    intercept_levels.reserve(dims);
    intercept_map.reserve(dims);
    for (std::size_t d = 0; d < dims; ++d) {
        const int levels = d < fe_levels.size() ? fe_levels[d] : 0;
        info.num_coefs[d] = std::max(0, levels);
        if (d < slope_only_flags.size() && slope_only_flags[d]) {
            continue;
        }
        intercept_fes.push_back(fes[d]);
        intercept_levels.push_back(levels);
        intercept_map.push_back(d);
    }

    if (intercept_fes.empty()) {
        if (groupvar) groupvar->resize(0);
        if (first_pair_stats) *first_pair_stats = FeComponentStats{};
    } else {
        const FeDofInfo intercept_dof = compute_fe_dof_reghdfe(
            intercept_fes, intercept_levels, method, groupvar, threads,
            first_pair_stats, weights, explicit_threads);
        for (std::size_t pos = 0; pos < intercept_map.size(); ++pos) {
            const std::size_t d = intercept_map[pos];
            info.levels[d] = intercept_dof.levels[pos];
            info.redundant[d] = intercept_dof.redundant[pos];
            info.num_coefs[d] = intercept_dof.num_coefs[pos];
            info.inexact[d] = intercept_dof.inexact[pos];
        }
    }

    for (std::size_t d = 0; d < dims; ++d) {
        info.df_a_levels += info.levels[d];
        info.df_a_exact += info.num_coefs[d];
    }
    info.df_a = info.df_a_exact;
    return info;
}

std::vector<uint8_t> compute_keep_mask_drop_singletons(const std::vector<Eigen::VectorXi>& fes,
                                                       int* dropped_out,
                                                       int num_threads_hint,
                                                       int runtime_capacity,
                                                       bool explicit_thread_request,
                                                       detail::ParallelWorkObserver* observer,
                                                       std::vector<int>* levels_out = nullptr) {
    if (levels_out) {
        levels_out->clear();
    }
    if (dropped_out) {
        *dropped_out = 0;
    }
    if (fes.empty()) {
        return {};
    }
    const int n = static_cast<int>(fes[0].size());
    for (const auto& fe : fes) {
        if (fe.size() != n) {
            throw std::runtime_error("Fixed-effect vectors must have the same length");
        }
    }
    if (n == 0) {
        return {};
    }

    // Threshold below which the original serial scan is kept: the parallel
    // path only pays off for large inputs, and small runs must not regress.
    constexpr int kParallelScanMinObs = 4194304;
    int scan_threads = 1;
#ifdef HDFE_USE_OPENMP
    scan_threads = num_threads_hint > 0
                       ? num_threads_hint
                       : omp_get_max_threads();
    scan_threads = std::max(1, scan_threads);
#else
    (void)num_threads_hint;
#endif
    // num_threads_hint has already been resolved against affinity, OpenMP's
    // thread limit, and the machine capacity by the public entry point.  Make
    // that resolved request authoritative for this phase too: inherited ICVs
    // and OpenMP dynamic teams must not silently shrink an explicit request.
    ScopedParallelRuntime scan_runtime(scan_threads, runtime_capacity);

    auto scan_t0 = std::chrono::steady_clock::now();
    // The scan needs one slot per level, not a numbering by order of first
    // appearance: a level whose identifiers fill a compact range keeps
    // identifier minus minimum, and its rows are never renumbered. The rows
    // kept and the rows dropped do not depend on the numbering.
    struct ScanDim {
        const int* raw = nullptr;
        int shift = 0;
        int groups = 0;
        bool ascending = false;
        FeIndexerLite renumbered;  //!< only when the range is not compact
        int level(int row) const {
            return renumbered.group_ids.empty()
                       ? raw[row] - shift
                       : renumbered.group_ids[static_cast<std::size_t>(row)];
        }
    };
    std::vector<ScanDim> indexers(fes.size());
    bool team_scan = false;
#ifdef HDFE_USE_OPENMP
    team_scan = scan_threads > 1 &&
                (explicit_thread_request || n >= kParallelScanMinObs);
    if (team_scan) {
        const int blocks = detail::deterministic_parallel_chunk_count(n);
        for (std::size_t d = 0; d < fes.size(); ++d) {
            ScanDim& dim = indexers[d];
            const int* const raw = fes[d].data();
            dim.raw = raw;
            std::vector<int> low(static_cast<std::size_t>(blocks), raw[0]);
            std::vector<int> high(static_cast<std::size_t>(blocks), raw[0]);
            std::vector<uint8_t> sorted(static_cast<std::size_t>(blocks), 1);
            if (observer) {
                observer->begin_region(scan_threads);
            }
#pragma omp parallel num_threads(scan_threads)
            {
                bool observed_work = false;
#pragma omp for schedule(static)
                for (int block = 0; block < blocks; ++block) {
                    if (observer && !observed_work) {
                        observer->observe_work();
                        observed_work = true;
                    }
                    const int first =
                        detail::deterministic_parallel_chunk_begin(n, block, blocks);
                    const int last =
                        detail::deterministic_parallel_chunk_end(n, block, blocks);
                    int minimum = raw[first];
                    int maximum = raw[first];
                    int previous = first > 0 ? raw[first - 1] : raw[first];
                    bool rising = true;
                    for (int i = first; i < last; ++i) {
                        const int value = raw[i];
                        minimum = std::min(minimum, value);
                        maximum = std::max(maximum, value);
                        rising = rising && value >= previous;
                        previous = value;
                    }
                    low[static_cast<std::size_t>(block)] = minimum;
                    high[static_cast<std::size_t>(block)] = maximum;
                    sorted[static_cast<std::size_t>(block)] = rising ? 1 : 0;
                }
            }
            if (observer) {
                observer->end_region();
            }
            const int min_id = *std::min_element(low.begin(), low.end());
            const int max_id = *std::max_element(high.begin(), high.end());
            const long long range =
                static_cast<long long>(max_id) - static_cast<long long>(min_id) + 1LL;
            constexpr long long kDenseRangeCap = 50000000LL;
            if (range > 0 && range <= kDenseRangeCap &&
                range <= static_cast<long long>(n) * 2LL) {
                dim.shift = min_id;
                dim.groups = static_cast<int>(range);
                dim.ascending = std::all_of(sorted.begin(), sorted.end(),
                                            [](uint8_t flag) { return flag != 0; });
            } else {
                // Phase 1 of the Stata-path plan: the sparse dimension is
                // renumbered on the scan's team, by the same order of first
                // appearance; XHDFE_SPARSE_RANK=0, or an index above its
                // budget, keeps the serial build.
                const auto sparse_t0 = std::chrono::steady_clock::now();
                if (build_indexer_lite_sparse_rank(fes[d], min_id, max_id, scan_threads,
                                                   observer, dim.renumbered, "singleton_lite")) {
                    detail::sparse_rank::profile_line(
                        "singleton_lite", "bitmap", "index", n, min_id, max_id,
                        dim.renumbered.num_groups, scan_threads, sparse_t0);
                } else {
                    dim.renumbered = build_indexer_lite(fes[d]);
                    detail::sparse_rank::profile_line(
                        "singleton_lite", "serial", detail::sparse_rank::serial_reason(), n,
                        min_id, max_id, dim.renumbered.num_groups, 1, sparse_t0);
                }
                dim.groups = dim.renumbered.num_groups;
            }
        }
    } else
#endif
    {
        for (std::size_t d = 0; d < fes.size(); ++d) {
            indexers[d].raw = fes[d].data();
            indexers[d].renumbered = build_indexer_lite(fes[d]);
            indexers[d].groups = indexers[d].renumbered.num_groups;
        }
    }
    cpu_profile_log_elapsed("singleton_indexers", scan_t0);
    scan_t0 = std::chrono::steady_clock::now();

    std::vector<std::vector<int>> counts(indexers.size());
    std::vector<std::vector<int>> active_xor(indexers.size());
    for (std::size_t d = 0; d < indexers.size(); ++d) {
        const int groups = indexers[d].groups;
        counts[d].assign(static_cast<std::size_t>(groups), 0);
        active_xor[d].assign(static_cast<std::size_t>(groups), 0);
    }

#ifdef HDFE_USE_OPENMP
    if (team_scan) {
        // Integer add and xor are associative and commutative, so any
        // aggregation order produces bit-identical counts/xor values. These
        // are transient scratch arrays, not solver state. Low-cardinality
        // dimensions must NOT use atomics (every thread would hammer the same
        // few cache lines); they get per-thread private arrays merged
        // serially. High-cardinality dimensions scatter over enough distinct
        // addresses that atomic contention is negligible.
        constexpr int kAtomicMinGroups = 65536;
        for (std::size_t d = 0; d < indexers.size(); ++d) {
            const ScanDim& dim = indexers[d];
            const int groups = dim.groups;
            int* __restrict cnt = counts[d].data();
            int* __restrict axr = active_xor[d].data();
            if (dim.ascending && dim.renumbered.group_ids.empty()) {
                // Sorted rows: a level is one run. Its count is the length
                // of the run and its xor the xor of consecutive integers,
                // which has a closed form.
                const int* const raw = dim.raw;
                const int shift = dim.shift;
                std::vector<int> run_begin(static_cast<std::size_t>(groups), -1);
                int* const begin_of = run_begin.data();
#pragma omp parallel num_threads(scan_threads)
                {
#pragma omp for schedule(static)
                    for (int i = 0; i < n; ++i) {
                        if (i == 0 || raw[i - 1] != raw[i]) {
                            begin_of[raw[i] - shift] = i;
                        }
                    }
#pragma omp for schedule(static)
                    for (int i = 0; i < n; ++i) {
                        if (i + 1 == n || raw[i + 1] != raw[i]) {
                            const int g = raw[i] - shift;
                            const int first = begin_of[g];
                            auto xor_to = [](int k) {
                                // xor of 0, 1, ..., k
                                switch (k & 3) {
                                    case 0: return k;
                                    case 1: return 1;
                                    case 2: return k + 1;
                                    default: return 0;
                                }
                            };
                            cnt[g] = i - first + 1;
                            axr[g] = xor_to(i) ^ (first > 0 ? xor_to(first - 1) : 0);
                        }
                    }
                }
                continue;
            }
            const int* __restrict gid =
                dim.renumbered.group_ids.empty() ? nullptr
                                                 : dim.renumbered.group_ids.data();
            const int* __restrict raw = dim.raw;
            const int shift = dim.shift;
            if (groups >= kAtomicMinGroups) {
                if (observer) {
                    observer->begin_region(scan_threads);
                }
#pragma omp parallel num_threads(scan_threads)
                {
                    bool observed_work = false;
#pragma omp for schedule(static)
                    for (int i = 0; i < n; ++i) {
                        if (observer && !observed_work) {
                            observer->observe_work();
                            observed_work = true;
                        }
                        const int g = gid ? gid[i] : raw[i] - shift;
#pragma omp atomic
                        cnt[g] += 1;
#pragma omp atomic
                        axr[g] ^= i;
                    }
                }
                if (observer) {
                    observer->end_region();
                }
            } else {
                std::vector<std::vector<int>> cnt_tls(
                    static_cast<std::size_t>(scan_threads));
                std::vector<std::vector<int>> axr_tls(
                    static_cast<std::size_t>(scan_threads));
                std::vector<std::exception_ptr> allocation_failures(
                    static_cast<std::size_t>(scan_threads));
                if (observer) {
                    observer->begin_region(scan_threads);
                }
#pragma omp parallel num_threads(scan_threads)
                {
                    const int tid = omp_get_thread_num();
                    std::vector<int>& c = cnt_tls[static_cast<std::size_t>(tid)];
                    std::vector<int>& a = axr_tls[static_cast<std::size_t>(tid)];
                    try {
                        c.assign(static_cast<std::size_t>(groups), 0);
                        a.assign(static_cast<std::size_t>(groups), 0);
                    } catch (...) {
                        allocation_failures[static_cast<std::size_t>(tid)] = std::current_exception();
                    }
                    // Every thread reaches the barrier, including a failed
                    // allocator. All then enter or skip the worksharing loop.
#pragma omp barrier
                    const bool ready = std::none_of(allocation_failures.begin(),
                        allocation_failures.end(), [](const std::exception_ptr& failure) {
                            return static_cast<bool>(failure);
                        });
                    if (ready) {
                    bool observed_work = false;
#pragma omp for schedule(static)
                    for (int i = 0; i < n; ++i) {
                        if (observer && !observed_work) {
                            observer->observe_work();
                            observed_work = true;
                        }
                        const int g = gid ? gid[i] : raw[i] - shift;
                        c[static_cast<std::size_t>(g)] += 1;
                        a[static_cast<std::size_t>(g)] ^= i;
                    }
                    }
                }
                if (observer) {
                    observer->end_region();
                }
                for (const auto& failure : allocation_failures)
                    if (failure) std::rethrow_exception(failure);
                for (int t = 0; t < scan_threads; ++t) {
                    const std::vector<int>& c = cnt_tls[static_cast<std::size_t>(t)];
                    const std::vector<int>& a = axr_tls[static_cast<std::size_t>(t)];
                    if (c.empty()) {
                        continue;
                    }
                    for (int g = 0; g < groups; ++g) {
                        cnt[g] += c[static_cast<std::size_t>(g)];
                        axr[g] ^= a[static_cast<std::size_t>(g)];
                    }
                }
            }
        }
    } else
#endif
    {
        for (int i = 0; i < n; ++i) {
            for (std::size_t d = 0; d < indexers.size(); ++d) {
                const int g = indexers[d].level(i);
                counts[d][static_cast<std::size_t>(g)] += 1;
                active_xor[d][static_cast<std::size_t>(g)] ^= i;
            }
        }
    }

    cpu_profile_log_elapsed("singleton_counts", scan_t0);
    scan_t0 = std::chrono::steady_clock::now();
    std::vector<int> current;
    std::vector<int> next;
    std::vector<int> to_drop;
    current.reserve(static_cast<std::size_t>(n / 32 + 1024));
    for (std::size_t d = 0; d < indexers.size(); ++d) {
        const std::vector<int>& dim_counts = counts[d];
        const std::vector<int>& dim_xor = active_xor[d];
        for (std::size_t g = 0; g < dim_counts.size(); ++g) {
            if (dim_counts[g] == 1) {
                current.push_back(dim_xor[g]);
            }
        }
    }

    std::vector<uint8_t> keep(static_cast<std::size_t>(n), 1);
    int dropped_total = 0;
    // Each nonempty wave removes rows permanently; finish at the fixed point.
    while (!current.empty()) {
        to_drop.clear();
        to_drop.reserve(current.size());
        for (const int i : current) {
            if (!keep[static_cast<std::size_t>(i)]) {
                continue;
            }
            bool singleton = false;
            for (std::size_t d = 0; d < fes.size(); ++d) {
                const int g = indexers[d].level(i);
                if (counts[d][static_cast<std::size_t>(g)] == 1) {
                    singleton = true;
                    break;
                }
            }
            if (singleton) {
                keep[static_cast<std::size_t>(i)] = 0;
                to_drop.push_back(i);
            }
        }

        if (to_drop.empty()) {
            break;
        }
        dropped_total += static_cast<int>(to_drop.size());

        for (const int i : to_drop) {
            for (std::size_t d = 0; d < fes.size(); ++d) {
                const int g = indexers[d].level(i);
                int& count = counts[d][static_cast<std::size_t>(g)];
                count -= 1;
                active_xor[d][static_cast<std::size_t>(g)] ^= i;
            }
        }

        next.clear();
        next.reserve(to_drop.size());
        for (const int i : to_drop) {
            for (std::size_t d = 0; d < fes.size(); ++d) {
                const int g = indexers[d].level(i);
                if (counts[d][static_cast<std::size_t>(g)] == 1) {
                    next.push_back(active_xor[d][static_cast<std::size_t>(g)]);
                }
            }
        }
        current.swap(next);
    }
    cpu_profile_log_elapsed("singleton_waves", scan_t0);

    if (dropped_out) {
        *dropped_out = dropped_total;
    }
    // Levels left per dimension after the drops: what the automatic selector
    // would otherwise count again on the retained rows.
    if (levels_out) {
        levels_out->assign(indexers.size(), 0);
        for (std::size_t d = 0; d < indexers.size(); ++d) {
            int present = 0;
            for (const int count : counts[d]) {
                present += count > 0 ? 1 : 0;
            }
            (*levels_out)[d] = present;
        }
    }
    return keep;
}

std::vector<uint8_t> compute_keep_mask_drop_singletons_fweights(
    const std::vector<Eigen::VectorXi>& fes,
    const Eigen::Ref<const Eigen::VectorXd>& weights,
    int* dropped_rows_out,
    double* dropped_weighted_out,
    int num_threads_hint,
    int runtime_capacity,
    bool explicit_thread_request,
    const std::vector<std::int64_t>* validated_integer_weights,
    detail::ParallelWorkObserver* observer) {
    if (dropped_rows_out) {
        *dropped_rows_out = 0;
    }
    if (dropped_weighted_out) {
        *dropped_weighted_out = 0.0;
    }
    if (fes.empty()) {
        return {};
    }
    const int n = static_cast<int>(fes[0].size());
    for (const auto& fe : fes) {
        if (fe.size() != n) {
            throw std::runtime_error("Fixed-effect vectors must have the same length");
        }
    }
    if (weights.size() != n) {
        throw std::runtime_error("Weights must have the same length as fixed-effect vectors");
    }
    if (n == 0) {
        return {};
    }

    constexpr int kParallelScanMinObs = 4194304;
    int scan_threads = 1;
#ifdef HDFE_USE_OPENMP
    scan_threads = num_threads_hint > 0
                       ? num_threads_hint
                       : omp_get_max_threads();
    scan_threads = std::max(1, scan_threads);
#else
    (void)num_threads_hint;
    (void)explicit_thread_request;
    (void)observer;
#endif
    ScopedParallelRuntime scan_runtime(scan_threads, runtime_capacity);

    // Validate and integerize before any parallel region. This preserves the
    // deterministic first-invalid-row failure and proves that no per-group
    // weighted count can overflow int64_t.
    std::vector<std::int64_t> owned_integer_weights;
    const std::vector<std::int64_t>* row_weights_ptr =
        validated_integer_weights;
    if (row_weights_ptr == nullptr) {
        (void)checked_frequency_weight_sum(
            weights, &owned_integer_weights);
        row_weights_ptr = &owned_integer_weights;
    } else if (row_weights_ptr->size() != static_cast<std::size_t>(n)) {
        throw std::logic_error(
            "Validated frequency-weight cache has the wrong length");
    }
    const std::vector<std::int64_t>& row_weights = *row_weights_ptr;

    std::vector<FeIndexerLite> indexers(fes.size());
#ifdef HDFE_USE_OPENMP
    if (scan_threads > 1 &&
        (explicit_thread_request || n >= kParallelScanMinObs)) {
        for (std::size_t d = 0; d < fes.size(); ++d) {
            indexers[d] = build_indexer_lite_team(fes[d], scan_threads, observer);
        }
    } else
#endif
    {
        for (std::size_t d = 0; d < fes.size(); ++d) {
            indexers[d] = build_indexer_lite(fes[d]);
        }
    }

    std::vector<std::vector<std::int64_t>> counts(indexers.size());
    std::vector<std::vector<int>> active_xor(indexers.size());
    for (std::size_t d = 0; d < indexers.size(); ++d) {
        const std::size_t groups =
            static_cast<std::size_t>(indexers[d].num_groups);
        counts[d].assign(groups, 0);
        active_xor[d].assign(groups, 0);
    }

#ifdef HDFE_USE_OPENMP
    if (scan_threads > 1 &&
        (explicit_thread_request || n >= kParallelScanMinObs)) {
        constexpr int kAtomicMinGroups = 65536;
        for (std::size_t d = 0; d < indexers.size(); ++d) {
            const int groups = indexers[d].num_groups;
            const int* __restrict gid = indexers[d].group_ids.data();
            std::int64_t* __restrict cnt = counts[d].data();
            int* __restrict axr = active_xor[d].data();
            if (groups >= kAtomicMinGroups) {
                if (observer) {
                    observer->begin_region(scan_threads);
                }
#pragma omp parallel num_threads(scan_threads)
                {
                    bool observed_work = false;
#pragma omp for schedule(static)
                    for (int i = 0; i < n; ++i) {
                        if (observer && !observed_work) {
                            observer->observe_work();
                            observed_work = true;
                        }
                        const int g = gid[i];
                        const std::int64_t w =
                            row_weights[static_cast<std::size_t>(i)];
#pragma omp atomic
                        cnt[g] += w;
#pragma omp atomic
                        axr[g] ^= i;
                    }
                }
                if (observer) {
                    observer->end_region();
                }
            } else {
                std::vector<std::vector<std::int64_t>> cnt_tls(
                    static_cast<std::size_t>(scan_threads));
                std::vector<std::vector<int>> axr_tls(
                    static_cast<std::size_t>(scan_threads));
                if (observer) {
                    observer->begin_region(scan_threads);
                }
#pragma omp parallel num_threads(scan_threads)
                {
                    const int tid = omp_get_thread_num();
                    std::vector<std::int64_t>& local =
                        cnt_tls[static_cast<std::size_t>(tid)];
                    std::vector<int>& local_xor =
                        axr_tls[static_cast<std::size_t>(tid)];
                    local.assign(static_cast<std::size_t>(groups), 0);
                    local_xor.assign(static_cast<std::size_t>(groups), 0);
                    bool observed_work = false;
#pragma omp for schedule(static)
                    for (int i = 0; i < n; ++i) {
                        if (observer && !observed_work) {
                            observer->observe_work();
                            observed_work = true;
                        }
                        local[static_cast<std::size_t>(gid[i])] +=
                            row_weights[static_cast<std::size_t>(i)];
                        local_xor[static_cast<std::size_t>(gid[i])] ^= i;
                    }
                }
                if (observer) {
                    observer->end_region();
                }
                for (int t = 0; t < scan_threads; ++t) {
                    const std::vector<std::int64_t>& local =
                        cnt_tls[static_cast<std::size_t>(t)];
                    const std::vector<int>& local_xor =
                        axr_tls[static_cast<std::size_t>(t)];
                    for (int g = 0; g < groups; ++g) {
                        cnt[g] += local[static_cast<std::size_t>(g)];
                        axr[g] ^= local_xor[static_cast<std::size_t>(g)];
                    }
                }
            }
        }
    } else
#endif
    {
        for (int i = 0; i < n; ++i) {
            const std::int64_t w =
                row_weights[static_cast<std::size_t>(i)];
            for (std::size_t d = 0; d < indexers.size(); ++d) {
                const int g =
                    indexers[d].group_ids[static_cast<std::size_t>(i)];
                counts[d][static_cast<std::size_t>(g)] += w;
                active_xor[d][static_cast<std::size_t>(g)] ^= i;
            }
        }
    }

    std::vector<int> current;
    std::vector<int> next;
    std::vector<int> to_drop;
    current.reserve(static_cast<std::size_t>(n / 32 + 1024));
    for (std::size_t d = 0; d < indexers.size(); ++d) {
        for (std::size_t g = 0; g < counts[d].size(); ++g) {
            if (counts[d][g] == 1) {
                current.push_back(active_xor[d][g]);
            }
        }
    }

    std::vector<uint8_t> keep(static_cast<std::size_t>(n), 1);
    to_drop.reserve(static_cast<std::size_t>(n / 32 + 1024));
    int dropped_rows_total = 0;
    double dropped_w_total = 0.0;
    while (!current.empty()) {
        to_drop.clear();
        to_drop.reserve(current.size());
        for (const int i : current) {
            if (!keep[static_cast<std::size_t>(i)]) {
                continue;
            }
            bool singleton = false;
            for (std::size_t d = 0; d < indexers.size(); ++d) {
                const int g =
                    indexers[d].group_ids[static_cast<std::size_t>(i)];
                if (counts[d][static_cast<std::size_t>(g)] == 1) {
                    singleton = true;
                    break;
                }
            }
            if (singleton) {
                keep[static_cast<std::size_t>(i)] = 0;
                to_drop.push_back(i);
                dropped_w_total += static_cast<double>(
                    row_weights[static_cast<std::size_t>(i)]);
            }
        }
        if (to_drop.empty()) {
            break;
        }
        dropped_rows_total += static_cast<int>(to_drop.size());
        for (const int i : to_drop) {
            const std::int64_t w =
                row_weights[static_cast<std::size_t>(i)];
            for (std::size_t d = 0; d < indexers.size(); ++d) {
                const int g =
                    indexers[d].group_ids[static_cast<std::size_t>(i)];
                counts[d][static_cast<std::size_t>(g)] -= w;
                active_xor[d][static_cast<std::size_t>(g)] ^= i;
            }
        }

        next.clear();
        next.reserve(to_drop.size());
        for (const int i : to_drop) {
            for (std::size_t d = 0; d < indexers.size(); ++d) {
                const int g =
                    indexers[d].group_ids[static_cast<std::size_t>(i)];
                if (counts[d][static_cast<std::size_t>(g)] == 1) {
                    next.push_back(
                        active_xor[d][static_cast<std::size_t>(g)]);
                }
            }
        }
        current.swap(next);
    }

    if (dropped_rows_out) {
        *dropped_rows_out = dropped_rows_total;
    }
    if (dropped_weighted_out) {
        *dropped_weighted_out = dropped_w_total;
    }
    return keep;
}

// The rows a team copies when the sample is filtered. Copies and counts
// are exact, so the team changes nothing but the time; `threads` is the
// resolved request of the caller and 1 keeps the serial loops.
struct RowFilterTeam {
    int threads = 1;
    bool explicit_request = false;

    // Small inputs stay serial unless the team was asked for.
    bool shares(std::size_t rows) const {
        constexpr std::size_t kParallelFilterMinRows = 4194304;
        return threads > 1 && (explicit_request || rows >= kParallelFilterMinRows);
    }
};

std::vector<int> build_keep_indices(const std::vector<uint8_t>& keep,
                                    const RowFilterTeam& team = {}) {
    std::vector<int> out;
#ifdef HDFE_USE_OPENMP
    if (team.shares(keep.size())) {
        // Count by block, place the blocks, then fill: the indices come out
        // in ascending order whatever the team.
        const int n = static_cast<int>(keep.size());
        const int blocks = detail::deterministic_parallel_chunk_count(n);
        std::vector<int> begin(static_cast<std::size_t>(blocks) + 1U, 0);
        const uint8_t* const flags = keep.data();
#pragma omp parallel for schedule(static) num_threads(team.threads)
        for (int block = 0; block < blocks; ++block) {
            const int first = detail::deterministic_parallel_chunk_begin(n, block, blocks);
            const int last = detail::deterministic_parallel_chunk_end(n, block, blocks);
            int kept = 0;
            for (int i = first; i < last; ++i) {
                kept += flags[i] ? 1 : 0;
            }
            begin[static_cast<std::size_t>(block) + 1U] = kept;
        }
        for (int block = 0; block < blocks; ++block) {
            begin[static_cast<std::size_t>(block) + 1U] +=
                begin[static_cast<std::size_t>(block)];
        }
        out.resize(static_cast<std::size_t>(begin[static_cast<std::size_t>(blocks)]));
        int* const indices = out.data();
#pragma omp parallel for schedule(static) num_threads(team.threads)
        for (int block = 0; block < blocks; ++block) {
            const int first = detail::deterministic_parallel_chunk_begin(n, block, blocks);
            const int last = detail::deterministic_parallel_chunk_end(n, block, blocks);
            int position = begin[static_cast<std::size_t>(block)];
            for (int i = first; i < last; ++i) {
                if (flags[i]) {
                    indices[position++] = i;
                }
            }
        }
        return out;
    }
#else
    (void)team;
#endif
    out.reserve(keep.size());
    for (std::size_t i = 0; i < keep.size(); ++i) {
        if (keep[i]) {
            out.push_back(static_cast<int>(i));
        }
    }
    return out;
}

template <typename Value>
void filter_values(const Value* from,
                   Value* to,
                   const std::vector<int>& idx,
                   const RowFilterTeam& team) {
    const std::ptrdiff_t rows = static_cast<std::ptrdiff_t>(idx.size());
    const int* const source = idx.data();
#ifdef HDFE_USE_OPENMP
#pragma omp parallel for schedule(static) num_threads(team.threads) \
    if(team.shares(idx.size()))
#else
    (void)team;
#endif
    for (std::ptrdiff_t r = 0; r < rows; ++r) {
        to[r] = from[source[r]];
    }
}

Eigen::VectorXd filter_vector(const Eigen::Ref<const Eigen::VectorXd>& v,
                              const std::vector<int>& idx,
                              const RowFilterTeam& team = {}) {
    Eigen::VectorXd out(static_cast<Eigen::Index>(idx.size()));
    if (v.innerStride() == 1) {
        filter_values(v.data(), out.data(), idx, team);
        return out;
    }
    for (std::size_t r = 0; r < idx.size(); ++r) {
        out(static_cast<Eigen::Index>(r)) = v(idx[r]);
    }
    return out;
}

Eigen::VectorXi filter_vector(const Eigen::Ref<const Eigen::VectorXi>& v,
                              const std::vector<int>& idx,
                              const RowFilterTeam& team = {}) {
    Eigen::VectorXi out(static_cast<Eigen::Index>(idx.size()));
    if (v.innerStride() == 1) {
        filter_values(v.data(), out.data(), idx, team);
        return out;
    }
    for (std::size_t r = 0; r < idx.size(); ++r) {
        out(static_cast<Eigen::Index>(r)) = v(idx[r]);
    }
    return out;
}

Eigen::MatrixXd filter_rows(const Eigen::Ref<const Eigen::MatrixXd>& m,
                            const std::vector<int>& idx,
                            const RowFilterTeam& team = {}) {
    Eigen::MatrixXd out(static_cast<Eigen::Index>(idx.size()), m.cols());
    if (m.innerStride() == 1) {
        // One column at a time: every column is one stream.
        for (Eigen::Index j = 0; j < m.cols(); ++j) {
            filter_values(m.data() + j * m.outerStride(), out.col(j).data(), idx, team);
        }
        return out;
    }
    for (std::size_t r = 0; r < idx.size(); ++r) {
        out.row(static_cast<Eigen::Index>(r)) = m.row(idx[r]);
    }
    return out;
}

std::vector<detail::HeterogeneousSlopeTerm> filter_slope_terms(
    const std::vector<detail::HeterogeneousSlopeTerm>& slopes,
    const std::vector<int>& idx,
    const RowFilterTeam& team = {}) {
    std::vector<detail::HeterogeneousSlopeTerm> out;
    out.reserve(slopes.size());
    for (const auto& slope : slopes) {
        detail::HeterogeneousSlopeTerm filtered;
        filtered.fe_index = slope.fe_index;
        filtered.include_intercept = slope.include_intercept;
        filtered.values = filter_vector(slope.values, idx, team);
        out.push_back(std::move(filtered));
    }
    return out;
}

std::vector<int> positive_weight_rows(const Eigen::VectorXd& weights, int zero_count) {
    if (zero_count == weights.size())
        throw std::runtime_error("No positive-weight observations remain");
    std::vector<int> rows;
    rows.reserve(static_cast<std::size_t>(weights.size() - zero_count));
    for (int i = 0; i < weights.size(); ++i) {
        const auto bits = detail::ieee_bits_detail::bits(weights[i]);
        if ((bits & UINT64_C(0x7fffffffffffffff)) != 0) rows.push_back(i);
    }
    return rows;
}

struct PositiveWeightInput {
    std::vector<int> rows;
    Eigen::VectorXd y, weights;
    Eigen::MatrixXd X;
    std::vector<Eigen::VectorXi> fes;
    std::optional<std::vector<Eigen::VectorXi>> clusters;
    std::optional<Eigen::MatrixXd> instruments;
    std::optional<std::vector<detail::HeterogeneousSlopeTerm>> slopes;

    PositiveWeightInput(const Eigen::Ref<const Eigen::VectorXd>& raw_y,
        const Eigen::Ref<const Eigen::MatrixXd>& raw_X,
        const std::vector<Eigen::VectorXi>& raw_fes, const Eigen::VectorXd& raw_weights,
        const std::vector<Eigen::VectorXi>* raw_clusters,
        const Eigen::MatrixXd* raw_instruments,
        const std::vector<detail::HeterogeneousSlopeTerm>* raw_slopes, int zero_count)
        : rows(positive_weight_rows(raw_weights, zero_count)),
          y(filter_vector(raw_y, rows)), weights(filter_vector(raw_weights, rows)),
          X(filter_rows(raw_X, rows)) {
        for (const auto& fe : raw_fes) fes.push_back(filter_vector(fe, rows));
        if (raw_clusters) {
            clusters.emplace();
            for (const auto& c : *raw_clusters) clusters->push_back(filter_vector(c, rows));
        }
        if (raw_instruments) instruments = filter_rows(*raw_instruments, rows);
        if (raw_slopes) slopes = filter_slope_terms(*raw_slopes, rows);
    }
};

struct MixedSavefeRecoveryResult {
    std::vector<Eigen::VectorXd> contributions;
    std::vector<Eigen::VectorXd> save_effects;
    std::vector<int> save_alpha_slot_by_dim;
    int iterations = 0;
    double max_delta = 0.0;
    bool converged = true;
};

struct MixedSavefeDim {
    FeIndexerLite indexer;
    const detail::HeterogeneousSlopeTerm* slope = nullptr;
    Eigen::VectorXd alpha;
    Eigen::VectorXd beta;
    std::vector<double> sw;
    std::vector<double> swz;
    std::vector<double> swzz;
    std::vector<double> rhs0;
    std::vector<double> rhs1;
};

std::vector<std::size_t> resolve_savefe_sweep_order(
    std::size_t dims,
    const std::vector<int>& override_order) {
    std::vector<std::size_t> order;
    order.reserve(dims);
    if (override_order.size() == dims && dims > 0) {
        std::vector<uint8_t> seen(dims, 0);
        bool valid = true;
        for (const int v : override_order) {
            if (v < 0 || v >= static_cast<int>(dims)) {
                valid = false;
                break;
            }
            const std::size_t idx = static_cast<std::size_t>(v);
            if (seen[idx]) {
                valid = false;
                break;
            }
            seen[idx] = 1;
        }
        if (valid) {
            for (const int v : override_order) {
                order.push_back(static_cast<std::size_t>(v));
            }
            return order;
        }
    }
    order.resize(dims);
    std::iota(order.begin(), order.end(), 0);
    return order;
}

MixedSavefeRecoveryResult recover_mixed_savefe_effects(
    const Eigen::VectorXd& partial,
    const std::vector<Eigen::VectorXi>& fes,
    const std::vector<detail::HeterogeneousSlopeTerm>& slopes,
    const Eigen::VectorXd* weights,
    const HdfeOptions& options) {
    const int n = static_cast<int>(partial.size());
    if (n == 0) {
        throw std::runtime_error("Partial residual vector must be non-empty");
    }
    const std::size_t dims = fes.size();
    MixedSavefeRecoveryResult result;
    result.contributions.resize(dims);
    result.save_alpha_slot_by_dim.assign(dims, -1);
    if (dims == 0) {
        result.converged = true;
        return result;
    }
    if (weights && weights->size() != n) {
        throw std::runtime_error("Weights must have the same length as the outcome");
    }

    const int scale_exponent = detail::fe_recovery_scale_exponent(partial);
    if (scale_exponent < 0) {
        Eigen::VectorXd normalized = partial;
        detail::scale_fe_recovery_vector(normalized, -scale_exponent);
        auto recovered = recover_mixed_savefe_effects(normalized, fes, slopes, weights, options);
        for (auto& value : recovered.contributions)
            detail::scale_fe_recovery_vector(value, scale_exponent);
        for (auto& value : recovered.save_effects)
            detail::scale_fe_recovery_vector(value, scale_exponent);
        recovered.max_delta = std::ldexp(recovered.max_delta, scale_exponent);
        return recovered;
    }

    std::vector<const detail::HeterogeneousSlopeTerm*> slope_by_dim(dims, nullptr);
    for (const auto& slope : slopes) {
        if (slope.fe_index < 0 || slope.fe_index >= static_cast<int>(dims)) {
            throw std::runtime_error("Heterogeneous slope FE index out of range");
        }
        const std::size_t dim = static_cast<std::size_t>(slope.fe_index);
        if (slope_by_dim[dim] != nullptr) {
            throw std::runtime_error("Only one heterogeneous slope per absorbed FE is supported");
        }
        if (slope.values.size() != n) {
            throw std::runtime_error("Heterogeneous slope variable must match FE length");
        }
        slope_by_dim[dim] = &slope;
    }

    std::vector<MixedSavefeDim> work;
    work.resize(dims);
    {
        SavefeTimer timer("savefe_mixed_recover_setup");
        for (std::size_t dim = 0; dim < dims; ++dim) {
            if (fes[dim].size() != n) {
                throw std::runtime_error("Each fixed-effect vector must match the length of y");
            }
            MixedSavefeDim& wdim = work[dim];
            wdim.indexer = build_indexer_lite(fes[dim]);
            wdim.slope = slope_by_dim[dim];
            const int groups = wdim.indexer.num_groups;
            wdim.alpha = Eigen::VectorXd::Zero(groups);
            if (wdim.slope != nullptr) {
                wdim.beta = Eigen::VectorXd::Zero(groups);
            }
            wdim.sw.assign(static_cast<std::size_t>(groups), 0.0);
            wdim.rhs0.assign(static_cast<std::size_t>(groups), 0.0);
            if (wdim.slope != nullptr) {
                wdim.swz.assign(static_cast<std::size_t>(groups), 0.0);
                wdim.swzz.assign(static_cast<std::size_t>(groups), 0.0);
                wdim.rhs1.assign(static_cast<std::size_t>(groups), 0.0);
            }
            for (int i = 0; i < n; ++i) {
                const int g = wdim.indexer.group_ids[static_cast<std::size_t>(i)];
                const double wi = weights ? (*weights)(i) : 1.0;
                wdim.sw[static_cast<std::size_t>(g)] += wi;
                if (wdim.slope != nullptr) {
                    const double z = wdim.slope->values(i);
                    wdim.swz[static_cast<std::size_t>(g)] += wi * z;
                    wdim.swzz[static_cast<std::size_t>(g)] += wi * z * z;
                }
            }
        }
    }

    const std::vector<std::size_t> order =
        resolve_savefe_sweep_order(dims, options.sweep_order_override);
    const bool use_symmetric = options.symmetric_sweep && order.size() > 1;
    const double fe_tol = options.fe_tolerance > 0.0 ? options.fe_tolerance : options.tol;
    const int max_iter = std::max(1, options.max_iter);
    Eigen::VectorXd residual = partial;
    double last_max_delta = 0.0;
    bool converged = false;

    auto run_dim = [&](std::size_t dim) -> double {
        MixedSavefeDim& wdim = work[dim];
        const int groups = wdim.indexer.num_groups;
        std::fill(wdim.rhs0.begin(), wdim.rhs0.end(), 0.0);
        if (wdim.slope != nullptr) {
            std::fill(wdim.rhs1.begin(), wdim.rhs1.end(), 0.0);
        }
        for (int i = 0; i < n; ++i) {
            const int g = wdim.indexer.group_ids[static_cast<std::size_t>(i)];
            const double wi = weights ? (*weights)(i) : 1.0;
            const double ri = residual(i);
            wdim.rhs0[static_cast<std::size_t>(g)] += wi * ri;
            if (wdim.slope != nullptr) {
                wdim.rhs1[static_cast<std::size_t>(g)] += wi * wdim.slope->values(i) * ri;
            }
        }

        double max_delta = 0.0;
        constexpr double kSolveTol = 1e-12;
        if (wdim.slope == nullptr) {
            for (int g = 0; g < groups; ++g) {
                const double denom = wdim.sw[static_cast<std::size_t>(g)];
                const double delta =
                    denom > 0.0 ? wdim.rhs0[static_cast<std::size_t>(g)] / denom : 0.0;
                wdim.rhs0[static_cast<std::size_t>(g)] = delta;
                wdim.alpha(g) += delta;
                max_delta = std::max(max_delta, std::abs(delta));
            }
            for (int i = 0; i < n; ++i) {
                const int g = wdim.indexer.group_ids[static_cast<std::size_t>(i)];
                residual(i) -= wdim.rhs0[static_cast<std::size_t>(g)];
            }
            return max_delta;
        }

        if (wdim.slope->include_intercept) {
            for (int g = 0; g < groups; ++g) {
                const std::size_t gs = static_cast<std::size_t>(g);
                const double sw = wdim.sw[gs];
                const double swz = wdim.swz[gs];
                const double swzz = wdim.swzz[gs];
                const double nr = wdim.rhs0[gs];
                const double nz = wdim.rhs1[gs];
                const double det = sw * swzz - swz * swz;
                const double scale = std::abs(sw * swzz) + std::abs(swz * swz);
                double delta_a = 0.0;
                double delta_b = 0.0;
                if (det > kSolveTol * scale) {
                    delta_a = (nr * swzz - nz * swz) / det;
                    delta_b = (sw * nz - swz * nr) / det;
                } else if (sw > 0.0) {
                    delta_a = nr / sw;
                }
                wdim.rhs0[gs] = delta_a;
                wdim.rhs1[gs] = delta_b;
                wdim.alpha(g) += delta_a;
                wdim.beta(g) += delta_b;
                max_delta = std::max(max_delta, std::abs(delta_a));
                max_delta = std::max(max_delta, std::abs(delta_b));
            }
            for (int i = 0; i < n; ++i) {
                const int g = wdim.indexer.group_ids[static_cast<std::size_t>(i)];
                const std::size_t gs = static_cast<std::size_t>(g);
                residual(i) -= wdim.rhs0[gs] + wdim.rhs1[gs] * wdim.slope->values(i);
            }
            return max_delta;
        }

        for (int g = 0; g < groups; ++g) {
            const std::size_t gs = static_cast<std::size_t>(g);
            const double denom = wdim.swzz[gs];
            const double delta_b = denom > 0.0 ? wdim.rhs1[gs] / denom : 0.0;
            wdim.rhs1[gs] = delta_b;
            wdim.beta(g) += delta_b;
            max_delta = std::max(max_delta, std::abs(delta_b));
        }
        for (int i = 0; i < n; ++i) {
            const int g = wdim.indexer.group_ids[static_cast<std::size_t>(i)];
            residual(i) -= wdim.rhs1[static_cast<std::size_t>(g)] * wdim.slope->values(i);
        }
        return max_delta;
    };

    {
        SavefeTimer timer("savefe_mixed_recover_loop");
        for (int iter = 0; iter < max_iter; ++iter) {
            double max_delta = 0.0;
            for (const std::size_t dim : order) {
                max_delta = std::max(max_delta, run_dim(dim));
            }
            if (use_symmetric) {
                for (std::size_t pos = order.size(); pos-- > 0;) {
                    max_delta = std::max(max_delta, run_dim(order[pos]));
                }
            }
            last_max_delta = max_delta;
            if (fe_tol <= 0.0 || max_delta <= fe_tol) {
                result.iterations = iter + 1;
                converged = true;
                break;
            }
        }
    }

    if (!converged) {
        result.iterations = max_iter;
    }
    result.max_delta = last_max_delta;
    result.converged = converged;

    {
        SavefeTimer timer("savefe_mixed_recover_expand");
        for (std::size_t dim = 0; dim < dims; ++dim) {
            MixedSavefeDim& wdim = work[dim];
            result.contributions[dim] = Eigen::VectorXd::Zero(n);
            const bool has_slope = wdim.slope != nullptr;
            const bool has_intercept = !has_slope || wdim.slope->include_intercept;
            int alpha_slot = -1;
            int beta_slot = -1;
            if (has_intercept) {
                alpha_slot = static_cast<int>(result.save_effects.size());
                result.save_alpha_slot_by_dim[dim] = alpha_slot;
                result.save_effects.emplace_back(Eigen::VectorXd::Zero(n));
            }
            if (has_slope) {
                beta_slot = static_cast<int>(result.save_effects.size());
                result.save_effects.emplace_back(Eigen::VectorXd::Zero(n));
            }

            for (int i = 0; i < n; ++i) {
                const int g = wdim.indexer.group_ids[static_cast<std::size_t>(i)];
                double contribution = 0.0;
                if (has_intercept) {
                    const double a = wdim.alpha(g);
                    contribution += a;
                    result.save_effects[static_cast<std::size_t>(alpha_slot)](i) = a;
                }
                if (has_slope) {
                    const double b = wdim.beta(g);
                    result.save_effects[static_cast<std::size_t>(beta_slot)](i) = b;
                    contribution += b * wdim.slope->values(i);
                }
                result.contributions[dim](i) = contribution;
            }
        }
    }

    if (savefe_profile_enabled()) {
        std::ostringstream oss;
        oss << "event=mixed_fe_recovery_end iterations=" << result.iterations
            << " converged=" << (result.converged ? 1 : 0)
            << " max_delta=" << result.max_delta
            << " saved_effects=" << result.save_effects.size();
        savefe_profile_log(oss.str());
    }
    return result;
}

void center_mixed_savefe_effects(std::vector<Eigen::VectorXd>& contributions,
                                 std::vector<Eigen::VectorXd>& save_effects,
                                 const std::vector<int>& save_alpha_slot_by_dim,
                                 const Eigen::VectorXd* weights,
                                 bool fit_intercept) {
    const std::size_t dims = contributions.size();
    if (save_alpha_slot_by_dim.size() != dims) {
        return;
    }
    int anchor_dim=-1;
    double removed_mean=0.0;
    for (std::size_t dim = 0; dim < dims; ++dim) {
        const int slot = save_alpha_slot_by_dim[dim];
        if (slot < 0 || slot >= static_cast<int>(save_effects.size())) {
            continue;
        }
        if (anchor_dim<0) anchor_dim=static_cast<int>(dim);
        const double mean = weighted_mean(contributions[dim], weights);
        contributions[dim].array() -= mean;
        save_effects[static_cast<std::size_t>(slot)].array() -= mean;
        if (!fit_intercept) removed_mean+=mean;
    }
    if (!fit_intercept && anchor_dim>=0) {
        // The intercept-bearing FE supplies the level when beta has no constant.
        contributions[anchor_dim].array()+=removed_mean;
        save_effects[save_alpha_slot_by_dim[anchor_dim]].array()+=removed_mean;
    }
}

int heterogeneous_slope_rank(const Eigen::VectorXi& fe,
                             const detail::HeterogeneousSlopeTerm& slope,
                             const Eigen::VectorXd* weights,
                             int threads = 1,
                             bool explicit_threads = false,
                             detail::ParallelWorkObserver* observer = nullptr) {
    if (fe.size() != slope.values.size()) {
        throw std::runtime_error("Heterogeneous slope variable must match FE length");
    }
    if (weights && weights->size() != fe.size()) {
        throw std::runtime_error("Weights must match heterogeneous slope length");
    }
    // Phase 5a: the ranks by first appearance on the fit's effective team, unchanged,
    // with the fit's observer, under the gate of the route's own indexers (a team
    // above one; explicit, or from 4194304 rows) and never inside a parallel region:
    // build_indexer_lite_team() has neither test, build_indexer_team() returns to the
    // serial build there. Otherwise, and under XHDFE_SLOPE_TEAM_INDEXERS=0,
    // build_indexer_lite(). The per-level sums and the rank count below stay serial,
    // in row order.
    const auto rank_t0 = std::chrono::steady_clock::now();
    int rank_threads = 1;
#ifdef HDFE_USE_OPENMP
    if (detail::slope_team_indexers_enabled() && threads > 1 && !omp_in_parallel() &&
        (explicit_threads || fe.size() >= 4194304)) {
        rank_threads = threads;
    }
    const FeIndexerLite idx = rank_threads > 1
                                  ? build_indexer_lite_team(fe, rank_threads, observer)
                                  : build_indexer_lite(fe);
#else
    (void)threads;
    (void)explicit_threads;
    (void)observer;
    const FeIndexerLite idx = build_indexer_lite(fe);
#endif
    if (cpu_profile_enabled()) {
        const std::chrono::duration<double, std::milli> elapsed =
            std::chrono::steady_clock::now() - rank_t0;
        std::cerr << "cpu_profile label=slope_rank_indexer team=" << rank_threads
                  << " ms=" << elapsed.count() << '\n';
    }
    std::vector<double> sw(static_cast<std::size_t>(idx.num_groups), 0.0);
    std::vector<double> sz(static_cast<std::size_t>(idx.num_groups), 0.0);
    std::vector<double> szz(static_cast<std::size_t>(idx.num_groups), 0.0);
    for (int i = 0; i < fe.size(); ++i) {
        const int g = idx.group_ids[static_cast<std::size_t>(i)];
        const double w = weights ? (*weights)(i) : 1.0;
        const double z = slope.values(i);
        sw[static_cast<std::size_t>(g)] += w;
        sz[static_cast<std::size_t>(g)] += w * z;
        szz[static_cast<std::size_t>(g)] += w * z * z;
    }
    constexpr double kDetTol = 1e-12;
    int rank = 0;
    for (int g = 0; g < idx.num_groups; ++g) {
        const double wg = sw[static_cast<std::size_t>(g)];
        const double zg = sz[static_cast<std::size_t>(g)];
        const double zzg = szz[static_cast<std::size_t>(g)];
        if (slope.include_intercept) {
            if (wg > 0.0) {
                const double det = wg * zzg - zg * zg;
                const double scale = wg * zzg;
                rank += (det > kDetTol * scale) ? 2 : 1;
            }
        } else {
            if (zzg > 0.0) {
                ++rank;
            }
        }
    }
    return rank;
}

void apply_heterogeneous_slope_dof(
    FeDofInfo& dof,
    const std::vector<Eigen::VectorXi>& fes,
    const std::vector<detail::HeterogeneousSlopeTerm>& slopes,
    const Eigen::VectorXd* weights,
    const std::vector<uint8_t>& nested_flags,
    bool adjust_continuous,
    int threads = 1,
    bool explicit_threads = false,
    detail::ParallelWorkObserver* observer = nullptr) {
    if (slopes.empty()) {
        return;
    }
    for (const auto& slope : slopes) {
        const int d = slope.fe_index;
        if (d < 0 || d >= static_cast<int>(fes.size()) ||
            d >= static_cast<int>(dof.levels.size())) {
            throw std::runtime_error("Heterogeneous slope FE index out of range");
        }
        const bool nested = d < static_cast<int>(nested_flags.size()) &&
                            nested_flags[static_cast<std::size_t>(d)] != 0;
        const int base_levels = dof.levels[static_cast<std::size_t>(d)];
        const int base_redundant = dof.redundant[static_cast<std::size_t>(d)];
        const int base_num_coefs = dof.num_coefs[static_cast<std::size_t>(d)];
        int slope_num_coefs = base_levels;
        if (adjust_continuous) {
            const int rank = heterogeneous_slope_rank(
                fes[static_cast<std::size_t>(d)], slope, weights, threads, explicit_threads,
                observer);
            slope_num_coefs = slope.include_intercept
                                   ? std::max(0, rank - base_levels)
                                   : rank;
            slope_num_coefs = std::min(base_levels, slope_num_coefs);
        }
        const int slope_redundant = std::max(0, base_levels - slope_num_coefs);
        if (slope.include_intercept) {
            dof.levels[static_cast<std::size_t>(d)] = 2 * base_levels;
            dof.redundant[static_cast<std::size_t>(d)] =
                base_redundant + slope_redundant;
            dof.num_coefs[static_cast<std::size_t>(d)] =
                (nested ? 0 : base_num_coefs) + slope_num_coefs;
        } else {
            dof.levels[static_cast<std::size_t>(d)] = base_levels;
            dof.redundant[static_cast<std::size_t>(d)] = slope_redundant;
            dof.num_coefs[static_cast<std::size_t>(d)] = slope_num_coefs;
        }
    }
}

int nested_levels_for_heterogeneous_dim(
    std::size_t dim,
    const std::vector<detail::HeterogeneousSlopeTerm>& slopes,
    const std::vector<int>& base_levels,
    const std::vector<int>& dof_levels) {
    for (const auto& slope : slopes) {
        if (slope.fe_index != static_cast<int>(dim)) {
            continue;
        }
        if (!slope.include_intercept) {
            return 0;
        }
        if (dim < base_levels.size()) {
            return base_levels[dim];
        }
        return dim < dof_levels.size() ? dof_levels[dim] : 0;
    }
    return dim < dof_levels.size() ? dof_levels[dim] : 0;
}

int nested_coefs_for_heterogeneous_dim(
    std::size_t dim,
    const std::vector<detail::HeterogeneousSlopeTerm>& slopes,
    const std::vector<int>& dof_num_coefs) {
    for (const auto& slope : slopes) {
        if (slope.fe_index == static_cast<int>(dim)) {
            return 0;
        }
    }
    return dim < dof_num_coefs.size() ? dof_num_coefs[dim] : 0;
}

constexpr double kGroupConstantTol = 1e-12;

bool approx_equal(double a, double b) {
    const double scale = 1.0 + std::max(std::abs(a), std::abs(b));
    return std::abs(a - b) <= kGroupConstantTol * scale;
}

int find_identical_fe(const Eigen::VectorXi& needle,
                      const std::vector<Eigen::VectorXi>& haystack) {
    for (int d = 0; d < static_cast<int>(haystack.size()); ++d) {
        if (haystack[static_cast<std::size_t>(d)].size() != needle.size()) {
            continue;
        }
        if ((haystack[static_cast<std::size_t>(d)].array() == needle.array()).all()) {
            return d;
        }
    }
    return -1;
}

[[noreturn]] void throw_crossproduct_overflow() {
    throw std::runtime_error(
        "cross-product (Gram/moment) overflowed for finite input; "
        "rescale y and/or X (values near |X| >= 1e153 can overflow FP64 moments)");
}

bool exact_fe_span_for_omission(
    const Eigen::Ref<const Eigen::VectorXd>& raw,
    const std::vector<Eigen::VectorXi>& fes,
    const std::vector<detail::HeterogeneousSlopeTerm>& slopes,
    bool constant_available,const detail::GroupIndividualStructure* grouped,
    bool mean) {
    using Fraction=detail::RankFraction;
    struct Block {
        const Eigen::VectorXi* ids;
        const Eigen::VectorXd* values;
        std::unordered_map<int,int> columns;
    };
    try {
        detail::ExactRankBudget budget;
        std::vector<Block> blocks;
        for(std::size_t d=0;d<fes.size();++d) {
            bool level=true;
            for(const auto& slope:slopes)
                if(slope.fe_index==static_cast<int>(d) && !slope.include_intercept) level=false;
            if(level) blocks.push_back({&fes[d],nullptr,{}});
        }
        for(const auto& slope:slopes)
            blocks.push_back({&fes[slope.fe_index],&slope.values,{}});
        int columns=constant_available ? 1 : 0;
        for(auto& block:blocks) for(int row=0;row<raw.size();++row) {
            budget.step();
            if(!block.columns.count((*block.ids)[row])) {
                if(columns>=2000000) return false;
                block.columns.emplace((*block.ids)[row],columns++);
            }
        }
        const int individual_start=columns;
        if(grouped) {
            if(grouped->num_individuals>2000000-columns) return false;
            columns+=grouped->num_individuals;
        }
        // Binary64 values are dyadic rationals. Range limits decline the
        // proof; they never turn a nonzero value into an exact zero.
        auto fraction=[](double value) {
            const auto bits=detail::ieee_bits_detail::bits(value);
            const unsigned field=static_cast<unsigned>((bits>>52)&2047);
            if(field==2047) throw std::runtime_error("nonfinite exact FE-span input");
            std::uint64_t mantissa=(bits&0x000fffffffffffffULL)|(field ? 0x0010000000000000ULL : 0);
            if(!mantissa) return Fraction();
            int exponent=field ? static_cast<int>(field)-1075 : -1074;
            while(!(mantissa&1)) {mantissa>>=1;++exponent;}
            std::int64_t numerator=static_cast<std::int64_t>(mantissa),denominator=1;
            if(exponent>=0) {
                if(exponent>=63 || mantissa>(static_cast<std::uint64_t>(INT64_MAX)>>exponent))
                    throw std::runtime_error("exact FE-span input range");
                numerator=static_cast<std::int64_t>(mantissa<<exponent);
            } else {
                if(exponent< -62) throw std::runtime_error("exact FE-span input range");
                denominator=static_cast<std::int64_t>(1ULL<<(-exponent));
            }
            return Fraction(bits>>63 ? -numerator : numerator,denominator);
        };
        detail::PackedRankAccumulator basis(columns+1,budget,2000000);
        for(int row=0;row<raw.size();++row) {
            detail::PackedRankAccumulator::Row equation;
            if(constant_available) equation.emplace_back(0,Fraction(1));
            for(const auto& block:blocks) {
                budget.step();
                const auto value=block.values ? fraction((*block.values)[row]) : Fraction(1);
                if(!value.zero()) equation.emplace_back(block.columns.at((*block.ids)[row]),value);
            }
            if(grouped) {
                const int first=grouped->group_ptr[row],last=grouped->group_ptr[row+1];
                const Fraction value(1,mean ? last-first : 1);
                for(int edge=first;edge<last;++edge) {
                    budget.step();
                    equation.emplace_back(individual_start+grouped->group_individual[edge],value);
                }
                std::sort(equation.begin(),equation.end(),[](const auto& a,const auto& b) {return a.first<b.first;});
            }
            const auto value=fraction(raw[row]);
            if(!value.zero()) equation.emplace_back(columns,value);
            basis.append(std::move(equation));
            if(basis.is_pivot(columns)) return false;
        }
        return true;
    } catch(const std::runtime_error&) {
        return false;
    }
}

bool require_safe_fe_omission(
    const Eigen::Ref<const Eigen::VectorXd>& raw,double raw_ss,double within_ss,
    const std::vector<Eigen::VectorXi>& fes,
    const std::vector<detail::HeterogeneousSlopeTerm>& slopes,
    bool constant_available,int column,bool exact_projection=false,
    const detail::GroupIndividualStructure* grouped=nullptr,bool mean=false) {
    auto bits=[](double value) {return detail::ieee_bits_detail::bits(value);};
    auto equal=[&](double a,double b) {
        const auto x=bits(a),y=bits(b);
        return x==y || (((x|y)&0x7fffffffffffffffULL)==0);
    };
    bool zero=true,constant=true;
    for(int row=0;row<raw.size();++row) {
        zero=zero && ((bits(raw[row])&0x7fffffffffffffffULL)==0);
        constant=constant && equal(raw[row],raw[0]);
    }
    if(zero || (constant_available && constant)) return true;
    if(exact_projection && within_ss>0.0) return false;
    std::vector<std::size_t> level_dimensions;
    for(std::size_t d=0;d<fes.size();++d) {
        bool level=true;
        for(const auto& slope:slopes)
            if(slope.fe_index==static_cast<int>(d) && !slope.include_intercept) level=false;
        if(!level) continue;
        level_dimensions.push_back(d);
        std::unordered_map<int,double> values;bool constant=true;
        for(int row=0;row<raw.size();++row) {
            const auto entry=values.emplace(fes[d][row],raw[row]);
            if(!entry.second && !equal(entry.first->second,raw[row])) {constant=false;break;}
        }
        if(constant) return true;
    }
    for(std::size_t a=0;a<level_dimensions.size();++a)
        for(std::size_t b=a+1;b<level_dimensions.size();++b)
            if(detail::exact_two_fe_span(raw,fes[level_dimensions[a]],fes[level_dimensions[b]])) return true;
    for(const auto& slope:slopes) {
        double multiplier=0;bool found=false;
        for(int row=0;row<raw.size();++row) if(bits(slope.values[row])&0x7fffffffffffffffULL) {
            multiplier=raw[row]/slope.values[row];found=true;break;
        }
        if(!found || !detail::ieee_finite(multiplier)) continue;
        const auto mbits=bits(multiplier)&0x7fffffffffffffffULL;
        if(mbits && !(mbits&0x7ff0000000000000ULL)) continue;
        bool exact=true;
        for(int row=0;row<raw.size();++row) {
            const double value=slope.values[row];
            const auto vbits=bits(value)&0x7fffffffffffffffULL;
            if(vbits && !(vbits&0x7ff0000000000000ULL)) {exact=false;break;}
            volatile double product=multiplier*value;
            const auto pbits=bits(product)&0x7fffffffffffffffULL;
            if(!detail::ieee_finite(product) || (!pbits && mbits && vbits) ||
               (pbits && (pbits>>52)<123)) {exact=false;break;}
            volatile double error=std::fma(multiplier,value,-product);
            detail::GroupExactDyadicSum difference;
            difference.add(raw[row]);difference.add(product,1,true);difference.add(error,1,true);
            if(!difference.exactly_zero()) {exact=false;break;}
        }
        if(exact) return true;
    }
    if(exact_fe_span_for_omission(raw,fes,slopes,constant_available,grouped,mean)) return true;
    if(!(raw_ss>0.0))
        throw std::runtime_error("Regressor column "+std::to_string(column)+
            " has nonzero values but its squared scale is not representable; no estimates returned");
    std::ostringstream message;
    message << "Regressor column " << column
            << " would be omitted by the FE-collinearity rule, but exact redundancy could not be established"
            << "; within/raw norm ratio=" << std::scientific << std::sqrt(within_ss/raw_ss)
            << ". Numerical identification is ambiguous; omission and estimates were refused."
            << " Inspect the absorbed component or reparameterize the regressor. No estimates returned.";
    throw std::runtime_error(message.str());
}

// Sum of squares of a column about its unweighted mean, computed in two
// passes after shifting by the first element so that a large common level
// (X = 1e14 + a) cannot cancel the variation of interest.
double centered_sum_of_squares(const Eigen::Ref<const Eigen::VectorXd>& x) {
    const Eigen::Index n = x.size();
    if (n <= 0) {
        return 0.0;
    }
    const long double shift = static_cast<long double>(x[0]);
    long double sum = 0.0L;
    for (Eigen::Index i = 0; i < n; ++i) {
        sum += static_cast<long double>(x[i]) - shift;
    }
    const long double mean = sum / static_cast<long double>(n);
    long double css = 0.0L;
    for (Eigen::Index i = 0; i < n; ++i) {
        const long double d = static_cast<long double>(x[i]) - shift - mean;
        css += d * d;
    }
    return static_cast<double>(css);
}

std::vector<uint8_t> compute_rank_collinearity_mask_from_gram(
    const Eigen::Ref<const Eigen::MatrixXd>& gram,
    const std::vector<int>& kept_slope_cols,
    double rank_collinear_tol,
    const std::vector<int>& collinear_priority,
    bool* decisions_separated,
    const Eigen::VectorXd* uncentered_diagonal);

std::vector<uint8_t> precise_rank_mask_with_anchor(
    const Eigen::Ref<const Eigen::MatrixXd>& X,
    const std::vector<int>& columns,
    const Eigen::VectorXd* weights,
    bool center,
    double tolerance,
    const std::vector<int>& priority,
    int threads,
    detail::ParallelWorkObserver* observer,
    int anchor_col = -1) {
    if (anchor_col < 0) {
        return detail::precise_ols_rank_mask(
            X, columns, weights, center, tolerance, priority, threads, observer);
    }
    // A pure-slope absorption transforms the intercept too. Keep that actual
    // column first in the rank factorization instead of centering by raw ones.
    std::vector<int> anchored_columns{anchor_col};
    anchored_columns.insert(anchored_columns.end(), columns.begin(), columns.end());
    std::vector<int> anchored_priority = priority;
    anchored_priority.resize(static_cast<std::size_t>(X.cols()), 0);
    anchored_priority[static_cast<std::size_t>(anchor_col)] =
        std::numeric_limits<int>::max();
    const auto mask = detail::precise_ols_rank_mask(
        X, anchored_columns, weights, false, tolerance, anchored_priority, threads, observer);
    return std::vector<uint8_t>(mask.begin() + 1, mask.end());
}

std::vector<uint8_t> compute_rank_collinearity_mask(
    const Eigen::Ref<const Eigen::MatrixXd>& transformed_X,
    const std::vector<int>& kept_slope_cols,
    int slope_cols,
    bool has_intercept,
    const Eigen::VectorXd* weights,
    double rank_collinear_tol,
    int threads,
    const std::vector<int>& collinear_priority,
    detail::ParallelWorkObserver* observer,
    int anchor_col = -1) {
    std::vector<uint8_t> result(static_cast<std::size_t>(std::max(0,slope_cols)),0);
    if(kept_slope_cols.empty() || slope_cols<=0) return result;

    // FP64 triage: the 2.26.2 Gram matrix over the kept columns decides the
    // rank whenever every decision is separated from the threshold by the
    // margin documented in compute_rank_collinearity_mask_from_gram. Only an
    // ambiguous decision pays the double-double sequential rank over the rows.
    const int p = static_cast<int>(kept_slope_cols.size());
    const Eigen::Index n = transformed_X.rows();
    const Eigen::Index stride = transformed_X.rows();
    const bool anchored = has_intercept && anchor_col >= 0;
    std::vector<const double*> col_ptrs(static_cast<std::size_t>(p));
    for (int j = 0; j < p; ++j) {
        col_ptrs[static_cast<std::size_t>(j)] =
            transformed_X.data() +
            static_cast<Eigen::Index>(kept_slope_cols[static_cast<std::size_t>(j)]) * stride;
    }
    int use_threads = 1;
#ifdef HDFE_USE_OPENMP
    use_threads = std::max(1, threads);
#endif
    const int chunks = deterministic_moment_chunk_count(n);
    std::vector<Eigen::VectorXd> sum_x_tls(
        static_cast<std::size_t>(chunks), Eigen::VectorXd::Zero(p));
    std::vector<Eigen::MatrixXd> sum_xx_tls(
        static_cast<std::size_t>(chunks), Eigen::MatrixXd::Zero(p, p));
    std::vector<double> sum_w_tls(static_cast<std::size_t>(chunks), 0.0);
    if (observer) {
        observer->begin_region(use_threads);
    }
#ifdef HDFE_USE_OPENMP
#pragma omp parallel for schedule(static, 1) num_threads(use_threads)
#endif
    for (int chunk = 0; chunk < chunks; ++chunk) {
        if (observer) {
            observer->observe_work();
        }
        Eigen::VectorXd& sum_x_local = sum_x_tls[static_cast<std::size_t>(chunk)];
        Eigen::MatrixXd& sum_xx_local = sum_xx_tls[static_cast<std::size_t>(chunk)];
        double sum_w_local = 0.0;
        std::vector<double> xvals(static_cast<std::size_t>(p), 0.0);
        const Eigen::Index begin = deterministic_moment_chunk_begin(n, chunk, chunks);
        const Eigen::Index end = deterministic_moment_chunk_end(n, chunk, chunks);
        for (Eigen::Index i = begin; i < end; ++i) {
            const double w = weights ? weights->data()[i] : 1.0;
            const double anchor = anchored ? transformed_X(i, anchor_col) : 1.0;
            if (weights || anchored) {
                sum_w_local += w * anchor * anchor;
            }
            for (int j = 0; j < p; ++j) {
                xvals[j] = col_ptrs[static_cast<std::size_t>(j)][i];
                sum_x_local(j) += w * xvals[j] * anchor;
            }
            for (int j = 0; j < p; ++j) {
                for (int k = 0; k <= j; ++k) {
                    sum_xx_local(j, k) += w * xvals[j] * xvals[k];
                }
            }
        }
        sum_w_tls[static_cast<std::size_t>(chunk)] = sum_w_local;
    }
    if (observer) {
        observer->end_region();
    }
    Eigen::VectorXd sum_x = Eigen::VectorXd::Zero(p);
    Eigen::MatrixXd sum_xx = Eigen::MatrixXd::Zero(p, p);
    double sum_w = 0.0;
    for (int chunk = 0; chunk < chunks; ++chunk) {
        sum_x.noalias() += sum_x_tls[static_cast<std::size_t>(chunk)];
        sum_xx.noalias() += sum_xx_tls[static_cast<std::size_t>(chunk)];
        sum_w += sum_w_tls[static_cast<std::size_t>(chunk)];
    }
    if (!weights && !anchored) {
        sum_w = static_cast<double>(n);
    }
    if (!hdfe::detail::ieee_all_finite(sum_x) ||
        !hdfe::detail::ieee_all_finite(sum_xx) ||
        !hdfe::detail::ieee_finite(sum_w)) {
        throw_crossproduct_overflow();
    }
    if (has_intercept && weights && !(sum_w > 0.0)) {
        throw std::runtime_error("Weights must sum to a positive value");
    }
    Eigen::MatrixXd gram = Eigen::MatrixXd::Zero(p, p);
    Eigen::VectorXd means;
    if (has_intercept) {
        if (!weights && !(sum_w > 0.0)) {
            sum_w = 1.0;
        }
        means = sum_x / sum_w;
    }
    for (int j = 0; j < p; ++j) {
        for (int k = 0; k <= j; ++k) {
            double value = sum_xx(j, k);
            if (has_intercept) {
                value -= means(j) * sum_x(k) + means(k) * sum_x(j) -
                         means(j) * means(k) * sum_w;
            }
            gram(j, k) = value;
            gram(k, j) = value;
        }
    }
    if (!hdfe::detail::ieee_all_finite(gram)) {
        throw_crossproduct_overflow();
    }

    bool separated = true;
    const Eigen::VectorXd uncentered_diagonal = sum_xx.diagonal();
    std::vector<uint8_t> selected = compute_rank_collinearity_mask_from_gram(
        gram, kept_slope_cols, rank_collinear_tol, collinear_priority, &separated,
        &uncentered_diagonal);
    if (!separated) {
        selected = precise_rank_mask_with_anchor(transformed_X, kept_slope_cols,
            weights, has_intercept, rank_collinear_tol, collinear_priority, threads, observer,
            anchored ? anchor_col : -1);
    }
    for(std::size_t pos=0;pos<kept_slope_cols.size();++pos)
        result[static_cast<std::size_t>(kept_slope_cols[pos])]=selected[pos];
    return result;
}

struct CrossproductResult {
    Eigen::MatrixXd xtx;
    Eigen::VectorXd xty;
    Eigen::VectorXd sum_x;
    double sum_w = 0.0;
};

CrossproductResult compute_crossproducts_selected(
    const Eigen::Ref<const Eigen::VectorXd>& y,
    const Eigen::Ref<const Eigen::MatrixXd>& X,
    const std::vector<int>& slope_cols,
    int intercept_col,
    const Eigen::VectorXd* weights,
    bool center_slopes,
    int threads,
    detail::ParallelWorkObserver* observer) {
    CrossproductResult out;
    std::vector<int> cols = slope_cols;
    if (intercept_col >= 0) {
        cols.push_back(intercept_col);
    }
    const int p = static_cast<int>(cols.size());
    const int k = static_cast<int>(slope_cols.size());
    out.xtx = Eigen::MatrixXd::Zero(p, p);
    out.xty = Eigen::VectorXd::Zero(p);
    if (center_slopes) {
        out.sum_x = Eigen::VectorXd::Zero(k);
    }
    out.sum_w = 0.0;
    if (p == 0) {
        return out;
    }

    std::vector<const double*> col_ptrs(static_cast<std::size_t>(p));
    const Eigen::Index n = X.rows();
    const Eigen::Index stride = X.rows();
    for (int j = 0; j < p; ++j) {
        col_ptrs[static_cast<std::size_t>(j)] =
            X.data() + static_cast<Eigen::Index>(cols[static_cast<std::size_t>(j)]) * stride;
    }

    int use_threads = 1;
#ifdef HDFE_USE_OPENMP
    use_threads = std::max(1, threads);
#endif
    const int chunks = deterministic_moment_chunk_count(n);
    std::vector<Eigen::MatrixXd> xtx_tls(
        static_cast<std::size_t>(chunks), Eigen::MatrixXd::Zero(p, p));
    std::vector<Eigen::VectorXd> xty_tls(
        static_cast<std::size_t>(chunks), Eigen::VectorXd::Zero(p));
    std::vector<Eigen::VectorXd> sum_x_tls;
    if (center_slopes) {
        sum_x_tls.assign(static_cast<std::size_t>(chunks),
                         Eigen::VectorXd::Zero(k));
    }
    std::vector<double> sum_w_tls(static_cast<std::size_t>(chunks), 0.0);

    if (observer) {
        observer->begin_region(use_threads);
    }
#ifdef HDFE_USE_OPENMP
#pragma omp parallel for schedule(static, 1) num_threads(use_threads)
#endif
    for (int chunk = 0; chunk < chunks; ++chunk) {
        if (observer) {
            observer->observe_work();
        }
        Eigen::MatrixXd& xtx_local = xtx_tls[static_cast<std::size_t>(chunk)];
        Eigen::VectorXd& xty_local = xty_tls[static_cast<std::size_t>(chunk)];
        Eigen::VectorXd* sum_x_local =
            center_slopes ? &sum_x_tls[static_cast<std::size_t>(chunk)] : nullptr;
        double sum_w_local = 0.0;
        std::vector<double> xvals(static_cast<std::size_t>(p), 0.0);
        const Eigen::Index begin =
            deterministic_moment_chunk_begin(n, chunk, chunks);
        const Eigen::Index end =
            deterministic_moment_chunk_end(n, chunk, chunks);
        for (Eigen::Index i = begin; i < end; ++i) {
            const double w = weights ? weights->data()[i] : 1.0;
            if (center_slopes && weights) {
                sum_w_local += w;
            }
            for (int j = 0; j < p; ++j) {
                xvals[j] = col_ptrs[static_cast<std::size_t>(j)][i];
            }
            for (int j = 0; j < p; ++j) {
                xty_local(j) += w * xvals[j] * y(i);
                for (int l = 0; l <= j; ++l) {
                    xtx_local(j, l) += w * xvals[j] * xvals[l];
                }
            }
            if (sum_x_local) {
                for (int j = 0; j < k; ++j) {
                    (*sum_x_local)(j) += w * xvals[j];
                }
            }
        }
        sum_w_tls[static_cast<std::size_t>(chunk)] = sum_w_local;
    }
    if (observer) {
        observer->end_region();
    }

    for (int chunk = 0; chunk < chunks; ++chunk) {
        out.xtx.noalias() += xtx_tls[static_cast<std::size_t>(chunk)];
        out.xty.noalias() += xty_tls[static_cast<std::size_t>(chunk)];
        if (center_slopes) {
            out.sum_x.noalias() += sum_x_tls[static_cast<std::size_t>(chunk)];
            out.sum_w += sum_w_tls[static_cast<std::size_t>(chunk)];
        }
    }

    if (!weights && center_slopes) {
        out.sum_w = static_cast<double>(n);
    }
    if (center_slopes && weights && !(out.sum_w > 0.0)) {
        throw std::runtime_error("Weights must sum to a positive value");
    }
    for (int j = 0; j < p; ++j) {
        for (int l = j + 1; l < p; ++l) {
            out.xtx(j, l) = out.xtx(l, j);
        }
    }
    if (!hdfe::detail::ieee_all_finite(out.xtx) ||
        !hdfe::detail::ieee_all_finite(out.xty) ||
        (center_slopes &&
         (!hdfe::detail::ieee_all_finite(out.sum_x) ||
          !hdfe::detail::ieee_finite(out.sum_w)))) {
        throw_crossproduct_overflow();
    }
    return out;
}

// Sequential FP64 rank decision on the (centered) Gram matrix, as in 2.26.2.
// `decisions_separated` reports whether every decision is safely away from
// the omission threshold once FP64 Gram rounding is accounted for. With
// U_jj the uncentered diagonal, the accumulation and centering error of the
// Schur complement of column j is bounded by
//   eta * (sqrt(U_jj) + sum_a |alpha_a| sqrt(U_aa))^2,   eta = 64 eps,
// (alpha = regression of column j on the kept columns), which is what makes
// large level offsets (X = 1000 + a) ambiguous in FP64. A kept column must
// then satisfy resid - unc >= (margin*tol)^2 * base and an omitted column
// resid + unc <= (tol/margin)^2 * base. A separated mask equals the
// double-double decision; anything else is recomputed in wide arithmetic by
// the caller (precise_ols_rank_mask), which is the only case that pays.
constexpr double kRankDecisionMargin = 100.0;

std::vector<uint8_t> compute_rank_collinearity_mask_from_gram(
    const Eigen::Ref<const Eigen::MatrixXd>& gram,
    const std::vector<int>& kept_slope_cols,
    double rank_collinear_tol,
    const std::vector<int>& collinear_priority,
    bool* decisions_separated,
    const Eigen::VectorXd* uncentered_diagonal) {
    const int p = static_cast<int>(gram.rows());
    std::vector<uint8_t> drop_mask(static_cast<std::size_t>(std::max(0, p)), 0);
    bool separated = true;
    if (p <= 0) {
        if (decisions_separated) *decisions_separated = true;
        return drop_mask;
    }
    if (!hdfe::detail::ieee_all_finite(gram)) {
        throw_crossproduct_overflow();
    }
    const double keep_margin_tol = rank_collinear_tol * kRankDecisionMargin;
    const double drop_margin_tol = rank_collinear_tol / kRankDecisionMargin;
    const double eta = 64.0 * std::numeric_limits<double>::epsilon();
    auto uncentered_scale = [&](int position) {
        if (!uncentered_diagonal || position < 0 ||
            position >= uncentered_diagonal->size()) {
            return std::sqrt(std::max(0.0, gram(position, position)));
        }
        return std::sqrt(std::max(0.0, (*uncentered_diagonal)[position]));
    };

    std::vector<int> ordered_positions(static_cast<std::size_t>(p));
    std::iota(ordered_positions.begin(), ordered_positions.end(), 0);
    if (!collinear_priority.empty()) {
        std::stable_sort(ordered_positions.begin(), ordered_positions.end(),
                         [&](int a, int b) {
                             const int pa =
                                 (a >= 0 && a < static_cast<int>(kept_slope_cols.size()))
                                     ? kept_slope_cols[static_cast<std::size_t>(a)]
                                     : -1;
                             const int pb =
                                 (b >= 0 && b < static_cast<int>(kept_slope_cols.size()))
                                     ? kept_slope_cols[static_cast<std::size_t>(b)]
                                     : -1;
                             const int pri_a =
                                 (pa >= 0 && pa < static_cast<int>(collinear_priority.size()))
                                     ? collinear_priority[static_cast<std::size_t>(pa)]
                                     : 0;
                             const int pri_b =
                                 (pb >= 0 && pb < static_cast<int>(collinear_priority.size()))
                                     ? collinear_priority[static_cast<std::size_t>(pb)]
                                     : 0;
                             if (pri_a != pri_b) {
                                 return pri_a > pri_b;
                             }
                             return a < b;
                         });
    }

    Eigen::MatrixXd gram_keep(0, 0);
    Eigen::LDLT<Eigen::MatrixXd> ldlt;
    std::vector<int> kept_positions;
    kept_positions.reserve(static_cast<std::size_t>(p));

    for (const int pos : ordered_positions) {
        const double base_var = gram(pos, pos);
        if (!hdfe::detail::ieee_finite(base_var)) {
            throw_crossproduct_overflow();
        }
        if (base_var <= 0.0) {
            drop_mask[static_cast<std::size_t>(pos)] = 1;
            continue;
        }
        double resid_var = base_var;
        double uncertainty_scale = uncentered_scale(pos);
        if (!kept_positions.empty()) {
            Eigen::VectorXd g(kept_positions.size());
            for (std::size_t i = 0; i < kept_positions.size(); ++i) {
                g(static_cast<Eigen::Index>(i)) = gram(kept_positions[i], pos);
            }
            const Eigen::VectorXd alpha = ldlt.solve(g);
            resid_var = base_var - g.dot(alpha);
            for (std::size_t i = 0; i < kept_positions.size(); ++i) {
                uncertainty_scale += std::abs(alpha(static_cast<Eigen::Index>(i))) *
                                     uncentered_scale(kept_positions[i]);
            }
        }
        if (!hdfe::detail::ieee_finite(resid_var)) {
            throw_crossproduct_overflow();
        }
        if (resid_var < 0.0) {
            resid_var = 0.0;
        }
        const double uncertainty = eta * uncertainty_scale * uncertainty_scale;
        const double base_uncertainty = eta * uncentered_scale(pos) * uncentered_scale(pos);
        if (!hdfe::detail::ieee_finite(uncertainty)) {
            separated = false;
        }
        const double base_norm = std::sqrt(base_var);
        const double resid_norm = std::sqrt(resid_var);
        if (!(base_norm > 0.0) || resid_norm <= rank_collinear_tol * base_norm) {
            drop_mask[static_cast<std::size_t>(pos)] = 1;
            if (base_norm > 0.0 &&
                !(resid_var + uncertainty <=
                  drop_margin_tol * drop_margin_tol *
                      std::max(0.0, base_var - base_uncertainty))) {
                separated = false;
            }
            continue;
        }
        if (!(resid_var - uncertainty >=
              keep_margin_tol * keep_margin_tol * (base_var + base_uncertainty))) {
            separated = false;
        }

        const int old = gram_keep.rows();
        gram_keep.conservativeResize(old + 1, old + 1);
        for (int i = 0; i < old; ++i) {
            const double v = gram(kept_positions[static_cast<std::size_t>(i)], pos);
            gram_keep(i, old) = v;
            gram_keep(old, i) = v;
        }
        gram_keep(old, old) = base_var;
        kept_positions.push_back(pos);
        ldlt.compute(gram_keep);
        if (ldlt.info() != Eigen::Success) {
            drop_mask[static_cast<std::size_t>(pos)] = 1;
            separated = false;
            kept_positions.pop_back();
            gram_keep.conservativeResize(old, old);
            if (old > 0) {
                ldlt.compute(gram_keep);
            }
        }
    }

    if (decisions_separated) {
        *decisions_separated = separated;
    }
    return drop_mask;
}

struct GroupCollapsedData {
    Eigen::VectorXd y;
    Eigen::MatrixXd X;
    std::vector<Eigen::VectorXi> standard_fes;
    std::optional<Eigen::VectorXd> weights;
    std::optional<std::vector<Eigen::VectorXi>> clusters;
    hdfe::detail::GroupIndividualStructure gi;
    Eigen::VectorXi group_values;
    Eigen::VectorXi individual_values;
    // For mapping results back to the long-format input: rep_row[g] is the 0-based row index in
    // the original (y, X, fes, group_ids, individual_ids) arrays corresponding to group g.
    std::vector<int> rep_row;
};

AbsorptionCacheKey hash_grouped_mobility_signature(
    const Eigen::Ref<const Eigen::VectorXd>& y,
    const Eigen::Ref<const Eigen::MatrixXd>& design,
    const std::vector<Eigen::VectorXi>& standard_fes,
    const hdfe::detail::GroupIndividualStructure& gi,
    GroupAggregation aggregation,
    const Eigen::VectorXd* weights,
    const HdfeOptions& options,
    int nobs_full,
    int singletons_dropped) {
    // A mobility profile is a method-selection hint, not a transformed-data
    // cache. Both domain-separated digests therefore cover the complete
    // post-singleton operator-equivalent structure, RHS count, weights,
    // backend and selection context, but deliberately not y/X values. This
    // preserves safe reuse across outcomes with the same operator and cost
    // shape; the separate absorption cache remains value-exact.
    // The second digest is stored in the legacy signature_canon field, but is
    // an independent fail-closed checksum rather than a permissive fallback.
    std::uint64_t h1 = kFnvOffset64;
    std::uint64_t h2 = kFnvOffset64 ^ kAbsorptionCacheSalt;
    auto update = [&](std::uint64_t value) {
        h1 = fnv1a_update(h1, value);
        h2 = fnv1a_update(h2, value + kAbsorptionCacheSalt);
    };
    auto update_int_vector = [&](const std::vector<int>& values) {
        update(static_cast<std::uint64_t>(values.size()));
        for (const int value : values) {
            update(static_cast<std::uint64_t>(static_cast<std::int64_t>(value)));
        }
    };
    auto update_eigen_int_vector = [&](const Eigen::VectorXi& values) {
        update(static_cast<std::uint64_t>(values.size()));
        for (Eigen::Index i = 0; i < values.size(); ++i) {
            update(static_cast<std::uint64_t>(
                static_cast<std::int64_t>(values(i))));
        }
    };
    auto update_double_vector = [&](const std::vector<double>& values) {
        update(static_cast<std::uint64_t>(values.size()));
        for (const double value : values) {
            update(hash_double_bits(value));
        }
    };

    // Versioned, scope-specific domain separator.
    update(0x58484446454d5032ULL);  // "XHDFEMP2"
    update(0x47524f5550494e44ULL);  // "GROUPIND"
    update(static_cast<std::uint64_t>(y.size()));
    update(static_cast<std::uint64_t>(design.rows()));
    update(static_cast<std::uint64_t>(design.cols()));
    update(static_cast<std::uint64_t>(design.cols() + 1));  // y plus X RHS
    update(static_cast<std::uint64_t>(standard_fes.size()));
    update(static_cast<std::uint64_t>(gi.num_groups));
    update(static_cast<std::uint64_t>(gi.num_individuals));
    update(static_cast<std::uint64_t>(nobs_full));
    update(static_cast<std::uint64_t>(singletons_dropped));
    update(aggregation == GroupAggregation::Mean ? 1ULL : 2ULL);
    update(weights ? 1ULL : 0ULL);
    update(options.weights_are_frequencies ? 1ULL : 0ULL);
    update(options.fit_intercept ? 1ULL : 0ULL);
    update(options.drop_singletons ? 1ULL : 0ULL);
    update(static_cast<std::uint64_t>(
        static_cast<std::uint32_t>(options.num_threads)));
    update(options.num_threads_explicit ? 1ULL : 0ULL);
    update(mobility_backend_tag());
    update(static_cast<std::uint64_t>(options.dof_method));
    update(options.dof_mobility_groups ? 1ULL : 0ULL);
    update(options.dof_adjust_clusters ? 1ULL : 0ULL);
    update(options.dof_adjust_continuous ? 1ULL : 0ULL);
    update(static_cast<std::uint64_t>(options.max_iter));
    update(static_cast<std::uint64_t>(static_cast<int>(options.tolerance_mode)));
    update(hash_double_bits(options.tol));
    update(static_cast<std::uint64_t>(
        static_cast<int>(options.absorption_method)));
    update(static_cast<std::uint64_t>(
        static_cast<int>(options.convergence_criterion)));
    update(options.symmetric_sweep ? 1ULL : 0ULL);
    update(options.use_sparse_solver ? 1ULL : 0ULL);
    update(options.use_krylov ? 1ULL : 0ULL);
    update(options.from_auto ? 1ULL : 0ULL);
    update(static_cast<std::uint64_t>(
        static_cast<std::uint32_t>(options.convergence_check_interval)));
    update(hash_double_bits(options.krylov_lambda));
    update(hash_double_bits(options.jacobi_relaxation));
    update(hash_double_bits(options.sparse_threshold));
    update_int_vector(options.sweep_order_override);

    for (const auto& fe : standard_fes) {
        update_eigen_int_vector(fe);
    }
    update_int_vector(gi.group_ptr);
    update_int_vector(gi.group_individual);
    update_double_vector(gi.group_scale);

    if (weights) {
        update(static_cast<std::uint64_t>(weights->size()));
        for (Eigen::Index i = 0; i < weights->size(); ++i) {
            update(hash_double_bits((*weights)(i)));
        }
    }

    AbsorptionCacheKey key;
    key.sig1 = h1 == 0 ? kFnvOffset64 : h1;
    key.sig2 = h2 == 0 ? (kFnvOffset64 ^ kAbsorptionCacheSalt) : h2;
    return key;
}

AbsorptionCacheKey hash_grouped_fit_signature(
    const Eigen::Ref<const Eigen::VectorXd>& y,
    const Eigen::Ref<const Eigen::MatrixXd>& X,
    const std::vector<Eigen::VectorXi>& fes,
    const Eigen::Ref<const Eigen::VectorXi>& group_ids,
    const Eigen::Ref<const Eigen::VectorXi>& individual_ids,
    GroupAggregation aggregation,
    const Eigen::VectorXd* weights,
    const HdfeOptions& options) {
    std::uint64_t h1 = kFnvOffset64;
    std::uint64_t h2 = kFnvOffset64 ^ kAbsorptionCacheSalt;
    auto update = [&](std::uint64_t value) {
        h1 = fnv1a_update(h1, value);
        h2 = fnv1a_update(h2, value + kAbsorptionCacheSalt);
    };
    auto update_double = [&](double value) {
        hash_update_double(h1, value);
        hash_update_double(h2, value);
    };
    auto update_int_vector = [&](const Eigen::VectorXi& values) {
        update(static_cast<std::uint64_t>(values.size()));
        for (Eigen::Index i = 0; i < values.size(); ++i) {
            update(static_cast<std::uint64_t>(
                static_cast<std::int64_t>(values[i])));
        }
    };

    update(0x5848444645474931ULL);  // "XHDFEGI1"
    update(static_cast<std::uint64_t>(y.size()));
    update(static_cast<std::uint64_t>(X.rows()));
    update(static_cast<std::uint64_t>(X.cols()));
    update(static_cast<std::uint64_t>(fes.size()));
    update(aggregation == GroupAggregation::Mean ? 1ULL : 2ULL);
    update(weights ? 1ULL : 0ULL);
    update(options.weights_are_frequencies ? 1ULL : 0ULL);
    update(options.fit_intercept ? 1ULL : 0ULL);
    update(options.drop_singletons ? 1ULL : 0ULL);

    update(static_cast<std::uint64_t>(options.dof_method));
    update(options.dof_mobility_groups ? 1ULL : 0ULL);
    update(options.dof_adjust_clusters ? 1ULL : 0ULL);
    update(options.dof_adjust_continuous ? 1ULL : 0ULL);
    for (Eigen::Index i = 0; i < y.size(); ++i) {
        update_double(y[i]);
    }
    for (Eigen::Index column = 0; column < X.cols(); ++column) {
        for (Eigen::Index row = 0; row < X.rows(); ++row) {
            update_double(X(row, column));
        }
    }
    for (const auto& fe : fes) {
        update_int_vector(fe);
    }
    update_int_vector(group_ids);
    update_int_vector(individual_ids);
    if (weights) {
        update(static_cast<std::uint64_t>(weights->size()));
        for (Eigen::Index i = 0; i < weights->size(); ++i) {
            update_double((*weights)[i]);
        }
    }

    return AbsorptionCacheKey{h1, h2};
}

GroupCollapsedData collapse_group_long_format(const Eigen::VectorXd& y,
                                              const Eigen::MatrixXd& X,
                                              const std::vector<Eigen::VectorXi>& fes,
                                              const Eigen::VectorXi& group_ids,
                                              const Eigen::VectorXi* individual_ids,
                                              int individual_fe_index,
                                              GroupAggregation aggregation,
                                              const Eigen::VectorXd* weights,
                                              bool weights_are_frequencies,
                                              const std::vector<Eigen::VectorXi>* clusters) {
    if (y.size() == 0) {
        throw std::runtime_error("Outcome vector must be non-empty");
    }
    const int n = static_cast<int>(y.size());
    if (X.rows() != n) {
        throw std::runtime_error("X must have the same number of rows as y");
    }
    require_finite_vector(y, "y");
    require_finite_matrix(X, "X");
    if (group_ids.size() != n) {
        throw std::runtime_error("group_ids must have the same length as y");
    }
    require_nonnegative_ids(group_ids, "group IDs");
    if (individual_ids && individual_ids->size() != n) {
        throw std::runtime_error("individual_ids must have the same length as y");
    }
    if (individual_ids) {
        require_nonnegative_ids(*individual_ids, "individual IDs");
    }
    if (weights && weights->size() != n) {
        throw std::runtime_error("weights must have the same length as y");
    }
    if (weights_are_frequencies && weights) {
        // Validate every long-format row before choosing one representative
        // per group.  Do not sum here: repeated individual rows must not make
        // an otherwise valid group-level frequency total overflow.
        validate_frequency_weight_values(*weights);
    }
    if (weights && !weights_are_frequencies) {
        // Analytic weights must be IEEE-finite and non-negative (re-audit
        // R-03): one negative or NaN value among many silently corrupts
        // every weighted moment while the only prior guard — a positive
        // total — still passes. Zero remains allowed (a zero-weight row
        // contributes nothing). ieee_finite is bit-level, immune to
        // -ffast-math folding std::isfinite into a constant.
        const double* w_chk = weights->data();
        for (int i = 0; i < n; ++i) {
            if (!hdfe::detail::ieee_finite(w_chk[i]) || w_chk[i] < 0.0) {
                throw std::runtime_error(
                    "weights must be finite and non-negative");
            }
        }
    }
    if (clusters) {
        for (const auto& c : *clusters) {
            if (c.size() != n) {
                throw std::runtime_error("clusters must have the same length as y");
            }
            require_nonnegative_ids(c, "cluster IDs");
        }
    }
    for (const auto& fe : fes) {
        if (fe.size() != n) {
            throw std::runtime_error("Each fixed-effect vector must be length n");
        }
        require_nonnegative_ids(fe, "fixed-effect IDs");
    }
    if (individual_ids && individual_fe_index < 0) {
        throw std::runtime_error("individual_ids must also be included in fes");
    }

    // Stata typically passes dense integer IDs (via egen group()).
    // For very large n (e.g., 100M edge rows), avoiding std::unordered_map node allocations is
    // critical. Prefer a dense-range mapping when the ID range is manageable; otherwise fall back
    // to unordered_map.
    constexpr std::int64_t kMaxDenseIdRange = 50000000LL;  // 50M ints ~= 200MB of RAM.

    bool use_dense_group_map = false;
    int group_min = 0;
    std::vector<int> group_dense;
    std::vector<int> group_index;  // only used in the unordered_map fallback
    std::vector<int> rep_row;
    std::vector<int> group_values;

    int group_max = group_ids(0);
    group_min = group_ids(0);
    for (int i = 1; i < n; ++i) {
        const int v = group_ids(i);
        group_min = std::min(group_min, v);
        group_max = std::max(group_max, v);
    }
    const std::int64_t group_range =
        static_cast<std::int64_t>(group_max) - static_cast<std::int64_t>(group_min) + 1LL;
    if (group_range > 0 && group_range <= kMaxDenseIdRange &&
        group_range <= static_cast<std::int64_t>(n)) {
        use_dense_group_map = true;
        group_dense.assign(static_cast<std::size_t>(group_range), -1);
        rep_row.reserve(static_cast<std::size_t>(std::min<std::int64_t>(n, group_range)));
        group_values.reserve(rep_row.capacity());
        for (int i = 0; i < n; ++i) {
            const int raw = group_ids(i);
            const std::size_t slot = static_cast<std::size_t>(raw - group_min);
            int& idx = group_dense[slot];
            if (idx < 0) {
                idx = static_cast<int>(rep_row.size());
                rep_row.push_back(i);
                group_values.push_back(raw);
            }
        }
    } else {
        std::unordered_map<int, int> group_map;
        group_map.reserve(static_cast<std::size_t>(n));
        group_index.assign(static_cast<std::size_t>(n), 0);
        rep_row.reserve(static_cast<std::size_t>(n));
        group_values.reserve(static_cast<std::size_t>(n));
        for (int i = 0; i < n; ++i) {
            const int raw = group_ids(i);
            auto it = group_map.find(raw);
            if (it == group_map.end()) {
                const int g = static_cast<int>(rep_row.size());
                group_map.emplace(raw, g);
                rep_row.push_back(i);
                group_values.push_back(raw);
                group_index[static_cast<std::size_t>(i)] = g;
            } else {
                group_index[static_cast<std::size_t>(i)] = it->second;
            }
        }
    }
    const int G = static_cast<int>(rep_row.size());
    if (G == 0) {
        throw std::runtime_error("No groups found");
    }

    auto group_of_row = [&](int i) -> int {
        if (use_dense_group_map) {
            const int raw = group_ids(i);
            const std::size_t slot = static_cast<std::size_t>(raw - group_min);
            return group_dense[slot];
        }
        return group_index[static_cast<std::size_t>(i)];
    };

    for (int i = 0; i < n; ++i) {
        const int g = group_of_row(i);
        const int r = rep_row[static_cast<std::size_t>(g)];
        if (!approx_equal(y(i), y(r))) {
            throw std::runtime_error("y is not constant within group_ids");
        }
        for (int j = 0; j < X.cols(); ++j) {
            if (!approx_equal(X(i, j), X(r, j))) {
                throw std::runtime_error("X is not constant within group_ids");
            }
        }
        if (weights) {
            const bool weights_match =
                weights_are_frequencies
                    ? ((*weights)(i) == (*weights)(r))
                    : approx_equal((*weights)(i), (*weights)(r));
            if (!weights_match) {
                throw std::runtime_error(
                    "weights are not constant within group_ids");
            }
        }
        if (clusters) {
            for (const auto& c : *clusters) {
                if (c(i) != c(r)) {
                    throw std::runtime_error("clusters are not constant within group_ids");
                }
            }
        }
        for (int d = 0; d < static_cast<int>(fes.size()); ++d) {
            if (individual_ids && d == individual_fe_index) {
                continue;
            }
            if (fes[static_cast<std::size_t>(d)](i) != fes[static_cast<std::size_t>(d)](r)) {
                throw std::runtime_error("Fixed effects are not constant within group_ids");
            }
        }
    }

    GroupCollapsedData out;
    out.y.resize(G);
    out.X.resize(G, X.cols());
    out.group_values = Eigen::VectorXi::Zero(G);
    if (weights) {
        out.weights = Eigen::VectorXd::Zero(G);
    }
    if (clusters) {
        out.clusters = std::vector<Eigen::VectorXi>{};
        out.clusters->reserve(clusters->size());
        for (std::size_t j = 0; j < clusters->size(); ++j) {
            out.clusters->emplace_back(Eigen::VectorXi::Zero(G));
        }
    }

    out.standard_fes.clear();
    out.standard_fes.reserve(fes.size());
    for (int d = 0; d < static_cast<int>(fes.size()); ++d) {
        if (individual_ids && d == individual_fe_index) {
            continue;
        }
        out.standard_fes.emplace_back(Eigen::VectorXi::Zero(G));
    }

    for (int g = 0; g < G; ++g) {
        const int r = rep_row[static_cast<std::size_t>(g)];
        out.group_values(g) = group_values[static_cast<std::size_t>(g)];
        out.y(g) = y(r);
        out.X.row(g) = X.row(r);
        if (out.weights) {
            (*out.weights)(g) = (*weights)(r);
        }
        if (out.clusters) {
            for (std::size_t j = 0; j < out.clusters->size(); ++j) {
                (*out.clusters)[j](g) = (*clusters)[j](r);
            }
        }
        int cursor = 0;
        for (int d = 0; d < static_cast<int>(fes.size()); ++d) {
            if (individual_ids && d == individual_fe_index) {
                continue;
            }
            out.standard_fes[static_cast<std::size_t>(cursor)](g) =
                fes[static_cast<std::size_t>(d)](r);
            ++cursor;
        }
    }

    out.rep_row = std::move(rep_row);

    if (!individual_ids) {
        return out;
    }

    bool use_dense_indiv_map = false;
    int indiv_min = 0;
    std::vector<int> indiv_dense;
    std::vector<int> indiv_index;  // only used in the unordered_map fallback
    std::vector<int> indiv_values;
    int I = 0;

    int indiv_max = (*individual_ids)(0);
    indiv_min = (*individual_ids)(0);
    for (int i = 1; i < n; ++i) {
        const int v = (*individual_ids)(i);
        indiv_min = std::min(indiv_min, v);
        indiv_max = std::max(indiv_max, v);
    }
    const std::int64_t indiv_range =
        static_cast<std::int64_t>(indiv_max) - static_cast<std::int64_t>(indiv_min) + 1LL;
    if (indiv_range > 0 && indiv_range <= kMaxDenseIdRange &&
        indiv_range <= static_cast<std::int64_t>(n)) {
        use_dense_indiv_map = true;
        indiv_dense.assign(static_cast<std::size_t>(indiv_range), -1);
        indiv_values.reserve(static_cast<std::size_t>(std::min<std::int64_t>(n, indiv_range)));
        for (int i = 0; i < n; ++i) {
            const int raw = (*individual_ids)(i);
            const std::size_t slot = static_cast<std::size_t>(raw - indiv_min);
            int& idx = indiv_dense[slot];
            if (idx < 0) {
                idx = I++;
                indiv_values.push_back(raw);
            }
        }
    } else {
        std::unordered_map<int, int> indiv_map;
        indiv_map.reserve(static_cast<std::size_t>(n));
        indiv_index.assign(static_cast<std::size_t>(n), 0);
        indiv_values.reserve(static_cast<std::size_t>(n));
        for (int i = 0; i < n; ++i) {
            const int raw = (*individual_ids)(i);
            auto it = indiv_map.find(raw);
            if (it == indiv_map.end()) {
                indiv_map.emplace(raw, I);
                indiv_values.push_back(raw);
                indiv_index[static_cast<std::size_t>(i)] = I;
                ++I;
            } else {
                indiv_index[static_cast<std::size_t>(i)] = it->second;
            }
        }
    }
    if (I == 0) {
        throw std::runtime_error("No individuals found");
    }
    out.individual_values = Eigen::VectorXi::Zero(I);
    for (int i = 0; i < I; ++i) {
        out.individual_values(i) = indiv_values[static_cast<std::size_t>(i)];
    }

    auto indiv_of_row = [&](int i) -> int {
        if (use_dense_indiv_map) {
            const int raw = (*individual_ids)(i);
            const std::size_t slot = static_cast<std::size_t>(raw - indiv_min);
            return indiv_dense[slot];
        }
        return indiv_index[static_cast<std::size_t>(i)];
    };

    std::vector<uint64_t> edges_by_group(static_cast<std::size_t>(n));
    for (int i = 0; i < n; ++i) {
        const uint64_t g = static_cast<uint64_t>(group_of_row(i));
        const uint64_t ind = static_cast<uint64_t>(indiv_of_row(i));
        edges_by_group[static_cast<std::size_t>(i)] = (g << 32) | (ind & 0xffffffffULL);
    }

    // Free mapping structures early to reduce peak memory use for huge n.
    if (!group_index.empty()) {
        std::vector<int>().swap(group_index);
    }
    if (!group_dense.empty()) {
        std::vector<int>().swap(group_dense);
    }
    if (!indiv_index.empty()) {
        std::vector<int>().swap(indiv_index);
    }
    if (!indiv_dense.empty()) {
        std::vector<int>().swap(indiv_dense);
    }

    std::sort(edges_by_group.begin(), edges_by_group.end());
    for (std::size_t i = 1; i < edges_by_group.size(); ++i) {
        if (edges_by_group[i] == edges_by_group[i - 1]) {
            throw std::runtime_error(
                "group_ids and individual_ids do not uniquely identify the observations");
        }
    }

    out.gi.num_groups = G;
    out.gi.num_individuals = I;
    out.gi.group_ptr.assign(static_cast<std::size_t>(G) + 1, 0);
    out.gi.group_individual.assign(static_cast<std::size_t>(n), 0);
    for (const uint64_t key : edges_by_group) {
        const int g = static_cast<int>(key >> 32);
        out.gi.group_ptr[static_cast<std::size_t>(g + 1)] += 1;
    }
    for (int g = 0; g < G; ++g) {
        out.gi.group_ptr[static_cast<std::size_t>(g + 1)] +=
            out.gi.group_ptr[static_cast<std::size_t>(g)];
    }
    std::vector<int> group_cursor = out.gi.group_ptr;
    for (const uint64_t key : edges_by_group) {
        const int g = static_cast<int>(key >> 32);
        const int ind = static_cast<int>(key & 0xffffffffULL);
        out.gi.group_individual[static_cast<std::size_t>(group_cursor[static_cast<std::size_t>(g)]++)] =
            ind;
    }

    out.gi.individual_ptr.assign(static_cast<std::size_t>(I) + 1, 0);
    out.gi.individual_group.assign(static_cast<std::size_t>(n), 0);
    for (const uint64_t key : edges_by_group) {
        const int ind = static_cast<int>(key & 0xffffffffULL);
        out.gi.individual_ptr[static_cast<std::size_t>(ind + 1)] += 1;
    }
    for (int i = 0; i < I; ++i) {
        out.gi.individual_ptr[static_cast<std::size_t>(i + 1)] +=
            out.gi.individual_ptr[static_cast<std::size_t>(i)];
    }
    std::vector<int> indiv_cursor = out.gi.individual_ptr;
    for (const uint64_t key : edges_by_group) {
        const int g = static_cast<int>(key >> 32);
        const int ind = static_cast<int>(key & 0xffffffffULL);
        out.gi.individual_group[static_cast<std::size_t>(indiv_cursor[static_cast<std::size_t>(ind)]++)] =
            g;
    }

    out.gi.group_scale.assign(static_cast<std::size_t>(G), 1.0);
    if (aggregation == GroupAggregation::Mean) {
        for (int g = 0; g < G; ++g) {
            const int size =
                out.gi.group_ptr[static_cast<std::size_t>(g + 1)] -
                out.gi.group_ptr[static_cast<std::size_t>(g)];
            if (size <= 0) {
                throw std::runtime_error("Invalid group with zero individuals");
            }
            out.gi.group_scale[static_cast<std::size_t>(g)] = 1.0 / static_cast<double>(size);
        }
    }

    return out;
}

struct GroupSingletonDropResult {
    std::vector<uint8_t> keep_groups;
    std::vector<int> individual_degrees;
    int dropped_groups = 0;
};

GroupSingletonDropResult drop_singletons_group_individual(
    const std::vector<Eigen::VectorXi>& standard_fes,
    const hdfe::detail::GroupIndividualStructure& gi,
    const Eigen::VectorXd* frequency_weights) {
    const int G = gi.num_groups;
    const int I = gi.num_individuals;
    GroupSingletonDropResult res;
    res.keep_groups.assign(static_cast<std::size_t>(G), 1);
    res.individual_degrees.assign(static_cast<std::size_t>(I), 0);

    if (G <= 0 || I <= 0) {
        return res;
    }
    if (static_cast<int>(gi.group_ptr.size()) != G + 1 ||
        static_cast<int>(gi.individual_ptr.size()) != I + 1) {
        throw std::runtime_error("Invalid group/individual structure");
    }

    std::vector<std::int64_t> group_frequency(
        static_cast<std::size_t>(G), INT64_C(1));
    if (frequency_weights) {
        if (frequency_weights->size() != G) {
            throw std::runtime_error(
                "Frequency weights must be group-level in group/individual mode");
        }
        (void)checked_frequency_weight_sum(
            *frequency_weights, &group_frequency);
    }

    // individual_degrees records structural group connections for rebuilding
    // the filtered graph.  singleton decisions use frequency_degree, which
    // is the degree in the literal fweight-expanded sample.
    std::vector<std::int64_t> frequency_degree(
        static_cast<std::size_t>(I), INT64_C(0));
    for (int i = 0; i < I; ++i) {
        res.individual_degrees[static_cast<std::size_t>(i)] =
            gi.individual_ptr[static_cast<std::size_t>(i + 1)] -
            gi.individual_ptr[static_cast<std::size_t>(i)];
        const int begin =
            gi.individual_ptr[static_cast<std::size_t>(i)];
        const int end =
            gi.individual_ptr[static_cast<std::size_t>(i + 1)];
        std::int64_t degree = 0;
        for (int pos = begin; pos < end; ++pos) {
            const int group =
                gi.individual_group[static_cast<std::size_t>(pos)];
            degree += group_frequency[static_cast<std::size_t>(group)];
        }
        frequency_degree[static_cast<std::size_t>(i)] = degree;
    }

    struct FeLevelIndex {
        FeLookup lookup;
        std::vector<int> level_id;
        std::vector<std::vector<int>> groups_by_level;
        std::vector<std::int64_t> counts;
    };

    std::vector<FeLevelIndex> feinfo;
    feinfo.reserve(standard_fes.size());
    for (const auto& fe : standard_fes) {
        if (fe.size() != G) {
            throw std::runtime_error("Standard fixed effects must be group-level (length #groups)");
        }
        FeLevelIndex info;
        info.lookup = build_lookup(fe);
        info.level_id.assign(static_cast<std::size_t>(G), 0);
        info.groups_by_level.assign(static_cast<std::size_t>(info.lookup.num_groups), {});
        for (int g = 0; g < G; ++g) {
            const int lid = info.lookup.index(fe(g));
            info.level_id[static_cast<std::size_t>(g)] = lid;
            info.groups_by_level[static_cast<std::size_t>(lid)].push_back(g);
        }
        info.counts.assign(
            static_cast<std::size_t>(info.lookup.num_groups), INT64_C(0));
        for (int g = 0; g < G; ++g) {
            const int lid = info.level_id[static_cast<std::size_t>(g)];
            info.counts[static_cast<std::size_t>(lid)] +=
                group_frequency[static_cast<std::size_t>(g)];
        }
        feinfo.push_back(std::move(info));
    }

    std::vector<uint8_t> in_queue(static_cast<std::size_t>(G), 0);
    std::deque<int> queue;
    auto enqueue_group = [&](int g) {
        if (g < 0 || g >= G) {
            return;
        }
        if (!res.keep_groups[static_cast<std::size_t>(g)] ||
            in_queue[static_cast<std::size_t>(g)]) {
            return;
        }
        in_queue[static_cast<std::size_t>(g)] = 1;
        queue.push_back(g);
    };

    for (int g = 0; g < G; ++g) {
        bool singleton = false;
        for (const auto& info : feinfo) {
            const int lid = info.level_id[static_cast<std::size_t>(g)];
            if (info.counts[static_cast<std::size_t>(lid)] == 1) {
                singleton = true;
                break;
            }
        }
        if (singleton) {
            enqueue_group(g);
        }
    }

    for (int i = 0; i < I; ++i) {
        if (frequency_degree[static_cast<std::size_t>(i)] == 1) {
            const int only =
                gi.individual_group[static_cast<std::size_t>(gi.individual_ptr[static_cast<std::size_t>(i)])];
            enqueue_group(only);
        }
    }

    while (!queue.empty()) {
        const int g = queue.front();
        queue.pop_front();
        in_queue[static_cast<std::size_t>(g)] = 0;
        if (!res.keep_groups[static_cast<std::size_t>(g)]) {
            continue;
        }

        res.keep_groups[static_cast<std::size_t>(g)] = 0;
        res.dropped_groups += 1;
        const std::int64_t dropped_frequency =
            group_frequency[static_cast<std::size_t>(g)];

        for (auto& info : feinfo) {
            const int lid = info.level_id[static_cast<std::size_t>(g)];
            std::int64_t& count =
                info.counts[static_cast<std::size_t>(lid)];
            if (count <= 0) {
                continue;
            }
            count -= dropped_frequency;
            if (count == 1) {
                int remaining = -1;
                for (const int gg : info.groups_by_level[static_cast<std::size_t>(lid)]) {
                    if (res.keep_groups[static_cast<std::size_t>(gg)]) {
                        remaining = gg;
                        break;
                    }
                }
                enqueue_group(remaining);
            }
        }

        const int begin = gi.group_ptr[static_cast<std::size_t>(g)];
        const int end = gi.group_ptr[static_cast<std::size_t>(g + 1)];
        for (int pos = begin; pos < end; ++pos) {
            const int i = gi.group_individual[static_cast<std::size_t>(pos)];
            int& deg = res.individual_degrees[static_cast<std::size_t>(i)];
            if (deg <= 0) {
                continue;
            }
            deg -= 1;
            std::int64_t& weighted_degree =
                frequency_degree[static_cast<std::size_t>(i)];
            weighted_degree -= dropped_frequency;
            if (weighted_degree == 1) {
                int remaining = -1;
                const int ibegin = gi.individual_ptr[static_cast<std::size_t>(i)];
                const int iend = gi.individual_ptr[static_cast<std::size_t>(i + 1)];
                for (int k = ibegin; k < iend; ++k) {
                    const int gg = gi.individual_group[static_cast<std::size_t>(k)];
                    if (res.keep_groups[static_cast<std::size_t>(gg)]) {
                        remaining = gg;
                        break;
                    }
                }
                enqueue_group(remaining);
            }
        }
    }

    return res;
}

GroupCollapsedData filter_group_collapsed(const GroupCollapsedData& data,
                                          const std::vector<uint8_t>& keep_groups,
                                          const std::vector<int>& individual_degrees,
                                          GroupAggregation aggregation) {
    const int G = data.gi.num_groups;
    const int I = data.gi.num_individuals;
    if (static_cast<int>(keep_groups.size()) != G) {
        throw std::runtime_error("Invalid keep mask for group filtering");
    }
    if (static_cast<int>(individual_degrees.size()) != I) {
        throw std::runtime_error("Invalid individual degree vector for group filtering");
    }

    std::vector<int> group_new(static_cast<std::size_t>(G), -1);
    int new_G = 0;
    for (int g = 0; g < G; ++g) {
        if (keep_groups[static_cast<std::size_t>(g)]) {
            group_new[static_cast<std::size_t>(g)] = new_G++;
        }
    }

    std::vector<int> ind_new(static_cast<std::size_t>(I), -1);
    int new_I = 0;
    for (int i = 0; i < I; ++i) {
        if (individual_degrees[static_cast<std::size_t>(i)] > 0) {
            ind_new[static_cast<std::size_t>(i)] = new_I++;
        }
    }

    GroupCollapsedData out;
    out.y = Eigen::VectorXd::Zero(new_G);
    out.X = Eigen::MatrixXd::Zero(new_G, data.X.cols());
    out.group_values = Eigen::VectorXi::Zero(new_G);
    if (data.individual_values.size() > 0) {
        out.individual_values = Eigen::VectorXi::Zero(new_I);
    }
    out.standard_fes.clear();
    out.standard_fes.reserve(data.standard_fes.size());
    for (const auto& fe : data.standard_fes) {
        (void)fe;
        out.standard_fes.emplace_back(Eigen::VectorXi::Zero(new_G));
    }
    if (data.weights) {
        out.weights = Eigen::VectorXd::Zero(new_G);
    }
    if (data.clusters) {
        out.clusters = std::vector<Eigen::VectorXi>{};
        out.clusters->reserve(data.clusters->size());
        for (std::size_t j = 0; j < data.clusters->size(); ++j) {
            out.clusters->emplace_back(Eigen::VectorXi::Zero(new_G));
        }
    }
    if (!data.rep_row.empty()) {
        if (static_cast<int>(data.rep_row.size()) != G) {
            throw std::runtime_error("Invalid rep_row size for group filtering");
        }
        out.rep_row.assign(static_cast<std::size_t>(new_G), 0);
    }

    for (int g = 0; g < G; ++g) {
        const int ng = group_new[static_cast<std::size_t>(g)];
        if (ng < 0) {
            continue;
        }
        out.y(ng) = data.y(g);
        out.X.row(ng) = data.X.row(g);
        if (data.group_values.size() == G) {
            out.group_values(ng) = data.group_values(g);
        }
        if (!out.rep_row.empty()) {
            out.rep_row[static_cast<std::size_t>(ng)] = data.rep_row[static_cast<std::size_t>(g)];
        }
        if (out.weights) {
            (*out.weights)(ng) = (*data.weights)(g);
        }
        if (out.clusters) {
            for (std::size_t j = 0; j < out.clusters->size(); ++j) {
                (*out.clusters)[j](ng) = (*data.clusters)[j](g);
            }
        }
        for (std::size_t d = 0; d < out.standard_fes.size(); ++d) {
            out.standard_fes[d](ng) = data.standard_fes[d](g);
        }
    }
    if (out.individual_values.size() == new_I && data.individual_values.size() == I) {
        for (int i = 0; i < I; ++i) {
            const int ni = ind_new[static_cast<std::size_t>(i)];
            if (ni >= 0) {
                out.individual_values(ni) = data.individual_values(i);
            }
        }
    }

    out.gi.num_groups = new_G;
    out.gi.num_individuals = new_I;
    out.gi.group_ptr.assign(static_cast<std::size_t>(new_G) + 1, 0);
    for (int g = 0; g < G; ++g) {
        const int ng = group_new[static_cast<std::size_t>(g)];
        if (ng < 0) {
            continue;
        }
        const int begin = data.gi.group_ptr[static_cast<std::size_t>(g)];
        const int end = data.gi.group_ptr[static_cast<std::size_t>(g + 1)];
        int count = 0;
        for (int pos = begin; pos < end; ++pos) {
            const int ni = ind_new[static_cast<std::size_t>(
                data.gi.group_individual[static_cast<std::size_t>(pos)])];
            if (ni >= 0) {
                ++count;
            }
        }
        out.gi.group_ptr[static_cast<std::size_t>(ng + 1)] = count;
    }
    for (int g = 0; g < new_G; ++g) {
        out.gi.group_ptr[static_cast<std::size_t>(g + 1)] +=
            out.gi.group_ptr[static_cast<std::size_t>(g)];
    }
    out.gi.group_individual.assign(static_cast<std::size_t>(out.gi.group_ptr.back()), 0);
    std::vector<int> cursor = out.gi.group_ptr;
    for (int g = 0; g < G; ++g) {
        const int ng = group_new[static_cast<std::size_t>(g)];
        if (ng < 0) {
            continue;
        }
        const int begin = data.gi.group_ptr[static_cast<std::size_t>(g)];
        const int end = data.gi.group_ptr[static_cast<std::size_t>(g + 1)];
        for (int pos = begin; pos < end; ++pos) {
            const int ni = ind_new[static_cast<std::size_t>(
                data.gi.group_individual[static_cast<std::size_t>(pos)])];
            if (ni < 0) {
                continue;
            }
            out.gi.group_individual[static_cast<std::size_t>(cursor[static_cast<std::size_t>(ng)]++)] =
                ni;
        }
    }

    out.gi.individual_ptr.assign(static_cast<std::size_t>(new_I) + 1, 0);
    for (int g = 0; g < new_G; ++g) {
        const int begin = out.gi.group_ptr[static_cast<std::size_t>(g)];
        const int end = out.gi.group_ptr[static_cast<std::size_t>(g + 1)];
        for (int pos = begin; pos < end; ++pos) {
            const int ni = out.gi.group_individual[static_cast<std::size_t>(pos)];
            out.gi.individual_ptr[static_cast<std::size_t>(ni + 1)] += 1;
        }
    }
    for (int i = 0; i < new_I; ++i) {
        out.gi.individual_ptr[static_cast<std::size_t>(i + 1)] +=
            out.gi.individual_ptr[static_cast<std::size_t>(i)];
    }
    out.gi.individual_group.assign(static_cast<std::size_t>(out.gi.group_ptr.back()), 0);
    std::vector<int> icursor = out.gi.individual_ptr;
    for (int g = 0; g < new_G; ++g) {
        const int begin = out.gi.group_ptr[static_cast<std::size_t>(g)];
        const int end = out.gi.group_ptr[static_cast<std::size_t>(g + 1)];
        for (int pos = begin; pos < end; ++pos) {
            const int ni = out.gi.group_individual[static_cast<std::size_t>(pos)];
            out.gi.individual_group[static_cast<std::size_t>(icursor[static_cast<std::size_t>(ni)]++)] =
                g;
        }
    }

    out.gi.group_scale.assign(static_cast<std::size_t>(new_G), 1.0);
    if (aggregation == GroupAggregation::Mean) {
        for (int g = 0; g < new_G; ++g) {
            const int size =
                out.gi.group_ptr[static_cast<std::size_t>(g + 1)] -
                out.gi.group_ptr[static_cast<std::size_t>(g)];
            if (size <= 0) {
                throw std::runtime_error("Invalid group with zero individuals after filtering");
            }
            out.gi.group_scale[static_cast<std::size_t>(g)] = 1.0 / static_cast<double>(size);
        }
    }

    return out;
}

void drop_zero_weight_groups(GroupCollapsedData& data, GroupAggregation aggregation,
                             bool frequency_weights) {
    if (!data.weights || frequency_weights) return;
    int zero_count = 0;
    for (int g = 0; g < data.weights->size(); ++g)
        zero_count += (detail::ieee_bits_detail::bits((*data.weights)[g]) &
                       UINT64_C(0x7fffffffffffffff)) == 0;
    if (!zero_count) return;
    const auto rows = positive_weight_rows(*data.weights, zero_count);
    std::vector<uint8_t> keep(static_cast<std::size_t>(data.gi.num_groups), 0);
    std::vector<int> degrees(static_cast<std::size_t>(data.gi.num_individuals), 0);
    for (int g : rows) {
        keep[static_cast<std::size_t>(g)] = 1;
        for (int pos = data.gi.group_ptr[static_cast<std::size_t>(g)];
             pos < data.gi.group_ptr[static_cast<std::size_t>(g+1)]; ++pos)
            ++degrees[static_cast<std::size_t>(data.gi.group_individual[static_cast<std::size_t>(pos)])];
    }
    data = filter_group_collapsed(data, keep, degrees, aggregation);
}

struct FeIndexMap {
    Eigen::VectorXi level_index;  // length G: 0..L-1
    Eigen::VectorXi raw_values;   // length L: raw ids for each level
    std::vector<int> level_ptr;   // length L+1: stable groups-by-level CSR
    std::vector<int> level_groups;
};

FeIndexMap build_fe_index_map(const Eigen::VectorXi& raw_ids) {
    const int n = static_cast<int>(raw_ids.size());
    if (n == 0) {
        return FeIndexMap{};
    }
    std::unordered_map<int, int> map;
    map.reserve(static_cast<std::size_t>(n));
    std::vector<int> raw_values;
    raw_values.reserve(static_cast<std::size_t>(n));
    Eigen::VectorXi idx(n);
    int next = 0;
    for (int i = 0; i < n; ++i) {
        const int raw = raw_ids(i);
        auto it = map.find(raw);
        if (it == map.end()) {
            map.emplace(raw, next);
            raw_values.push_back(raw);
            idx(i) = next;
            ++next;
        } else {
            idx(i) = it->second;
        }
    }

    Eigen::VectorXi levels(next);
    for (int i = 0; i < next; ++i) {
        levels(i) = raw_values[static_cast<std::size_t>(i)];
    }
    std::vector<int> level_ptr(static_cast<std::size_t>(next + 1), 0);
    for (int g = 0; g < n; ++g) {
        ++level_ptr[static_cast<std::size_t>(idx(g) + 1)];
    }
    for (int lid = 0; lid < next; ++lid) {
        level_ptr[static_cast<std::size_t>(lid + 1)] +=
            level_ptr[static_cast<std::size_t>(lid)];
    }
    std::vector<int> level_groups(static_cast<std::size_t>(n));
    std::vector<int> next_position = level_ptr;
    for (int g = 0; g < n; ++g) {
        const int lid = idx(g);
        level_groups[static_cast<std::size_t>(
            next_position[static_cast<std::size_t>(lid)]++)] = g;
    }
    FeIndexMap out;
    out.level_index = std::move(idx);
    out.raw_values = std::move(levels);
    out.level_ptr = std::move(level_ptr);
    out.level_groups = std::move(level_groups);
    return out;
}

void gi_group_sum(const hdfe::detail::GroupIndividualStructure& gi,
                  const Eigen::VectorXd& x,
                  Eigen::VectorXd& out,
                  int threads,
                  detail::ParallelWorkObserver* observer) {
    const int G = gi.num_groups;
    if (G <= 0) {
        out.resize(0);
        return;
    }
    if (x.size() != gi.num_individuals) {
        throw std::runtime_error("gi_group_sum: x must be length num_individuals");
    }
    if (static_cast<int>(gi.group_ptr.size()) != G + 1) {
        throw std::runtime_error("gi_group_sum: invalid group_ptr size");
    }
    if (static_cast<int>(gi.group_scale.size()) != G) {
        throw std::runtime_error("gi_group_sum: invalid group_scale size");
    }
    out.setZero(G);
#ifdef HDFE_USE_OPENMP
    const int local_threads = std::max(1, threads);
#else
    (void)threads;
#endif
    if (observer) {
        observer->begin_region(
#ifdef HDFE_USE_OPENMP
            local_threads
#else
            1
#endif
        );
    }
#ifndef HDFE_USE_OPENMP
    if (observer) {
        observer->observe_work();
    }
#else
#pragma omp parallel for schedule(static) num_threads(local_threads)
#endif
    for (int g = 0; g < G; ++g) {
#ifdef HDFE_USE_OPENMP
        if (observer) {
            observer->observe_work();
        }
#endif
        const int begin = gi.group_ptr[static_cast<std::size_t>(g)];
        const int end = gi.group_ptr[static_cast<std::size_t>(g + 1)];
        double sum = 0.0;
        for (int pos = begin; pos < end; ++pos) {
            const int i = gi.group_individual[static_cast<std::size_t>(pos)];
            sum += x(i);
        }
        out(g) = gi.group_scale[static_cast<std::size_t>(g)] * sum;
    }
    if (observer) {
        observer->end_region();
    }
}

void gi_individual_sum(const hdfe::detail::GroupIndividualStructure& gi,
                       const Eigen::VectorXd& x,
                       Eigen::VectorXd& out,
                       int threads,
                       detail::ParallelWorkObserver* observer) {
    const int I = gi.num_individuals;
    if (I <= 0) {
        out.resize(0);
        return;
    }
    if (x.size() != gi.num_groups) {
        throw std::runtime_error("gi_individual_sum: x must be length num_groups");
    }
    if (static_cast<int>(gi.individual_ptr.size()) != I + 1) {
        throw std::runtime_error("gi_individual_sum: invalid individual_ptr size");
    }
    if (static_cast<int>(gi.group_scale.size()) != gi.num_groups) {
        throw std::runtime_error("gi_individual_sum: invalid group_scale size");
    }
    out.setZero(I);
#ifdef HDFE_USE_OPENMP
    const int local_threads = std::max(1, threads);
#else
    (void)threads;
#endif
    if (observer) {
        observer->begin_region(
#ifdef HDFE_USE_OPENMP
            local_threads
#else
            1
#endif
        );
    }
#ifndef HDFE_USE_OPENMP
    if (observer) {
        observer->observe_work();
    }
#else
#pragma omp parallel for schedule(static) num_threads(local_threads)
#endif
    for (int i = 0; i < I; ++i) {
#ifdef HDFE_USE_OPENMP
        if (observer) {
            observer->observe_work();
        }
#endif
        const int begin = gi.individual_ptr[static_cast<std::size_t>(i)];
        const int end = gi.individual_ptr[static_cast<std::size_t>(i + 1)];
        double sum = 0.0;
        for (int pos = begin; pos < end; ++pos) {
            const int g = gi.individual_group[static_cast<std::size_t>(pos)];
            sum += gi.group_scale[static_cast<std::size_t>(g)] * x(g);
        }
        out(i) = sum;
    }
    if (observer) {
        observer->end_region();
    }
}

Eigen::VectorXd gi_preconditioner(const hdfe::detail::GroupIndividualStructure& gi,
                                  const Eigen::VectorXd* weights,
                                  int threads,
                                  detail::ParallelWorkObserver* observer) {
    const int I = gi.num_individuals;
    const int G = gi.num_groups;
    if (I <= 0 || G <= 0) {
        return Eigen::VectorXd{};
    }
    if (weights && weights->size() != G) {
        throw std::runtime_error("gi_preconditioner: weights must be length num_groups");
    }
    if (static_cast<int>(gi.individual_ptr.size()) != I + 1) {
        throw std::runtime_error("gi_preconditioner: invalid individual_ptr size");
    }
    Eigen::VectorXd diag = Eigen::VectorXd::Ones(I);
#ifdef HDFE_USE_OPENMP
    const int local_threads = std::max(1, threads);
#else
    (void)threads;
#endif
    if (observer) {
        observer->begin_region(
#ifdef HDFE_USE_OPENMP
            local_threads
#else
            1
#endif
        );
    }
#ifndef HDFE_USE_OPENMP
    if (observer) {
        observer->observe_work();
    }
#else
#pragma omp parallel for schedule(static) num_threads(local_threads)
#endif
    for (int i = 0; i < I; ++i) {
#ifdef HDFE_USE_OPENMP
        if (observer) {
            observer->observe_work();
        }
#endif
        const int begin = gi.individual_ptr[static_cast<std::size_t>(i)];
        const int end = gi.individual_ptr[static_cast<std::size_t>(i + 1)];
        double acc = 0.0;
        for (int pos = begin; pos < end; ++pos) {
            const int g = gi.individual_group[static_cast<std::size_t>(pos)];
            const double scale = gi.group_scale[static_cast<std::size_t>(g)];
            const double w = weights ? (*weights)(g) : 1.0;
            acc += w * scale * scale;
        }
        diag(i) = acc > 0.0 ? acc : 1.0;
    }
    if (observer) {
        observer->end_region();
    }
    return diag;
}

Eigen::VectorXd accel_a1(const Eigen::VectorXd& x3,
                         const Eigen::VectorXd& x2,
                         const Eigen::VectorXd& x1,
                         int accel,
                         double a1p1,
                         double a2p1,
                         int a2p2) {
    if (accel == 1) {
        return x3 + a1p1 * (x2 - x1);
    }
    if (accel != 2) {
        return x3;
    }

    const Eigen::ArrayXd x3a = x3.array();
    const Eigen::ArrayXd x2a = x2.array();
    const Eigen::ArrayXd x1a = x1.array();
    const Eigen::ArrayXd d1 = x2a - x1a;
    const Eigen::ArrayXd d2 = x3a - x2a;
    const Eigen::ArrayXd c1 =
        (x3a > x2a).cast<double>() * (x2a > x1a).cast<double>() *
        ((x3a + x1a) < (2.0 * x2a)).cast<double>();
    const Eigen::ArrayXd c2 =
        (x3a < x2a).cast<double>() * (x2a < x1a).cast<double>() *
        ((x3a + x1a) > (2.0 * x2a)).cast<double>();
    const Eigen::ArrayXd ratio = d2 / d1;
    const Eigen::ArrayXd dum =
        x2a - ((d2 * d1) / (d2 - d1)) * (1.0 - ratio.pow(static_cast<double>(a2p2)));
    const Eigen::ArrayXd mask =
        ((c1 + c2) > 0.5).cast<double>() * (d1.abs() > a2p1).cast<double>() *
        ((d2 - d1).abs() > a2p1).cast<double>();
    return (mask > 0.5).select(dum, x3a).matrix();
}

void update_standard_fe(const Eigen::VectorXd& residual,
                        const FeIndexMap& map,
                        const Eigen::VectorXd* weights,
                        Eigen::VectorXd& level_values,
                        Eigen::VectorXd& group_values,
                        int threads,
                        detail::ParallelWorkObserver* observer) {
    const int G = static_cast<int>(residual.size());
    if (map.level_index.size() != G) {
        throw std::runtime_error("update_standard_fe: FE index length mismatch");
    }
    if (weights && weights->size() != G) {
        throw std::runtime_error("update_standard_fe: weights length mismatch");
    }
    const int L = static_cast<int>(map.raw_values.size());
    level_values.setZero(L);
    if (static_cast<int>(map.level_ptr.size()) != L + 1 ||
        static_cast<int>(map.level_groups.size()) != G) {
        throw std::runtime_error("update_standard_fe: invalid groups-by-level index");
    }
#ifdef HDFE_USE_OPENMP
    const int local_threads = std::max(1, threads);
#else
    (void)threads;
#endif
    if (observer) {
        observer->begin_region(
#ifdef HDFE_USE_OPENMP
            local_threads
#else
            1
#endif
        );
    }
#ifndef HDFE_USE_OPENMP
    if (observer) {
        observer->observe_work();
    }
#else
#pragma omp parallel for schedule(static) num_threads(local_threads)
#endif
    for (int lid = 0; lid < L; ++lid) {
        if (observer) {
            observer->observe_work();
        }
        double numerator = 0.0;
        double denom = 0.0;
        const int begin = map.level_ptr[static_cast<std::size_t>(lid)];
        const int end = map.level_ptr[static_cast<std::size_t>(lid + 1)];
        for (int pos = begin; pos < end; ++pos) {
            const int g = map.level_groups[static_cast<std::size_t>(pos)];
            const double w = weights ? (*weights)(g) : 1.0;
            numerator += w * residual(g);
            denom += w;
        }
        if (denom > 0.0) {
            level_values(lid) = numerator / denom;
        } else {
            level_values(lid) = 0.0;
        }
    }
    if (observer) {
        observer->end_region();
    }
    group_values.resize(G);
    if (observer) {
        observer->begin_region(
#ifdef HDFE_USE_OPENMP
            local_threads
#else
            1
#endif
        );
    }
#ifndef HDFE_USE_OPENMP
    if (observer) {
        observer->observe_work();
    }
#else
#pragma omp parallel for schedule(static) num_threads(local_threads)
#endif
    for (int g = 0; g < G; ++g) {
#ifdef HDFE_USE_OPENMP
        if (observer) {
            observer->observe_work();
        }
#endif
        group_values(g) = level_values(map.level_index(g));
    }
    if (observer) {
        observer->end_region();
    }
}

Eigen::VectorXd solve_a1(Eigen::VectorXd x,
                         const hdfe::detail::GroupIndividualStructure& gi,
                         const Eigen::VectorXd& dd,
                         const Eigen::VectorXd* weights,
                         const Eigen::VectorXd& precond,
                         int max_iter,
                         double tol,
                         int verbose,
                         int threads,
                         detail::ParallelWorkObserver* observer) {
    const int I = gi.num_individuals;
    const int G = gi.num_groups;
    if (dd.size() != G) {
        throw std::runtime_error("solve_a1: dd must be length num_groups");
    }
    if (weights && weights->size() != G) {
        throw std::runtime_error("solve_a1: weights must be length num_groups");
    }
    if (precond.size() != I) {
        throw std::runtime_error("solve_a1: preconditioner must be length num_individuals");
    }
    if (x.size() != I) {
        throw std::runtime_error("solve_a1: initial x must be length num_individuals");
    }

    Eigen::VectorXd tmp_group(G);
    Eigen::VectorXd ax(I);
    gi_group_sum(gi, x, tmp_group, threads, observer);
    if (weights) {
        tmp_group.array() *= weights->array();
    }
    gi_individual_sum(gi, tmp_group, ax, threads, observer);

    Eigen::VectorXd rhs_group = dd;
    if (weights) {
        rhs_group.array() *= weights->array();
    }
    Eigen::VectorXd b(I);
    gi_individual_sum(gi, rhs_group, b, threads, observer);

    Eigen::VectorXd r = b - ax;
    Eigen::VectorXd z = r.array() / precond.array();
    Eigen::VectorXd p = z;
    double rsold = r.dot(z);

    Eigen::VectorXd q(I);
    int it = 0;
    while (std::sqrt(rsold) > tol && it < max_iter) {
        gi_group_sum(gi, p, tmp_group, threads, observer);
        if (weights) {
            tmp_group.array() *= weights->array();
        }
        gi_individual_sum(gi, tmp_group, q, threads, observer);
        const double denom = p.dot(q);
        if (!hdfe::detail::ieee_finite(denom) || denom == 0.0) {
            break;
        }
        const double alpha = rsold / denom;
        x.noalias() += alpha * p;
        r.noalias() -= alpha * q;
        z = r.array() / precond.array();
        const double rsnew = r.dot(z);
        const double beta = rsnew / rsold;
        p = z + beta * p;
        rsold = rsnew;
        ++it;
        if (verbose > 1) {
            std::cout << "subiterations (" << it << ") dif=" << std::sqrt(rsold) << "\n";
        }
    }
    if (verbose > 0) {
        std::cout << "subiterations (" << it << ") tol=" << tol << "\n";
    }
    return x;
}

double weighted_mse(const Eigen::VectorXd& r, const Eigen::VectorXd* weights) {
    if (!weights) {
        return r.size() > 0 ? r.squaredNorm() / static_cast<double>(r.size()) : 0.0;
    }
    const double sumw = weights->sum();
    if (sumw <= 0.0) {
        throw std::runtime_error("Weights must sum to a positive value");
    }
    return (r.array().square() * weights->array()).sum() / sumw;
}

int find_matching_fe_index(const Eigen::VectorXi& clusters,
                           const std::vector<Eigen::VectorXi>& fes) {
    for (std::size_t d = 0; d < fes.size(); ++d) {
        const auto& fe = fes[d];
        if (fe.size() != clusters.size()) {
            continue;
        }
        bool same = true;
        for (int i = 0; i < clusters.size(); ++i) {
            if (clusters(i) != fe(i)) {
                same = false;
                break;
            }
        }
        if (same) {
            return static_cast<int>(d);
        }
    }
    return -1;
}

// The two full scans of fe_nested_within_cluster (identity with the cluster
// vector, bounds of fe) by blocks on a team: a flag per region and an exact
// minimum and maximum per block, combined in block order. Serial below
// kNestedScanMinRows rows or with one thread.
constexpr int kNestedScanMinRows = 1 << 20;
constexpr int kNestedScanBlock = 1 << 16;

int nested_scan_blocks(int n) {
    return n / kNestedScanBlock + (n % kNestedScanBlock != 0);
}

int nested_scan_team(int n, int threads) {
    int team = 1;
#ifdef HDFE_USE_OPENMP
    if (!omp_in_parallel() && n >= kNestedScanMinRows) {
        team = std::max(1, std::min(threads, nested_scan_blocks(n)));
    }
#else
    (void)n;
    (void)threads;
#endif
    return team;
}

bool equal_by_blocks(const int* a, const int* b, int n, int team,
                     detail::ParallelWorkObserver& observer) {
    const int blocks = nested_scan_blocks(n);
    std::atomic<int> differ{0};
    observer.begin_region(team);
#ifdef HDFE_USE_OPENMP
#pragma omp parallel for schedule(static) num_threads(team)
#else
    (void)team;
#endif
    for (int block = 0; block < blocks; ++block) {
        if (differ.load(std::memory_order_relaxed)) {
            continue;
        }
        const int lo = block * kNestedScanBlock;
        const int hi = lo + std::min(n - lo, kNestedScanBlock);
        observer.observe_work();
        for (int i = lo; i < hi; ++i) {
            if (a[i] != b[i]) {
                differ.store(1, std::memory_order_relaxed);
                break;
            }
        }
    }
    observer.end_region();
    return differ.load() == 0;
}

void bounds_by_blocks(const int* a, int n, int team, int& min_out, int& max_out,
                      detail::ParallelWorkObserver& observer) {
    const int blocks = nested_scan_blocks(n);
    std::vector<int> low(static_cast<std::size_t>(blocks));
    std::vector<int> high(static_cast<std::size_t>(blocks));
    observer.begin_region(team);
#ifdef HDFE_USE_OPENMP
#pragma omp parallel for schedule(static) num_threads(team)
#else
    (void)team;
#endif
    for (int block = 0; block < blocks; ++block) {
        const int lo = block * kNestedScanBlock;
        const int hi = lo + std::min(n - lo, kNestedScanBlock);
        observer.observe_work();
        int minimum = a[lo];
        int maximum = a[lo];
        for (int i = lo + 1; i < hi; ++i) {
            minimum = std::min(minimum, a[i]);
            maximum = std::max(maximum, a[i]);
        }
        low[static_cast<std::size_t>(block)] = minimum;
        high[static_cast<std::size_t>(block)] = maximum;
    }
    observer.end_region();
    min_out = low[0];
    max_out = high[0];
    for (int block = 1; block < blocks; ++block) {
        min_out = std::min(min_out, low[static_cast<std::size_t>(block)]);
        max_out = std::max(max_out, high[static_cast<std::size_t>(block)]);
    }
}

bool fe_nested_within_cluster(const Eigen::VectorXi& fe,
                              const Eigen::VectorXi& clusters,
                              int threads = 1,
                              detail::ParallelWorkObserver* observer = nullptr) {
    if (fe.size() != clusters.size()) {
        return false;
    }
    const int n = fe.size();
    if (n == 0) {
        return true;
    }
    if (fe.data() == clusters.data()) {
        return true;
    }
    const int team = observer ? nested_scan_team(n, threads) : 1;
    if (fe(0) == clusters(0) && fe(n / 2) == clusters(n / 2) &&
        fe(n - 1) == clusters(n - 1)) {
        bool identical = true;
        if (team > 1) {
            identical = equal_by_blocks(fe.data(), clusters.data(), n, team, *observer);
        } else {
            for (int i = 0; i < n; ++i) {
                if (fe(i) != clusters(i)) {
                    identical = false;
                    break;
                }
            }
        }
        if (identical) {
            return true;
        }
    }
    int min_id = fe(0);
    int max_id = fe(0);
    if (team > 1) {
        bounds_by_blocks(fe.data(), n, team, min_id, max_id, *observer);
    } else {
        for (int i = 1; i < n; ++i) {
            const int v = fe(i);
            min_id = std::min(min_id, v);
            max_id = std::max(max_id, v);
        }
    }
    const long long range_ll =
        static_cast<long long>(max_id) - static_cast<long long>(min_id) + 1LL;
    constexpr long long kDenseRangeCap = 50000000LL;
    const bool dense_ok =
        min_id >= 0 && range_ll > 0 && range_ll <= kDenseRangeCap &&
        range_ll <= static_cast<long long>(n) * 2LL;
    if (dense_ok) {
        const int range = static_cast<int>(range_ll);
        std::vector<int> mapping(static_cast<std::size_t>(range), 0);
        std::vector<uint8_t> seen(static_cast<std::size_t>(range), 0);
        for (int i = 0; i < n; ++i) {
            const int idx = fe(i) - min_id;
            const int cl_id = clusters(i);
            if (!seen[static_cast<std::size_t>(idx)]) {
                seen[static_cast<std::size_t>(idx)] = 1;
                mapping[static_cast<std::size_t>(idx)] = cl_id;
            } else if (mapping[static_cast<std::size_t>(idx)] != cl_id) {
                return false;
            }
        }
        return true;
    }

    std::unordered_map<int, int> mapping;
    mapping.reserve(static_cast<std::size_t>(n));
    for (int i = 0; i < n; ++i) {
        const int fe_id = fe(i);
        const int cl_id = clusters(i);
        auto it = mapping.find(fe_id);
        if (it == mapping.end()) {
            mapping.emplace(fe_id, cl_id);
        } else if (it->second != cl_id) {
            return false;
        }
    }
    return true;
}

double normal_ppf(double p) {
    if (!(p > 0.0 && p < 1.0)) {
        throw std::runtime_error("normal_ppf requires p in (0, 1)");
    }
    // Peter J. Acklam's inverse normal CDF approximation.
    constexpr double a1 = -3.969683028665376e+01;
    constexpr double a2 = 2.209460984245205e+02;
    constexpr double a3 = -2.759285104469687e+02;
    constexpr double a4 = 1.383577518672690e+02;
    constexpr double a5 = -3.066479806614716e+01;
    constexpr double a6 = 2.506628277459239e+00;

    constexpr double b1 = -5.447609879822406e+01;
    constexpr double b2 = 1.615858368580409e+02;
    constexpr double b3 = -1.556989798598866e+02;
    constexpr double b4 = 6.680131188771972e+01;
    constexpr double b5 = -1.328068155288572e+01;

    constexpr double c1 = -7.784894002430293e-03;
    constexpr double c2 = -3.223964580411365e-01;
    constexpr double c3 = -2.400758277161838e+00;
    constexpr double c4 = -2.549732539343734e+00;
    constexpr double c5 = 4.374664141464968e+00;
    constexpr double c6 = 2.938163982698783e+00;

    constexpr double d1 = 7.784695709041462e-03;
    constexpr double d2 = 3.224671290700398e-01;
    constexpr double d3 = 2.445134137142996e+00;
    constexpr double d4 = 3.754408661907416e+00;

    constexpr double plow = 0.02425;
    constexpr double phigh = 1.0 - plow;

    if (p < plow) {
        const double q = std::sqrt(-2.0 * std::log(p));
        return (((((c1 * q + c2) * q + c3) * q + c4) * q + c5) * q + c6) /
               ((((d1 * q + d2) * q + d3) * q + d4) * q + 1.0);
    }
    if (p <= phigh) {
        const double q = p - 0.5;
        const double r = q * q;
        return (((((a1 * r + a2) * r + a3) * r + a4) * r + a5) * r + a6) * q /
               (((((b1 * r + b2) * r + b3) * r + b4) * r + b5) * r + 1.0);
    }
    const double q = std::sqrt(-2.0 * std::log(1.0 - p));
    return -(((((c1 * q + c2) * q + c3) * q + c4) * q + c5) * q + c6) /
           ((((d1 * q + d2) * q + d3) * q + d4) * q + 1.0);
}

double normal_critical_value(double level_percent) {
    if (!(level_percent > 0.0 && level_percent < 100.0)) {
        throw std::runtime_error("level must be between 0 and 100");
    }
    const double p = 0.5 + (level_percent / 200.0);
    return normal_ppf(p);
}

double student_t_cdf(double t, double df) {
    if (!(df > 0.0) || !hdfe::detail::ieee_finite(df)) {
        return std::numeric_limits<double>::quiet_NaN();
    }
    if (!hdfe::detail::ieee_finite(t)) {
        return std::numeric_limits<double>::quiet_NaN();
    }
    const double probability =
        hdfe::detail::student_t_internal::two_sided_probability(
            std::abs(t), df);
    return t > 0.0 ? 1.0 - 0.5 * probability : 0.5 * probability;
}

double student_t_inv_cdf(double p, double df) {
    return hdfe::detail::student_t_internal::inverse_cdf(p, df);
}

double student_t_critical_value(double level_percent, double df) {
    if (!(level_percent > 0.0 && level_percent < 100.0)) {
        throw std::runtime_error("level must be between 0 and 100");
    }
    if (!(df > 0.0) || !hdfe::detail::ieee_finite(df)) {
        return std::numeric_limits<double>::quiet_NaN();
    }
    const double upper_tail = (100.0 - level_percent) / 200.0;
    return hdfe::detail::student_t_internal::inverse_survival(
        upper_tail, df);
}

// When inference is unavailable (a saturated/over-specified model or fewer
// than two clusters), regress/reghdfe report missing standard errors, t,
// p-values, confidence intervals and F-statistic while retaining point
// estimates. Mirror that behaviour here: convert covariance diagonals for
// non-omitted coefficients to a sentinel below -kVDiagZeroEps so Stata's
// sqrt(V[j,j]) is missing, and mark the public inferential vectors as NaN.
// Off-diagonals are cleaned to 0 so `ereturn post` accepts the matrix.
void mark_inference_unavailable(hdfe::HdfeResults& results) {
    constexpr double kVDiagSentinel = -1.0e-10;  // below the 1e-12 fix-to-zero threshold
    const double nan = std::numeric_limits<double>::quiet_NaN();
    const int n_coef = static_cast<int>(results.coefficients.size());
    for (int j = 0; j < n_coef; ++j) {
        const bool is_omitted =
            (j < static_cast<int>(results.omitted_reason.size()) &&
             results.omitted_reason[j] != 0);
        if (is_omitted) {
            continue;
        }
        const double vjj = results.covariance(j, j);
        if (!(hdfe::detail::ieee_finite(vjj) && vjj <= kVDiagSentinel)) {
            results.covariance(j, j) = kVDiagSentinel;
        }
        if (j < results.std_errors.size()) {
            results.std_errors(j) = nan;
        }
        if (j < results.tvalues.size()) {
            results.tvalues(j) = nan;
        }
        if (j < results.pvalues.size()) {
            results.pvalues(j) = nan;
        }
        if (j < results.conf_int.rows()) {
            results.conf_int(j, 0) = nan;
            results.conf_int(j, 1) = nan;
        }
    }
    for (int i = 0; i < n_coef; ++i) {
        for (int j = 0; j < n_coef; ++j) {
            if (i != j && !hdfe::detail::ieee_finite(results.covariance(i, j))) {
                results.covariance(i, j) = 0.0;
            }
        }
    }
}

void enforce_estimation_output_postcondition(
    hdfe::HdfeResults& results,
    bool intercept_inference_unavailable,
    bool inference_unavailable) {
    if (!results.converged) {
        return;
    }

    auto fail = [&](const char* field) {
        // Leave an inspectable fail-closed state even if a language binding
        // catches the exception and retains the estimator object.
        results.converged = false;
        results.precision_certified = false;
        throw std::runtime_error(
            std::string("xhdfe: converged fit produced invalid ") + field +
            " output; results were rejected");
    };

    {
        // The recovered constant of a model without a constant (group/
        // individual sum aggregation whose membership columns do not span
        // it) is reported missing: that trailing slot is the only permitted
        // non-finite coefficient.
        const int n_coef = static_cast<int>(results.coefficients.size());
        const int checked =
            (intercept_inference_unavailable && !results.model_has_constant && n_coef > 0)
                ? n_coef - 1
                : n_coef;
        if (!hdfe::detail::ieee_all_finite(results.coefficients.head(checked))) {
            fail("non-finite coefficient");
        }
    }

    const int p = static_cast<int>(results.coefficients.size());
    if (results.std_errors.size() != p ||
        results.covariance.rows() != p ||
        results.covariance.cols() != p) {
        fail("inference-shape");
    }
    if (inference_unavailable) {
        return;
    }

    std::vector<int> inference_indices;
    inference_indices.reserve(static_cast<std::size_t>(p));
    for (int j = 0; j < p; ++j) {
        const bool omitted =
            j < static_cast<int>(results.omitted_reason.size()) &&
            results.omitted_reason[static_cast<std::size_t>(j)] != 0;
        const bool unidentified_intercept =
            intercept_inference_unavailable && j == p - 1;
        if (!omitted && !unidentified_intercept) {
            if (!hdfe::detail::ieee_finite(results.std_errors[j])) {
                fail("non-finite standard-error");
            }
            inference_indices.push_back(j);
        }
    }
    for (const int row : inference_indices) {
        for (const int col : inference_indices) {
            if (!hdfe::detail::ieee_finite(results.covariance(row, col))) {
                fail("non-finite covariance");
            }
        }
    }
}

void recompute_inference(Eigen::VectorXd& coefficients,
                         Eigen::VectorXd& std_errors,
                         Eigen::VectorXd& tvalues,
                         Eigen::VectorXd& pvalues,
                         Eigen::MatrixXd& conf_int,
                         double level_percent,
                         double df_resid,
                         bool quantiles = true) {
    const int p = static_cast<int>(coefficients.size());
    const double nan = std::numeric_limits<double>::quiet_NaN();
    tvalues.resize(p);
    pvalues.resize(p);
    conf_int.resize(p, 2);
    // quantiles == false (HdfeOptions::inference_quantiles): an internal fit
    // whose caller uses only the coefficients must neither depend on nor be
    // refused by Student-t quantiles it never delivers (issue #18).
    const bool df_ok = quantiles && (df_resid > 0.0) &&
                       hdfe::detail::ieee_finite(df_resid);
    const double crit = df_ok ? student_t_critical_value(level_percent, df_resid) : nan;
    for (int j = 0; j < p; ++j) {
        const double se = std_errors(j);
        if (!hdfe::detail::ieee_finite(se) || se <= 0.0) {
            tvalues(j) = nan;
            pvalues(j) = nan;
            conf_int(j, 0) = nan;
            conf_int(j, 1) = nan;
            continue;
        }
        const double t = coefficients(j) / se;
        tvalues(j) = t;
        const double abs_t = std::abs(t);
        if (df_ok && hdfe::detail::ieee_finite(abs_t)) {
            pvalues(j) =
                hdfe::detail::student_t_internal::two_sided_probability(
                    abs_t, df_resid);
        } else {
            pvalues(j) = nan;
        }
        const double half = crit * se;
        conf_int(j, 0) = coefficients(j) - half;
        conf_int(j, 1) = coefficients(j) + half;
    }
}

double n1_tolerance(const HdfeOptions& options) {
    return options.tolerance_mode == ToleranceMode::ReghdfeComparable
        ? std::min(options.tol, 1.0e-9) : options.tol;
}

// Necessary stationarity check for the original retained regressors. The
// reduced OLS Gram check alone cannot detect an inaccurate FE projection.
// Uses the established absorption limit and an arithmetic allowance from the
// values and operations summed; it is not a forward-error certificate.
void require_original_ols_moments(
    const Eigen::Ref<const Eigen::VectorXd>& y,
    const Eigen::Ref<const Eigen::MatrixXd>& X,
    const Eigen::Ref<const Eigen::VectorXd>& within_y,
    const Eigen::Ref<const Eigen::MatrixXd>& within_X,
    const std::vector<int>& kept,
    const detail::OlsResult& ols, const HdfeOptions& options, bool refined) {
    const auto started = std::chrono::steady_clock::now();
    const int n = static_cast<int>(y.size()), p = static_cast<int>(kept.size());
    if (p == 0) return;
    constexpr int block = 4096;
    const int chunks = n / block + (n % block != 0);
    const int width = 4 * p + 1;
    std::vector<long double> values(static_cast<std::size_t>(chunks) * width, 0.0L);
    const int threads = std::max(1, options.num_threads);
    if (options.parallel_observer) options.parallel_observer->begin_region(threads);
#ifdef HDFE_USE_OPENMP
#pragma omp parallel for schedule(static) num_threads(threads)
#endif
    for (int chunk = 0; chunk < chunks; ++chunk) {
        if (options.parallel_observer) options.parallel_observer->observe_work();
        long double* out = values.data() + static_cast<std::size_t>(chunk) * width;
        const int first = chunk * block;
        const int end = first + std::min(block, n - first);
        for (int i = first; i < end; ++i) {
            const long double u = ols.residuals[i];
            long double formation = std::abs(static_cast<long double>(within_y[i]));
            for (int j = 0; j < within_X.cols(); ++j)
                formation += std::abs(static_cast<long double>(within_X(i,j)) * ols.coefficients[j]);
            for (int j = 0; j < p; ++j) {
                const long double x = X(i, kept[j]);
                out[4*j] += x*u;
                out[4*j+1] += x*x;
                out[4*j+2] += std::abs(x*u);
                out[4*j+3] += std::abs(x)*formation;
            }
            out[4*p] += static_cast<long double>(y[i])*y[i];
        }
    }
    if (options.parallel_observer) options.parallel_observer->end_region();
    std::vector<long double> total(width, 0.0L);
    for (int k = 0; k < chunks; ++k)
        for (int j = 0; j < width; ++j) total[j] += values[static_cast<std::size_t>(k)*width+j];
    // FP64 roundoff also covers runtimes that reduce x87 precision.
    const long double unit = std::numeric_limits<double>::epsilon()/2;
    const long double mu = (block + chunks + 4)*unit;
    const long double gamma = mu/(1-mu);
    const long double formation_gamma = detail::N1NormalEvidence::gamma(2*within_X.cols()+2);
    const long double target = std::max(8.0*std::max(0.0,n1_tolerance(options)),
                                       64.0*std::numeric_limits<double>::epsilon());
    int failed = -1;
    long double failed_defect = 0, failed_scale = 0, failed_arithmetic = 0;
    long double worst = 0, worst_allowance = 0;
    for (int j = 0; j < p; ++j) {
        const long double scale = std::sqrt(total[4*j+1])*std::sqrt(total[4*p]);
        const long double arithmetic = gamma*(total[4*j+2]+target*scale) +
                                       formation_gamma*total[4*j+3];
        const long double defect = std::abs(total[4*j]);
        if (scale > 0) {
            worst = std::max(worst, defect/scale);
            worst_allowance = std::max(worst_allowance, arithmetic/scale);
        }
        if (failed < 0 && defect > target*scale + arithmetic) {
            failed = j;
            failed_defect = defect;
            failed_scale = scale;
            failed_arithmetic = arithmetic;
        }
    }
    const double seconds = std::chrono::duration<double>(std::chrono::steady_clock::now()-started).count();
    if (read_env_bool("XHDFE_ORIGINAL_NORMAL_DIAG").value_or(false)) {
        std::cerr << "xhdfe original_normal refined=" << refined << " relative=" << (double)worst
                  << " target=" << (double)target << " arithmetic=" << (double)worst_allowance
                  << " seconds=" << seconds << " pass=" << (failed<0) << '\n';
    }
    if (failed >= 0) {
        std::ostringstream message;
        message << "N1: original-design normal equation failed at regressor "
                << kept[static_cast<std::size_t>(failed)] + 1
                << " (defect=" << std::scientific << static_cast<double>(failed_defect)
                << ", limit=" << static_cast<double>(target * failed_scale)
                << ", arithmetic=" << static_cast<double>(failed_arithmetic)
                << "); no estimates returned";
        throw detail::N1Failure(message.str());
    }
}

void require_n1_fit(const detail::AbsorptionResult& absorption,
                    const detail::OlsResult& ols,
                    const std::vector<int>& kept_columns,
                    bool has_intercept, int design_columns,
                    const HdfeOptions& options,
                    const Eigen::MatrixXd* gram = nullptr,
                    const Eigen::VectorXd* rhs = nullptr) {
    // Default fit: the free necessary check. The normal-equation defect of the
    // solved system is recomputed from the Gram matrix and right-hand side
    // already formed for the OLS stage (O(p^2), no pass over the data). It
    // detects a wrong or non-finite linear solve; the per-row evidence below
    // is an audit instrument (XHDFE_CERTIFY=1) and never runs by default.
    if (gram && rhs && gram->rows() > 0 && gram->rows() == gram->cols() &&
        gram->rows() == ols.coefficients.size() && rhs->size() == ols.coefficients.size()) {
        const Eigen::VectorXd defect = *rhs - (*gram) * ols.coefficients;
        const double gram_scale = gram->norm() * ols.coefficients.norm();
        const double scale = std::max(rhs->norm(), gram_scale);
        const double arithmetic = 64.0 * std::numeric_limits<double>::epsilon() *
            static_cast<double>(gram->rows()) * (rhs->norm() + gram_scale);
        const double limit = n1_tolerance(options) * scale + arithmetic;
        if (!hdfe::detail::ieee_all_finite(defect) || !(defect.norm() <= limit)) {
            std::ostringstream message;
            message << "N1: normal-equation defect " << std::scientific << defect.norm()
                    << " exceeds its limit " << limit << "; no estimates returned";
            throw detail::N1Failure(message.str());
        }
    }
    if (!detail::n1_capture_active) return;
    if (!ols.n1_normal)
        throw detail::N1Failure("N1: missing residual evidence; no estimates returned");
    ols.n1_normal->require(n1_tolerance(options));
    if (!absorption.fe_levels.empty() && !absorption.n1_fe)
        throw detail::N1Failure("N1: missing signed FE evidence; no estimates returned");
    // The absorber already enforces the established per-column FE contract.
    // A combined moment scaled by ||u|| would impose an extra work target.
}

// A failed necessary check permits one continuation at the caller's unchanged
// tolerance and concrete method. Reconstruct alphas only when they already
// existed; the group forward guard still evaluates the original data.
detail::AbsorptionResult refine_n1_absorption(
    const Eigen::Ref<const Eigen::VectorXd>& y,
    const Eigen::Ref<const Eigen::MatrixXd>& X,
    const std::vector<Eigen::VectorXi>& fes, const Eigen::VectorXd* weights,
    const HdfeOptions& options, AbsorptionMethod method,
    const std::vector<detail::HeterogeneousSlopeTerm>& slopes,
    const detail::GroupIndividualStructure* gi,
    const detail::AbsorptionResult& previous, int remaining,
    const Eigen::VectorXd* previous_coefficients = nullptr,
    const std::vector<int>* previous_columns = nullptr) {
    HdfeOptions continuation = options;
    continuation.max_iter = remaining;
    continuation.absorption_method = method;
    continuation.from_auto = false;
    if (!previous.sweep_order_used.empty())
        continuation.sweep_order_override = previous.sweep_order_used;
    detail::N1ContinuationPredicate necessary_moments;
    Eigen::VectorXd refinement_coefficients;
    std::vector<FeIndexMap> refinement_maps;
    // A failed three-FE CUDA fit uses the graph-preconditioned correction.
    // Reconstruct from the original inputs to avoid preserving orthogonal
    // drift from the failed primary transform. Other continuations are unchanged.
    const bool three_fe_cg = fes.size() == 3 &&
        (method == AbsorptionMethod::GaussSeidel ||
         method == AbsorptionMethod::SymmetricGaussSeidel);
    if (!gi && (fes.size() == 2 || three_fe_cg) && !weights && slopes.empty() && previous.gpu_used &&
        !options.retain_fixed_effects &&
        options.tolerance_mode == ToleranceMode::ReghdfeComparable &&
        previous_coefficients && previous_columns &&
        previous_coefficients->size() == static_cast<int>(previous_columns->size())) {
        refinement_coefficients = Eigen::VectorXd::Zero(previous.X_tilde.cols());
        for (std::size_t j = 0; j < previous_columns->size(); ++j)
            refinement_coefficients[(*previous_columns)[j]] = (*previous_coefficients)[j];
        refinement_maps.reserve(fes.size());
        for (const auto& fe : fes) {
            refinement_maps.push_back(build_fe_index_map(fe));
            // Only stable groups-by-level CSR is needed during the continuation.
            refinement_maps.back().level_index.resize(0);
            refinement_maps.back().raw_values.resize(0);
        }
        necessary_moments = [&](const Eigen::VectorXd& yr, const Eigen::MatrixXd& xr) {
            const int rows = static_cast<int>(yr.size());
            const int threads = std::max(1, options.num_threads);
            Eigen::VectorXd residual(rows);
            double maximum = 0.0;
            std::atomic<bool> finite{true};
            if (options.parallel_observer) options.parallel_observer->begin_region(threads);
#ifdef HDFE_USE_OPENMP
#pragma omp parallel for schedule(static) num_threads(threads) reduction(max:maximum)
#endif
            for (int i = 0; i < rows; ++i) {
                if (options.parallel_observer) options.parallel_observer->observe_work();
                double value = yr[i];
                for (int j = 0; j < xr.cols(); ++j)
                    value -= xr(i, j) * refinement_coefficients[j];
                residual[i] = value;
                if (!hdfe::detail::ieee_finite(value)) finite.store(false, std::memory_order_relaxed);
                maximum = std::max(maximum, std::abs(value));
            }
            if (options.parallel_observer) options.parallel_observer->end_region();
            if (!finite.load(std::memory_order_relaxed)) return false;
            if (maximum == 0.0) return true;
            const int chunks = detail::deterministic_parallel_chunk_count(rows);
            std::vector<long double> norm_parts(static_cast<std::size_t>(chunks), 0.0L);
            if (options.parallel_observer) options.parallel_observer->begin_region(threads);
#ifdef HDFE_USE_OPENMP
#pragma omp parallel for schedule(static) num_threads(threads)
#endif
            for (int chunk = 0; chunk < chunks; ++chunk) {
                if (options.parallel_observer) options.parallel_observer->observe_work();
                const int begin = detail::deterministic_parallel_chunk_begin(rows, chunk, chunks);
                const int end = detail::deterministic_parallel_chunk_end(rows, chunk, chunks);
                long double sum = 0.0L;
                for (int i = begin; i < end; ++i) {
                    residual[i] /= maximum;
                    const long double value = residual[i];
                    sum += value * value;
                }
                norm_parts[static_cast<std::size_t>(chunk)] = sum;
            }
            if (options.parallel_observer) options.parallel_observer->end_region();
            long double norm_squared = 0.0L;
            for (const auto value : norm_parts) norm_squared += value;
            long double worst = 0.0L;
            for (const auto& map : refinement_maps) {
                const int levels = static_cast<int>(map.level_ptr.size()) - 1;
                if (options.parallel_observer) options.parallel_observer->begin_region(threads);
#ifdef HDFE_USE_OPENMP
#pragma omp parallel for schedule(static) num_threads(threads) reduction(max:worst)
#endif
                for (int g = 0; g < levels; ++g) {
                    if (options.parallel_observer) options.parallel_observer->observe_work();
                    const int begin = map.level_ptr[g], end = map.level_ptr[g + 1];
                    long double sum = 0.0L;
                    for (int i = begin; i < end; ++i) sum += residual[map.level_groups[i]];
                    if (end > begin)
                        worst = std::max(worst, std::abs(sum) /
                            std::sqrt(static_cast<long double>(end - begin) * norm_squared));
                }
                if (options.parallel_observer) options.parallel_observer->end_region();
            }
            const double target = n1_tolerance(options);
            if (read_env_bool("XHDFE_ORIGINAL_NORMAL_DIAG").value_or(false))
                std::cerr << "xhdfe n1_continuation_fe maximum=" << static_cast<double>(worst)
                          << " target=" << target << " pass=" << (worst <= target) << '\n';
            if (worst > target) return false;

            // At the final within-OLS solution, Xr'u=0, hence X'u=(X-Xr)'u.
            // Check the absorption contribution using the previous slopes;
            // the caller still solves OLS and applies the unchanged full check.
            const int p = static_cast<int>(previous_columns->size());
            constexpr int block = 4096;
            const int blocks = rows / block + (rows % block != 0);
            const int width = 4 * p + 1;
            std::vector<long double> partials(static_cast<std::size_t>(blocks) * width, 0.0L);
            if (options.parallel_observer) options.parallel_observer->begin_region(threads);
#ifdef HDFE_USE_OPENMP
#pragma omp parallel for schedule(static) num_threads(threads)
#endif
            for (int chunk = 0; chunk < blocks; ++chunk) {
                if (options.parallel_observer) options.parallel_observer->observe_work();
                long double* out = partials.data() + static_cast<std::size_t>(chunk) * width;
                const int first = chunk * block, last = std::min(rows, first + block);
                for (int i = first; i < last; ++i) {
                    const long double u = static_cast<long double>(residual[i]) * maximum;
                    long double formation = std::abs(static_cast<long double>(yr[i]));
                    for (int j = 0; j < xr.cols(); ++j)
                        formation += std::abs(static_cast<long double>(xr(i,j)) * refinement_coefficients[j]);
                    for (int j = 0; j < p; ++j) {
                        const int column = (*previous_columns)[static_cast<std::size_t>(j)];
                        const long double original = X(i,column);
                        const long double removed = original - xr(i,column);
                        out[4*j] += removed*u;
                        out[4*j+1] += original*original;
                        out[4*j+2] += std::abs(removed*u);
                        out[4*j+3] += std::abs(removed)*formation;
                    }
                    out[4*p] += static_cast<long double>(y[i])*y[i];
                }
            }
            if (options.parallel_observer) options.parallel_observer->end_region();
            std::vector<long double> total(width, 0.0L);
            for (int chunk = 0; chunk < blocks; ++chunk)
                for (int j = 0; j < width; ++j)
                    total[j] += partials[static_cast<std::size_t>(chunk)*width+j];
            const long double unit = std::numeric_limits<double>::epsilon()/2;
            const long double mu = (block + blocks + 4)*unit;
            const long double gamma = mu/(1-mu);
            const long double formation_gamma = detail::N1NormalEvidence::gamma(2*xr.cols()+2);
            const long double normal_target = std::max(8.0*std::max(0.0,target),
                64.0*std::numeric_limits<double>::epsilon());
            bool ready = true;
            long double worst_normal = 0.0L;
            for (int j = 0; j < p; ++j) {
                const long double scale = std::sqrt(total[4*j+1])*std::sqrt(total[4*p]);
                const long double arithmetic = gamma*(total[4*j+2]+normal_target*scale) +
                                               formation_gamma*total[4*j+3];
                const long double defect = std::abs(total[4*j]);
                if (scale > 0.0L) worst_normal = std::max(worst_normal, defect/scale);
                if (!(defect <= normal_target*scale + arithmetic)) ready = false;
            }
            if (read_env_bool("XHDFE_ORIGINAL_NORMAL_DIAG").value_or(false))
                std::cerr << "xhdfe n1_continuation_normal relative=" << static_cast<double>(worst_normal)
                          << " target=" << static_cast<double>(normal_target) << " pass=" << ready << '\n';
            return ready;
        };
    }
    detail::ScopedN1Continuation continuation_scope(necessary_moments ? &necessary_moments : nullptr);
    detail::AbsorptionResult next = gi
        ? detail::absorb_fixed_effects_group_individual(
              previous.y_tilde, previous.X_tilde, fes, *gi, weights, continuation, method)
        : (three_fe_cg && necessary_moments)
            ? detail::absorb_fixed_effects_v6(y, X, fes, weights, continuation, method, slopes)
            : detail::absorb_fixed_effects_v6(
                  previous.y_tilde, previous.X_tilde, fes, weights, continuation, method, slopes);
    if (next.gpu_used != previous.gpu_used ||
        next.schwarz_used != previous.schwarz_used ||
        next.mlsmr_used != previous.mlsmr_used)
        throw detail::N1Failure("N1: refinement changed method or backend; no estimates returned");
    auto compose = [](auto& newer, const auto& older) {
        if (older.empty()) { newer.clear(); return; }
        if (newer.size() != older.size()) { newer.clear(); return; }
        for (std::size_t d = 0; d < newer.size(); ++d) {
            if (newer[d].rows() != older[d].rows() || newer[d].cols() != older[d].cols()) {
                newer.clear(); return;
            }
            newer[d] += older[d];
        }
    };
    compose(next.fe_alpha_y, previous.fe_alpha_y);
    compose(next.fe_alpha_X, previous.fe_alpha_X);
    compose(next.fe_slope_alpha_y, previous.fe_slope_alpha_y);
    compose(next.fe_slope_alpha_X, previous.fe_slope_alpha_X);
    next.iterations += previous.iterations;
    next.gpu_absorption_iterations += previous.gpu_absorption_iterations;
    if (gi)
        detail::certify_group_individual_candidate(y, X, fes, *gi, weights, options, next);
    else
        detail::certify_absorption_result(y, X, fes, weights, options, slopes, next, nullptr, true);
    return next;
}

// Package D: what the tier's attempt did with the finer blocks, into the fit's
// diagnostics (the request, its source and the cache flag stay); an outcome of
// nullptr (no attempt: ineligible, another route) clears the attempt's fields.
void record_reduced_pcg_fine(ReducedPcgFineDiagnostics& fine, const detail::ReducedPcgOutcome* outcome) noexcept {
    const detail::ReducedPcgOutcome none;
    const detail::ReducedPcgOutcome& o = outcome != nullptr ? *outcome : none;
    fine.used = o.fine_used;
    fine.parts = o.fine_parts;
    fine.hinted_applies = o.hinted_applies;
    fine.alloc_failed = o.fine_alloc_failed;
    fine.retry = o.fine_retry;
    fine.retry_factor = o.fine_retry_factor;
    fine.retry_parts = o.fine_retry_parts;
    fine.retry_iterations = o.fine_retry_iterations;
}

}  // namespace

FeComponentStats compute_first_pair_component_stats(
    const Eigen::VectorXi& first_fe,
    const Eigen::VectorXi& second_fe,
    const Eigen::VectorXd* weights) {
    if (first_fe.size() != second_fe.size()) {
        throw std::runtime_error(
            "First-pair FE vectors must have the same length");
    }
    if (weights != nullptr && weights->size() != first_fe.size()) {
        throw std::runtime_error(
            "First-pair component weights must match the FE vectors");
    }

    FeComponentStats stats;
    const Eigen::Index n = first_fe.size();
    if (n == 0) {
        return stats;
    }

    const FeIndexerLite first = build_indexer_lite(first_fe);
    const FeIndexerLite second = build_indexer_lite(second_fe);
    if (first.num_groups <= 0 || second.num_groups <= 0) {
        return stats;
    }
    const int total_nodes = detail::sparse_rank::checked_component_node_count(
        detail::sparse_rank::pair_node_count(first.num_groups, second.num_groups));

    UnionFind uf(total_nodes);
    for (Eigen::Index i = 0; i < n; ++i) {
        uf.unite(
            first.group_ids[static_cast<std::size_t>(i)],
            first.num_groups +
                second.group_ids[static_cast<std::size_t>(i)]);
    }

    std::vector<long long> counts(static_cast<std::size_t>(total_nodes), 0);
    std::vector<long double> weight_sums;
    if (weights != nullptr) {
        weight_sums.assign(static_cast<std::size_t>(total_nodes), 0.0L);
    }
    long double total_weight = 0.0L;
    for (Eigen::Index i = 0; i < n; ++i) {
        const int root = uf.find(
            first.group_ids[static_cast<std::size_t>(i)]);
        const std::size_t index = static_cast<std::size_t>(root);
        counts[index] += 1;
        if (weights != nullptr) {
            const double weight = (*weights)[i];
            if (!(weight > 0.0) || !(weight < 1e300)) {
                throw std::runtime_error(
                    "First-pair component weights must be finite and "
                    "positive");
            }
            weight_sums[index] += static_cast<long double>(weight);
            total_weight += static_cast<long double>(weight);
        }
    }

    long double largest_weight = 0.0L;
    for (std::size_t c = 0; c < counts.size(); ++c) {
        if (counts[c] <= 0) {
            continue;
        }
        ++stats.num_components;
        stats.largest_component_n_obs =
            std::max(stats.largest_component_n_obs, counts[c]);
        if (weights != nullptr) {
            largest_weight = std::max(largest_weight, weight_sums[c]);
        }
    }
    stats.largest_component_obs_share =
        static_cast<double>(stats.largest_component_n_obs) /
        static_cast<double>(n);
    if (weights == nullptr) {
        stats.largest_component_weight_share =
            stats.largest_component_obs_share;
    } else if (total_weight > 0.0L) {
        stats.largest_component_weight_share =
            static_cast<double>(largest_weight / total_weight);
    }
    return stats;
}

class HdfeRegressorV11::AttemptTransaction {
public:
    explicit AttemptTransaction(HdfeRegressorV11& owner)
        : owner_(owner), owns_attempt_(owner.lifecycle_state_ != LifecycleState::InProgress) {
        if (owns_attempt_) {
            owner_.begin_attempt();
        }
    }

    ~AttemptTransaction() {
        if (owns_attempt_ && !committed_) {
            owner_.fail_attempt();
        }
    }

    void commit(LifecycleState ready_state) noexcept {
        owner_.commit_attempt(ready_state);
        committed_ = true;
    }

private:
    HdfeRegressorV11& owner_;
    bool owns_attempt_ = false;
    bool committed_ = false;
};

void HdfeRegressorV11::clear_consumable_state() noexcept {
    results_ = HdfeResults{};
    results_.converged = false;
    results_.precision_certified = false;
    results_.fe_recovery_converged = false;
    method_used_ = AbsorptionMethod::Auto;
    grouped_signature_1_ = 0;
    grouped_signature_2_ = 0;
    grouped_signature_valid_ = false;
    gpu_used_ = false;
    gpu_status_code_ = 0;
    gpu_attempted_ = false;
    gpu_absorption_converged_ = false;
    gpu_absorption_iterations_ = 0;
    cuda_tail_code_ = 0;
    reduced_pcg_status_ = 0;
    reduced_pcg_reason_ = detail::reduced_pcg_effective(options_) ? "not_reached" : "off";
    reduced_pcg_discarded_iterations_ = 0;
    reduced_pcg_fine_ = ReducedPcgFineDiagnostics{};
    reduced_pcg_fine_.request = detail::reduced_pcg_apply_fine_request(options_);
    reduced_pcg_fine_.source = detail::reduced_pcg_apply_fine_source(options_);
    reduced_pcg_transient_fallback_ = false;
    krylov_pcg_published_ = false;
    slope_solver_diagnostics_ = {};
    slope_scores_enabled_ = false;
    slope_csr_owner_enabled_ = false;
    threads_used_ = 0;
    threads_requested_ = 0;
    threads_effective_ = 0;
    parallel_workers_active_ = 0;
    thread_capacity_ = 0;
    openmp_enabled_ = false;
    thread_limit_code_ = 0;
    thread_limit_reason_ = "not_run";
    first_pair_component_stats_ = FeComponentStats{};
    if (parallel_observer_) {
        parallel_observer_->reset();
    }
}

void HdfeRegressorV11::begin_attempt() {
    clear_consumable_state();
    slope_solver_diagnostics_ = detail::resolve_slope_solver(options_, slope_scores_enabled_, slope_csr_owner_enabled_);
    lifecycle_state_ = LifecycleState::InProgress;
    generation_ = generation_ == std::numeric_limits<std::uint64_t>::max()
                      ? 1
                      : generation_ + 1;
}

void HdfeRegressorV11::fail_attempt() noexcept {
    clear_consumable_state();
    lifecycle_state_ = LifecycleState::Failed;
}

void HdfeRegressorV11::commit_attempt(LifecycleState ready_state) noexcept {
    lifecycle_state_ = ready_state;
}

void HdfeRegressorV11::invalidate_semantics() noexcept {
    clear_consumable_state();
    lifecycle_state_ = LifecycleState::Empty;
    generation_ = generation_ == std::numeric_limits<std::uint64_t>::max()
                      ? 1
                      : generation_ + 1;
}

void HdfeRegressorV11::reset_moved_from() noexcept {
    clear_consumable_state();
    lifecycle_state_ = LifecycleState::Empty;
    generation_ = 0;
}

const char* HdfeRegressorV11::lifecycle_state_name() const noexcept {
    switch (lifecycle_state_) {
        case LifecycleState::Empty: return "empty";
        case LifecycleState::InProgress: return "in_progress";
        case LifecycleState::Failed: return "failed";
        case LifecycleState::PartialReady: return "partial_ready";
        case LifecycleState::StandardReady: return "standard_ready";
        case LifecycleState::GroupedReady: return "grouped_ready";
    }
    return "failed";
}

bool HdfeRegressorV11::has_estimation_result() const noexcept {
    return lifecycle_state_ == LifecycleState::StandardReady ||
           lifecycle_state_ == LifecycleState::GroupedReady;
}

bool HdfeRegressorV11::has_partial_result() const noexcept {
    return lifecycle_state_ == LifecycleState::PartialReady;
}

void HdfeRegressorV11::set_reduced_pcg_apply_fine(int request) {
    // Package D (round 09, E.4): the constructor's rule.
    if (request != kReducedPcgApplyFineUnset && request != kReducedPcgApplyFineAuto &&
        (request < 1 || request > 8)) {
        throw std::invalid_argument(
            "reduced_pcg_apply_fine must be unset, automatic, or an integer from 1 to 8");
    }
    options_.reduced_pcg_apply_fine = request;
}

void HdfeRegressorV11::set_slope_solver(SlopeSolverRequest request) {
    if (request < SlopeSolverRequest::Unset || request > SlopeSolverRequest::Direct)
        throw std::invalid_argument("slope_solver must be unset, off, schur, network or direct");
    options_.slope_solver = request;
    options_.slope_solver_from_global = false;
}

void HdfeRegressorV11::set_weights_are_frequencies(bool value) noexcept {
    if (options_.weights_are_frequencies != value) {
        options_.weights_are_frequencies = value;
        invalidate_semantics();
    }
}

HdfeRegressorV11::HdfeRegressorV11(HdfeOptions options, ThreadingOptions threading)
    : options_(options),
      threading_(threading),
      parallel_observer_(std::make_shared<detail::ParallelWorkObserver>()) {
    if (options_.absorption_method == AbsorptionMethod::ReducedPcg) {
        throw std::invalid_argument(
            "absorption method reduced-pcg is reported when the reduced-system tier publishes a fit; "
            "it cannot be requested (use auto)");
    }
    if (options_.absorption_method == AbsorptionMethod::KrylovPcg) {
        throw std::invalid_argument(
            "absorption method krylov-pcg is reported when the Krylov-PCG route is forced; "
            "it cannot be requested (use auto)");
    }
    // Package D: no request, the automatic rule, or an explicit factor from 1 to 8.
    if (options_.reduced_pcg_apply_fine != kReducedPcgApplyFineUnset &&
        options_.reduced_pcg_apply_fine != kReducedPcgApplyFineAuto &&
        (options_.reduced_pcg_apply_fine < 1 || options_.reduced_pcg_apply_fine > 8)) {
        throw std::invalid_argument(
            "reduced_pcg_apply_fine must be unset, automatic, or an integer from 1 to 8");
    }
    if (options_.slope_solver < SlopeSolverRequest::Unset || options_.slope_solver > SlopeSolverRequest::Direct)
        throw std::invalid_argument("slope_solver must be unset, off, schur, network or direct");
    if (!options_.symmetric_sweep) {
        options_.symmetric_sweep = threading_.symmetric_sweep;
    }
    clear_consumable_state();
    lifecycle_state_ = LifecycleState::Empty;
}

HdfeRegressorV11::HdfeRegressorV11(const HdfeRegressorV11& other)
    : options_(other.options_),
      threading_(other.threading_),
      results_(other.results_),
      threads_used_(other.threads_used_),
      threads_requested_(other.threads_requested_),
      threads_effective_(other.threads_effective_),
      parallel_workers_active_(other.parallel_workers_active_),
      thread_capacity_(other.thread_capacity_),
      openmp_enabled_(other.openmp_enabled_),
      thread_limit_code_(other.thread_limit_code_),
      thread_limit_reason_(other.thread_limit_reason_),
      parallel_observer_(std::make_shared<detail::ParallelWorkObserver>()),
      method_used_(other.method_used_),
      lifecycle_state_(other.lifecycle_state_),
      generation_(other.generation_),
      grouped_signature_1_(other.grouped_signature_1_),
      grouped_signature_2_(other.grouped_signature_2_),
      grouped_signature_valid_(other.grouped_signature_valid_),
      gpu_used_(other.gpu_used_),
      gpu_status_code_(other.gpu_status_code_),
      gpu_attempted_(other.gpu_attempted_),
      gpu_absorption_converged_(other.gpu_absorption_converged_),
      gpu_absorption_iterations_(other.gpu_absorption_iterations_),
      cuda_tail_code_(other.cuda_tail_code_),
      first_pair_component_stats_(other.first_pair_component_stats_),
      reduced_pcg_status_(other.reduced_pcg_status_),
      reduced_pcg_reason_(other.reduced_pcg_reason_),
      reduced_pcg_discarded_iterations_(other.reduced_pcg_discarded_iterations_),
      reduced_pcg_fine_(other.reduced_pcg_fine_),
      reduced_pcg_transient_fallback_(other.reduced_pcg_transient_fallback_),
      krylov_pcg_published_(other.krylov_pcg_published_),
      slope_solver_diagnostics_(other.slope_solver_diagnostics_),
      slope_scores_enabled_(other.slope_scores_enabled_),
      slope_csr_owner_enabled_(other.slope_csr_owner_enabled_) {
    if (lifecycle_state_ == LifecycleState::InProgress) {
        fail_attempt();
    }
}

HdfeRegressorV11& HdfeRegressorV11::operator=(
    const HdfeRegressorV11& other) {
    if (this == &other) {
        return *this;
    }
    options_ = other.options_;
    threading_ = other.threading_;
    results_ = other.results_;
    threads_used_ = other.threads_used_;
    threads_requested_ = other.threads_requested_;
    threads_effective_ = other.threads_effective_;
    parallel_workers_active_ = other.parallel_workers_active_;
    thread_capacity_ = other.thread_capacity_;
    openmp_enabled_ = other.openmp_enabled_;
    thread_limit_code_ = other.thread_limit_code_;
    thread_limit_reason_ = other.thread_limit_reason_;
    parallel_observer_ = std::make_shared<detail::ParallelWorkObserver>();
    method_used_ = other.method_used_;
    lifecycle_state_ = other.lifecycle_state_;
    generation_ = other.generation_;
    grouped_signature_1_ = other.grouped_signature_1_;
    grouped_signature_2_ = other.grouped_signature_2_;
    grouped_signature_valid_ = other.grouped_signature_valid_;
    gpu_used_ = other.gpu_used_;
    gpu_status_code_ = other.gpu_status_code_;
    gpu_attempted_ = other.gpu_attempted_;
    gpu_absorption_converged_ = other.gpu_absorption_converged_;
    gpu_absorption_iterations_ = other.gpu_absorption_iterations_;
    cuda_tail_code_ = other.cuda_tail_code_;
    first_pair_component_stats_ = other.first_pair_component_stats_;
    reduced_pcg_status_ = other.reduced_pcg_status_;
    reduced_pcg_reason_ = other.reduced_pcg_reason_;
    reduced_pcg_discarded_iterations_ = other.reduced_pcg_discarded_iterations_;
    reduced_pcg_fine_ = other.reduced_pcg_fine_;
    reduced_pcg_transient_fallback_ = other.reduced_pcg_transient_fallback_;
    krylov_pcg_published_ = other.krylov_pcg_published_;
    slope_solver_diagnostics_ = other.slope_solver_diagnostics_;
    slope_scores_enabled_ = other.slope_scores_enabled_;
    slope_csr_owner_enabled_ = other.slope_csr_owner_enabled_;
    if (lifecycle_state_ == LifecycleState::InProgress) {
        fail_attempt();
    }
    return *this;
}

HdfeRegressorV11::HdfeRegressorV11(HdfeRegressorV11&& other) noexcept
    : options_(std::move(other.options_)),
      threading_(std::move(other.threading_)),
      results_(std::move(other.results_)),
      threads_used_(other.threads_used_),
      threads_requested_(other.threads_requested_),
      threads_effective_(other.threads_effective_),
      parallel_workers_active_(other.parallel_workers_active_),
      thread_capacity_(other.thread_capacity_),
      openmp_enabled_(other.openmp_enabled_),
      thread_limit_code_(other.thread_limit_code_),
      thread_limit_reason_(std::move(other.thread_limit_reason_)),
      parallel_observer_(std::move(other.parallel_observer_)),
      method_used_(other.method_used_),
      lifecycle_state_(other.lifecycle_state_),
      generation_(other.generation_),
      grouped_signature_1_(other.grouped_signature_1_),
      grouped_signature_2_(other.grouped_signature_2_),
      grouped_signature_valid_(other.grouped_signature_valid_),
      gpu_used_(other.gpu_used_),
      gpu_status_code_(other.gpu_status_code_),
      gpu_attempted_(other.gpu_attempted_),
      gpu_absorption_converged_(other.gpu_absorption_converged_),
      gpu_absorption_iterations_(other.gpu_absorption_iterations_),
      cuda_tail_code_(other.cuda_tail_code_),
      first_pair_component_stats_(other.first_pair_component_stats_),
      reduced_pcg_status_(other.reduced_pcg_status_),
      reduced_pcg_reason_(std::move(other.reduced_pcg_reason_)),
      reduced_pcg_discarded_iterations_(other.reduced_pcg_discarded_iterations_),
      reduced_pcg_fine_(other.reduced_pcg_fine_),
      reduced_pcg_transient_fallback_(other.reduced_pcg_transient_fallback_),
      krylov_pcg_published_(other.krylov_pcg_published_),
      slope_solver_diagnostics_(other.slope_solver_diagnostics_),
      slope_scores_enabled_(other.slope_scores_enabled_),
      slope_csr_owner_enabled_(other.slope_csr_owner_enabled_) {
    if (lifecycle_state_ == LifecycleState::InProgress) {
        fail_attempt();
    }
    other.reset_moved_from();
}

HdfeRegressorV11& HdfeRegressorV11::operator=(HdfeRegressorV11&& other) noexcept {
    if (this == &other) {
        return *this;
    }
    options_ = std::move(other.options_);
    threading_ = std::move(other.threading_);
    results_ = std::move(other.results_);
    threads_used_ = other.threads_used_;
    threads_requested_ = other.threads_requested_;
    threads_effective_ = other.threads_effective_;
    parallel_workers_active_ = other.parallel_workers_active_;
    thread_capacity_ = other.thread_capacity_;
    openmp_enabled_ = other.openmp_enabled_;
    thread_limit_code_ = other.thread_limit_code_;
    thread_limit_reason_ = std::move(other.thread_limit_reason_);
    parallel_observer_ = std::move(other.parallel_observer_);
    method_used_ = other.method_used_;
    lifecycle_state_ = other.lifecycle_state_;
    generation_ = other.generation_;
    grouped_signature_1_ = other.grouped_signature_1_;
    grouped_signature_2_ = other.grouped_signature_2_;
    grouped_signature_valid_ = other.grouped_signature_valid_;
    gpu_used_ = other.gpu_used_;
    gpu_status_code_ = other.gpu_status_code_;
    gpu_attempted_ = other.gpu_attempted_;
    gpu_absorption_converged_ = other.gpu_absorption_converged_;
    gpu_absorption_iterations_ = other.gpu_absorption_iterations_;
    cuda_tail_code_ = other.cuda_tail_code_;
    first_pair_component_stats_ = other.first_pair_component_stats_;
    reduced_pcg_status_ = other.reduced_pcg_status_;
    reduced_pcg_reason_ = std::move(other.reduced_pcg_reason_);
    reduced_pcg_discarded_iterations_ = other.reduced_pcg_discarded_iterations_;
    reduced_pcg_fine_ = other.reduced_pcg_fine_;
    reduced_pcg_transient_fallback_ = other.reduced_pcg_transient_fallback_;
    krylov_pcg_published_ = other.krylov_pcg_published_;
    slope_solver_diagnostics_ = other.slope_solver_diagnostics_;
    slope_scores_enabled_ = other.slope_scores_enabled_;
    slope_csr_owner_enabled_ = other.slope_csr_owner_enabled_;
    if (lifecycle_state_ == LifecycleState::InProgress) {
        fail_attempt();
    }
    other.reset_moved_from();
    return *this;
}

HdfeRegressorV11::ThreadResolution HdfeRegressorV11::resolve_threads(
    int n_rows, int num_fes, bool legacy_density) const {
    ThreadResolution resolution;
    resolution.requested = options_.num_threads;
    if (options_.num_threads < 0) {
        throw std::invalid_argument("num_threads must be nonnegative");
    }
#ifdef HDFE_USE_OPENMP
    resolution.openmp_enabled = true;
    if (options_.num_threads > 1 && omp_in_parallel()) {
        throw std::runtime_error(
            "an explicit num_threads > 1 request cannot be guaranteed from "
            "inside an active OpenMP region; call xhdfe outside that region");
    }
    const int available_processors = std::max(1, omp_get_num_procs());
    const int runtime_limit = std::max(1, omp_get_thread_limit());
    resolution.capacity = std::max(
        1, std::min(available_processors, runtime_limit));

    if (options_.num_threads == 0 && omp_in_parallel()) {
        resolution.effective = 1;
        resolution.limit_code = 5;
        resolution.limit_reason = "active_openmp_region";
        return resolution;
    }

    // Fixed effects absorbed and not retained: the problem-size cap and the
    // dense automatic rows per thread apply only here.
    const bool capped_path = !options_.retain_fixed_effects && num_fes > 0;
    auto cap_for_problem_size = [&](int requested) {
        int capped = std::max(1, requested);
        if (capped_path) {
            int problem_cap = 16;
            if (n_rows < 100000) {
                problem_cap = 1;
            } else if (n_rows < 250000) {
                problem_cap = 8;
            }
            capped = std::min(capped, problem_cap);
        }
        return std::max(1, capped);
    };

    if (options_.num_threads > 0) {
        resolution.effective =
            std::min(options_.num_threads, resolution.capacity);
        if (resolution.effective < options_.num_threads) {
            resolution.limit_code = 1;
            resolution.limit_reason = "runtime_capacity";
        }
        return resolution;
    }

    int threads_cap = threading_.default_threads;
    if (threads_cap <= 0) {
        threads_cap = omp_get_max_threads();
    }
    threads_cap = std::max(1, std::min(threads_cap, resolution.capacity));

    if (n_rows < threading_.min_parallel_rows) {
        threads_cap = 1;
        resolution.limit_code = 2;
        resolution.limit_reason = "auto_policy";
    } else {
        int rows_per_thread = threading_.target_rows_per_thread;
        if (rows_per_thread == 0) {
            rows_per_thread = capped_path && !legacy_density
                                  ? auto_rows_per_thread_absorb()
                                  : kAutoRowsPerThreadUncapped;
        }
        if (rows_per_thread > 0) {
            const int by_rows =
                std::max(1, n_rows / std::max(1, rows_per_thread));
            if (by_rows < threads_cap) {
                threads_cap = by_rows;
                resolution.limit_code = 2;
                resolution.limit_reason = "auto_policy";
            }
        }
        if (threading_.max_threads > 0 &&
            threading_.max_threads < threads_cap) {
            threads_cap = threading_.max_threads;
            resolution.limit_code = 3;
            resolution.limit_reason = "auto_max_threads";
        }
        const int problem_capped = cap_for_problem_size(threads_cap);
        if (problem_capped < threads_cap) {
            threads_cap = problem_capped;
            resolution.limit_code = 2;
            resolution.limit_reason = "auto_policy";
        }
    }

    resolution.effective = std::max(1, threads_cap);
    return resolution;
#else
    (void)n_rows;
    (void)num_fes;
    (void)legacy_density;
    resolution.openmp_enabled = false;
    resolution.capacity = 1;
    resolution.effective = 1;
    resolution.limit_code = 4;
    resolution.limit_reason = "openmp_unavailable";
    if (options_.num_threads > 1) {
        throw std::runtime_error(
            "num_threads > 1 requires an xhdfe build with OpenMP support");
    }
    return resolution;
#endif
}

int HdfeRegressorV11::resolved_thread_count(int n_rows, int num_fes) const {
    return resolve_threads(n_rows, num_fes).effective;
}

namespace {
// thread_limit_code 6: the per-user team registry lowered an automatic team.
constexpr int kThreadLimitAutoTeamCoordination = 6;
constexpr const char* kThreadLimitAutoTeamCoordinationReason =
    "auto_team_coordination";
}  // namespace

HdfeRegressorV11::ThreadResolution HdfeRegressorV11::coordinate_auto_team(
    ThreadResolution resolution, int n_rows, int num_fes,
    detail::AutoTeamRegistration& registration, bool lease) const {
    if (!resolution.openmp_enabled ||
        !detail::auto_team_coordination_enabled()) {
        return resolution;
    }
    // An explicit request is recorded and never reduced. A positive
    // targetrowsperthread() sizes the legacy team like the requested one, so
    // it is never reduced either.
    const bool explicit_request = options_.num_threads > 0;
    const int legacy =
        explicit_request
            ? resolution.effective
            : std::min(resolution.effective,
                       resolve_threads(n_rows, num_fes, true).effective);
    const detail::AutoTeamGrant grant =
        lease ? registration.acquire_lease(resolution.effective, legacy,
                                           resolution.capacity,
                                           explicit_request)
              : registration.acquire_intent(resolution.effective, legacy,
                                            resolution.capacity,
                                            explicit_request);
    if (!explicit_request && grant.reduced &&
        grant.team < resolution.effective) {
        resolution.effective = std::max(1, grant.team);
        resolution.limit_code = kThreadLimitAutoTeamCoordination;
        resolution.limit_reason = kThreadLimitAutoTeamCoordinationReason;
    }
    return resolution;
}

void HdfeRegressorV11::begin_parallel_observation(
    const ThreadResolution& resolution) {
    if (!parallel_observer_) {
        parallel_observer_ = std::make_shared<detail::ParallelWorkObserver>();
    }
    threads_requested_ = resolution.requested;
    threads_effective_ = resolution.effective;
    thread_capacity_ = resolution.capacity;
    openmp_enabled_ = resolution.openmp_enabled;
    thread_limit_code_ = resolution.limit_code;
    thread_limit_reason_ = resolution.limit_reason;
    threads_used_ = 1;
    parallel_workers_active_ = 1;
    parallel_observer_->reset();
    if (detail::reduced_pcg_effective(options_)) detail::reduced_pcg_forget_observation();
}

void HdfeRegressorV11::end_parallel_observation() {
    threads_used_ = std::max(1, parallel_observer_->max_team_size());
    parallel_workers_active_ =
        std::max(1, parallel_observer_->active_workers());
    if (detail::reduced_pcg_effective(options_))
        detail::reduced_pcg_fold_observation(threads_used_, parallel_workers_active_);
}

AbsorptionMethod HdfeRegressorV11::select_method(std::size_t num_fes) const {
    if (options_.absorption_method != AbsorptionMethod::Auto) {
        return options_.absorption_method;
    }
    if (num_fes <= 1) {
        return AbsorptionMethod::GaussSeidel;
    }
    if (options_.symmetric_sweep) {
        return AbsorptionMethod::SymmetricGaussSeidel;
    }
    return AbsorptionMethod::GaussSeidel;
}

void HdfeRegressorV11::apply_common_postprocessing(const Eigen::Ref<const Eigen::VectorXd>& y,
                                                  const Eigen::Ref<const Eigen::MatrixXd>& X,
                                                  const Eigen::VectorXd* weights,
                                                  const std::vector<int>& fe_levels,
                                                  const detail::OlsResult& ols_result) {
    results_.coefficients = ols_result.coefficients;
    results_.std_errors = ols_result.std_errors;
    results_.tvalues = ols_result.tvalues;
    results_.pvalues = ols_result.pvalues;
    results_.conf_int = ols_result.conf_int;
    results_.covariance = ols_result.covariance;
    // The fit's team (ScopedParallelRuntime) copies the n residuals.
    int copy_threads = 1;
#ifdef HDFE_USE_OPENMP
    copy_threads = omp_get_max_threads();
#endif
    assign_by_blocks(results_.residuals, ols_result.residuals, copy_threads,
                     *parallel_observer_);
    results_.omitted_reason.clear();
    results_.fe_collinear_ss_ratio.resize(0);
    results_.nobs = static_cast<int>(y.size());
    results_.nobs_full = results_.nobs;
    results_.num_singletons = 0;
    results_.nobs_effective = static_cast<double>(results_.nobs);
    results_.nobs_full_effective = results_.nobs_effective;
    results_.num_singletons_effective = 0.0;
    results_.sample_index.resize(0);
    results_.df_resid = ols_result.df_resid;
    results_.df_resid_unadj = ols_result.df_resid;
    results_.df_m = 0.0;
    results_.df_a = 0.0;
    results_.df_a_levels = 0.0;
    results_.df_a_exact = 0.0;
    results_.df_a_nested = 0.0;
    results_.r2 = ols_result.r2;
    results_.r2_within = ols_result.r2_within;
    results_.sigma2 = ols_result.sigma2;
    results_.rss = ols_result.rss;
    results_.tss = ols_result.tss;
    results_.tss_within = ols_result.within_tss;
    results_.fe_num_levels = fe_levels;
    results_.fe_base_levels = fe_levels;
    results_.fe_base_redundant.clear();
    results_.fe_redundant.clear();
    results_.fe_num_coefs.clear();
    results_.fe_inexact.clear();
    results_.fe_nested.clear();
    results_.groupvar.resize(0);
    results_.fe_effects.clear();
    results_.fe_save_effects.clear();
    results_.fe_recovery_iterations = 0;
    results_.fe_recovery_max_delta = 0.0;
    results_.fe_recovery_converged = true;
    results_.abs_residual = 0.0;
    results_.abs_residual_rel = 0.0;
    results_.krylov_internal_tolerance = 0.0;
    results_.krylov_max_final_backward_error = 0.0;
    results_.krylov_max_condition = 0.0;
    results_.krylov_max_condition_times_backward_error = 0.0;
    results_.auto_routing_retry_policy_enabled = false;
    results_.auto_routing_retry_eligible = false;
    results_.auto_routing_retry_fired = false;
    results_.auto_routing_retry_status = 0;
    results_.auto_routing_retry_primary_method = -1;
    results_.auto_routing_retry_primary_iterations = 0;
    results_.auto_routing_retry_primary_abs_residual_rel = 0.0;
    results_.auto_routing_retry_iterations = 0;
    results_.auto_routing_retry_abs_residual_rel = 0.0;
    results_.auto_routing_retry_elapsed_seconds = 0.0;
    results_.precision_certified = true;
    results_.num_clusters = ols_result.num_clusters;
    results_.cluster_counts.clear();
    results_.cluster_combo_counts.clear();
    results_.cluster_scale = 1.0;
}

void HdfeRegressorV11::fit(const Eigen::Ref<const Eigen::VectorXd>& y,
                           const Eigen::Ref<const Eigen::MatrixXd>& X,
                           const std::vector<Eigen::VectorXi>& fes,
                           const Eigen::VectorXd* weights,
                           const std::vector<Eigen::VectorXi>* clusters,
                           const Eigen::MatrixXd* instruments,
                           const std::vector<int>& endogenous_idx,
                           const std::vector<detail::HeterogeneousSlopeTerm>* slopes) {
    AttemptTransaction attempt(*this);
    detail::ReducedPcgFitScope reduced_pcg_fit_scope(detail::reduced_pcg_effective(options_));
    if (options_.dof_method == DofAdjustmentMethod::Exact) {
        throw std::runtime_error(
            "dofadjustments(exact) currently requires group() and individual(); no estimates returned");
    }
    // Validate the actual CUDA request before installing the task-local CPU override.
    const bool cuda_requested = require_cuda_compatible_method(options_, fes.size());
    const bool weighted_cpu_routed = options_.weighted_cpu_route &&
        weighted_cpu_route_applies(options_, weights, fes.size(), cuda_requested);
    const bool cuda_execution_required = cuda_requested && !weighted_cpu_routed;
    std::optional<detail::ScopedGpuBackendOverride> weighted_cpu_route_scope;
    if (weighted_cpu_routed) {
        weighted_cpu_route_scope.emplace(detail::GpuBackend::Cpu);
    }
    const auto fit_outer_t0 = std::chrono::steady_clock::now();
    if (y.size() == 0) {
        throw std::runtime_error("Outcome vector must be non-empty");
    }
    if (X.rows() != y.size()) {
        throw std::runtime_error("X must have the same number of rows as y");
    }
    const int nobs_full = static_cast<int>(y.size());
    // Released on every exit path; a nested fit() acts on this record.
    detail::AutoTeamRegistration team_registration;
    // Resolve before validating large inputs so the fail-closed scans use the
    // same explicit/automatic thread contract as the remaining preprocessing.
    const ThreadResolution preprocessing_thread_resolution =
        coordinate_auto_team(
            resolve_threads(nobs_full, static_cast<int>(fes.size())),
            nobs_full, static_cast<int>(fes.size()), team_registration,
            false);
    const int validation_threads = preprocessing_thread_resolution.effective;
    require_finite_vector(y, "y", validation_threads);
    require_finite_matrix(X, "X", validation_threads);
    for (const auto& fe : fes) {
        if (fe.size() != y.size()) {
            throw std::runtime_error(
                "Each fixed-effect vector must have the same length as y");
        }
        require_nonnegative_ids(fe, "fixed-effect IDs", validation_threads);
    }
    if (weights && weights->size() != y.size()) {
        throw std::runtime_error("Weights must have the same length as y");
    }
    int zero_weight_count = 0;
    if (weights && !options_.weights_are_frequencies) {
        // Analytic weights must be IEEE-finite and non-negative (re-audit
        // R-03): one negative or NaN value among many silently corrupts
        // every weighted moment while the only prior guard â a positive
        // total â still passes. Zero remains allowed (a zero-weight row
        // contributes nothing). ieee_finite is bit-level, immune to
        // -ffast-math folding std::isfinite into a constant. Frequency
        // weights keep their stricter positive-integer validation.
        const double* w_chk = weights->data();
        const Eigen::Index n_w = weights->size();
        for (Eigen::Index i = 0; i < n_w; ++i) {
            if (!hdfe::detail::ieee_finite(w_chk[i]) || w_chk[i] < 0.0) {
                throw std::runtime_error(
                    "weights must be finite and non-negative");
            }
            zero_weight_count += (detail::ieee_bits_detail::bits(w_chk[i]) &
                                  UINT64_C(0x7fffffffffffffff)) == 0;
        }
    }
    gpu_used_ = false;
    gpu_status_code_ = 0;
    gpu_attempted_ = false;
    gpu_absorption_converged_ = false;
    gpu_absorption_iterations_ = 0;
    cuda_tail_code_ = 0;
    first_pair_component_stats_ = FeComponentStats{};
    if (clusters) {
        for (const auto& c : *clusters) {
            if (c.size() != y.size()) {
                throw std::runtime_error("Clusters must have the same length as y");
            }
            require_nonnegative_ids(c, "cluster IDs", validation_threads);
        }
    }
    if (instruments) {
        if (instruments->rows() != y.size()) {
            throw std::runtime_error(
                "Instruments must have the same number of rows as y");
        }
        require_finite_matrix(*instruments, "instruments", validation_threads);
    }
    const std::vector<detail::HeterogeneousSlopeTerm> empty_slopes;
    const std::vector<detail::HeterogeneousSlopeTerm>* slopes_in =
        slopes ? slopes : &empty_slopes;
    const bool has_slopes = slopes_in && !slopes_in->empty();
    if (has_slopes && fes.empty()) {
        throw std::runtime_error("Heterogeneous slopes require at least one absorbed FE");
    }
    if (has_slopes) {
        for (const auto& slope : *slopes_in) {
            if (slope.fe_index < 0 || slope.fe_index >= static_cast<int>(fes.size())) {
                throw std::runtime_error("Heterogeneous slope FE index out of range");
            }
            if (slope.values.size() != y.size()) {
                throw std::runtime_error("Heterogeneous slope variable must have the same length as y");
            }
            require_finite_vector(
                slope.values, "heterogeneous slope values", validation_threads);
        }
    }

    const bool wants_iv = !endogenous_idx.empty();
    const bool has_instruments = instruments && instruments->cols() > 0;
    if (wants_iv && !has_instruments) {
        throw std::runtime_error("Endogenous regressors supplied without instruments");
    }
    if (has_instruments && !wants_iv) {
        throw std::runtime_error(
            "Instrument matrix supplied but no endogenous indices were provided");
    }

    if (zero_weight_count) {
        PositiveWeightInput sample(y, X, fes, *weights, clusters, instruments, slopes, zero_weight_count);
        fit(sample.y, sample.X, sample.fes, &sample.weights,
            sample.clusters ? &*sample.clusters : nullptr,
            sample.instruments ? &*sample.instruments : nullptr, endogenous_idx,
            sample.slopes ? &*sample.slopes : nullptr);
        for (int i = 0; i < results_.sample_index.size(); ++i)
            results_.sample_index[i] = sample.rows.at(static_cast<std::size_t>(results_.sample_index[i]));
        // Package C: the inner call ran under the override as a CPU call; only the
        // outer, routed call publishes the code.
        if (weighted_cpu_routed) gpu_status_code_ = detail::kGpuStatusWeightedCpuRoute;
        reduced_pcg_fit_scope.complete();
        attempt.commit(LifecycleState::StandardReady);
        return;
    }

    const bool has_fes = !fes.empty();
    const MobilityProfileConfig mobility_cfg = load_mobility_profile_config();
    const AbsorptionCacheConfig abs_cache_cfg = load_absorption_cache_config();
    const FeStructureCacheConfig fe_cache_cfg = load_fe_structure_cache_config();
    // Resolve before singleton preprocessing: that phase can itself create an
    // OpenMP team on large inputs.  This makes explicit nested requests fail
    // before any work and makes auto mode use one worker inside an already
    // active OpenMP region, just like the estimator proper.
    std::vector<std::int64_t> integer_frequency_weights;
    const std::int64_t nobs_full_frequency =
        (options_.weights_are_frequencies && weights)
            ? checked_frequency_weight_sum(
                  *weights,
                  (options_.drop_singletons && has_fes)
                      ? &integer_frequency_weights
                      : nullptr)
            : static_cast<std::int64_t>(nobs_full);
    const double nobs_full_effective =
        static_cast<double>(nobs_full_frequency);
    int singletons_dropped_rows = 0;
    auto current_nobs_effective = [&](Eigen::Index row_count) -> double {
        if (options_.weights_are_frequencies && weights) {
            // In the ordinary FE path, a row can be a weighted singleton only
            // when its positive integer frequency is exactly one.  Preserve
            // the subtraction in int64 so a small singleton count is not lost
            // next to totals close to 2^63.
            const std::int64_t kept_frequency =
                nobs_full_frequency -
                static_cast<std::int64_t>(singletons_dropped_rows);
            return static_cast<double>(kept_frequency);
        }
        return static_cast<double>(row_count);
    };

    double singletons_dropped_effective = 0.0;
    // Levels per fixed effect left by the singleton scan, for the automatic
    // selector's representation check (empty when the scan did not run).
    std::vector<int> singleton_scan_levels;
    detail::ParallelWorkObserver preprocessing_observer;
    int preprocessing_threads_used = 1;
    int preprocessing_parallel_workers_active = 1;
    bool preprocessing_parallel_observed = false;
    std::vector<int> kept_idx;
    std::optional<Eigen::VectorXd> y_work;
    std::optional<Eigen::MatrixXd> X_work;
    std::optional<std::vector<Eigen::VectorXi>> fes_work;
    std::optional<Eigen::VectorXd> weights_work;
    std::optional<std::vector<Eigen::VectorXi>> clusters_work;
    std::optional<Eigen::MatrixXd> instruments_work;
    std::optional<std::vector<detail::HeterogeneousSlopeTerm>> slopes_work;

    const Eigen::MatrixXd* inst_ptr = has_instruments ? instruments : nullptr;

    FeStructureCache fe_cache;
    bool fe_cache_hit = false;
    FeStructureDigest fe_cache_signature{};
    bool fe_cache_signature_ready = false;
    auto ensure_fe_cache_signature = [&]() {
        if (!fe_cache_signature_ready) {
            fe_cache_signature = hash_fe_structure_cache_signature(
                fes, weights, options_.drop_singletons, options_.weights_are_frequencies,
                preprocessing_thread_resolution.effective, parallel_observer_.get());
            fe_cache_signature_ready = true;
        }
    };

    auto run_fit_once = [&](const Eigen::Ref<const Eigen::VectorXd>& y_use,
                       const Eigen::Ref<const Eigen::MatrixXd>& X_use,
                       const std::vector<Eigen::VectorXi>& fes_use,
                       const Eigen::VectorXd* w_ptr,
                       const std::vector<Eigen::VectorXi>* c_ptr,
                       const Eigen::MatrixXd* inst_use,
                       const std::vector<detail::HeterogeneousSlopeTerm>* slopes_use,
                       bool skip_cache_read, bool& provisional_cache_hit) {
        detail::additive_cell_projection::ScopedPublicAutoRequest additive_request(
            options_.absorption_method==AbsorptionMethod::Auto);
        detail::ScopedN1Capture n1_capture(detail::ordinary_audit_enabled());
        if (y_use.size() == 0) {
            throw std::runtime_error(
                "no observations remain for estimation (empty input or every row "
                "dropped as a singleton)");
        }
        const auto fit_t0 = std::chrono::steady_clock::now();
        const ThreadResolution thread_resolution = coordinate_auto_team(
            resolve_threads(static_cast<int>(y_use.size()),
                            static_cast<int>(fes_use.size())),
            static_cast<int>(y_use.size()), static_cast<int>(fes_use.size()),
            team_registration, true);
        begin_parallel_observation(thread_resolution);
        const int threads = thread_resolution.effective;
        ScopedParallelRuntime parallel_runtime(
            threads, thread_resolution.capacity);

        HdfeOptions tuned = options_;
        tuned.from_auto = (options_.absorption_method == AbsorptionMethod::Auto);
        tuned.auto_intent = (options_.absorption_method == AbsorptionMethod::Auto);
        tuned.fast_intent = options_.tolerance_mode == ToleranceMode::XhdfeFast &&
                            !options_.retain_fixed_effects;
        tuned.comparable_intent =
            options_.tolerance_mode == ToleranceMode::ReghdfeComparable;
        // F2-A: the CPU route selector lent to the CUDA completion of the
        // primary absorption (GPU branch of the Auto-MLSMR selection below). It
        // lives as long as this fit and evaluates the selector at most once.
        std::function<detail::AutoRouteAnswer()> cuda_tail_route;
        std::optional<detail::AutoRouteAnswer> cuda_tail_route_answer;
        int cuda_tail_route_evaluations = 0;
        tuned.num_threads_explicit = options_.num_threads > 0;
        tuned.parallel_observer = parallel_observer_.get();
        const std::optional<bool> env_krylov = read_env_bool("XHDFE_USE_KRYLOV");
        tuned.num_threads = threads;
        // Preserve exact instrument proportionality before independent FE
        // transformations can turn it into numerical rank. Test the original
        // retained sample, after singleton and positive-weight filtering.
        std::optional<Eigen::MatrixXd> distinct_instruments;
        if (wants_iv && inst_use) {
            distinct_instruments = detail::remove_exact_proportional_instruments(
                *inst_use, threads, tuned.parallel_observer);
            if (distinct_instruments) inst_use = &*distinct_instruments;
        }
        const std::vector<detail::HeterogeneousSlopeTerm>& slope_terms =
            slopes_use ? *slopes_use : empty_slopes;
        const bool has_slopes_use = !slope_terms.empty();
        if (!has_slopes_use && slope_solver_diagnostics_.request != SlopeSolverRequest::Off) {
            slope_solver_diagnostics_.reason = (suppress_auto_routing_retry_ || grouped_call_mark_)
                ? "group" : "no_slopes";
        }
        tuned.certify_weighted_gauss_seidel =
            options_.absorption_method == AbsorptionMethod::GaussSeidel &&
            tuned.tolerance_mode == ToleranceMode::ReghdfeComparable &&
            !options_.symmetric_sweep && !tuned.retain_fixed_effects && !has_slopes_use &&
            !grouped_call_mark_ && !suppress_auto_routing_retry_ && !wants_iv && !has_instruments &&
            w_ptr != nullptr && fes_use.size() == 3 &&
            detail::effective_gpu_backend() == detail::GpuBackend::Cpu;
        std::vector<bool> absorbed_levels(fes_use.size(), true);
        for (const auto& slope : slope_terms) {
            absorbed_levels[static_cast<std::size_t>(slope.fe_index)] =
                slope.include_intercept;
        }
        bool absorbed_constant = std::any_of(
            absorbed_levels.begin(), absorbed_levels.end(),
            [](bool level) { return level; });
        // A nonzero slope constant within each retained group spans the same
        // columns as level FEs. This is an exact structural test, not a near-
        // collinearity threshold; genuinely varying slopes keep the constant.
        if (!absorbed_constant) {
            for (const auto& slope : slope_terms) {
                const auto& ids = fes_use[static_cast<std::size_t>(slope.fe_index)];
                std::unordered_map<int, double> first_value;
                bool constant_in_groups = true;
                for (Eigen::Index i = 0; i < ids.size(); ++i) {
                    const double value = slope.values[i];
                    if (value == 0.0) {
                        constant_in_groups = false;
                        break;
                    }
                    const auto entry = first_value.emplace(ids[i], value);
                    if (!entry.second && entry.first->second != value) {
                        constant_in_groups = false;
                        break;
                    }
                }
                if (constant_in_groups) {
                    absorbed_constant = true;
                    break;
                }
            }
        }
        // Never send a structurally zero within-constant to OLS/2SLS.
        // Its reported normalization is recovered after the identified fit.
        const bool drop_intercept = options_.fit_intercept && absorbed_constant;
        // E2: the leading columns of every matrix this fit absorbs are X_use,
        // the columns the FE-collinearity rule below omits when annihilated;
        // its centred variant applies when the model has a constant. The
        // heterogeneous-slope certificate reads both (fe_absorption.cpp).
        tuned.fe_collinear_omission_cols = static_cast<int>(X_use.cols());
        tuned.fe_collinear_centred = options_.fit_intercept || absorbed_constant;
        tuned.ordinary_krylov_parity_floor =
            options_.ordinary_krylov_parity_floor && !has_slopes_use;
        tuned.ordinary_auto_routing_retry =
            options_.ordinary_auto_routing_retry &&
            !suppress_auto_routing_retry_ && !has_slopes_use &&
            read_env_bool("XHDFE_AUTO_ROUTING_RETRY").value_or(true);
        tuned.ordinary_auto_early_routing =
            options_.ordinary_auto_early_routing && tuned.ordinary_auto_routing_retry &&
            read_env_bool("XHDFE_AUTO_EARLY_ROUTING").value_or(true);

        MobilityHint mobility_hint;
        bool have_mobility_hint = false;
        bool mobility_profile_match = false;
        MobilityProfile profile;
        bool have_profile = false;
        if (!has_slopes_use && (mobility_cfg.mode == "read" || mobility_cfg.mode == "auto")) {
            if (load_mobility_profile(mobility_cfg.path, profile)) {
                have_profile = true;
            }
        }
        if (have_profile && profile.profile_kind == "standard") {
            bool match = false;
            if (profile.signature != 0 || profile.signature_canon != 0) {
                const std::uint64_t sig = hash_fe_signature(fes_use, options_.drop_singletons);
                if (profile.signature != 0 && profile.signature == sig) {
                    match = true;
                }
                if (!match && profile.signature_canon != 0 &&
                    profile.signature_canon == sig) {
                    match = true;
                }
            }
            if (!match && fe_cache_hit &&
                profile.signature != 0) {
                const std::vector<int>* kept_ptr =
                    (options_.drop_singletons && !kept_idx.empty()) ? &kept_idx : nullptr;
                const std::uint64_t sig_raw =
                    hash_fe_signature_filtered(fes, kept_ptr, options_.drop_singletons);
                match = (profile.signature == sig_raw);
            }
            if (match) {
                mobility_hint = build_standard_mobility_hint(profile);
                have_mobility_hint = true;
                mobility_profile_match = true;
            }
        }
        if (have_mobility_hint && !mobility_hint.sweep_order.empty()) {
            tuned.sweep_order_override = mobility_hint.sweep_order;
        }
        if (have_mobility_hint && mobility_hint.force_symmetric &&
            options_.absorption_method == AbsorptionMethod::Auto &&
            !options_.symmetric_sweep) {
            tuned.symmetric_sweep = true;
        }

        bool allow_profile_write =
            !has_slopes_use &&
            (mobility_cfg.mode == "write" ||
             (mobility_cfg.mode == "auto" && mobility_cfg.allow_auto_write && !mobility_profile_match));
        bool allow_cache_read = false;
        bool allow_cache_write = false;
        std::string cache_path;
        if (abs_cache_cfg.mode_set) {
            if (abs_cache_cfg.mode != "off") {
                if (!abs_cache_cfg.path.empty()) {
                    cache_path = abs_cache_cfg.path;
                } else if (mobility_cfg.mode != "off") {
                    cache_path = absorption_cache_path(mobility_cfg.path);
                }
                allow_cache_read =
                    abs_cache_cfg.mode == "read" || abs_cache_cfg.mode == "auto";
                allow_cache_write =
                    abs_cache_cfg.mode == "write" ||
                    (abs_cache_cfg.mode == "auto" && abs_cache_cfg.allow_auto_write);
                if (cache_path.empty()) {
                    allow_cache_read = false;
                    allow_cache_write = false;
                }
            }
        } else if (abs_cache_cfg.mode != "off" && !abs_cache_cfg.path.empty()) {
            allow_cache_read =
                abs_cache_cfg.mode == "read" || abs_cache_cfg.mode == "auto";
            allow_cache_write =
                abs_cache_cfg.mode == "write" ||
                (abs_cache_cfg.mode == "auto" && abs_cache_cfg.allow_auto_write);
            cache_path = abs_cache_cfg.path;
        } else {
            allow_cache_read =
                mobility_cfg.mode == "read" || mobility_cfg.mode == "auto";
            allow_cache_write =
                mobility_cfg.mode == "write" ||
                (mobility_cfg.mode == "auto" && mobility_cfg.allow_auto_write);
            cache_path = absorption_cache_path(mobility_cfg.path);
        }
        if (has_slopes_use) {
            allow_cache_read = false;
            allow_cache_write = false;
            cache_path.clear();
        }
        if (skip_cache_read) {
            allow_cache_read = false;
        }
        AbsorptionCacheKey abs_cache_key;
        bool abs_cache_key_ready = false;
        bool cache_hit = false;
        std::optional<CachedSavefePublication> cached_savefe;

        // PF3_CANDIDATE2_PROTOTYPE_BEGIN
        // Accuracy-only opt-in for the standard CUDA Auto/comparable path.
        // Keep the default and every adjacent estimator surface byte-for-byte
        // equivalent unless the explicit environment gate is enabled.
        const bool cuda_auto_comparable_accuracy_retry =
            read_env_bool("XHDFE_CUDA_AUTO_COMPARABLE_ACCURACY_RETRY").value_or(false) &&
            options_.absorption_method == AbsorptionMethod::Auto &&
            options_.convergence_criterion == ConvergenceCriterion::Auto &&
            options_.tolerance_mode == ToleranceMode::ReghdfeComparable &&
            cuda_backend_env_requested() &&
            !options_.retain_fixed_effects && !options_.refine_stored_residuals &&
            !options_.save_groupvar && !options_.symmetric_sweep &&
            !options_.use_sparse_solver && !options_.use_krylov &&
            options_.sweep_order_override.empty() &&
            !env_krylov.has_value() && !has_slopes_use && w_ptr == nullptr &&
            !wants_iv && !has_instruments &&
            mobility_cfg.mode == "off" && abs_cache_cfg.mode == "off" &&
            fe_cache_cfg.mode == "off" && !fe_cache_hit &&
            !allow_profile_write && !allow_cache_read && !allow_cache_write &&
            !savefe_profile_enabled() && !cpu_profile_enabled() &&
            tuned.tol > 1.0e-10;
        const bool cuda_auto_comparable_accuracy_retry_diag =
            read_env_bool(
                "XHDFE_CUDA_AUTO_COMPARABLE_ACCURACY_RETRY_DIAG").value_or(false);
        const bool cuda_auto_forward_accuracy_repair =
            read_env_bool(
                "XHDFE_CUDA_AUTO_FORWARD_ACCURACY_REPAIR").value_or(false) &&
            options_.absorption_method == AbsorptionMethod::Auto &&
            options_.convergence_criterion == ConvergenceCriterion::Auto &&
            (options_.tolerance_mode == ToleranceMode::ReghdfeComparable ||
             options_.tolerance_mode == ToleranceMode::XhdfeFast) &&
            cuda_backend_env_requested() &&
            !options_.retain_fixed_effects && !options_.refine_stored_residuals &&
            !options_.save_groupvar && !options_.symmetric_sweep &&
            !options_.use_sparse_solver && !options_.use_krylov &&
            options_.sweep_order_override.empty() &&
            !env_krylov.has_value() && !has_slopes_use && w_ptr == nullptr &&
            !wants_iv && !has_instruments &&
            mobility_cfg.mode == "off" && abs_cache_cfg.mode == "off" &&
            fe_cache_cfg.mode == "off" && !fe_cache_hit &&
            !allow_profile_write && !allow_cache_read && !allow_cache_write &&
            !savefe_profile_enabled() && !cpu_profile_enabled();
        const std::optional<bool> cuda_accuracy_ladder_override =
            read_env_bool(
                "XHDFE_CUDA_AUTO_COMPARABLE_ACCURACY_LADDER");
        const bool cuda_auto_comparable_accuracy_ladder =
            cuda_auto_forward_accuracy_repair
                ? cuda_accuracy_ladder_override.value_or(true)
                : (cuda_auto_comparable_accuracy_retry &&
                   cuda_accuracy_ladder_override.value_or(false));
        // PF3_CANDIDATE2_PROTOTYPE_END

        if (have_mobility_hint && options_.absorption_method == AbsorptionMethod::Auto &&
            !options_.use_krylov && !options_.use_sparse_solver) {
            if (mobility_hint.use_krylov) {
                tuned.use_krylov = true;
                tuned.use_sparse_solver = false;
            } else if (mobility_hint.use_sparse) {
                tuned.use_sparse_solver = true;
                tuned.use_krylov = false;
            } else {
                tuned.use_krylov = false;
                tuned.use_sparse_solver = false;
            }
        }
        if (env_krylov.has_value()) {
            tuned.use_krylov = *env_krylov;
            if (tuned.use_krylov) {
                tuned.use_sparse_solver = false;
            }
        }

        // Package B (strict-residual on CUDA): the candidate is today's strict
        // CUDA gate (standard_auto_precision_repair below, evaluated here with
        // the effective tuned solver flags, and the branch of the repair lambda)
        // with the public exclusions: auto-mlsmr, weights, saved effects, the
        // group() re-entry of fit_grouped and the Stata collapse (the mark), and
        // the legacy switch. The record is set where the lambda takes that
        // branch; it governs the route, the acceptance, the stored vector and
        // the trace. The route reads its own comparable copy of the options
        // (strict_cuda_route); tuned keeps the strict configuration.
        const bool strict_cuda_scope_candidate =
            !strict_cuda_legacy_acceptance() && !fes_use.empty() &&
            cuda_backend_env_requested() &&
            options_.absorption_method == AbsorptionMethod::Auto &&
            options_.convergence_criterion == ConvergenceCriterion::Auto &&
            tuned.tolerance_mode == ToleranceMode::StrictResidual &&
            !has_slopes_use && !tuned.use_sparse_solver && !tuned.use_krylov &&
            w_ptr == nullptr && !options_.retain_fixed_effects &&
            !suppress_auto_routing_retry_ && !grouped_call_mark_;
        bool strict_cuda_scope = false;
        bool strict_cuda_route_from_auto = tuned.from_auto;
        HdfeOptions strict_cuda_route;
        // Package B, stage 2a' (b/RESPOSTA_2A_B.md): the sweep-exit request of a fit
        // in scope, given to its primary absorption only (fe_absorption.hpp).
        detail::StrictSweepExitRequest strict_sweep_exit;

        bool benchmark_methods =
            allow_profile_write && !have_mobility_hint &&
            options_.absorption_method == AbsorptionMethod::Auto &&
            !options_.symmetric_sweep && !options_.use_sparse_solver &&
            !options_.use_krylov && fes_use.size() > 1;

        AbsorptionMethod preferred_method = AbsorptionMethod::Auto;
        if (have_mobility_hint && mobility_hint.has_method) {
            preferred_method = mobility_hint.preferred_method;
        }
        AbsorptionMethod selected_method = AbsorptionMethod::Auto;
        if (options_.absorption_method != AbsorptionMethod::Auto) {
            selected_method = options_.absorption_method;
        } else if (options_.symmetric_sweep) {
            selected_method = AbsorptionMethod::SymmetricGaussSeidel;
        } else if (preferred_method != AbsorptionMethod::Auto) {
            selected_method = preferred_method;
        }
        bool cuda_auto_forward_probe_candidate = false;
        bool weighted_four_fe_auto_band = false;
        bool weighted_three_fe_iv_auto_band = false;
        auto select_cpu_auto_mlsmr = [&](const HdfeOptions& selection_options) {
            const AbsorptionMethod fallback = auto_mlsmr_sweep_fallback(
                fes_use.size(), selection_options.symmetric_sweep);
            const AbsorptionMethod picked = select_auto_mlsmr_method(
                fes_use, w_ptr, selection_options, static_cast<int>(X_use.cols()),
                fallback, nullptr, tuned.num_threads, tuned.parallel_observer,
                singleton_scan_levels.size() == fes_use.size() ? &singleton_scan_levels : nullptr);
            return picked == AbsorptionMethod::Mlsmr ? picked : fallback;
        };
        // ---- Auto-MLSMR selection (CPU-only, standard FEs) -----------------------
        // Plain absorptionmethod(auto) now uses the same selector as the explicit
        // absorptionmethod(auto-mlsmr) alias. The selector probes standard-FE designs
        // and resolves to MLSMR only for large, slow-converging cases; otherwise it
        // resolves to the sweep fallback. Resolving the fallback here also prevents a
        // second survey by the adaptive Schwarz gate after the selector has already
        // decided to stay on a sweep. GPU, savefe, and heterogeneous-slope cases
        // resolve to the sweep fallback. Preserve Comparable CUDA Auto intent
        // only for ordinary unweighted two-FE LSMR selection (CUDA04); the
        // other published routes do not need that replacement.
        {
            const bool explicit_auto_mlsmr =
                (options_.absorption_method == AbsorptionMethod::AutoMlsmr);
            const bool default_auto_promote =
                (options_.absorption_method == AbsorptionMethod::Auto) &&
                (selected_method == AbsorptionMethod::Auto);
            // GUARD: 4+ FE default-auto stays on the full-data gate/MAP path. The
            // 200k-sample rho probe over-promotes huge, well-connected 4-way
            // graphs to MLSMR (simulated_panel 173M: full-data 7 GS iters but
            // sample rho=0.79 -> MLSMR ~46x). Explicit absorptionmethod(auto-mlsmr)
            // is uncapped. Tune the cap with XHDFE_AUTO_MLSMR_DEFAULT_MAX_FES.
            const int default_promote_max_fes =
                read_env_int("XHDFE_AUTO_MLSMR_DEFAULT_MAX_FES", 3, 1);
            // A bounded four-FE band covers medium matched-panel designs such
            // as `workers`, where the selector chooses a faster and materially
            // tighter MLSMR solve. Keep very large four-way designs on their
            // established sweep path: the 173M-row simulated panel is
            // well-connected and MLSMR is about 46x slower there. The row cap
            // is deliberately independent of thread count.
            const int default_four_fe_max_rows = read_env_int(
                "XHDFE_AUTO_MLSMR_DEFAULT_4FE_MAX_ROWS", 2000000, 1);
            const bool bounded_four_fe_promote =
                default_promote_max_fes >= 3 &&
                fes_use.size() == 4 &&
                y_use.size() <= default_four_fe_max_rows;
            const bool default_auto_promote_eff =
                default_auto_promote &&
                (static_cast<int>(fes_use.size()) <= default_promote_max_fes ||
                 bounded_four_fe_promote);
            const bool weighted_auto_projection = default_auto_promote_eff && w_ptr != nullptr &&
                options_.tolerance_mode == ToleranceMode::ReghdfeComparable &&
                options_.convergence_criterion == ConvergenceCriterion::Auto &&
                !has_slopes_use && !suppress_auto_routing_retry_ && !grouped_call_mark_ &&
                !benchmark_methods && !tuned.symmetric_sweep &&
                !tuned.use_sparse_solver && !tuned.use_krylov;
            weighted_four_fe_auto_band = weighted_auto_projection &&
                fes_use.size() == 4 && !wants_iv && !has_instruments;
            weighted_three_fe_iv_auto_band = weighted_auto_projection &&
                fes_use.size() == 3 && options_.fit_intercept &&
                !options_.weights_are_frequencies && endogenous_idx.size() == 1 &&
                inst_use && inst_use->cols() == 1;
            const bool use_auto_mlsmr_selector =
                explicit_auto_mlsmr || default_auto_promote_eff;
            if (use_auto_mlsmr_selector && !has_slopes_use &&
                !options_.retain_fixed_effects && !gpu_backend_env_requested()) {
                selected_method = select_cpu_auto_mlsmr(options_);
                tuned.from_auto = false;
                benchmark_methods = false;
            } else if (use_auto_mlsmr_selector) {
                if (cuda_auto_forward_accuracy_repair && !has_slopes_use &&
                    !options_.retain_fixed_effects) {
                    const int fast_min_rows = read_env_int(
                        "XHDFE_AUTO_MLSMR_FAST_MIN_ROWS", 1000000, 1);
                    const int fast_min_rhs = read_env_int(
                        "XHDFE_AUTO_MLSMR_FAST_MIN_RHS", 8, 1);
                    const int fast_min_fes = read_env_int(
                        "XHDFE_AUTO_MLSMR_FAST_MIN_FES", 3, 1);
                    const int rhs_count = static_cast<int>(X_use.cols());
                    const bool moderate_band_shape =
                        y_use.size() >= fast_min_rows &&
                        rhs_count >= fast_min_rhs &&
                        static_cast<int>(fes_use.size()) >= fast_min_fes &&
                        rhs_count + 1 +
                                (options_.fit_intercept ? 1 : 0) <=
                            detail::kCudaForwardProbeMaxP;
                    if (moderate_band_shape) {
                        const AbsorptionMethod sweep_fallback =
                            auto_mlsmr_sweep_fallback(
                                fes_use.size(), options_.symmetric_sweep);
                        AutoMlsmrSelectionDiagnostics diagnostics;
                        (void)select_auto_mlsmr_method(
                            fes_use, w_ptr, options_, rhs_count,
                            sweep_fallback, &diagnostics, tuned.num_threads,
                            tuned.parallel_observer,
                            singleton_scan_levels.size() == fes_use.size()
                                ? &singleton_scan_levels : nullptr);
                        const double rho_min = read_env_double(
                            "XHDFE_AUTO_MLSMR_FAST_RHO_MIN", 0.60,
                            0.0, 1.0);
                        const double rho_max = read_env_double(
                            "XHDFE_AUTO_MLSMR_FAST_RHO_MAX", 0.675,
                            0.0, 1.0);
                        cuda_auto_forward_probe_candidate =
                            diagnostics.evaluated &&
                            diagnostics.per_sweep_rho >= rho_min &&
                            diagnostics.per_sweep_rho <= rho_max;
                        if (cuda_auto_comparable_accuracy_retry_diag) {
                            std::cerr
                                << "xhdfe cuda_auto_forward_accuracy_repair"
                                << " event=preselector"
                                << " candidate="
                                << (cuda_auto_forward_probe_candidate ? 1 : 0)
                                << " rho="
                                << diagnostics.per_sweep_rho
                                << " rho_min=" << rho_min
                                << " rho_max=" << rho_max << '\n';
                        }
                    }
                }
                // GPU-requested or ineligible auto selector -> normal sweep selector.
                selected_method =
                    auto_mlsmr_sweep_fallback(fes_use.size(), options_.symmetric_sweep);
                tuned.from_auto = cuda_backend_env_requested() &&
                    fes_use.size() == 2 && w_ptr == nullptr &&
                    options_.absorption_method == AbsorptionMethod::Auto &&
                    options_.tolerance_mode == ToleranceMode::ReghdfeComparable &&
                    options_.convergence_criterion == ConvergenceCriterion::Auto;
                if (strict_cuda_scope_candidate) {
                    // Package B: the value the line above gives a reghdfe-comparable
                    // request; the route of a fit in scope takes it, tuned keeps its own.
                    strict_cuda_route_from_auto = cuda_backend_env_requested() &&
                        fes_use.size() == 2 && w_ptr == nullptr &&
                        options_.absorption_method == AbsorptionMethod::Auto &&
                        options_.convergence_criterion == ConvergenceCriterion::Auto;
                }
                if (gpu_backend_env_requested() && !has_slopes_use &&
                    !options_.retain_fixed_effects) {
                    // F2-A: without the GPU request the branch above would take
                    // this fit's route from the selector. The CUDA three-FE
                    // Comparable completion asks it the same question, with the
                    // same arguments (design, public options, fallback, team,
                    // level counts), only after it predicts a long device tail,
                    // so short tails never pay the probe; once per fit, the
                    // answer is remembered. Its full cost is recorded for the
                    // trace only; no decision reads a clock.
                    const int route_rhs = static_cast<int>(X_use.cols());
                    const AbsorptionMethod route_fallback =
                        auto_mlsmr_sweep_fallback(fes_use.size(), options_.symmetric_sweep);
                    const int route_threads = tuned.num_threads;
                    detail::ParallelWorkObserver* const route_observer =
                        tuned.parallel_observer;
                    cuda_tail_route = [&, this, route_rhs, route_fallback, route_threads,
                                       route_observer]() {
                        if (!cuda_tail_route_answer) {
                            const auto route_t0 = std::chrono::steady_clock::now();
                            ++cuda_tail_route_evaluations;
                            AutoMlsmrSelectionDiagnostics diagnostics;
                            // Package B: a fit in scope (the record, read when the
                            // selector is first asked) asks the question of a
                            // reghdfe-comparable request (the band at
                            // select_auto_mlsmr_method's low_rhs_precision_band is off).
                            HdfeOptions strict_cuda_request;
                            if (strict_cuda_scope) {
                                strict_cuda_request = options_;
                                strict_cuda_request.tolerance_mode =
                                    ToleranceMode::ReghdfeComparable;
                            }
                            const AbsorptionMethod picked = select_auto_mlsmr_method(
                                fes_use, w_ptr, strict_cuda_scope ? strict_cuda_request : options_,
                                route_rhs, route_fallback,
                                &diagnostics, route_threads, route_observer,
                                singleton_scan_levels.size() == fes_use.size()
                                    ? &singleton_scan_levels : nullptr);
                            detail::AutoRouteAnswer answer;
                            answer.mlsmr = picked == AbsorptionMethod::Mlsmr;
                            answer.rho = diagnostics.per_sweep_rho;
                            answer.seconds = std::chrono::duration<double>(
                                std::chrono::steady_clock::now() - route_t0).count();
                            cuda_tail_route_answer = answer;
                        }
                        detail::AutoRouteAnswer answer = *cuda_tail_route_answer;
                        answer.evaluations = cuda_tail_route_evaluations;
                        return answer;
                    };
                }
                benchmark_methods = false;
            }
        }
        if (has_slopes_use &&
            (options_.absorption_method == AbsorptionMethod::Auto ||
             options_.absorption_method == AbsorptionMethod::AutoMlsmr)) {
            // The auto-MLSMR selector intentionally falls back to sweeps for
            // slopes, but Option-A's slope certificate/continuation must still
            // remember that the public request was adaptive Auto.
            tuned.from_auto = true;
        }
        if (selected_method == AbsorptionMethod::Auto && fes_use.size() == 2 &&
            y_use.size() < 50000) {
            const bool has_inst_use = inst_use && inst_use->cols() > 0;
            if (const auto fast_method = select_two_fe_auto_fastpath(
                    fes_use, w_ptr, options_, gpu_backend_env_requested(), has_inst_use)) {
                selected_method = *fast_method;
            }
        }

        // Cache identity must not depend on whether ensure_cache_key() first
        // runs before or after the solve.  The compute path mutates `tuned`
        // below to record the concrete method selected from Auto; hashing that
        // mutable object made a write-only run produce a different key from an
        // otherwise identical read-only run.  Freeze the fully resolved
        // pre-solve configuration (including effective threads, explicit-team
        // status, mobility/env choices and the effective GPU request) once and
        // use the same immutable snapshot for both reads and writes.
        const HdfeOptions cache_key_options = tuned;

        detail::AbsorptionResult absorption;
        // E1: the fits whose certified capturing primary is followed by the
        // projection of the mode (publish_savefe_projection below): saved
        // effects, public reghdfe-comparable and Auto method, no slopes (their
        // effects come from the mixed recovery), not the group() re-entry, no
        // instruments except for the just-identified weighted three-effect
        // CPU fit, whose plain fit can select MLSMR on the augmented design.
        const bool reuse_weighted_cpu_selector =
            (weighted_four_fe_auto_band || weighted_three_fe_iv_auto_band) &&
            !mobility_gpu_backend_selected();
        const bool savefe_accurate_projection =
            options_.retain_fixed_effects && !fes_use.empty() &&
            options_.tolerance_mode == ToleranceMode::ReghdfeComparable &&
            options_.absorption_method == AbsorptionMethod::Auto &&
            !has_slopes_use && !suppress_auto_routing_retry_ &&
            ((!wants_iv && !has_instruments) ||
             (weighted_three_fe_iv_auto_band && reuse_weighted_cpu_selector)) &&
            savefe_accurate_projection_enabled();
        const bool reselect_weighted_savefe_projection = savefe_accurate_projection &&
            reuse_weighted_cpu_selector;
        // Amendment of 16nov2026 (auditor): only a capturing primary whose
        // certificate (abs_residual_rel) stopped above the floor of the mode
        // is sent to the projection. The floor is the Krylov parity floor that
        // MLSMR and the reduced tier apply at this tolerance (1e-11 at the
        // default 1e-8; it follows the public tolerance), not a new tolerance:
        // at or below it the sweep already meets what the route of the mode
        // delivers, and it is published exactly as before.
        const double savefe_projection_floor =
            savefe_accurate_projection ? detail::mode_parity_floor(tuned) : 0.0;
        // Set only while that projection runs: the reduced tier then reads the
        // fit as the same fit without saved effects.
        bool savefe_projection_tier_eligible = false;
        // Point 13 (17nov2026), the tier's trace only: while the capturing sweep
        // of a fit that E1 may follow with a projection runs (owable, set by
        // absorb_with_precision_repair with the trace on), its final line
        // "status=ineligible reason=savefe" is owed instead of printed. Once E1
        // decides, absorb_with_precision_repair prints it, or
        // publish_savefe_projection hands the fit the projection's own line.
        bool savefe_final_line_owable = false;
        bool savefe_final_line_owed = false;
        // The published absorption is that projection: the residuals and the
        // constant are then those of the fit without saved effects.
        bool savefe_projection_published = false;
        const bool standard_auto_precision_repair =
            !fes_use.empty() &&
            (options_.absorption_method == AbsorptionMethod::Auto ||
             options_.absorption_method == AbsorptionMethod::AutoMlsmr) &&
            options_.convergence_criterion == ConvergenceCriterion::Auto &&
            !has_slopes_use && !tuned.use_sparse_solver && !tuned.use_krylov;
        const bool bound_cpu_strict_repair =
            tuned.tolerance_mode == ToleranceMode::StrictResidual &&
            options_.absorption_method == AbsorptionMethod::Auto &&
            standard_auto_precision_repair && !tuned.retain_fixed_effects &&
            !wants_iv && !has_instruments && !grouped_call_mark_ && !suppress_auto_routing_retry_ &&
            w_ptr == nullptr && !mobility_gpu_backend_selected();
        // Medium four-way matched panels such as `workers` are the bounded
        // CUDA counterpart of the CPU auto-MLSMR promotion above. Their
        // ill-conditioned FE graph can satisfy the public 1e-8 residual
        // contract while CUDA atomic-order noise still moves coefficients at
        // about 1e-7 across otherwise identical processes. In fast mode,
        // start directly with the scale-invariant update criterion that an
        // unsuccessful primary pass would otherwise trigger; in comparable
        // mode, solve at a tighter internal tolerance. Both retain the
        // caller's original tolerance for the public certificate.
        const bool bounded_four_fe_cuda =
            standard_auto_precision_repair && cuda_backend_env_requested() &&
            !options_.retain_fixed_effects && w_ptr == nullptr &&
            fes_use.size() == 4 && y_use.size() <= detail::kBoundedCudaProjectionRows &&
            tuned.tol > 0.0 && tuned.tol <= 1.0e-8;
        const bool bounded_four_fe_cuda_fast =
            bounded_four_fe_cuda &&
            tuned.tolerance_mode == ToleranceMode::XhdfeFast;
        const bool bounded_four_fe_cuda_precision =
            bounded_four_fe_cuda &&
            tuned.tolerance_mode == ToleranceMode::ReghdfeComparable;
        const double bounded_precision_limit =
            bounded_four_fe_cuda_precision
                ? std::min(1.0e-10, 0.5 * tuned.tol)
                : 0.5 * tuned.tol;
        auto bounded_auto_gate_failed = [&](const detail::AbsorptionResult& candidate) {
            const bool bounded_fast_contract =
                standard_auto_precision_repair &&
                tuned.tolerance_mode == ToleranceMode::XhdfeFast &&
                tuned.tol > 0.0 && tuned.tol <= 1.0e-8 &&
                y_use.size() < 1000000;
            return (bounded_fast_contract || bounded_four_fe_cuda_precision) &&
                candidate.abs_residual_rel > bounded_precision_limit;
        };
        // Package B: the options and the bounded four-effect decisions the route
        // reads. For a fit in scope (the record) they are those of a
        // reghdfe-comparable request: its copy strict_cuda_route, the precision
        // flag of a bounded four-effect fit, no fast flag, the precision limit.
        // Outside the scope, and after a status 2 drops the record, they are the
        // strict configuration above, unchanged.
        auto route_options = [&]() -> const HdfeOptions& {
            return strict_cuda_scope ? strict_cuda_route : tuned;
        };
        auto route_bounded_fast = [&]() {
            return strict_cuda_scope ? false : bounded_four_fe_cuda_fast;
        };
        auto route_bounded_precision = [&]() {
            return strict_cuda_scope ? bounded_four_fe_cuda : bounded_four_fe_cuda_precision;
        };
        auto route_bounded_limit = [&]() {
            return strict_cuda_scope
                ? (bounded_four_fe_cuda ? std::min(1.0e-10, 0.5 * tuned.tol) : 0.5 * tuned.tol)
                : bounded_precision_limit;
        };
        auto route_gate_failed = [&](const detail::AbsorptionResult& candidate) {
            return strict_cuda_scope
                ? (route_bounded_precision() && candidate.abs_residual_rel > route_bounded_limit())
                : bounded_auto_gate_failed(candidate);
        };
        std::unique_ptr<detail::MixedNetworkScores> network_scores;
        auto absorb_with_precision_repair_impl = [&](
            const Eigen::Ref<const Eigen::MatrixXd>& design,
            AbsorptionMethod requested_method) {
            network_scores.reset();
            auto& slope = slope_solver_diagnostics_;
            const bool slope_requested = slope.request != SlopeSolverRequest::Off;
            if (slope_requested) {
                const char* reason = (suppress_auto_routing_retry_ || grouped_call_mark_) ? "group"
                    : !has_slopes_use ? "no_slopes"
                    : !detail::reduced_pcg_effective(options_) ? "tier_off" : "not_reached";
                slope.reset_outcome(reason);
            }
            int mixed_network_spent = 0;
            int mixed_network_gpu_spent = 0;
            std::optional<detail::ScopedCudaForwardProbeRequest>
                forward_probe_request;
            if (cuda_auto_forward_probe_candidate) {
                forward_probe_request.emplace(true);
            }
            bool requested_backend_unavailable = false;
            std::optional<detail::ScopedGpuBackendOverride>
                unavailable_backend_cpu_fallback;
            // The half of the retry's eligibility known before the primary
            // solve; finalize_backend_status adds the primary's outcome.
            // Early routing applies only where it holds.
            auto retry_statically_eligible = [&]() {
                const bool in_band =
                    !fes_use.empty() &&
                    (fes_use.size() <= 3 ||
                     (fes_use.size() == 4 && y_use.size() <= 2000000));
                bool nested = false;
#ifdef HDFE_USE_OPENMP
                nested = omp_in_parallel() != 0;
#endif
                return tuned.ordinary_auto_routing_retry &&
                       options_.absorption_method == AbsorptionMethod::Auto &&
                       (requested_method == AbsorptionMethod::GaussSeidel ||
                        requested_method == AbsorptionMethod::SymmetricGaussSeidel) &&
                       in_band && !wants_iv && !has_instruments &&
                       !cuda_backend_env_requested() &&
                       tuned.tolerance_mode == ToleranceMode::ReghdfeComparable &&
                       tuned.tol == 1.0e-8 && w_ptr == nullptr && slope_terms.empty() &&
                       !tuned.retain_fixed_effects && !tuned.save_groupvar &&
                       !tuned.use_sparse_solver && !tuned.use_krylov && !nested;
            };
            auto finalize_backend_status = [&](detail::AbsorptionResult candidate) {
                if (requested_backend_unavailable) {
                    candidate.gpu_used = false;
                    candidate.gpu_status_code = 2;
                    candidate.gpu_attempted = false;
                    candidate.gpu_absorption_converged = false;
                    candidate.gpu_absorption_iterations = 0;
                }
                if (mixed_network_gpu_spent > 0) {
                    candidate.gpu_attempted = true;
                    candidate.gpu_absorption_iterations += mixed_network_gpu_spent;
                }
                if (candidate.auto_routing_retry_status == 4) {
                    // The primary left early and the retry's MLSMR, run at
                    // once, was certified: its diagnostics stand as set.
                    if (early_routing_trace_on()) {
                        std::ostringstream line;
                        line.precision(10);
                        line << "xhdfe early_routing_trace event=final static_eligible=1"
                             << " eligible=1 requested=" << static_cast<int>(requested_method)
                             << " primary="
                             << candidate.auto_routing_retry_primary_method
                             << " primary_iterations="
                             << candidate.auto_routing_retry_primary_iterations
                             << " primary_rel="
                             << candidate.auto_routing_retry_primary_abs_residual_rel
                             << " primary_converged=0 primary_certified=0 status=4"
                             << " retry_iterations=" << candidate.auto_routing_retry_iterations
                             << " retry_rel=" << candidate.auto_routing_retry_abs_residual_rel
                             << " retry_s=" << candidate.auto_routing_retry_elapsed_seconds
                             << " iterations=" << candidate.iterations
                             << " mlsmr=" << (candidate.mlsmr_used ? 1 : 0)
                             << " rel=" << candidate.abs_residual_rel << '\n';
                        std::cerr << line.str();
                    }
                    return candidate;
                }
                AbsorptionMethod actual_primary_method = requested_method;
                if (candidate.mlsmr_used) {
                    actual_primary_method = krylov_method_used(candidate);
                } else if (candidate.schwarz_used) {
                    actual_primary_method = AbsorptionMethod::Schwarz;
                }
                const bool in_default_promotion_band =
                    !fes_use.empty() &&
                    (fes_use.size() <= 3 ||
                     (fes_use.size() == 4 && y_use.size() <= 2000000));
                bool nested_parallel = false;
#ifdef HDFE_USE_OPENMP
                nested_parallel = omp_in_parallel() != 0;
#endif
                candidate.auto_routing_retry_policy_enabled =
                    tuned.ordinary_auto_routing_retry;
                candidate.auto_routing_retry_primary_method =
                    static_cast<int>(actual_primary_method);
                candidate.auto_routing_retry_primary_iterations =
                    candidate.iterations;
                candidate.auto_routing_retry_primary_abs_residual_rel =
                    candidate.abs_residual_rel;
                const bool eligible =
                    tuned.ordinary_auto_routing_retry &&
                    options_.absorption_method == AbsorptionMethod::Auto &&
                    !candidate.mlsmr_used && !candidate.schwarz_used &&
                    (actual_primary_method == AbsorptionMethod::GaussSeidel ||
                     actual_primary_method ==
                         AbsorptionMethod::SymmetricGaussSeidel) &&
                    in_default_promotion_band && !wants_iv && !has_instruments &&
                    !cuda_backend_env_requested() && !candidate.gpu_used &&
                    !candidate.gpu_attempted && candidate.gpu_status_code == 0 &&
                    candidate.converged && candidate.precision_certified &&
                    tuned.tolerance_mode == ToleranceMode::ReghdfeComparable &&
                    tuned.tol == 1.0e-8 &&
                    // P8 (CPU-W): weighted fits too, within the bounds of
                    // cpu_weighted_retry_enabled (k <= 3, public Comparable,
                    // Auto method and criterion).
                    (w_ptr == nullptr ||
                     (cpu_weighted_retry_enabled() && tuned.comparable_intent &&
                      options_.convergence_criterion == ConvergenceCriterion::Auto &&
                      fes_use.size() <= 3)) &&
                    slope_terms.empty() && !tuned.retain_fixed_effects &&
                    !tuned.save_groupvar && !tuned.use_sparse_solver &&
                    !tuned.use_krylov && !nested_parallel;
                candidate.auto_routing_retry_eligible = eligible;
                if (eligible) {
                    candidate.auto_routing_retry_status = 1;
                }
                // Early-routing trace: the outcome of this solve and of the
                // retry, with the static half of `eligible` (the conditions
                // known before the primary solve).
                auto trace_final = [&](const detail::AbsorptionResult& out) {
                    if (!early_routing_trace_on()) {
                        return;
                    }
                    const bool static_eligible = retry_statically_eligible();
                    std::ostringstream line;
                    line.precision(10);
                    line << "xhdfe early_routing_trace event=final"
                         << " static_eligible=" << (static_eligible ? 1 : 0)
                         << " eligible=" << (eligible ? 1 : 0)
                         << " requested=" << static_cast<int>(requested_method)
                         << " primary=" << static_cast<int>(actual_primary_method)
                         << " primary_iterations=" << candidate.iterations
                         << " primary_rel=" << candidate.abs_residual_rel
                         << " primary_converged=" << (candidate.converged ? 1 : 0)
                         << " primary_certified=" << (candidate.precision_certified ? 1 : 0)
                         << " status=" << out.auto_routing_retry_status
                         << " retry_iterations=" << out.auto_routing_retry_iterations
                         << " retry_rel=" << out.auto_routing_retry_abs_residual_rel
                         << " retry_s=" << out.auto_routing_retry_elapsed_seconds
                         << " iterations=" << out.iterations
                         << " mlsmr=" << (out.mlsmr_used ? 1 : 0)
                         << " rel=" << out.abs_residual_rel << '\n';
                    std::cerr << line.str();
                };
                if (read_env_bool("XHDFE_AUTO_ROUTING_RETRY_DIAG").value_or(false)) {
                    std::cerr << "xhdfe auto_routing_retry"
                              << " policy=" << (tuned.ordinary_auto_routing_retry ? 1 : 0)
                              << " eligible=" << (eligible ? 1 : 0)
                              << " requested=" << static_cast<int>(options_.absorption_method)
                              << " primary=" << static_cast<int>(actual_primary_method)
                              << " certified=" << (candidate.precision_certified ? 1 : 0)
                              << " rel=" << candidate.abs_residual_rel << '\n';
                }
                // P8 (CPU-W, its accounting; cpu_retry_accounting_enabled): a
                // weighted retry runs within what the primary left of max_iter.
                const bool retry_accounting = w_ptr != nullptr && cpu_retry_accounting_enabled();
                const int retry_budget =
                    std::max(0, tuned.max_iter - std::max(0, candidate.iterations));
                if (retry_accounting && eligible && retry_budget <= 0 &&
                    candidate.abs_residual_rel > kOrdinaryAutoRoutingRetryTrigger) {
                    // Nothing left for the retry: the primary stands (status 3).
                    candidate.auto_routing_retry_status = 3;
                }
                if (eligible && candidate.abs_residual_rel >
                                    kOrdinaryAutoRoutingRetryTrigger &&
                    (!retry_accounting || retry_budget > 0)) {
                    const auto retry_started = std::chrono::steady_clock::now();
                    HdfeOptions retry_options = tuned;
                    retry_options.absorption_method = AbsorptionMethod::Mlsmr;
                    retry_options.from_auto = false;
                    if (retry_accounting) retry_options.max_iter = retry_budget;
                    detail::AbsorptionResult retry =
                        detail::absorb_fixed_effects_v6(
                            y_use, design, fes_use, w_ptr, retry_options,
                            AbsorptionMethod::Mlsmr, slope_terms);
                    detail::certify_absorption_result(
                        y_use, design, fes_use, w_ptr, tuned, slope_terms, retry);
                    const double retry_seconds = std::chrono::duration<double>(
                        std::chrono::steady_clock::now() - retry_started).count();
                    const bool force_failure = read_env_bool(
                        "XHDFE_TEST_AUTO_ROUTING_RETRY_FAIL").value_or(false);
                    if (force_failure) {
                        retry.converged = false;
                        retry.precision_certified = false;
                    }
                    auto diagnostics = [&](detail::AbsorptionResult& out,
                                           int status) {
                        out.auto_routing_retry_policy_enabled = true;
                        out.auto_routing_retry_eligible = true;
                        out.auto_routing_retry_fired = true;
                        out.auto_routing_retry_status = status;
                        out.auto_routing_retry_primary_method =
                            static_cast<int>(actual_primary_method);
                        out.auto_routing_retry_primary_iterations =
                            candidate.iterations;
                        out.auto_routing_retry_primary_abs_residual_rel =
                            candidate.abs_residual_rel;
                        out.auto_routing_retry_iterations = retry.iterations;
                        out.auto_routing_retry_abs_residual_rel =
                            retry.abs_residual_rel;
                        out.auto_routing_retry_elapsed_seconds = retry_seconds;
                    };
                    if (retry.converged && retry.precision_certified) {
                        diagnostics(retry, 2);
                        // P8 (CPU-W): the published total counts the primary too.
                        if (retry_accounting) retry.iterations += std::max(0, candidate.iterations);
                        retry.mlsmr_used = true;
                        method_used_ = AbsorptionMethod::Mlsmr;
                        trace_final(retry);
                        return retry;
                    }
                    diagnostics(candidate, 3);
                    if (retry_accounting) {
                        // P8 (CPU-W): the trace shows the primary; the published
                        // total counts the discarded retry's work too.
                        trace_final(candidate);
                        candidate.iterations += std::max(0, retry.iterations);
                        return candidate;
                    }
                }
                trace_final(candidate);
                return candidate;
            };
            auto certify_public_contract = [&](detail::AbsorptionResult& candidate) {
                // Package B: a fit in scope is certified as a reghdfe-comparable
                // request (its limit and its dominant-origin normalisation).
                detail::certify_absorption_result(
                    y_use, design, fes_use, w_ptr, route_options(), slope_terms, candidate);
            };
            auto configure_native_cuda_repair = [&](HdfeOptions& candidate) {
                if (w_ptr != nullptr) {
                    candidate.tolerance_mode = ToleranceMode::ReghdfeComparable;
                    candidate.convergence_criterion =
                        ConvergenceCriterion::NormChange;
                    if (candidate.tol > 0.0) {
                        candidate.tol =
                            tuned.tolerance_mode == ToleranceMode::StrictResidual
                                ? 0.1 * candidate.tol
                                : std::min(candidate.tol, 1.0e-11);
                    }
                } else {
                    // A cold CG restart must retain the caller's Comparable
                    // floor even when this repair selects the update check.
                    candidate.tolerance_mode =
                        route_options().tolerance_mode == ToleranceMode::ReghdfeComparable
                            ? ToleranceMode::ReghdfeComparable
                            : ToleranceMode::XhdfeFast;
                    candidate.convergence_criterion =
                        ConvergenceCriterion::Reghdfe;
                }
            };
            // P3-fix (3'): the strict branch passes the strict provenance and
            // whether its native attempt already used the one device LSMR
            // restart of the sequence (RELATORIO_P3FIX_20261109.md 11.3); the
            // weighted repair of the other modes passes neither (unchanged).
            auto run_strict_cuda_repair = [&](int remaining = -1,
                                              bool strict_provenance = false,
                                              bool strict_lsmr_consumed = false) {
                HdfeOptions strict_options = tuned;
                if (remaining >= 0) strict_options.max_iter = remaining;
                strict_options.strict_provenance = strict_provenance;
                strict_options.strict_lsmr_consumed = strict_lsmr_consumed;
                strict_options.tolerance_mode = ToleranceMode::StrictResidual;
                strict_options.convergence_criterion =
                    ConvergenceCriterion::Auto;
                if (strict_options.tol > 0.0) {
                    strict_options.tol = std::min(strict_options.tol, 1.0e-10);
                }
                detail::AbsorptionResult candidate =
                    detail::absorb_fixed_effects_v6(
                        y_use, design, fes_use, w_ptr, strict_options,
                        requested_method, slope_terms);
                certify_public_contract(candidate);
                return candidate;
            };

            // strict-residual's absolute max-mean polish is not scale invariant
            // and can exhaust max_iter after the independent backward-error
            // certificate is already small.  On an explicit CUDA Auto request,
            // use the native CG update criterion at the requested tolerance and
            // judge the result against the original strict certificate.
            detail::AbsorptionResult primary;
            bool primary_ready = false;
            // Package B: where today's branch below is taken, a fit in scope sets
            // the record and takes the route of a reghdfe-comparable request with
            // its own copy of the options (tuned keeps the strict configuration).
            if (strict_cuda_scope_candidate && standard_auto_precision_repair &&
                cuda_backend_env_requested() &&
                tuned.tolerance_mode == ToleranceMode::StrictResidual) {
                strict_cuda_scope = true;
                strict_cuda_route = tuned;
                strict_cuda_route.tolerance_mode = ToleranceMode::ReghdfeComparable;
                strict_cuda_route.from_auto = strict_cuda_route_from_auto;
                // Stage 2a': the public tolerance, passed explicitly (the primary's may
                // be tighter), the rank tolerance of the column selection below, and
                // whether the fit has instruments (the step is then skipped).
                strict_sweep_exit.tol = options_.tol;
                strict_sweep_exit.rank_tol = std::max(1e-6, tuned.tol * 10.0);
                strict_sweep_exit.instruments = wants_iv || has_instruments;
                strict_sweep_exit.frozen_stop = strict_frozen_stop();
                strict_sweep_exit.trace_level = strict_accept_trace_level();
            }
            if (!strict_cuda_scope && standard_auto_precision_repair &&
                cuda_backend_env_requested() &&
                tuned.tolerance_mode == ToleranceMode::StrictResidual) {
                HdfeOptions strict_gpu_options = tuned;
                configure_native_cuda_repair(strict_gpu_options);
                // P3-fix (3'), strict scope: a broken CG stage of this attempt
                // restarts cold with the device LSMR and the strict check in the
                // CUDA wrapper, never with its cold MAP (the sequence's one
                // LSMR restart; cuda_strict_lsmr_restart in the result).
                strict_gpu_options.strict_provenance = true;
                detail::AbsorptionResult strict_gpu =
                    detail::absorb_fixed_effects_v6(
                        y_use, design, fes_use, w_ptr, strict_gpu_options,
                        requested_method, slope_terms);
                certify_public_contract(strict_gpu);
                if (strict_gpu.gpu_used && strict_gpu.converged &&
                    strict_gpu.precision_certified) {
                    return finalize_backend_status(std::move(strict_gpu));
                }
                // A native CG proxy can break down or miss the independent
                // certificate. Retry the strict device path with the remaining
                // actual iteration budget; the public tolerance stays fixed.
                // P3-fix (3'): this is the sequence's one strict repair, with
                // the strict provenance and the state of its LSMR restart; a
                // broken CG stage in it restarts with the device LSMR only if
                // the native attempt did not use it, and is refused otherwise.
                if ((strict_gpu.gpu_used || strict_gpu.gpu_status_code == 3) &&
                    strict_gpu.iterations < tuned.max_iter) {
                    detail::AbsorptionResult strict_retry =
                        run_strict_cuda_repair(
                            tuned.max_iter - strict_gpu.iterations, true,
                            strict_gpu.cuda_strict_lsmr_restart);
                    strict_retry.iterations += strict_gpu.iterations;
                    strict_retry.gpu_absorption_iterations =
                        strict_retry.iterations;
                    if (strict_retry.gpu_used && strict_retry.converged &&
                        strict_retry.precision_certified) {
                        return finalize_backend_status(std::move(strict_retry));
                    }
                    strict_retry.converged = false;
                    strict_retry.precision_certified = false;
                    return finalize_backend_status(std::move(strict_retry));
                }
                if (!strict_gpu.gpu_used && strict_gpu.gpu_status_code == 2) {
                    // CUDA is not compiled or no device is visible.  Preserve
                    // the documented CPU fallback and its honest unavailable
                    // diagnostics; the certification row will still reject it
                    // as a CUDA execution because gpu_used remains false.
                    requested_backend_unavailable = true;
                    unavailable_backend_cpu_fallback.emplace(
                        detail::GpuBackend::Cpu);
                    primary = detail::absorb_fixed_effects_v6(
                        y_use, design, fes_use, w_ptr, tuned,
                        requested_method, slope_terms);
                    primary_ready = true;
                } else {
                    // CUDA was actually attempted but failed, failed to
                    // converge, or failed its public certificate.  Never hide
                    // that outcome behind a CPU result.
                    strict_gpu.converged = false;
                    strict_gpu.precision_certified = false;
                    return finalize_backend_status(std::move(strict_gpu));
                }
            }

            // P3-fix (3'), scope addendum 2 (RELATORIO_P3FIX_20261109.md 11.10): a
            // strict-residual primary on CUDA outside the strict branch above (an
            // explicit criterion or method) carries the strict provenance, so a
            // broken CG stage restarts with the device LSMR and the strict check,
            // never with the cold MAP; its one strict repair follows below.
            const bool strict_primary_provenance =
                !primary_ready &&
                route_options().tolerance_mode == ToleranceMode::StrictResidual &&
                cuda_backend_env_requested();
            // The reduced-system tier (on by default; the fit's request, else
            // XHDFE_REDUCED_PCG=0 for the process, turns it off) before any
            // primary. Eligibility reads the public request
            // (options_), since the savefe refinement re-enters here with
            // tuned.retain_fixed_effects cleared and group() re-enters fit()
            // with the retry suppressed. The one exception is E1's projection
            // after a certified capturing primary (savefe_projection_tier_eligible):
            // it is the same fit without saved effects and is eligible like it;
            // the refinement of an uncertified primary stays out. A declined
            // attempt changes nothing that the chain below reads.
            if (detail::reduced_pcg_effective(options_) && !primary_ready) {
                bool cuda_reduced = false;
                // A CUDA fit whose request a profile or a cache keeps out of the
                // CUDA tier runs the existing CUDA route and names the first that
                // applies; nullptr otherwise.
                const char* cuda_reduced_kept_out = nullptr;
#ifdef HDFE_USE_CUDA
                // Experimental CUDA tier is opt-in (the fit's request, else
                // XHDFE_REDUCED_PCG_CUDA=1 for the process) and never shares
                // persistent cache/profile entries with either existing route.
                // Each of the seven conditions belongs to exactly one reason.
                const bool cuda_reduced_requested =
                    options_.tolerance_mode == ToleranceMode::ReghdfeComparable &&
                    cuda_backend_env_requested() && detail::reduced_pcg_cuda_effective(options_);
                if (cuda_reduced_requested) {
                    cuda_reduced_kept_out =
                        (mobility_cfg.mode != "off" || allow_profile_write) ? "mobility_profile"
                        : (abs_cache_cfg.mode != "off" || allow_cache_read || allow_cache_write)
                              ? "absorption_cache"
                        : (fe_cache_cfg.mode != "off" || fe_cache_hit) ? "fe_structure_cache"
                        : nullptr;
                }
                cuda_reduced = cuda_reduced_requested && cuda_reduced_kept_out == nullptr;
#endif
                bool nested_region = false;
#ifdef HDFE_USE_OPENMP
                nested_region = omp_in_parallel() != 0;
#endif
                const char* ineligible =
                    options_.absorption_method != AbsorptionMethod::Auto ? "method"
                    : options_.convergence_criterion != ConvergenceCriterion::Auto ? "criterion"
                    : options_.tolerance_mode != ToleranceMode::ReghdfeComparable ? "tolerance_mode"
                    : !(tuned.tol > 0.0) ? "tol"
                    : (gpu_backend_env_requested() && !cuda_reduced)
                          ? (cuda_reduced_kept_out != nullptr ? cuda_reduced_kept_out : "gpu")
                    : w_ptr != nullptr ? "weights"
                    : !slope_terms.empty() ? "slopes"
                    : (options_.retain_fixed_effects && !savefe_projection_tier_eligible) ? "savefe"
                    : options_.save_groupvar ? "groupvar"
                    : (wants_iv || has_instruments) ? "iv"
                    : (fes_use.size() < 2 || fes_use.size() > 5) ? "fe_count"
                    : suppress_auto_routing_retry_ ? "group"
                    : !tuned.ordinary_krylov_parity_floor ? "parity_floor"
                    : (tuned.use_krylov || tuned.use_sparse_solver) ? "forced_solver"
                    : allow_profile_write ? "profile_write"
                    : nested_region ? "nested" : nullptr;
                if (slope_requested) {
                    // The leading tier vetoes reach "slopes" before the
                    // ordinary parity floor, which slopes explicitly disable.
                    const char* reason = (suppress_auto_routing_retry_ || grouped_call_mark_) ? "group"
                        : !has_slopes_use ? "no_slopes"
                        : ineligible == nullptr ? "not_reached"
                        : std::strcmp(ineligible, "slopes") != 0 ? ineligible
                        : (options_.retain_fixed_effects || tuned.retain_fixed_effects) ? "savefe"
                        : options_.save_groupvar ? "groupvar"
                        : (wants_iv || has_instruments) ? "iv"
                        : (tuned.use_sparse_solver || tuned.use_krylov) ? "forced_solver"
                        : nested_region ? "nested"
                        : allow_profile_write ? "profile_write"
                        : (allow_cache_read || allow_cache_write) ? "absorption_cache"
                        : fe_cache_cfg.mode != "off" ? "fe_structure_cache"
                        : mobility_cfg.mode != "off" ? "mobility_profile"
                        : !detail::mixed_network_shape(fes_use, slope_terms) ? "shape" : nullptr;
                    if (reason != nullptr) {
                        slope.reason = reason;
                    } else {
                        auto* capture = slope_scores_enabled_ &&
                            drop_intercept && options_.fit_intercept && c_ptr && c_ptr->size() == 2 &&
                            tuned.se_type == StandardErrorType::Cluster &&
                            detail::cluster_shared_passes_enabled() &&
                            !detail::multiway_scores_copy_enabled()
                            ? &network_scores : nullptr;
                        try {
                            auto network = detail::absorb_mixed_network(
                                y_use, design, fes_use, slope_terms, tuned,
                                detail::mixed_network_mode(slope.request), cuda_reduced,
                                c_ptr, capture, slope_csr_owner_enabled_, slope.csr_owner_used);
                            slope.used = slope.request;
                            slope.status = SlopeSolverStatus::Accepted;
                            slope.reason = "none";
                            method_used_ = AbsorptionMethod::KrylovPcg;
                            reduced_pcg_status_ = 0;
                            reduced_pcg_reason_ = "separate_mixed_network";
                            reduced_pcg_discarded_iterations_ = 0;
                            record_reduced_pcg_fine(reduced_pcg_fine_, nullptr);
                            return network;
                        } catch (const detail::MixedNetworkDecline& decline) {
                            mixed_network_spent = decline.iterations;
                            mixed_network_gpu_spent = cuda_reduced ? mixed_network_spent : 0;
                            slope.status = SlopeSolverStatus::Declined;
                            slope.reason = decline.reason;
                            slope.discarded_iters = mixed_network_spent;
                            if (detail::mixed_network_trace_enabled()) {
                                std::fprintf(stderr, "mixed_network_decline reason=%s spent=%d\n",
                                             decline.what(), mixed_network_spent);
                            }
                            if (mixed_network_spent >= tuned.max_iter) throw;
                        }
                    }
                }
                if (ineligible != nullptr) {
                    reduced_pcg_status_ = 0;
                    reduced_pcg_reason_ = ineligible;
                    reduced_pcg_discarded_iterations_ = 0;
                    record_reduced_pcg_fine(reduced_pcg_fine_, nullptr);
                    if (savefe_final_line_owable && std::strcmp(ineligible, "savefe") == 0) {
                        savefe_final_line_owed = true;  // point 13: printed once E1 decides
                    } else {
                        detail::reduced_pcg_final_line(std::string("status=ineligible reason=") + ineligible);
                    }
                } else {
                    // The fit's read-only diagnostics; an accepted result is
                    // reported as ReducedPcg with the tier's iterations, a
                    // declined one keeps the chain's method and iterations.
                    detail::ReducedPcgOutcome outcome;
                    std::optional<detail::AbsorptionResult> reduced;
#ifdef HDFE_USE_CUDA
                    if (cuda_reduced) {
                        reduced = detail::absorb_reduced_pcg_cuda(
                            y_use, design, fes_use, tuned, kOrdinaryAutoRoutingRetryTrigger, &outcome);
                    } else
#endif
                    {
                        reduced = detail::absorb_reduced_pcg(
                            y_use, design, fes_use, tuned, kOrdinaryAutoRoutingRetryTrigger, &outcome);
                    }
                    reduced_pcg_status_ = outcome.status;
                    reduced_pcg_reason_ = outcome.reason;
                    reduced_pcg_discarded_iterations_ = reduced ? 0 : outcome.iterations;
                    // Package D: the finer blocks of the attempt. After a transient
                    // memory fallback (the finer blocks not allocated, the repetition
                    // on the coarse blocks, or a decline for memory that leaves the
                    // fit to the chain) the fit writes no absorption-cache entry (3.1).
                    record_reduced_pcg_fine(reduced_pcg_fine_, &outcome);
                    if (outcome.fine_retry || outcome.fine_alloc_failed ||
                        (outcome.status == 2 && std::strcmp(outcome.reason, "memory") == 0))
                        reduced_pcg_transient_fallback_ = true;
                    if (reduced) {
                        reduced->auto_routing_retry_policy_enabled = tuned.ordinary_auto_routing_retry;
                        return std::move(*reduced);
                    }
                }
            }
            if (!primary_ready) {
                HdfeOptions primary_options = route_options();
                primary_options.strict_provenance = strict_primary_provenance;
                if (route_bounded_precision()) {
                    primary_options.tol =
                        std::min(primary_options.tol, 1.0e-10);
                    // The earlier sweep selector clears this internal flag.
                    // Preserve the actual public Auto intent for CUDA routing.
                    primary_options.from_auto =
                        options_.absorption_method == AbsorptionMethod::Auto;
                } else if (route_bounded_fast()) {
                    configure_native_cuda_repair(primary_options);
                }
                // Early routing on the retry's eligible CPU route: a primary
                // that leaves early is replaced at once by the retry's MLSMR.
                primary_options.early_routing =
                    tuned.ordinary_auto_early_routing && retry_statically_eligible();
                // F2-A: only the primary absorption may hand its CUDA tail to
                // the host; repairs, retries and continuations never receive the
                // selector, so auto_intent alone never re-enables a route there.
                if (cuda_tail_route) {
                    primary_options.cuda_tail_route = &cuda_tail_route;
                }
                // Package B, stage 2a': only the primary absorption of a fit in scope
                // carries the sweep-exit request (repairs and refinements never do). The
                // four-effect MAP fallback below (map_options = primary_options) carries
                // it too: it is the primary's second attempt, and `consumed` keeps the
                // step to one execution per fit.
                if (strict_cuda_scope) {
                    primary_options.strict_sweep_exit = &strict_sweep_exit;
                }
                if (early_routing_trace_on()) {
                    std::ostringstream line;
                    line.precision(10);
                    line << "xhdfe early_routing_trace event=primary_begin"
                         << " n=" << y_use.size() << " nfe=" << fes_use.size()
                         << " cols=" << design.cols()
                         << " requested=" << static_cast<int>(requested_method)
                         << " policy=" << (tuned.ordinary_auto_routing_retry ? 1 : 0)
                         << " early=" << (primary_options.early_routing ? 1 : 0)
                         << " mode=" << static_cast<int>(tuned.tolerance_mode)
                         << " tol=" << tuned.tol << '\n';
                    std::cerr << line.str();
                }
                primary_options.max_iter -= mixed_network_spent;
                primary = detail::absorb_fixed_effects_v6(
                    y_use, design, fes_use, w_ptr, primary_options,
                    requested_method, slope_terms);
                primary.iterations += mixed_network_spent;
                if (primary.early_routing_left != 0) {
                    // The retry's MLSMR, exactly as finalize_backend_status
                    // runs it (cold, full budget), reported as status 4 with
                    // the primary's iterations and prediction.
                    const auto routed_started = std::chrono::steady_clock::now();
                    HdfeOptions retry_options = tuned;
                    retry_options.absorption_method = AbsorptionMethod::Mlsmr;
                    retry_options.from_auto = false;
                    detail::AbsorptionResult routed =
                        detail::absorb_fixed_effects_v6(
                            y_use, design, fes_use, w_ptr, retry_options,
                            AbsorptionMethod::Mlsmr, slope_terms);
                    detail::certify_absorption_result(
                        y_use, design, fes_use, w_ptr, tuned, slope_terms, routed);
                    const double routed_seconds = std::chrono::duration<double>(
                        std::chrono::steady_clock::now() - routed_started).count();
                    if (read_env_bool("XHDFE_TEST_AUTO_ROUTING_RETRY_FAIL").value_or(false)) {
                        routed.converged = false;
                        routed.precision_certified = false;
                    }
                    const bool routed_ok = routed.converged && routed.precision_certified;
                    if (read_env_bool("XHDFE_AUTO_ROUTING_RETRY_DIAG").value_or(false)) {
                        std::cerr << "xhdfe auto_routing_retry event=left_early"
                                  << " rule="
                                  << (primary.early_routing_left == 1 ? "predictive"
                                                                      : "structural")
                                  << " iter=" << primary.iterations
                                  << " q=" << primary.early_routing_rate
                                  << " kappa=" << primary.early_routing_kappa
                                  << " predicted=" << primary.early_routing_prediction
                                  << " retry_certified=" << (routed_ok ? 1 : 0) << '\n';
                    }
                    if (routed_ok) {
                        routed.auto_routing_retry_policy_enabled = true;
                        routed.auto_routing_retry_eligible = true;
                        routed.auto_routing_retry_fired = true;
                        routed.auto_routing_retry_status = 4;
                        routed.auto_routing_retry_primary_method =
                            static_cast<int>(requested_method);
                        routed.auto_routing_retry_primary_iterations = primary.iterations;
                        routed.auto_routing_retry_primary_abs_residual_rel =
                            primary.early_routing_prediction;
                        routed.auto_routing_retry_iterations = routed.iterations;
                        routed.auto_routing_retry_abs_residual_rel = routed.abs_residual_rel;
                        routed.auto_routing_retry_elapsed_seconds = routed_seconds;
                        routed.mlsmr_used = true;
                        method_used_ = AbsorptionMethod::Mlsmr;
                        return finalize_backend_status(std::move(routed));
                    }
                    // MLSMR failed: the primary again with early routing off,
                    // then today's route unchanged.
                    primary_options.early_routing = false;
                    primary = detail::absorb_fixed_effects_v6(
                        y_use, design, fes_use, w_ptr, primary_options,
                        requested_method, slope_terms);
                }
                if (route_bounded_precision() && primary.gpu_attempted &&
                    primary.gpu_status_code == 3 && !primary.converged &&
                    primary.iterations < primary_options.max_iter) {
                    const int cg_iterations = std::max(0, primary.iterations);
                    HdfeOptions map_options = primary_options;
                    // Ordinary Comparable Auto resolves to norm-change MAP.
                    // Make that route explicit after a failed CG attempt.
                    map_options.convergence_criterion = ConvergenceCriterion::NormChange;
                    map_options.from_auto = route_options().from_auto;
                    map_options.max_iter -= cg_iterations;
                    primary = detail::absorb_fixed_effects_v6(
                        y_use, design, fes_use, w_ptr, map_options,
                        requested_method, slope_terms);
                    primary.iterations += cg_iterations;
                    primary.gpu_absorption_iterations = primary.iterations;
                }
                if ((route_bounded_fast() ||
                     route_bounded_precision()) && primary.gpu_used) {
                    certify_public_contract(primary);
                }
                if (!primary.gpu_used && primary.gpu_status_code == 2) {
                    // Package B: a device lost after the entry leaves a fit in
                    // scope to today's code: the record is dropped, so the route
                    // reads tuned and the strict decisions again.
                    strict_cuda_scope = false;
                    requested_backend_unavailable = true;
                    unavailable_backend_cpu_fallback.emplace(
                        detail::GpuBackend::Cpu);
                    primary = detail::absorb_fixed_effects_v6(
                        y_use, design, fes_use, w_ptr, tuned,
                        requested_method, slope_terms);
                }
            }

            if (primary.cg_restart_required) {
                if (early_routing_trace_on()) {
                    std::ostringstream line;
                    line << "xhdfe early_routing_trace event=cg_restart"
                         << " primary_iterations=" << primary.iterations
                         << " primary_converged=" << (primary.converged ? 1 : 0)
                         << " max_iter=" << tuned.max_iter << '\n';
                    std::cerr << line.str();
                }
                // FE orthogonality alone cannot detect null-space drift from
                // a broken CG recurrence. Reabsorbing its residual preserves
                // that damage, so restart from the original RHS instead.
                if (primary.iterations >= tuned.max_iter) {
                    primary.converged = false;
                    primary.precision_certified = false;
                    return finalize_backend_status(std::move(primary));
                }
                HdfeOptions repair_options = route_options();
                repair_options.max_iter -= primary.iterations;
                repair_options.absorption_method = AbsorptionMethod::Mlsmr;
                repair_options.from_auto = false;
                detail::AbsorptionResult repaired = detail::absorb_fixed_effects_v6(
                    y_use, design, fes_use, w_ptr, repair_options,
                    AbsorptionMethod::Mlsmr, slope_terms);
                repaired.iterations += primary.iterations;
                certify_public_contract(repaired);
                repaired.mlsmr_used = true;
                method_used_ = AbsorptionMethod::Mlsmr;
                return finalize_backend_status(std::move(repaired));
            }

            // PF3_CANDIDATE2_PROTOTYPE_BEGIN
            // A successful public-tolerance primary pass can still be above
            // the opt-in 1e-10 accuracy target. Re-solve from the original
            // y/design (never from the primary residual) with the same
            // Auto-resolved CUDA method and a tighter internal tolerance.
            constexpr double kCudaAutoComparableAccuracyTarget = 1.0e-10;
            const bool cuda_accuracy_retry_triggered =
                cuda_auto_comparable_accuracy_retry &&
                !cuda_auto_forward_accuracy_repair && primary.gpu_used &&
                primary.gpu_attempted && primary.gpu_status_code == 1 &&
                primary.gpu_absorption_converged && primary.converged &&
                primary.precision_certified &&
                hdfe::detail::ieee_finite(primary.abs_residual_rel) &&
                primary.abs_residual_rel > kCudaAutoComparableAccuracyTarget;
            if (cuda_auto_comparable_accuracy_retry_diag &&
                cuda_auto_comparable_accuracy_retry) {
                std::cerr
                    << "xhdfe cuda_auto_comparable_accuracy_retry event=primary"
                    << " triggered=" << (cuda_accuracy_retry_triggered ? 1 : 0)
                    << " abs_residual_rel=" << primary.abs_residual_rel
                    << " iterations=" << primary.iterations << '\n';
            }
            if (cuda_accuracy_retry_triggered) {
                const int primary_iterations = primary.iterations;
                int accumulated_iterations = primary_iterations;
                // The primary already passed the public certificate. Every
                // later stage is judged only against the tighter accuracy
                // target; when none reaches it, the best certified candidate
                // (smallest backward error) is returned as the device result.
                // Refusing here would turn an accuracy improvement into a
                // fail-closed loss of a fit the default route accepts
                // (patents: primary 4.0e-9, cold retry 1.1e-10 > 1e-10).
                detail::AbsorptionResult best_certified = primary;
                auto consider_best = [&](const detail::AbsorptionResult& candidate) {
                    if (candidate.gpu_used && candidate.gpu_attempted &&
                        candidate.gpu_status_code == 1 &&
                        candidate.gpu_absorption_converged && candidate.converged &&
                        candidate.precision_certified &&
                        hdfe::detail::ieee_finite(candidate.abs_residual_rel) &&
                        candidate.abs_residual_rel < best_certified.abs_residual_rel) {
                        best_certified = candidate;
                    }
                };
                if (cuda_auto_comparable_accuracy_ladder) {
                    constexpr std::array<double, 3> kWarmStageTolerances = {
                        1.0e-9, 3.0e-10, 1.0e-10};
                    detail::AbsorptionResult stage_seed = std::move(primary);
                    for (std::size_t stage = 0;
                         stage < kWarmStageTolerances.size(); ++stage) {
                        HdfeOptions stage_options = tuned;
                        stage_options.tol = kWarmStageTolerances[stage];
                        stage_options.tolerance_mode =
                            ToleranceMode::ReghdfeComparable;
                        stage_options.convergence_criterion =
                            ConvergenceCriterion::Auto;
                        detail::AbsorptionResult staged =
                            detail::absorb_fixed_effects_v6(
                                stage_seed.y_tilde, stage_seed.X_tilde,
                                fes_use, w_ptr, stage_options,
                                requested_method, slope_terms);
                        certify_public_contract(staged);
                        const int stage_iterations = staged.iterations;
                        accumulated_iterations += stage_iterations;
                        staged.iterations = accumulated_iterations;
                        staged.gpu_absorption_iterations =
                            accumulated_iterations;
                        const bool stage_valid =
                            staged.gpu_used && staged.gpu_attempted &&
                            staged.gpu_status_code == 1 &&
                            staged.gpu_absorption_converged &&
                            staged.converged && staged.precision_certified &&
                            hdfe::detail::ieee_finite(
                                staged.abs_residual_rel);
                        const bool stage_accepted =
                            stage_valid &&
                            staged.abs_residual_rel <=
                                kCudaAutoComparableAccuracyTarget;
                        if (cuda_auto_comparable_accuracy_retry_diag) {
                            std::cerr
                                << "xhdfe cuda_auto_comparable_accuracy_retry"
                                << " event=ladder_stage"
                                << " stage=" << (stage + 1)
                                << " tol=" << kWarmStageTolerances[stage]
                                << " valid=" << (stage_valid ? 1 : 0)
                                << " accepted=" << (stage_accepted ? 1 : 0)
                                << " abs_residual_rel="
                                << staged.abs_residual_rel
                                << " stage_iterations=" << stage_iterations
                                << " reported_total_iterations="
                                << accumulated_iterations << '\n';
                        }
                        if (stage_accepted) {
                            return finalize_backend_status(std::move(staged));
                        }
                        if (!stage_valid) {
                            break;
                        }
                        consider_best(staged);
                        stage_seed = std::move(staged);
                    }
                    if (cuda_auto_comparable_accuracy_retry_diag) {
                        std::cerr
                            << "xhdfe cuda_auto_comparable_accuracy_retry"
                            << " event=ladder_cold_fallback"
                            << " prior_reported_iterations="
                            << accumulated_iterations << '\n';
                    }
                }
                HdfeOptions retry_options = tuned;
                retry_options.tol = kCudaAutoComparableAccuracyTarget;
                retry_options.tolerance_mode = ToleranceMode::ReghdfeComparable;
                retry_options.convergence_criterion = ConvergenceCriterion::Auto;
                detail::AbsorptionResult retried =
                    detail::absorb_fixed_effects_v6(
                        y_use, design, fes_use, w_ptr, retry_options,
                        requested_method, slope_terms);
                certify_public_contract(retried);
                const int retry_iterations = retried.iterations;
                retried.iterations += accumulated_iterations;
                retried.gpu_absorption_iterations = retried.iterations;
                const bool retry_accepted =
                    retried.gpu_used && retried.gpu_attempted &&
                    retried.gpu_status_code == 1 &&
                    retried.gpu_absorption_converged && retried.converged &&
                    retried.precision_certified &&
                    hdfe::detail::ieee_finite(retried.abs_residual_rel) &&
                    retried.abs_residual_rel <=
                        kCudaAutoComparableAccuracyTarget;
                if (cuda_auto_comparable_accuracy_retry_diag) {
                    std::cerr
                        << "xhdfe cuda_auto_comparable_accuracy_retry event=retry"
                        << " accepted=" << (retry_accepted ? 1 : 0)
                        << " accepted_stage=cold"
                        << " abs_residual_rel=" << retried.abs_residual_rel
                        << " primary_iterations=" << primary_iterations
                        << " retry_iterations=" << retry_iterations
                        << " total_iterations=" << retried.iterations << '\n';
                }
                if (!retry_accepted) {
                    consider_best(retried);
                    if (cuda_auto_comparable_accuracy_retry_diag) {
                        std::cerr
                            << "xhdfe cuda_auto_comparable_accuracy_retry event=best_certified"
                            << " abs_residual_rel=" << best_certified.abs_residual_rel
                            << " iterations=" << best_certified.iterations << '\n';
                    }
                    best_certified.gpu_absorption_iterations = retried.iterations;
                    best_certified.iterations = retried.iterations;
                    return finalize_backend_status(std::move(best_certified));
                }
                return finalize_backend_status(std::move(retried));
            }
            // PF3_CANDIDATE2_PROTOTYPE_END

            auto forward_probe_rss_threshold = [](
                const detail::CudaForwardProbeSummary& probe) {
                constexpr double kReleasedRssGate = 5.0e-9;
                constexpr double kReferenceContraction = 0.9999;
                const int sweeps = std::max(1, probe.continuation_sweeps);
                // The second checkpoint is 2K sweeps after publication.
                // RSS excess is a squared residual error, hence its geometric
                // contraction over that interval is rho^(2 * 2K)=rho^(4K).
                return kReleasedRssGate *
                       (1.0 - std::pow(
                                    kReferenceContraction,
                                    4.0 * static_cast<double>(sweeps)));
            };
            auto forward_probe_is_stable = [&](
                const detail::AbsorptionResult& candidate) {
                const auto& probe = candidate.cuda_forward_probe;
                return probe.status == 1 &&
                       hdfe::detail::ieee_finite(probe.rss_drift_rel) &&
                       probe.rss_drift_rel <
                           forward_probe_rss_threshold(probe);
            };
            auto forward_accuracy_retry_triggered = [&]
                (const detail::AbsorptionResult& candidate) {
                if (!cuda_auto_forward_accuracy_repair ||
                    !cuda_auto_forward_probe_candidate ||
                    requested_backend_unavailable || !candidate.gpu_used ||
                    !candidate.gpu_attempted ||
                    candidate.gpu_status_code != 1 ||
                    !candidate.gpu_absorption_converged ||
                    !candidate.converged || !candidate.precision_certified) {
                    return false;
                }
                const auto& probe = candidate.cuda_forward_probe;
                if (probe.status != 1 ||
                    !hdfe::detail::ieee_finite(probe.rss_drift_rel)) {
                    if (cuda_auto_comparable_accuracy_retry_diag) {
                        std::cerr
                            << "xhdfe cuda_auto_forward_accuracy_repair"
                            << " event=probe_unavailable"
                            << " status=" << probe.status << '\n';
                    }
                    return false;
                }
                const double threshold =
                    forward_probe_rss_threshold(probe);
                if (probe.rss_drift_rel < threshold) {
                    return false;
                }
                if (cuda_auto_comparable_accuracy_retry_diag) {
                    std::cerr
                        << "xhdfe cuda_auto_forward_accuracy_repair"
                        << " event=selector"
                        << " selected=1"
                        << " rss_drift_rel=" << probe.rss_drift_rel
                        << " threshold=" << threshold << '\n';
                }
                return true;
            };
            auto run_forward_accuracy_retry = [&]
                (detail::AbsorptionResult candidate) {
                const int initial_iterations = candidate.iterations;
                int accumulated_iterations = initial_iterations;
                if (cuda_auto_comparable_accuracy_ladder) {
                    constexpr std::array<double, 3> kWarmStageTolerances = {
                        1.0e-9, 3.0e-10, 1.0e-10};
                    detail::AbsorptionResult stage_seed =
                        std::move(candidate);
                    for (std::size_t stage = 0;
                         stage < kWarmStageTolerances.size(); ++stage) {
                        HdfeOptions stage_options = tuned;
                        stage_options.tol = kWarmStageTolerances[stage];
                        stage_options.tolerance_mode =
                            ToleranceMode::ReghdfeComparable;
                        stage_options.convergence_criterion =
                            ConvergenceCriterion::Auto;
                        detail::AbsorptionResult staged =
                            detail::absorb_fixed_effects_v6(
                                stage_seed.y_tilde, stage_seed.X_tilde,
                                fes_use, w_ptr, stage_options,
                                requested_method, slope_terms);
                        certify_public_contract(staged);
                        const int stage_iterations = staged.iterations;
                        accumulated_iterations += stage_iterations;
                        staged.iterations = accumulated_iterations;
                        staged.gpu_absorption_iterations =
                            accumulated_iterations;
                        const bool accepted =
                            staged.gpu_used && staged.gpu_attempted &&
                            staged.gpu_status_code == 1 &&
                            staged.gpu_absorption_converged &&
                            staged.converged && staged.precision_certified &&
                            hdfe::detail::ieee_finite(
                                staged.abs_residual_rel) &&
                            staged.abs_residual_rel <=
                                kCudaAutoComparableAccuracyTarget &&
                            forward_probe_is_stable(staged);
                        if (cuda_auto_comparable_accuracy_retry_diag) {
                            std::cerr
                                << "xhdfe cuda_auto_forward_accuracy_repair"
                                << " event=ladder_stage"
                                << " stage=" << (stage + 1)
                                << " accepted=" << (accepted ? 1 : 0)
                                << " abs_residual_rel="
                                << staged.abs_residual_rel
                                << " rss_drift_rel="
                                << staged.cuda_forward_probe.rss_drift_rel
                                << " stage_iterations=" << stage_iterations
                                << " total_iterations="
                                << accumulated_iterations << '\n';
                        }
                        if (accepted) {
                            staged.cuda_accuracy_retry_trigger = 2;
                            staged.cuda_accuracy_retry_stage =
                                static_cast<int>(stage + 1);
                            staged.cuda_accuracy_retry_iterations =
                                accumulated_iterations - initial_iterations;
                            return staged;
                        }
                        const bool stage_valid =
                            staged.gpu_used && staged.gpu_attempted &&
                            staged.gpu_status_code == 1 &&
                            staged.gpu_absorption_converged &&
                            staged.converged && staged.precision_certified;
                        if (!stage_valid) {
                            break;
                        }
                        stage_seed = std::move(staged);
                    }
                }

                HdfeOptions retry_options = tuned;
                retry_options.tol = kCudaAutoComparableAccuracyTarget;
                retry_options.tolerance_mode =
                    ToleranceMode::ReghdfeComparable;
                retry_options.convergence_criterion =
                    ConvergenceCriterion::Auto;
                detail::AbsorptionResult retried =
                    detail::absorb_fixed_effects_v6(
                        y_use, design, fes_use, w_ptr, retry_options,
                        requested_method, slope_terms);
                certify_public_contract(retried);
                const int retry_iterations = retried.iterations;
                retried.iterations += accumulated_iterations;
                retried.gpu_absorption_iterations = retried.iterations;
                const bool accepted =
                    retried.gpu_used && retried.gpu_attempted &&
                    retried.gpu_status_code == 1 &&
                    retried.gpu_absorption_converged && retried.converged &&
                    retried.precision_certified &&
                    hdfe::detail::ieee_finite(retried.abs_residual_rel) &&
                    retried.abs_residual_rel <=
                        kCudaAutoComparableAccuracyTarget &&
                    forward_probe_is_stable(retried);
                if (cuda_auto_comparable_accuracy_retry_diag) {
                    std::cerr
                        << "xhdfe cuda_auto_forward_accuracy_repair"
                        << " event=cold"
                        << " accepted=" << (accepted ? 1 : 0)
                        << " abs_residual_rel="
                        << retried.abs_residual_rel
                        << " rss_drift_rel="
                        << retried.cuda_forward_probe.rss_drift_rel
                        << " retry_iterations=" << retry_iterations
                        << " total_iterations=" << retried.iterations
                        << '\n';
                }
                retried.cuda_accuracy_retry_trigger = 2;
                retried.cuda_accuracy_retry_stage = 4;
                retried.cuda_accuracy_retry_iterations =
                    retried.iterations - initial_iterations;
                if (!accepted) {
                    retried.gpu_used = false;
                    retried.gpu_status_code = 3;
                    retried.gpu_absorption_converged = false;
                    retried.converged = false;
                    retried.precision_certified = false;
                }
                return retried;
            };
            auto finalize_with_forward_repair = [&]
                (detail::AbsorptionResult candidate) {
                const bool probe_required =
                    cuda_auto_forward_accuracy_repair &&
                    cuda_auto_forward_probe_candidate &&
                    candidate.gpu_used && candidate.gpu_attempted &&
                    candidate.gpu_status_code == 1 &&
                    candidate.gpu_absorption_converged &&
                    candidate.converged && candidate.precision_certified;
                if (probe_required &&
                    (candidate.cuda_forward_probe.status != 1 ||
                     !hdfe::detail::ieee_finite(
                         candidate.cuda_forward_probe.rss_drift_rel))) {
                    if (cuda_auto_comparable_accuracy_retry_diag) {
                        std::cerr
                            << "xhdfe cuda_auto_forward_accuracy_repair"
                            << " event=required_probe_failed"
                            << " status="
                            << candidate.cuda_forward_probe.status << '\n';
                    }
                    candidate.gpu_used = false;
                    candidate.gpu_status_code = 3;
                    candidate.gpu_absorption_converged = false;
                    candidate.converged = false;
                    candidate.precision_certified = false;
                    return finalize_backend_status(std::move(candidate));
                }
                if (forward_accuracy_retry_triggered(candidate)) {
                    candidate = run_forward_accuracy_retry(
                        std::move(candidate));
                }
                return finalize_backend_status(std::move(candidate));
            };
            // The public certificate deliberately allows an 8x FP envelope.
            // On bounded default-fast problems, use one half of the requested
            // tolerance as the repair trigger; the bounded four-FE CUDA case
            // uses the tighter stability target above. This catches
            // scientifically material coefficient drift that can still sit
            // inside the public 8x reporting envelope, without adding another
            // certificate pass.
            // P3-fix (3'), scope addendum 2: the sequence's one strict repair after
            // the strict primary's device LSMR restart was rejected with budget
            // left (the strict branch's rule); a broken CG stage in it is refused.
            if (strict_primary_provenance && primary.cuda_strict_lsmr_restart &&
                !(primary.gpu_used && primary.converged && primary.precision_certified) &&
                (primary.gpu_used || primary.gpu_status_code == 3)) {
                if (primary.iterations >= tuned.max_iter) {
                    primary.converged = false;
                    primary.precision_certified = false;
                    return finalize_backend_status(std::move(primary));
                }
                detail::AbsorptionResult strict_retry = run_strict_cuda_repair(
                    tuned.max_iter - primary.iterations, true, true);
                strict_retry.iterations += primary.iterations;
                strict_retry.gpu_absorption_iterations = strict_retry.iterations;
                if (strict_retry.gpu_used && strict_retry.converged &&
                    strict_retry.precision_certified) {
                    return finalize_backend_status(std::move(strict_retry));
                }
                strict_retry.converged = false;
                strict_retry.precision_certified = false;
                return finalize_backend_status(std::move(strict_retry));
            }
            const bool primary_precision_gate_failed =
                route_gate_failed(primary);
            const bool repair_eligible = standard_auto_precision_repair &&
                requested_method != AbsorptionMethod::Mlsmr &&
                (!primary.precision_certified || primary_precision_gate_failed);
            if (!repair_eligible) {
                return finalize_with_forward_repair(std::move(primary));
            }

            if (!requested_backend_unavailable &&
                cuda_backend_env_requested() &&
                !(primary.gpu_status_code == 2 && !primary.gpu_used)) {
                const int primary_iterations =
                    primary.gpu_attempted ? std::max(0, primary.iterations) : 0;
                if (primary_iterations >= tuned.max_iter) {
                    primary.converged = false;
                    primary.precision_certified = false;
                    return finalize_backend_status(std::move(primary));
                }
                HdfeOptions repair_options = route_options();
                repair_options.max_iter -= primary_iterations;
                configure_native_cuda_repair(repair_options);
                if (route_bounded_precision() && repair_options.tol > 0.0) {
                    repair_options.tol =
                        std::min(repair_options.tol, 1.0e-10);
                }
                detail::AbsorptionResult repaired =
                    detail::absorb_fixed_effects_v6(
                        y_use, design, fes_use, w_ptr, repair_options,
                        requested_method, slope_terms);
                certify_public_contract(repaired);
                repaired.iterations += primary_iterations;
                repaired.gpu_absorption_iterations = repaired.iterations;
                if (repaired.gpu_used && repaired.converged &&
                    repaired.precision_certified &&
                    (!primary_precision_gate_failed ||
                     repaired.abs_residual_rel <= route_bounded_limit())) {
                    return finalize_with_forward_repair(std::move(repaired));
                }
                if (w_ptr != nullptr && repaired.gpu_used) {
                    if (repaired.iterations >= tuned.max_iter) {
                        repaired.converged = false;
                        repaired.precision_certified = false;
                        return finalize_backend_status(std::move(repaired));
                    }
                    detail::AbsorptionResult strict_retry =
                        run_strict_cuda_repair(tuned.max_iter - repaired.iterations);
                    strict_retry.iterations += repaired.iterations;
                    strict_retry.gpu_absorption_iterations =
                        strict_retry.iterations;
                    if (strict_retry.gpu_used && strict_retry.converged &&
                        strict_retry.precision_certified) {
                        return finalize_backend_status(std::move(strict_retry));
                    }
                    strict_retry.converged = false;
                    strict_retry.precision_certified = false;
                    return finalize_backend_status(std::move(strict_retry));
                }
                // P3-fix (C): a repair that converged and passed the public
                // certificate but missed the bounded xhdfe-fast target is
                // refused as before; the message says so, not "did not converge".
                if (tuned.tolerance_mode == ToleranceMode::XhdfeFast &&
                    primary_precision_gate_failed && repaired.gpu_used &&
                    repaired.converged && repaired.precision_certified) {
                    repaired.fast_repair_target = bounded_precision_limit;
                }
                repaired.converged = false;
                repaired.precision_certified = false;
                return finalize_backend_status(std::move(repaired));
            }

            if (primary.gpu_used) {
                primary.converged = false;
                primary.precision_certified = false;
                return finalize_backend_status(std::move(primary));
            }

            int strict_iterations_used = primary.iterations;
            auto strict_budget_exhausted = [&]() {
                return bound_cpu_strict_repair && strict_iterations_used >= tuned.max_iter;
            };
            if (strict_budget_exhausted()) {
                primary.converged = false;
                primary.precision_certified = false;
                return finalize_backend_status(std::move(primary));
            }

            auto run_mlsmr_repair = [&]() {
                HdfeOptions repair_options = tuned;
                repair_options.absorption_method = AbsorptionMethod::Mlsmr;
                repair_options.from_auto = false;
                if (bound_cpu_strict_repair) {
                    repair_options.max_iter -= strict_iterations_used;
                }
                detail::AbsorptionResult candidate;
                if (!tuned.retain_fixed_effects && w_ptr == nullptr) {
                    candidate = detail::absorb_fixed_effects_v6(
                        primary.y_tilde, primary.X_tilde, fes_use, w_ptr,
                        repair_options, AbsorptionMethod::Mlsmr, slope_terms);
                    candidate.iterations += bound_cpu_strict_repair ? strict_iterations_used : primary.iterations;
                    certify_public_contract(candidate);
                } else {
                    candidate = detail::absorb_fixed_effects_v6(
                        y_use, design, fes_use, w_ptr, repair_options,
                        AbsorptionMethod::Mlsmr, slope_terms);
                }
                if (bound_cpu_strict_repair) {
                    strict_iterations_used = candidate.iterations;
                }
                return candidate;
            };
            bool mlsmr_repair_attempted = false;
            detail::AbsorptionResult mlsmr_repair;
            if (!tuned.retain_fixed_effects && primary.iterations >= 40) {
                mlsmr_repair = run_mlsmr_repair();
                mlsmr_repair_attempted = true;
                if (mlsmr_repair.converged &&
                    mlsmr_repair.precision_certified) {
                    mlsmr_repair.mlsmr_used = true;
                    method_used_ = AbsorptionMethod::Mlsmr;
                    return finalize_backend_status(std::move(mlsmr_repair));
                }
                if (strict_budget_exhausted()) {
                    mlsmr_repair.converged = false;
                    mlsmr_repair.precision_certified = false;
                    return finalize_backend_status(std::move(mlsmr_repair));
                }
            }

            const detail::AbsorptionResult* sweep_seed = &primary;
            detail::AbsorptionResult update_repair;
            if (!tuned.retain_fixed_effects && w_ptr == nullptr &&
                tuned.tolerance_mode == ToleranceMode::XhdfeFast &&
                tuned.tol > 0.0) {
                // Continue with the scale-invariant update rule first.  Its
                // deliberately loose internal stop is only a performance
                // hint: the original public certificate and bounded fast gate
                // below remain authoritative.  If it is insufficient, its
                // improved residual seeds the tighter continuation instead of
                // being discarded.
                HdfeOptions update_options = tuned;
                update_options.convergence_criterion =
                    ConvergenceCriterion::Reghdfe;
                update_options.tol = std::min(5.0e-7, 50.0 * tuned.tol);
                update_repair = detail::absorb_fixed_effects_v6(
                    primary.y_tilde, primary.X_tilde, fes_use, w_ptr,
                    update_options, requested_method, slope_terms);
                update_repair.iterations += primary.iterations;
                certify_public_contract(update_repair);
                if (update_repair.converged &&
                    update_repair.precision_certified &&
                    update_repair.abs_residual_rel <= bounded_precision_limit) {
                    return finalize_backend_status(std::move(update_repair));
                }
                sweep_seed = &update_repair;
            }

            // Continue the same sweep method under the scale-invariant
            // norm-of-update rule at a tighter internal tolerance.  This is
            // substantially cheaper than MLSMR on some moderate-contraction
            // graphs and never weakens the caller's public contract.
            HdfeOptions honest_options = tuned;
            honest_options.tolerance_mode = ToleranceMode::ReghdfeComparable;
            if (bound_cpu_strict_repair) {
                honest_options.max_iter -= strict_iterations_used;
            }
            if (honest_options.tol > 0.0) {
                honest_options.tol = std::min(
                    honest_options.tol,
                    tuned.retain_fixed_effects ? 2.5e-10 : 1.0e-9);
            }
            detail::AbsorptionResult honest;
            if (!tuned.retain_fixed_effects && w_ptr == nullptr) {
                // In the unweighted path, the first candidate differs from
                // the original design only by vectors in the FE span.
                // Continue from that residual instead of discarding its
                // completed sweeps; the independent certificate below is
                // still evaluated against the original y/design.  Weighted
                // absorption is excluded because its internal scaling would
                // be applied twice, and savefe because its recovered FE
                // contributions must span the full solve.
                honest = detail::absorb_fixed_effects_v6(
                    sweep_seed->y_tilde, sweep_seed->X_tilde, fes_use, w_ptr,
                    honest_options, requested_method, slope_terms);
                honest.iterations += bound_cpu_strict_repair ? strict_iterations_used : sweep_seed->iterations;
            } else {
                honest = detail::absorb_fixed_effects_v6(
                    y_use, design, fes_use, w_ptr, honest_options,
                    requested_method, slope_terms);
            }
            certify_public_contract(honest);
            if (bound_cpu_strict_repair) {
                strict_iterations_used = honest.iterations;
            }
            if (honest.converged && honest.precision_certified &&
                (tuned.tolerance_mode != ToleranceMode::XhdfeFast ||
                 tuned.tol <= 0.0 ||
                 honest.abs_residual_rel <= bounded_precision_limit)) {
                return finalize_backend_status(std::move(honest));
            }
            if (strict_budget_exhausted()) {
                honest.converged = false;
                honest.precision_certified = false;
                return finalize_backend_status(std::move(honest));
            }
            if (tuned.retain_fixed_effects) {
                honest.converged = false;
                honest.precision_certified = false;
                return finalize_backend_status(std::move(honest));
            }
            if (mlsmr_repair_attempted) {
                mlsmr_repair.converged = false;
                mlsmr_repair.precision_certified = false;
                if (bound_cpu_strict_repair) {
                    mlsmr_repair.iterations = strict_iterations_used;
                }
                return finalize_backend_status(std::move(mlsmr_repair));
            }

            detail::AbsorptionResult repaired = run_mlsmr_repair();
            if (repaired.converged && repaired.precision_certified) {
                repaired.mlsmr_used = true;
                method_used_ = AbsorptionMethod::Mlsmr;
                return finalize_backend_status(std::move(repaired));
            }

            primary.converged = false;
            primary.precision_certified = false;
            if (bound_cpu_strict_repair) {
                primary.iterations = strict_iterations_used;
            }
            return finalize_backend_status(std::move(primary));
        };
        // E1 (Verifications/low_memory_20261116/briefs/
        // E1_SAVEFE_COMPARABLE_PROJECTION_FIRST.md): in the fits that
        // savefe_accurate_projection selects, a certified capturing primary that
        // stopped above the floor of the mode (savefe_projection_floor) is not
        // published as it is: its norm-change exit is looser than the route of
        // the mode (public path-like fixture: certificate 2.0e-9, b 8.7e-8 and SE
        // 9.1e-5 from the same fit without saved effects). The projection is recomputed without
        // capture by the same call, eligible for the reduced tier like the fit
        // without saved effects. Certified, with the primary's levels, it
        // supplies y~, X~, the certificate and the flags; the primary supplies
        // what the recovery reads (captured coefficients, group identifiers,
        // weight sums, sweep order), so the saved effects are the captured ones
        // evaluated at the accurate b. Otherwise (not certified, other levels,
        // an exception other than a fatal error of the CUDA tier, which leaves
        // the fit without estimates) the primary is published as before, and the attempt
        // leaves no trace in method_used_ or the tier diagnostics. The published
        // iterations count both solves, as in the refinement below.
        auto publish_savefe_projection = [&](
            const Eigen::Ref<const Eigen::MatrixXd>& design,
            AbsorptionMethod requested_method,
            detail::AbsorptionResult primary) -> detail::AbsorptionResult {
            const AbsorptionMethod method_before = method_used_;
            const int tier_status_before = reduced_pcg_status_;
            const std::string tier_reason_before = reduced_pcg_reason_;
            const int tier_discarded_before = reduced_pcg_discarded_iterations_;
            const ReducedPcgFineDiagnostics tier_fine_before = reduced_pcg_fine_;
            const AbsorptionMethod tuned_method_before = tuned.absorption_method;
            detail::AbsorptionResult projection;
            bool thrown = false;
            // Point 13: the projection's final trace line is kept until the
            // decision below (dropped unless published).
            detail::ReducedPcgFinalKeep final_line_keep(savefe_final_line_owed);
            tuned.retain_fixed_effects = false;
            savefe_projection_tier_eligible = true;
            try {
                if (reselect_weighted_savefe_projection) {
                    // The capturing sweep cannot run MLSMR. The published
                    // projection can use the same selector as a plain fit.
                    HdfeOptions selection_options = options_;
                    selection_options.retain_fixed_effects = false;
                    requested_method = select_cpu_auto_mlsmr(selection_options);
                    tuned.absorption_method = requested_method;
                }
                projection = absorb_with_precision_repair_impl(design, requested_method);
            }
#ifdef HDFE_USE_CUDA
            catch (const detail::reduced_cuda::Error& error) {
                // A fatal error of the CUDA tier (the kind the tier rethrows)
                // leaves the fit without estimates, as from a fit without saved
                // effects; the two flags are restored first. The tier declines on
                // its other kinds; should one arrive here, it is treated as below.
                if (error.kind() == detail::reduced_cuda::ErrorKind::Fatal) {
                    tuned.retain_fixed_effects = true;
                    tuned.absorption_method = tuned_method_before;
                    savefe_projection_tier_eligible = false;
                    throw;
                }
                thrown = true;
            }
#endif
            catch (...) {
                thrown = true;
            }
            tuned.retain_fixed_effects = true;
            tuned.absorption_method = tuned_method_before;
            savefe_projection_tier_eligible = false;
            if (savefe_projection_abandon_test()) thrown = true;  // tests only (round 09, E.2)
            const bool certified =
                !thrown && projection.converged && projection.precision_certified &&
                projection.cuda_projection_moments_met;
            const bool same_levels = projection.fe_levels == primary.fe_levels;
            const bool published = certified && same_levels;
            if (read_env_bool("XHDFE_AUTO_ROUTING_RETRY_DIAG").value_or(false)) {
                std::cerr << "xhdfe savefe_accurate_projection published=" << (published ? 1 : 0)
                          << " skipped=0 floor=" << savefe_projection_floor
                          << " thrown=" << (thrown ? 1 : 0)
                          << " certified=" << (certified ? 1 : 0)
                          << " same_levels=" << (same_levels ? 1 : 0)
                          << " primary_rel=" << primary.abs_residual_rel
                          << " primary_iterations=" << primary.iterations
                          << " rel=" << projection.abs_residual_rel
                          << " iterations=" << projection.iterations
                          << " tier_status=" << reduced_pcg_status_
                          << " mlsmr=" << (projection.mlsmr_used ? 1 : 0)
                          << " retry_status=" << projection.auto_routing_retry_status
                          << std::endl;
            }
            if (!published) {
                // A transient projection failure must not make the capturing
                // primary bypass the next attempt through a cache hit.
                allow_cache_write = false;
                method_used_ = method_before;
                reduced_pcg_status_ = tier_status_before;
                reduced_pcg_reason_ = tier_reason_before;
                reduced_pcg_discarded_iterations_ = tier_discarded_before;
                reduced_pcg_fine_ = tier_fine_before;
                return primary;
            }
            projection.fe_alpha_y = std::move(primary.fe_alpha_y);
            projection.fe_alpha_X = std::move(primary.fe_alpha_X);
            projection.fe_group_ids = std::move(primary.fe_group_ids);
            projection.fe_weight_sums = std::move(primary.fe_weight_sums);
            projection.sweep_order_used = std::move(primary.sweep_order_used);
            projection.iterations += primary.iterations;
            if (reselect_weighted_savefe_projection) {
                // As in the plain fit, use the selected method for direct
                // MLSMR. The outer caller resolves any subsequent repair.
                method_used_ = requested_method;
                tuned.absorption_method = requested_method;
            }
            savefe_projection_published = true;
            // Point 13: the projection's line becomes the fit's final line (the
            // capture's, printed before, if the fit ends without estimates).
            if (final_line_keep.publish("status=ineligible reason=savefe")) {
                savefe_final_line_owed = false;
            }
            return projection;
        };
        // savefe: the alpha-capturing sweep cannot use the accelerated or
        // Krylov routes, and its norm-change stop can leave the projection
        // above the certificate (credit2: relative residual 5e-8 at 1e-8,
        // returned uncertified by 2.26.2). Before refusing, make the one
        // refinement the precision contract asks for: the projection is
        // recomputed without alpha capture by the route of the mode (the
        // accelerated sweep, the comparable retry to MLSMR), certified like any
        // fit without savefe, and the fixed effects are then recovered from
        // the partial y - Xb by the map recovery below, which needs no
        // captured alphas. Only a stalled savefe primary pays for this.
        bool cpu_projection_refined = false;
        auto absorb_with_precision_repair = [&](
            const Eigen::Ref<const Eigen::MatrixXd>& design,
            AbsorptionMethod requested_method) {
            // Point 13: the capturing sweep's final trace line is owed while E1
            // may still publish a projection (see savefe_final_line_owed); a line
            // still owed when this call ends, by a return or an exception, is
            // printed then, as the code before printed it.
            struct OwedFinalLine {
                bool& owable;
                bool& owed;
                void flush() {
                    owable = false;
                    if (owed) {
                        owed = false;
                        detail::reduced_pcg_final_line("status=ineligible reason=savefe");
                    }
                }
                ~OwedFinalLine() {
                    try {
                        flush();
                    } catch (...) {
                    }
                }
            } owed_final_line{savefe_final_line_owable, savefe_final_line_owed};
            savefe_final_line_owable = tuned.retain_fixed_effects && savefe_accurate_projection &&
                                       detail::reduced_pcg_trace_level() > 0;
            detail::AbsorptionResult primary_result =
                absorb_with_precision_repair_impl(design, requested_method);
            savefe_final_line_owable = false;
            if (!primary_result.cuda_projection_moments_met) {
                if (detail::repair_cuda_projection(y_use, design, fes_use, w_ptr, tuned, primary_result)) {
                    savefe_projection_published = tuned.retain_fixed_effects;
                } else {
                    primary_result.precision_certified = false;
                }
                return primary_result;
            }
            if (primary_result.converged && !primary_result.cg_restart_required &&
                !primary_result.weighted_gs_moments_met) {
                if (detail::repair_weighted_gauss_seidel(fes_use, *w_ptr, tuned, primary_result)) {
                    cpu_projection_refined = true;
                    primary_result.reuse_raw_original_norm_sq = true;
                    detail::certify_absorption_result(
                        y_use, design, fes_use, w_ptr, tuned, slope_terms, primary_result);
                }
                if (!primary_result.weighted_gs_moments_met) {
                    primary_result.precision_certified = false;
                }
            }
            if (!tuned.retain_fixed_effects && primary_result.converged && primary_result.precision_certified &&
                primary_result.strict_cpu_max_abs_mean > tuned.tol) {
                const int budget = tuned.max_iter - primary_result.iterations;
                if (budget > 0) {
                    cpu_projection_refined = true;
                    HdfeOptions repair = tuned;
                    repair.absorption_method = primary_result.strict_cpu_projection_method;
                    repair.max_iter = budget;
                    detail::ScopedGpuBackendOverride cpu_scope(detail::GpuBackend::Cpu);
                    detail::AbsorptionResult refined = detail::absorb_fixed_effects_mlsmr(
                        primary_result.y_tilde, primary_result.X_tilde, fes_use, w_ptr, repair);
                    refined.iterations += primary_result.iterations;
                    refined.mlsmr_used = primary_result.mlsmr_used;
                    refined.raw_original_norm_sq = std::move(primary_result.raw_original_norm_sq);
                    refined.reuse_raw_original_norm_sq = true;
                    detail::certify_absorption_result(
                        y_use, design, fes_use, w_ptr, tuned, slope_terms, refined);
                    primary_result = std::move(refined);
                }
                if (primary_result.strict_cpu_max_abs_mean > tuned.tol) {
                    primary_result.precision_certified = false;
                }
            }
            if (!tuned.retain_fixed_effects ||
                (primary_result.converged && primary_result.precision_certified)) {
                if (tuned.retain_fixed_effects && savefe_accurate_projection) {
                    if (primary_result.abs_residual_rel > savefe_projection_floor) {
                        return publish_savefe_projection(design, requested_method,
                                                         std::move(primary_result));
                    }
                    owed_final_line.flush();
                    if (read_env_bool("XHDFE_AUTO_ROUTING_RETRY_DIAG").value_or(false)) {
                        std::cerr << "xhdfe savefe_accurate_projection published=0 skipped=1"
                                  << " primary_rel=" << primary_result.abs_residual_rel
                                  << " floor=" << savefe_projection_floor << std::endl;
                    }
                }
                return primary_result;
            }
            owed_final_line.flush();
            const double primary_rel = primary_result.abs_residual_rel;
            const int primary_iterations = primary_result.iterations;
            tuned.retain_fixed_effects = false;
            detail::AbsorptionResult projection;
            try {
                projection = absorb_with_precision_repair_impl(design, requested_method);
            } catch (...) {
                tuned.retain_fixed_effects = true;
                throw;
            }
            tuned.retain_fixed_effects = true;
            if (read_env_bool("XHDFE_AUTO_ROUTING_RETRY_DIAG").value_or(false)) {
                std::cerr << "xhdfe savefe_projection_refinement primary_rel=" << primary_rel
                          << " primary_iterations=" << primary_iterations
                          << " certified=" << (projection.converged &&
                                               projection.precision_certified ? 1 : 0)
                          << " rel=" << projection.abs_residual_rel
                          << " iterations=" << projection.iterations << std::endl;
            }
            if (projection.converged && projection.precision_certified &&
                projection.cuda_projection_moments_met) {
                // No captured alphas: the recovery below takes its map path.
                projection.fe_alpha_y.clear();
                projection.fe_alpha_X.clear();
                projection.iterations += primary_iterations;
                return projection;
            }
            return primary_result;
        };
        // WP1 Gate-1 closure: everything between fit-inner entry and here —
        // input marshalling, weight validation, option resolution, workspace
        // setup — was unattributed (~12% of small CPU fits).
        cpu_profile_log_elapsed("fit_prep", fit_t0);
        const auto absorption_t0 = std::chrono::steady_clock::now();
        bool absorption_ready = false;
        auto make_cache_key = [&](const Eigen::Ref<const Eigen::MatrixXd>& design,
                                  bool require_cpu_refined) {
            std::uint64_t generation = bound_cpu_strict_repair ? kCpuStrictRepairCacheGeneration
                                                               : kAbsorptionSolveContractGeneration;
            if (!tuned.strict_cpu_absolute_check) {
                generation = kAkmRelativeFwlCacheGeneration;
            }
            if (reuse_weighted_cpu_selector) {
                generation = weighted_three_fe_iv_auto_band ? kWeightedThreeFeIvCpuCacheGeneration
                                                            : kWeightedFourFeCpuCacheGeneration;
                if (options_.retain_fixed_effects) {
                    generation += reselect_weighted_savefe_projection ? 2ULL : 1ULL;
                }
            }
            // A structure-cache hit supplies compacted IDs for the retained
            // rows. Key both paths on the same original IDs and pruning policy.
            const FeStructureDigest* input_fe_structure = nullptr;
            if (!fes_use.empty() && fe_cache_cfg.mode != "off" && !fe_cache_cfg.path.empty()) {
                ensure_fe_cache_signature();
                input_fe_structure = &fe_cache_signature;
            }
            // Round 11 (B): an IV fit (the tier's "iv") keeps the key of 2.34.2.
            return hash_absorption_signature(
                y_use, design, fes_use, w_ptr, cache_key_options, generation, input_fe_structure,
                wants_iv || has_instruments, options_.retain_fixed_effects && !fes_use.empty(),
                savefe_accurate_projection, require_cpu_refined);
        };
        auto ensure_cache_key = [&](const Eigen::Ref<const Eigen::MatrixXd>& design) {
            if (!abs_cache_key_ready) {
                abs_cache_key = make_cache_key(design, false);
                abs_cache_key_ready = true;
            }
        };
        auto try_load_cache = [&](const Eigen::Ref<const Eigen::MatrixXd>& design,
                                  int design_cols) -> bool {
            if (has_slopes_use || !allow_cache_read || cache_path.empty() ||
                mobility_gpu_backend_selected()) {
                return false;
            }
            ensure_cache_key(design);
            AbsorptionCacheRecord cached;
            std::optional<SavefeTimer> read_timer;
            if (abs_cache_key.capture) read_timer.emplace("savefe_cache_read");
            auto decode = [&](const AbsorptionCacheKey& key) {
                return read_absorption_cache(cache_path, key, static_cast<int>(y_use.size()),
                    static_cast<int>(design.cols()), design_cols,
                    static_cast<int>(fes_use.size()), cached);
            };
            bool decoded = decode(abs_cache_key);
            if (!decoded && may_read_refined_v5(cache_path, abs_cache_key)) {
                try {
                    decoded = decode(make_cache_key(design, true));
                } catch (const std::bad_alloc&) {
                    // An inability to hash a historical candidate means a miss.
                }
            }
            read_timer.reset();
            if (!decoded) {
                return false;
            }
            if (!cached.converged || (bound_cpu_strict_repair && cached.iterations > tuned.max_iter)) {
                return false;
            }
            if (cached.nobs != y_use.size() ||
                cached.cols != design.cols() ||
                cached.design_cols != design_cols) {
                return false;
            }
            if (static_cast<int>(cached.fe_levels.size()) !=
                static_cast<int>(fes_use.size())) {
                return false;
            }
            absorption.y_tilde = std::move(cached.y_tilde);
            absorption.X_tilde = std::move(cached.X_tilde);
            absorption.fe_levels = std::move(cached.fe_levels);
            absorption.sweep_order_used = std::move(cached.sweep_order);
            absorption.iterations = cached.iterations;
            absorption.converged = cached.converged;
            absorption.krylov_internal_tolerance =
                cached.krylov_internal_tolerance;
            absorption.krylov_max_final_backward_error =
                cached.krylov_max_final_backward_error;
            absorption.krylov_max_condition = cached.krylov_max_condition;
            absorption.krylov_max_condition_times_backward_error =
                cached.krylov_max_condition_times_backward_error;
            absorption.auto_routing_retry_policy_enabled =
                cached.auto_routing_retry_policy_enabled;
            absorption.auto_routing_retry_eligible =
                cached.auto_routing_retry_eligible;
            absorption.auto_routing_retry_fired =
                cached.auto_routing_retry_fired;
            absorption.auto_routing_retry_status =
                cached.auto_routing_retry_status;
            absorption.auto_routing_retry_primary_method =
                cached.auto_routing_retry_primary_method;
            absorption.auto_routing_retry_primary_iterations =
                cached.auto_routing_retry_primary_iterations;
            absorption.auto_routing_retry_primary_abs_residual_rel =
                cached.auto_routing_retry_primary_abs_residual_rel;
            absorption.auto_routing_retry_iterations =
                cached.auto_routing_retry_iterations;
            absorption.auto_routing_retry_abs_residual_rel =
                cached.auto_routing_retry_abs_residual_rel;
            absorption.auto_routing_retry_elapsed_seconds =
                cached.auto_routing_retry_elapsed_seconds;
            method_used_ = cached.method;
            // A transform the reduced-system tier published is stored under
            // its public name, reduced-pcg. The hit then holds the internal
            // route a fresh fit of the same inputs holds when the tier
            // publishes: the resolution of the call sites below, in method_used_
            // and tuned.absorption_method, set before the certificate as there.
            // The N1 continuation and the legacy residual refinement read it.
            // (The call sites' slope adjustment cannot apply: no read with slopes.)
            const bool tier_record = method_used_ == AbsorptionMethod::ReducedPcg;
            if (cached.savefe) {
                provisional_cache_hit = true;
                auto& p = *cached.savefe;
                if ((p.tier_status == 1) != tier_record) {
                    throw SavefeCacheMiss{};
                }
                method_used_ = static_cast<AbsorptionMethod>(p.internal_method);
                tuned.absorption_method = static_cast<AbsorptionMethod>(p.tuned_method);
                tuned.symmetric_sweep = (p.route_flags & kSavefeSymmetric) != 0;
                tuned.use_sparse_solver = (p.route_flags & kSavefeUseSparse) != 0;
                tuned.use_krylov = (p.route_flags & kSavefeUseKrylov) != 0;
                tuned.from_auto = (p.route_flags & kSavefeFromAuto) != 0;
                absorption.mlsmr_used = (p.route_flags & kSavefeMlsmr) != 0;
                absorption.schwarz_used = (p.route_flags & kSavefeSchwarz) != 0;
                absorption.krylov_pcg_used = (p.route_flags & kSavefeKrylovPcg) != 0;
            } else if (tier_record) {
                if (selected_method == AbsorptionMethod::Auto) {
                    selected_method = select_method(fes_use.size());
                }
                method_used_ = selected_method;
                if (tuned.symmetric_sweep &&
                    options_.absorption_method == AbsorptionMethod::Auto &&
                    method_used_ != AbsorptionMethod::SymmetricGaussSeidel &&
                    fes_use.size() > 1) {
                    method_used_ = AbsorptionMethod::SymmetricGaussSeidel;
                }
                tuned.absorption_method = method_used_;
            }
            if (tuned.strict_cpu_absolute_check && tuned.tolerance_mode == ToleranceMode::StrictResidual &&
                !tuned.retain_fixed_effects &&
                (method_used_ == AbsorptionMethod::Lsmr || method_used_ == AbsorptionMethod::Mlsmr)) {
                absorption.strict_cpu_projection_method = method_used_;
            }
            detail::certify_absorption_result(
                y_use, design, fes_use, w_ptr, tuned, slope_terms, absorption);
            if (!absorption.precision_certified ||
                !absorption.weighted_gs_moments_met ||
                absorption.strict_cpu_max_abs_mean > tuned.tol ||
                bounded_auto_gate_failed(absorption)) {
                if (cached.savefe) throw SavefeCacheMiss{};
                absorption = detail::AbsorptionResult{};
                return false;
            }
            savefe_projection_published = cached.savefe_projection_published;
            cpu_projection_refined = cached.cpu_projection_refined;
            cache_hit = true;
            if (cached.savefe) {
                cached_savefe = std::move(cached.savefe);
                return true;
            }
            // An accepted transform read back reports what the fresh fit
            // reported (status 1, reason none); any other hit says where the
            // absorption came from, and the trace line marks the hit.
            if (tier_record) reduced_pcg_status_ = 1;
            if (detail::reduced_pcg_effective(options_)) {
                reduced_pcg_reason_ = tier_record ? "none" : "cache";
                detail::reduced_pcg_final_line(
                    std::string("status=cache method=") + method_name(absorption_method_used()) +
                    " iterations=" + std::to_string(absorption.iterations));
            }
            reduced_pcg_fine_.cache_hit = true;  // package D
            return true;
        };
        auto benchmark_absorption = [&](const Eigen::Ref<const Eigen::MatrixXd>& design,
                                        AbsorptionMethod& best_method,
                                        bool& best_use_sparse,
                                        bool& best_use_krylov,
                                        detail::AbsorptionResult& best_absorption) -> bool {
            struct AbsorptionCandidate {
                AbsorptionMethod method;
                bool use_sparse;
                bool use_krylov;
                bool symmetric;
            };

            std::vector<AbsorptionCandidate> candidates;
            candidates.reserve(5);
            candidates.push_back({AbsorptionMethod::GaussSeidel, false, false, false});
            if (fes_use.size() > 1) {
                candidates.push_back({AbsorptionMethod::SymmetricGaussSeidel, false, false, true});
            }
            if (fes_use.size() > 1 && threads > 1) {
                candidates.push_back({AbsorptionMethod::Jacobi, false, false, false});
            }
            candidates.push_back({AbsorptionMethod::GaussSeidel, true, false, false});
            candidates.push_back({AbsorptionMethod::GaussSeidel, false, true, false});

            double best_time = std::numeric_limits<double>::infinity();
            bool have_best = false;
            for (const auto& cand : candidates) {
                HdfeOptions bench_opts = tuned;
                bench_opts.absorption_method = cand.method;
                bench_opts.symmetric_sweep = cand.symmetric;
                bench_opts.use_sparse_solver = cand.use_sparse;
                bench_opts.use_krylov = cand.use_krylov;
                if (bench_opts.use_krylov) {
                    bench_opts.use_sparse_solver = false;
                }

                const auto t0 = std::chrono::steady_clock::now();
                detail::AbsorptionResult res =
                    detail::absorb_fixed_effects_v6(y_use, design, fes_use, w_ptr, bench_opts,
                                                    cand.method, slope_terms);
                const auto t1 = std::chrono::steady_clock::now();
                const double elapsed =
                    std::chrono::duration<double, std::milli>(t1 - t0).count();

                if (!res.converged || !res.precision_certified) {
                    continue;
                }
                if (elapsed < best_time) {
                    best_time = elapsed;
                    best_method = cand.method;
                    best_use_sparse = cand.use_sparse;
                    best_use_krylov = cand.use_krylov;
                    best_absorption = std::move(res);
                    have_best = true;
                }
            }
            return have_best;
        };

        int design_cols = 0;
        if (drop_intercept && !inst_use) {
            design_cols = static_cast<int>(X_use.cols());
            if (!absorption_ready && try_load_cache(X_use, design_cols)) {
                absorption_ready = true;
                allow_profile_write = false;
            }
            if (!absorption_ready && benchmark_methods) {
                AbsorptionMethod best_method = AbsorptionMethod::Auto;
                bool best_use_sparse = false;
                bool best_use_krylov = false;
                if (benchmark_absorption(X_use, best_method, best_use_sparse, best_use_krylov, absorption)) {
                    method_used_ = best_method;
                    tuned.absorption_method = best_method;
                    tuned.symmetric_sweep = (best_method == AbsorptionMethod::SymmetricGaussSeidel);
                    tuned.use_sparse_solver = best_use_sparse;
                    tuned.use_krylov = best_use_krylov;
                    if (tuned.use_krylov) {
                        tuned.use_sparse_solver = false;
                    }
                    absorption_ready = true;
                }
            }
            if (!absorption_ready) {
                if (selected_method == AbsorptionMethod::Auto) {
                    selected_method = select_method(fes_use.size());
                }
                method_used_ = selected_method;
                if (has_slopes_use && method_used_ == AbsorptionMethod::Jacobi) {
                    method_used_ = fes_use.size() > 1 ? AbsorptionMethod::SymmetricGaussSeidel
                                                       : AbsorptionMethod::GaussSeidel;
                }
                if (tuned.symmetric_sweep &&
                    options_.absorption_method == AbsorptionMethod::Auto &&
                    method_used_ != AbsorptionMethod::SymmetricGaussSeidel &&
                    fes_use.size() > 1) {
                    method_used_ = AbsorptionMethod::SymmetricGaussSeidel;
                }
                tuned.absorption_method = method_used_;
                absorption = absorb_with_precision_repair(X_use, method_used_);
                if (absorption.schwarz_used) {
                    method_used_ = AbsorptionMethod::Schwarz;  // adaptive gate diverted to Schwarz
                } else if (absorption.mlsmr_used) {
                    method_used_ = krylov_method_used(absorption);
                }
            }
            if (allow_cache_write && !cache_hit && absorption.converged &&
                absorption.precision_certified && !cache_path.empty()) {
                ensure_cache_key(X_use);
            }
        } else {
            if (drop_intercept && inst_use && inst_use->cols() > 0) {
                design_cols = static_cast<int>(X_use.cols());
                const Eigen::MatrixXd combined = append_matrix(X_use, inst_use);
                if (!absorption_ready && try_load_cache(combined, design_cols)) {
                    absorption_ready = true;
                    allow_profile_write = false;
                }
                if (!absorption_ready && benchmark_methods) {
                    AbsorptionMethod best_method = AbsorptionMethod::Auto;
                    bool best_use_sparse = false;
                    bool best_use_krylov = false;
                    if (benchmark_absorption(combined, best_method, best_use_sparse, best_use_krylov,
                                             absorption)) {
                        method_used_ = best_method;
                        tuned.absorption_method = best_method;
                        tuned.symmetric_sweep = (best_method == AbsorptionMethod::SymmetricGaussSeidel);
                        tuned.use_sparse_solver = best_use_sparse;
                        tuned.use_krylov = best_use_krylov;
                        if (tuned.use_krylov) {
                            tuned.use_sparse_solver = false;
                        }
                        absorption_ready = true;
                    }
                }
                if (!absorption_ready) {
                    if (selected_method == AbsorptionMethod::Auto) {
                        selected_method = select_method(fes_use.size());
                    }
                    method_used_ = selected_method;
                    if (has_slopes_use && method_used_ == AbsorptionMethod::Jacobi) {
                        method_used_ = fes_use.size() > 1 ? AbsorptionMethod::SymmetricGaussSeidel
                                                           : AbsorptionMethod::GaussSeidel;
                    }
                    if (tuned.symmetric_sweep &&
                        options_.absorption_method == AbsorptionMethod::Auto &&
                        method_used_ != AbsorptionMethod::SymmetricGaussSeidel &&
                        fes_use.size() > 1) {
                        method_used_ = AbsorptionMethod::SymmetricGaussSeidel;
                    }
                    tuned.absorption_method = method_used_;
                    absorption = absorb_with_precision_repair(combined, method_used_);
                    if (absorption.schwarz_used) {
                        method_used_ = AbsorptionMethod::Schwarz;
                    } else if (absorption.mlsmr_used) {
                        method_used_ = krylov_method_used(absorption);
                    }
                }
                if (allow_cache_write && !cache_hit && absorption.converged &&
                    absorption.precision_certified && !cache_path.empty()) {
                    ensure_cache_key(combined);
                }
            } else {
                Eigen::MatrixXd design =
                    drop_intercept ? Eigen::MatrixXd(X_use)
                                   : maybe_add_intercept(X_use, options_.fit_intercept);
                design_cols = static_cast<int>(design.cols());
                if (!inst_use || inst_use->cols() == 0) {
                    if (!absorption_ready && try_load_cache(design, design_cols)) {
                        absorption_ready = true;
                        allow_profile_write = false;
                    }
                    if (!absorption_ready && benchmark_methods) {
                        AbsorptionMethod best_method = AbsorptionMethod::Auto;
                        bool best_use_sparse = false;
                        bool best_use_krylov = false;
                        if (benchmark_absorption(design, best_method, best_use_sparse, best_use_krylov,
                                                 absorption)) {
                            method_used_ = best_method;
                            tuned.absorption_method = best_method;
                            tuned.symmetric_sweep =
                                (best_method == AbsorptionMethod::SymmetricGaussSeidel);
                            tuned.use_sparse_solver = best_use_sparse;
                            tuned.use_krylov = best_use_krylov;
                            if (tuned.use_krylov) {
                                tuned.use_sparse_solver = false;
                            }
                            absorption_ready = true;
                        }
                    }
                    if (!absorption_ready) {
                        if (selected_method == AbsorptionMethod::Auto) {
                            selected_method = select_method(fes_use.size());
                        }
                        method_used_ = selected_method;
                        if (has_slopes_use && method_used_ == AbsorptionMethod::Jacobi) {
                            method_used_ = fes_use.size() > 1 ? AbsorptionMethod::SymmetricGaussSeidel
                                                               : AbsorptionMethod::GaussSeidel;
                        }
                        if (tuned.symmetric_sweep &&
                            options_.absorption_method == AbsorptionMethod::Auto &&
                            method_used_ != AbsorptionMethod::SymmetricGaussSeidel &&
                            fes_use.size() > 1) {
                            method_used_ = AbsorptionMethod::SymmetricGaussSeidel;
                        }
                        tuned.absorption_method = method_used_;
                        absorption = absorb_with_precision_repair(design, method_used_);
                        if (absorption.schwarz_used) {
                            method_used_ = AbsorptionMethod::Schwarz;
                        } else if (absorption.mlsmr_used) {
                            method_used_ = krylov_method_used(absorption);
                        }
                    }
                    if (allow_cache_write && !cache_hit && absorption.converged &&
                        absorption.precision_certified && !cache_path.empty()) {
                        ensure_cache_key(design);
                    }
                } else {
                    const Eigen::MatrixXd combined = append_matrix(design, inst_use);
                    if (!absorption_ready && try_load_cache(combined, design_cols)) {
                        absorption_ready = true;
                        allow_profile_write = false;
                    }
                    if (!absorption_ready && benchmark_methods) {
                        AbsorptionMethod best_method = AbsorptionMethod::Auto;
                        bool best_use_sparse = false;
                        bool best_use_krylov = false;
                        if (benchmark_absorption(combined, best_method, best_use_sparse, best_use_krylov,
                                                 absorption)) {
                            method_used_ = best_method;
                            tuned.absorption_method = best_method;
                            tuned.symmetric_sweep =
                                (best_method == AbsorptionMethod::SymmetricGaussSeidel);
                            tuned.use_sparse_solver = best_use_sparse;
                            tuned.use_krylov = best_use_krylov;
                            if (tuned.use_krylov) {
                                tuned.use_sparse_solver = false;
                            }
                            absorption_ready = true;
                        }
                    }
                    if (!absorption_ready) {
                        if (selected_method == AbsorptionMethod::Auto) {
                            selected_method = select_method(fes_use.size());
                        }
                        method_used_ = selected_method;
                        if (has_slopes_use && method_used_ == AbsorptionMethod::Jacobi) {
                            method_used_ = fes_use.size() > 1 ? AbsorptionMethod::SymmetricGaussSeidel
                                                               : AbsorptionMethod::GaussSeidel;
                        }
                        if (tuned.symmetric_sweep &&
                            options_.absorption_method == AbsorptionMethod::Auto &&
                            method_used_ != AbsorptionMethod::SymmetricGaussSeidel &&
                            fes_use.size() > 1) {
                            method_used_ = AbsorptionMethod::SymmetricGaussSeidel;
                        }
                        tuned.absorption_method = method_used_;
                        absorption = absorb_with_precision_repair(combined, method_used_);
                        if (absorption.schwarz_used) {
                            method_used_ = AbsorptionMethod::Schwarz;
                        } else if (absorption.mlsmr_used) {
                            method_used_ = krylov_method_used(absorption);
                        }
                    }
                    if (allow_cache_write && !cache_hit && absorption.converged &&
                        absorption.precision_certified && !cache_path.empty()) {
                        ensure_cache_key(combined);
                    }
                }
            }
        }

        cpu_profile_log_elapsed("absorption", absorption_t0);
        // Package B, stage 2a': the sweep-exit step of a fit in scope (trace only).
        if (strict_cuda_scope && strict_accept_trace_on()) {
            std::ostringstream line;
            line.precision(17);
            line << "strict_accept_trace sweep_exit reached=" << (strict_sweep_exit.consumed ? 1 : 0)
                 << " formed=" << (strict_sweep_exit.formed ? 1 : 0)
                 << " skipped=" << (strict_sweep_exit.skipped[0] != '\0' ? strict_sweep_exit.skipped : "-")
                 << " columns=" << strict_sweep_exit.columns
                 << " lambda_min=" << strict_sweep_exit.lambda_min
                 << " D0=" << strict_sweep_exit.d0 << " limit=" << strict_sweep_exit.tol
                 << " sweeps=" << strict_sweep_exit.sweeps
                 << " confirmations=" << strict_sweep_exit.confirmations
                 << " confirmed=" << (strict_sweep_exit.confirmed ? 1 : 0)
                 << " exit=" << strict_sweep_exit.exit
                 << " readings=" << strict_sweep_exit.readings
                 << " best=" << strict_sweep_exit.best
                 << " frozen_stop=" << strict_frozen_stop_name(strict_sweep_exit.frozen_stop)
                 << " last_in_sweep=" << strict_sweep_exit.last_in_sweep
                 << " last_fresh=" << strict_sweep_exit.last_fresh
                 << " seconds_raw=" << strict_sweep_exit.seconds_raw
                 << " seconds_gram=" << strict_sweep_exit.seconds_gram
                 << " seconds_solve=" << strict_sweep_exit.seconds_solve
                 << " seconds=" << strict_sweep_exit.seconds_total
                 << " iterations=" << absorption.iterations << '\n';
            std::cerr << line.str();
        }
        detail::N1RefinementBudget n1_budget{
            tuned.max_iter, cpu_projection_refined || absorption.cuda_projection_repaired};
        // Package B: the passes of the checks of a fit in scope (trace only) and
        // the host's per-effect D(e) of the last pass (the continuation's
        // self-check against its first in-sweep reading, trace only).
        int strict_cuda_pass = 0;
        std::vector<long double> strict_cuda_first_effect_host;
        for (;;) {
        gpu_used_ = absorption.gpu_used;
        gpu_status_code_ = absorption.gpu_status_code;
        gpu_attempted_ = absorption.gpu_attempted;
        gpu_absorption_converged_ = absorption.gpu_absorption_converged;
        gpu_absorption_iterations_ = absorption.gpu_absorption_iterations;
        cuda_tail_code_ = absorption.cuda_tail;
        require_accepted_absorption(tuned, absorption, "HDFE absorption");
        require_cuda_execution(cuda_execution_required, absorption);
        const auto stats_t0 = std::chrono::steady_clock::now();
        double sum_weights_for_stats = static_cast<double>(y_use.size());
        // Center TSS when the model contains an explicit or absorbed constant.
        // A pure slope can supply it when it is constant within every group.
        const bool model_has_intercept =
            options_.fit_intercept || absorbed_constant;
        auto transformed_X = absorption.X_tilde.leftCols(design_cols);
        const int transformed_full_cols = static_cast<int>(transformed_X.cols());
        const bool transformed_has_intercept =
            (options_.fit_intercept && !drop_intercept && transformed_full_cols > 0);
        const int transformed_slope_cols =
            transformed_has_intercept ? (transformed_full_cols - 1) : transformed_full_cols;
        // The sums of squares of y and of y-tilde and the squared norms of each
        // slope column before and after the absorption (read by the collinearity
        // test below) are independent. Each reduction is computed whole with
        // the same expression regardless of team size.
        double total_tss = 0.0;
        double within_tss = 0.0;
        const bool with_fe = !fes_use.empty();
        const std::size_t stats_tasks = with_fe ? 2 : 1;
        const std::size_t norm_cols = static_cast<std::size_t>(transformed_slope_cols);
        detail::InlineOrDynamicBuffer<double> raw_ss_by_col(norm_cols);
        detail::InlineOrDynamicBuffer<double> tilde_ss_by_col(norm_cols);
        run_serial_tasks_on_team(
            stats_tasks + 2 * norm_cols,
            [&](std::size_t task) {
                if (task == 0) {
                    if (model_has_intercept) {
                        total_tss = compute_total_sum_of_squares(
                            y_use, w_ptr, &sum_weights_for_stats);
                    } else {
                        total_tss = weighted_sum_of_squares(y_use, w_ptr);
                        sum_weights_for_stats =
                            w_ptr ? w_ptr->sum() : static_cast<double>(y_use.size());
                    }
                } else if (task < stats_tasks) {
                    within_tss = weighted_sum_of_squares(absorption.y_tilde, w_ptr);
                } else {
                    const std::size_t j = (task - stats_tasks) / 2;
                    if ((task - stats_tasks) % 2 == 0) {
                        raw_ss_by_col[j] = X_use.col(j).squaredNorm();
                    } else {
                        tilde_ss_by_col[j] = transformed_X.col(j).squaredNorm();
                    }
                }
            },
            tuned.num_threads, *tuned.parallel_observer);
        if (!with_fe) {
            within_tss = total_tss;
        }
        cpu_profile_log_elapsed("fit_stats", stats_t0);
        if (!cached_savefe && read_env_bool("XHDFE_DEBUG_SOLVER").value_or(false)) {
            std::cerr << "xhdfe solver: use_krylov=" << (tuned.use_krylov ? 1 : 0)
                      << " use_sparse=" << (tuned.use_sparse_solver ? 1 : 0)
                      << " method=" << static_cast<int>(method_used_)
                      << " iterations=" << absorption.iterations
                      << " cache_hit=" << (cache_hit ? 1 : 0) << "\n";
        }

        const int rank_anchor_col = has_slopes_use && transformed_has_intercept
                                        ? transformed_full_cols - 1 : -1;

        // Stata/reghdfe-style collinearity with absorbed fixed effects:
        // after partialling-out, regressors with near-zero variation are omitted.
        constexpr double kFeCollinearTol = detail::kFeCollinearTol;
        const double rank_collinear_tol = std::max(1e-6, tuned.tol * 10.0);
        std::vector<int> kept_slope_cols;
        std::vector<int> omitted_slope_cols;
        std::vector<int> omitted_fe_slope_cols;
        std::vector<int> omitted_rank_slope_cols;
        Eigen::VectorXd fe_collinear_ss_ratio;
        if (options_.capture_fe_collinear_ss_ratio) {
            fe_collinear_ss_ratio.resize(transformed_slope_cols);
        }
        kept_slope_cols.reserve(static_cast<std::size_t>(std::max(0, transformed_slope_cols)));
        omitted_slope_cols.reserve(static_cast<std::size_t>(std::max(0, transformed_slope_cols)));
        const auto collinearity_t0 = std::chrono::steady_clock::now();
        std::optional<bool> exact_single_level_projection;
        for (int j = 0; j < transformed_slope_cols; ++j) {
            const double raw_ss = raw_ss_by_col[static_cast<std::size_t>(j)];
            const double tilde_ss = tilde_ss_by_col[static_cast<std::size_t>(j)];
            if (options_.capture_fe_collinear_ss_ratio) {
                fe_collinear_ss_ratio[j] =
                    raw_ss > 0.0 ? tilde_ss / raw_ss
                                 : (tilde_ss <= kFeCollinearTol
                                        ? 0.0
                                        : std::numeric_limits<double>::infinity());
            }
            const bool finite = hdfe::detail::ieee_finite(raw_ss) && hdfe::detail::ieee_finite(tilde_ss);
            bool collinear =
                finite && (raw_ss <= 0.0 ? (tilde_ss <= kFeCollinearTol)
                                         : (tilde_ss <= kFeCollinearTol * raw_ss));
            if (collinear && detail::ordinary_audit_enabled()) {
                // Audit mode: exact redundancy proof or an informative refusal.
                bool verified=false;
                if(fes_use.size()==1 && slope_terms.empty() && raw_ss>0 && tilde_ss>0) {
                    if(!exact_single_level_projection) exact_single_level_projection=detail::exact_level_projection(
                        y_use,X_use,fes_use[0],w_ptr,absorption.y_tilde,transformed_X.leftCols(X_use.cols()));
                    verified=*exact_single_level_projection;
                }
                collinear=require_safe_fe_omission(X_use.col(j),raw_ss,tilde_ss,fes_use,
                    slope_terms,model_has_intercept,j+1,verified);
            } else if (collinear && model_has_intercept && raw_ss > 0.0 && tilde_ss > 0.0) {
                // A level shift is absorbed by any constant in the model, so
                // the relevant scale of the column is its variation about the
                // mean: X = 1e14 + a must not be omitted when a varies within
                // the FEs. The centered scale never exceeds the raw one, so
                // this can only retain a column the raw ratio would omit.
                const double centered_ss = centered_sum_of_squares(X_use.col(j));
                // Projecting a column of magnitude |x| leaves FP64 rounding of
                // about eps*|x| per row; within variation below that floor is
                // not distinguishable from an exact redundancy.
                const double rounding_floor =
                    16.0 * std::numeric_limits<double>::epsilon() *
                    std::numeric_limits<double>::epsilon() * raw_ss;
                collinear = !(centered_ss > 0.0) ||
                            tilde_ss <= kFeCollinearTol * centered_ss ||
                            tilde_ss <= rounding_floor;
            }
            if (collinear) {
                omitted_fe_slope_cols.push_back(j);
                omitted_slope_cols.push_back(j);
            } else {
                kept_slope_cols.push_back(j);
            }
        }

        cpu_profile_log_elapsed("collinearity_scales", collinearity_t0);
        Eigen::MatrixXd xtx_used;
        Eigen::VectorXd xty_used;
        bool have_precomputed = false;

        // Detect remaining linear dependencies among kept slopes (including intercept collinearity).
        const bool use_precomputed = (!wants_iv && tuned.se_type != StandardErrorType::Cluster);
        if (use_precomputed) {
            const int k_initial = static_cast<int>(kept_slope_cols.size());
            const int intercept_col = transformed_has_intercept ? (transformed_full_cols - 1) : -1;
            const CrossproductResult cp = compute_crossproducts_selected(
                absorption.y_tilde, transformed_X, kept_slope_cols, intercept_col, w_ptr,
                options_.fit_intercept, tuned.num_threads, tuned.parallel_observer);

            std::vector<int> keep_positions;
            keep_positions.reserve(kept_slope_cols.size());
            if (k_initial > 0) {
                // FP64 triage on the Gram already formed for OLS (2.26.2 rule);
                // the double-double rank runs only for unseparated decisions.
                Eigen::MatrixXd gram = cp.xtx.topLeftCorner(k_initial, k_initial);
                if (options_.fit_intercept) {
                    double denom = rank_anchor_col >= 0 ? cp.xtx(k_initial, k_initial) : cp.sum_w;
                    if (!(denom > 0.0)) {
                        denom = 1.0;
                    }
                    const Eigen::VectorXd cross = rank_anchor_col >= 0
                        ? Eigen::VectorXd(cp.xtx.col(k_initial).head(k_initial)) : cp.sum_x;
                    gram.noalias() -= (cross * cross.transpose()) / denom;
                }
                bool rank_separated = true;
                const Eigen::VectorXd uncentered_diagonal =
                    cp.xtx.diagonal().head(k_initial);
                std::vector<uint8_t> drop_mask =
                    compute_rank_collinearity_mask_from_gram(
                        gram, kept_slope_cols, rank_collinear_tol,
                        options_.collinear_priority, &rank_separated,
                        &uncentered_diagonal);
                if (!rank_separated) {
                    drop_mask = precise_rank_mask_with_anchor(
                        transformed_X, kept_slope_cols, w_ptr, options_.fit_intercept,
                        rank_collinear_tol, options_.collinear_priority,
                        tuned.num_threads, tuned.parallel_observer, rank_anchor_col);
                }

                std::vector<int> new_kept;
                std::vector<int> new_omitted;
                new_kept.reserve(kept_slope_cols.size());
                new_omitted.reserve(kept_slope_cols.size());
                for (std::size_t pos = 0; pos < kept_slope_cols.size(); ++pos) {
                    const int idx = kept_slope_cols[pos];
                    if (drop_mask[static_cast<std::size_t>(pos)]) {
                        new_omitted.push_back(idx);
                    } else {
                        new_kept.push_back(idx);
                        keep_positions.push_back(static_cast<int>(pos));
                    }
                }
                kept_slope_cols.swap(new_kept);
                omitted_rank_slope_cols.insert(omitted_rank_slope_cols.end(),
                                               new_omitted.begin(), new_omitted.end());
                omitted_slope_cols.insert(omitted_slope_cols.end(),
                                          new_omitted.begin(), new_omitted.end());
            }

            std::vector<int> xtx_cols = keep_positions;
            if (intercept_col >= 0) {
                xtx_cols.push_back(k_initial);
            }
            const int p_used = static_cast<int>(xtx_cols.size());
            xtx_used.resize(p_used, p_used);
            xty_used.resize(p_used);
            for (int i = 0; i < p_used; ++i) {
                const int col_i = xtx_cols[static_cast<std::size_t>(i)];
                xty_used(i) = cp.xty(col_i);
                for (int j = 0; j < p_used; ++j) {
                    const int col_j = xtx_cols[static_cast<std::size_t>(j)];
                    xtx_used(i, j) = cp.xtx(col_i, col_j);
                }
            }
            have_precomputed = true;
        } else if (!kept_slope_cols.empty()) {
            const std::vector<uint8_t> drop_mask = compute_rank_collinearity_mask(
                transformed_X, kept_slope_cols, transformed_slope_cols,
                transformed_has_intercept,
                w_ptr, rank_collinear_tol, tuned.num_threads,
                options_.collinear_priority, tuned.parallel_observer, rank_anchor_col);

            std::vector<int> new_kept;
            std::vector<int> new_omitted;
            new_kept.reserve(kept_slope_cols.size());
            new_omitted.reserve(kept_slope_cols.size());
            for (const int idx : kept_slope_cols) {
                if (idx >= 0 && idx < transformed_slope_cols &&
                    drop_mask[static_cast<std::size_t>(idx)]) {
                    new_omitted.push_back(idx);
                } else {
                    new_kept.push_back(idx);
                }
            }
            kept_slope_cols.swap(new_kept);
            omitted_rank_slope_cols.insert(omitted_rank_slope_cols.end(),
                                           new_omitted.begin(), new_omitted.end());
            omitted_slope_cols.insert(omitted_slope_cols.end(),
                                      new_omitted.begin(), new_omitted.end());
        }
        cpu_profile_log_elapsed("collinearity", collinearity_t0);

        // Build the design matrix actually used in OLS/IV:
        // (kept slopes) [+ intercept column if present].
        const auto design_t0 = std::chrono::steady_clock::now();
        const int design_used_cols = static_cast<int>(kept_slope_cols.size()) +
                                     (transformed_has_intercept ? 1 : 0);
        bool design_identity = (design_used_cols == transformed_full_cols);
        if (design_identity) {
            for (std::size_t j = 0; j < kept_slope_cols.size(); ++j) {
                if (kept_slope_cols[j] != static_cast<int>(j)) {
                    design_identity = false;
                    break;
                }
            }
        }
        Eigen::MatrixXd transformed_X_used_storage;
        if (!design_identity) {
            transformed_X_used_storage.resize(transformed_X.rows(), design_used_cols);
            for (int out_j = 0; out_j < static_cast<int>(kept_slope_cols.size()); ++out_j) {
                transformed_X_used_storage.col(out_j) =
                    transformed_X.col(kept_slope_cols[static_cast<std::size_t>(out_j)]);
            }
            if (transformed_has_intercept) {
                transformed_X_used_storage.col(static_cast<int>(kept_slope_cols.size())) =
                    transformed_X.col(transformed_full_cols - 1);
            }
        }
        // When no column was dropped or reordered, the copy above would
        // reproduce transformed_X element-for-element, so alias it instead.
        // transformed_X views absorption.X_tilde, which is only read for the
        // remainder of this fit.
        const Eigen::Ref<const Eigen::MatrixXd> transformed_X_used =
            design_identity ? Eigen::Ref<const Eigen::MatrixXd>(transformed_X)
                            : Eigen::Ref<const Eigen::MatrixXd>(transformed_X_used_storage);
        cpu_profile_log_elapsed("design_copy", design_t0);

        const int df_m_effective = static_cast<int>(kept_slope_cols.size());
        const double nobs_effective =
            current_nobs_effective(y_use.size());

        auto network_scores_for_pass = std::move(network_scores);
        detail::OlsResult ols_result;
        // Phase 5b (DESENHO_FASE5B.md): the passes of a multi-way clustered fit, shared
        // inside this pass of the N1 loop only; the pair is asked for when a recovered
        // constant gives it consumers. Null under XHDFE_CLUSTER_SHARED_PASSES=0.
        detail::ClusterPasses cluster_passes;
        detail::ClusterPasses* const passes =
            (detail::cluster_shared_passes_enabled() && tuned.se_type == StandardErrorType::Cluster &&
             c_ptr && c_ptr->size() >= 2) ? &cluster_passes : nullptr;
        if (passes) {
            passes->want_pair = c_ptr->size() == 2 && drop_intercept;
            if (passes->want_pair && network_scores_for_pass && network_scores_for_pass->geometry &&
                design_identity && !transformed_has_intercept &&
                !wants_iv && !w_ptr && options_.fit_intercept && transformed_X_used.cols() > 0 &&
                transformed_X_used.cols() == X_use.cols() && network_scores_for_pass->clusters == c_ptr) {
                passes->network = network_scores_for_pass.get();
            }
        }
        // For IV sandwich inference the score design is X-hat, while
        // residuals and the normalization means use the actual regressors.
        // Keep X-hat alive through intercept-covariance postprocessing.
        Eigen::MatrixXd iv_score_X_storage;
        Eigen::MatrixXd iv_score_low_storage;
        Eigen::VectorXd iv_intercept_covariance;
        detail::OlsWideCovariance iv_covariance_wide;
        detail::DkraayInfluences iv_dkraay_influences;
        const auto ols_t0 = std::chrono::steady_clock::now();
        if (!wants_iv) {
            if (transformed_X_used.cols() == 0) {
                // Degenerate case: all regressors were collinear after partialling-out.
                // Return an intercept-only fit downstream (intercept computed later when drop_intercept=true).
                detail::OlsResult empty;
                empty.coefficients.resize(0);
                empty.std_errors.resize(0);
                empty.tvalues.resize(0);
                empty.pvalues.resize(0);
                empty.conf_int.resize(0, 2);
                empty.residuals.resize(absorption.y_tilde.size());
                empty.n1_normal = std::make_shared<detail::N1NormalEvidence>(1, 0);
                for (int i = 0; i < empty.residuals.size(); ++i) {
                    const double value = absorption.y_tilde[i];
                    empty.residuals[i] = value;
                    empty.n1_normal->chunks[0].add(value, value, w_ptr ? (*w_ptr)[i] : 1.0,
                        0, [](int) { return 0.0; }, [](int) { return 0.0; }, [](int) { return 0.0; });
                }
                empty.df_resid = nobs_effective;
                if (tuned.se_type == StandardErrorType::Cluster) {
                    if (!c_ptr || c_ptr->empty())
                        throw std::runtime_error("Cluster-robust errors requested but no cluster variables were provided");
                    const auto counts = compute_cluster_counts(*c_ptr);
                    empty.num_clusters = *std::min_element(counts.begin(), counts.end());
                    if (c_ptr->size() == 1 && empty.num_clusters > 1 && nobs_effective > 0.0)
                        empty.cov_scale = static_cast<double>(empty.num_clusters) / (empty.num_clusters-1.0) *
                            (nobs_effective-1.0) / nobs_effective;
                }
                empty.rss = weighted_sum_of_squares(empty.residuals, w_ptr);
                empty.tss = total_tss;
                empty.within_tss = within_tss;
                const double missing_r2 =
                    std::numeric_limits<double>::quiet_NaN();
                empty.r2 = (total_tss > 0.0)
                               ? 1.0 - empty.rss / total_tss
                               : missing_r2;
                empty.r2_within = (within_tss > 0.0)
                                      ? 1.0 - empty.rss / within_tss
                                      : missing_r2;
                empty.sigma2 = 0.0;
                empty.nobs = static_cast<int>(absorption.y_tilde.size());
                ols_result = std::move(empty);
            } else if (tuned.se_type == StandardErrorType::Cluster) {
                if (!c_ptr || c_ptr->empty()) {
                    throw std::runtime_error(
                        "Cluster-robust errors requested but no cluster variables were provided");
                }
                if (c_ptr->size() == 1) {
                    ols_result = detail::run_ols(absorption.y_tilde, transformed_X_used, w_ptr, &(*c_ptr)[0],
                                                 tuned.se_type, total_tss, within_tss, nobs_effective,
                                                 false, nullptr, tuned.num_threads_explicit,
                                                 tuned.parallel_observer);
                } else {
                    ols_result = detail::run_ols_multiway(absorption.y_tilde, transformed_X_used, w_ptr, c_ptr,
                                                         tuned.se_type, total_tss, within_tss,
                                                         tuned.ssc_g_df, tuned.ssc_g_adj, nobs_effective,
                                                         nullptr, tuned.num_threads_explicit,
                                                         tuned.parallel_observer, passes);
                    log_cluster_passes_ols(passes);
                }
            } else if (have_precomputed &&
                       xtx_used.rows() == transformed_X_used.cols() &&
                       xty_used.size() == transformed_X_used.cols()) {
                ols_result = detail::run_ols_fast_from_xtx(absorption.y_tilde, transformed_X_used, w_ptr,
                                                           tuned.se_type, total_tss, within_tss,
                                                           xtx_used, xty_used, nobs_effective,
                                                           tuned.weights_are_frequencies,
                                                           tuned.num_threads_explicit,
                                                           tuned.parallel_observer);
            } else {
                ols_result = detail::run_ols(absorption.y_tilde, transformed_X_used, w_ptr, nullptr, tuned.se_type,
                                             total_tss, within_tss, nobs_effective,
                                             tuned.weights_are_frequencies, nullptr,
                                             tuned.num_threads_explicit,
                                             tuned.parallel_observer);
            }
        } else {
            if (!inst_use || inst_use->cols() == 0) {
                throw std::runtime_error("IV requested but no instruments were provided");
            }
            const auto instrument_slice = absorption.X_tilde.rightCols(inst_use->cols());
            std::vector<int> cleaned =
                sanitize_endogenous_idx(endogenous_idx, transformed_slope_cols);
            if (cleaned.empty()) {
                throw std::runtime_error(
                    "At least one endogenous index is required for IV estimation");
            }
            std::vector<int> slope_map(static_cast<std::size_t>(transformed_slope_cols), -1);
            for (int pos = 0; pos < static_cast<int>(kept_slope_cols.size()); ++pos) {
                slope_map[static_cast<std::size_t>(kept_slope_cols[static_cast<std::size_t>(pos)])] = pos;
            }
            std::vector<int> active_endog_cols;
            active_endog_cols.reserve(cleaned.size());
            for (const int idx : cleaned) {
                if (idx < 0 || idx >= transformed_slope_cols) {
                    throw std::runtime_error("Endogenous index out of bounds");
                }
                const int mapped = slope_map[static_cast<std::size_t>(idx)];
                if (mapped >= 0) {
                    active_endog_cols.push_back(mapped);
                }
            }
            if (active_endog_cols.empty()) {
                throw std::runtime_error(
                    "All endogenous regressors are collinear after partialling-out");
            }
            Eigen::MatrixXd X_endog = select_columns(transformed_X_used, active_endog_cols);
            const int exogenous_cols = static_cast<int>(transformed_X_used.cols()) -
                                       static_cast<int>(active_endog_cols.size());
            Eigen::MatrixXd instrument_matrix(instrument_slice.rows(),
                                              exogenous_cols + instrument_slice.cols());
            std::vector<bool> is_endogenous(static_cast<std::size_t>(transformed_X_used.cols()), false);
            for (const int index : active_endog_cols) {
                is_endogenous[static_cast<std::size_t>(index)] = true;
            }
            int cursor = 0;
            for (int column = 0; column < transformed_X_used.cols(); ++column) {
                if (!is_endogenous[static_cast<std::size_t>(column)]) {
                    instrument_matrix.col(cursor++) = transformed_X_used.col(column);
                }
            }
            if (instrument_slice.cols() > 0) {
                instrument_matrix.block(0, cursor, instrument_slice.rows(),
                                        instrument_slice.cols()) = instrument_slice;
            }
            if (instrument_matrix.cols() == 0) {
                throw std::runtime_error(
                    "Instrument matrix is empty after combining exogenous regressors and user-supplied instruments");
            }
            Eigen::MatrixXd projected_low;
            Eigen::MatrixXd projected =
                detail::project_endogenous(instrument_matrix, X_endog,
                                           exogenous_cols, w_ptr, tuned.parallel_observer, &projected_low);
            iv_score_X_storage = transformed_X_used;
            Eigen::MatrixXd& second_stage = iv_score_X_storage;
            if (projected_low.size()) {
                iv_score_low_storage = Eigen::MatrixXd::Zero(second_stage.rows(), second_stage.cols());
            }
            for (int idx = 0; idx < static_cast<int>(active_endog_cols.size()); ++idx) {
                second_stage.col(active_endog_cols[static_cast<std::size_t>(idx)]) = projected.col(idx);
                if (projected_low.size()) {
                    iv_score_low_storage.col(active_endog_cols[static_cast<std::size_t>(idx)]) = projected_low.col(idx);
                }
            }
            // 2SLS inference must use residuals from the ACTUAL regressors
            // (u = y - X b), not the projected second-stage design; the solve
            // itself stays on the instrumented design.
            const Eigen::Ref<const Eigen::MatrixXd>& iv_actual_X = transformed_X_used;
            const Eigen::MatrixXd* score_low = iv_score_low_storage.size() ? &iv_score_low_storage : nullptr;
            Eigen::VectorXd normalization_means;
            if(score_low && drop_intercept && options_.fit_intercept) {
                normalization_means.resize(static_cast<int>(kept_slope_cols.size()));
                for(int pos=0;pos<normalization_means.size();++pos)
                    normalization_means[pos]=fixed_chunk_weighted_mean(
                        X_use.col(kept_slope_cols[static_cast<std::size_t>(pos)]),w_ptr);
            }
            const Eigen::VectorXd* means_ptr=normalization_means.size() ? &normalization_means : nullptr;
            Eigen::VectorXd* intercept_ptr=means_ptr ? &iv_intercept_covariance : nullptr;
            if (tuned.se_type == StandardErrorType::Cluster) {
                if (!c_ptr || c_ptr->empty()) {
                    throw std::runtime_error(
                        "Cluster-robust errors requested but no cluster variables were provided");
                }
                if (c_ptr->size() == 1) {
                    ols_result = detail::run_ols_with_score_low(absorption.y_tilde, second_stage, w_ptr, &(*c_ptr)[0],
                                                 tuned.se_type, total_tss, within_tss, nobs_effective,
                                                 false, &iv_actual_X,
                                                 tuned.num_threads_explicit,
                                                 tuned.parallel_observer, score_low, means_ptr, intercept_ptr,
                                                 tuned.dkraay_bandwidth >= 0 ? &iv_dkraay_influences : nullptr);
                } else {
                    ols_result = detail::run_ols_multiway_with_score_low(absorption.y_tilde, second_stage, w_ptr, c_ptr,
                                                         tuned.se_type, total_tss, within_tss,
                                                         tuned.ssc_g_df, tuned.ssc_g_adj, nobs_effective,
                                                         &iv_actual_X, tuned.num_threads_explicit,
                                                         tuned.parallel_observer, score_low, means_ptr, intercept_ptr,
                                                         intercept_ptr ? &iv_covariance_wide : nullptr, passes);
                    log_cluster_passes_ols(passes);
                }
            } else {
                ols_result = detail::run_ols_with_score_low(absorption.y_tilde, second_stage, w_ptr, nullptr, tuned.se_type,
                                             total_tss, within_tss, nobs_effective,
                                             tuned.weights_are_frequencies, &iv_actual_X,
                                             tuned.num_threads_explicit,
                                             tuned.parallel_observer, score_low, means_ptr, intercept_ptr);
            }
        }
        bool covariance_uses_network_scores = network_scores_for_pass && network_scores_for_pass->consumed;
        if (network_scores_for_pass) network_scores_for_pass->geometry.reset();
        cpu_profile_log_elapsed("ols", ols_t0);

        const Eigen::Ref<const Eigen::MatrixXd> score_X_tilde_used =
            wants_iv ? Eigen::Ref<const Eigen::MatrixXd>(iv_score_X_storage)
                     : Eigen::Ref<const Eigen::MatrixXd>(transformed_X_used);

        const auto post_t0 = std::chrono::steady_clock::now();
        auto post_phase_t0 = std::chrono::steady_clock::now();
        apply_common_postprocessing(y_use, X_use, w_ptr, absorption.fe_levels, ols_result);
        // Explicit intercept, or one spanned by absorbed levels (also under
        // noconstant); false only for noconstant fits without absorbed levels.
        results_.model_has_constant = model_has_intercept;
        cpu_profile_log_elapsed("post_common", post_phase_t0);
        results_.nobs_effective = nobs_effective;
        results_.nobs_full_effective = nobs_full_effective;
        results_.num_singletons_effective =
            options_.weights_are_frequencies && weights
                ? static_cast<double>(singletons_dropped_rows)
                : std::max(0.0, nobs_full_effective - nobs_effective);
        results_.vcv_psd_fixed = false;
        results_.num_iterations = absorption.iterations;
        results_.converged = absorption.converged;
        results_.abs_residual = absorption.abs_residual;
        results_.abs_residual_rel = absorption.abs_residual_rel;
        results_.krylov_internal_tolerance =
            absorption.krylov_internal_tolerance;
        results_.krylov_max_final_backward_error =
            absorption.krylov_max_final_backward_error;
        results_.krylov_max_condition = absorption.krylov_max_condition;
        results_.krylov_max_condition_times_backward_error =
            absorption.krylov_max_condition_times_backward_error;
        results_.auto_routing_retry_policy_enabled =
            absorption.auto_routing_retry_policy_enabled;
        results_.auto_routing_retry_eligible =
            absorption.auto_routing_retry_eligible;
        results_.auto_routing_retry_fired =
            absorption.auto_routing_retry_fired;
        results_.auto_routing_retry_status =
            absorption.auto_routing_retry_status;
        results_.auto_routing_retry_primary_method =
            absorption.auto_routing_retry_primary_method;
        results_.auto_routing_retry_primary_iterations =
            absorption.auto_routing_retry_primary_iterations;
        results_.auto_routing_retry_primary_abs_residual_rel =
            absorption.auto_routing_retry_primary_abs_residual_rel;
        results_.auto_routing_retry_iterations =
            absorption.auto_routing_retry_iterations;
        results_.auto_routing_retry_abs_residual_rel =
            absorption.auto_routing_retry_abs_residual_rel;
        results_.auto_routing_retry_elapsed_seconds =
            absorption.auto_routing_retry_elapsed_seconds;
        results_.slope_block_checked = absorption.slope_block_checked;
        results_.slope_block_residual_rel = absorption.slope_block_residual_rel;
        results_.slope_block_frobenius_rel = absorption.slope_block_frobenius_rel;
        results_.slope_block_rms_rel = absorption.slope_block_rms_rel;
        results_.slope_block_max_rel = absorption.slope_block_max_rel;
        results_.slope_block_skipped_max_rel =
            absorption.slope_block_skipped_max_rel;
        results_.slope_certificate_worst_fe =
            absorption.slope_certificate_worst_fe;
        results_.slope_certificate_worst_moment =
            absorption.slope_certificate_worst_moment;
        results_.slope_accuracy_retry_stages =
            absorption.slope_accuracy_retry_stages;
        results_.slope_accuracy_retry_iterations =
            absorption.slope_accuracy_retry_iterations;
        results_.slope_internal_tolerance = absorption.slope_internal_tolerance;
        results_.precision_certified = absorption.precision_certified;
        // Package B: a fit in scope writes its suggestion only after the final
        // acceptance (below, beside the absorption cache), so that a refused
        // fit leaves none; every other fit writes it here, as before.
        if (allow_profile_write && absorption.converged &&
            absorption.precision_certified && !strict_cuda_scope) {
            MobilityProfile profile = compute_mobility_profile(
                fes_use, nobs_full, singletons_dropped_rows, options_.drop_singletons,
                absorption.sweep_order_used);
            if (options_.absorption_method == AbsorptionMethod::Auto &&
                !options_.symmetric_sweep) {
                profile.suggest_method = method_used_;
                profile.suggest_symmetric =
                    (method_used_ == AbsorptionMethod::SymmetricGaussSeidel);
            }
            profile.suggest_use_sparse = tuned.use_sparse_solver;
            profile.suggest_use_krylov = tuned.use_krylov;
            write_mobility_profile(mobility_cfg.path, profile);
        }

        // Expand omitted regressors back to the original column layout so Python sees a stable shape.
        // Omitted slopes get coef=0 and inference entries set to NaN (Stata-style "(omitted)").
        if ((!omitted_slope_cols.empty()) &&
            results_.coefficients.size() == static_cast<int>(kept_slope_cols.size()) +
                                                 (transformed_has_intercept ? 1 : 0)) {
            const double nan = std::numeric_limits<double>::quiet_NaN();
            const int full_cols = transformed_full_cols;
            Eigen::VectorXd coef_full = Eigen::VectorXd::Zero(full_cols);
            Eigen::VectorXd se_full = Eigen::VectorXd::Constant(full_cols, nan);
            Eigen::VectorXd t_full = Eigen::VectorXd::Constant(full_cols, nan);
            Eigen::VectorXd p_full = Eigen::VectorXd::Constant(full_cols, nan);
            Eigen::MatrixXd ci_full = Eigen::MatrixXd::Constant(full_cols, 2, nan);
            Eigen::MatrixXd cov_full = Eigen::MatrixXd::Zero(full_cols, full_cols);
            Eigen::MatrixXd cov_used = results_.covariance;

            // Fill kept slopes.
            for (int pos = 0; pos < static_cast<int>(kept_slope_cols.size()); ++pos) {
                const int j = kept_slope_cols[static_cast<std::size_t>(pos)];
                coef_full(j) = results_.coefficients(pos);
                se_full(j) = results_.std_errors(pos);
                t_full(j) = results_.tvalues(pos);
                p_full(j) = results_.pvalues(pos);
                ci_full(j, 0) = results_.conf_int(pos, 0);
                ci_full(j, 1) = results_.conf_int(pos, 1);

                for (int pos2 = 0; pos2 < static_cast<int>(kept_slope_cols.size()); ++pos2) {
                    const int k = kept_slope_cols[static_cast<std::size_t>(pos2)];
                    if (cov_used.rows() > pos && cov_used.cols() > pos2) {
                        cov_full(j, k) = cov_used(pos, pos2);
                    }
                }
            }
            // Fill intercept if it was part of the transformed design.
            if (transformed_has_intercept) {
                const int intercept_full_idx = full_cols - 1;
                const int intercept_pos = static_cast<int>(kept_slope_cols.size());
                coef_full(intercept_full_idx) = results_.coefficients(intercept_pos);
                se_full(intercept_full_idx) = results_.std_errors(intercept_pos);
                t_full(intercept_full_idx) = results_.tvalues(intercept_pos);
                p_full(intercept_full_idx) = results_.pvalues(intercept_pos);
                ci_full(intercept_full_idx, 0) = results_.conf_int(intercept_pos, 0);
                ci_full(intercept_full_idx, 1) = results_.conf_int(intercept_pos, 1);

                if (cov_used.rows() > intercept_pos && cov_used.cols() > intercept_pos) {
                    cov_full(intercept_full_idx, intercept_full_idx) =
                        cov_used(intercept_pos, intercept_pos);
                }
                for (int pos = 0; pos < static_cast<int>(kept_slope_cols.size()); ++pos) {
                    const int j = kept_slope_cols[static_cast<std::size_t>(pos)];
                    if (cov_used.rows() > pos && cov_used.cols() > intercept_pos) {
                        cov_full(j, intercept_full_idx) = cov_used(pos, intercept_pos);
                    }
                    if (cov_used.rows() > intercept_pos && cov_used.cols() > pos) {
                        cov_full(intercept_full_idx, j) = cov_used(intercept_pos, pos);
                    }
                }
            }

            results_.coefficients = std::move(coef_full);
            results_.std_errors = std::move(se_full);
            results_.tvalues = std::move(t_full);
            results_.pvalues = std::move(p_full);
            results_.conf_int = std::move(ci_full);
            results_.covariance = std::move(cov_full);
        }

        if (drop_intercept) {
            post_phase_t0 = std::chrono::steady_clock::now();
            const int slope_cols = static_cast<int>(results_.coefficients.size());
            double denom = 0.0;
            const double y_mean =
                fixed_chunk_weighted_mean(y_use, w_ptr, tuned.num_threads, &denom,
                                          tuned.parallel_observer);
            Eigen::VectorXd x_means = Eigen::VectorXd::Zero(slope_cols);
            if (slope_cols > 0 && denom > 0.0) {
                for (int j = 0; j < slope_cols; ++j) {
                    x_means(j) =
                        fixed_chunk_weighted_mean(X_use.col(j), w_ptr,
                                                  tuned.num_threads, nullptr,
                                                  tuned.parallel_observer);
                }
            }
            const double intercept = y_mean - x_means.dot(results_.coefficients);
            const int out_cols = slope_cols + 1;
            results_.coefficients.conservativeResize(out_cols);
            results_.coefficients(out_cols - 1) = intercept;

            const double nan = std::numeric_limits<double>::quiet_NaN();
            results_.std_errors.conservativeResize(out_cols);
            results_.std_errors(out_cols - 1) = nan;
            results_.tvalues.conservativeResize(out_cols);
            results_.tvalues(out_cols - 1) = nan;
            results_.pvalues.conservativeResize(out_cols);
            results_.pvalues(out_cols - 1) = nan;
            Eigen::MatrixXd conf_new = Eigen::MatrixXd::Constant(out_cols, 2, nan);
            conf_new.topRows(slope_cols) = results_.conf_int;
            results_.conf_int = std::move(conf_new);

            Eigen::MatrixXd cov_new = Eigen::MatrixXd::Constant(out_cols, out_cols, nan);
            cov_new.topLeftCorner(slope_cols, slope_cols) = results_.covariance;
            results_.covariance = std::move(cov_new);
            cpu_profile_log_elapsed("post_intercept", post_phase_t0);

        }

        const char* fe_recovery_method = "map";
        bool used_mixed_savefe = false;
        const double n1_reference_intercept = options_.fit_intercept && results_.coefficients.size()
            ? results_.coefficients[results_.coefficients.size() - 1] : 0.0;
        Eigen::VectorXd n1_partial;
        detail::N1ReconstructionEvidence n1_reconstruction;
        const bool capture_fe_reconstruction = detail::n1_capture_active;
        Eigen::VectorXd recovery_beta;
        if (cached_savefe) {
            auto& publication = *cached_savefe;
            if (publication.beta.size() != results_.coefficients.size() ||
                publication.kept_columns != kept_slope_cols ||
                (publication.beta.size() > 0 &&
                 std::memcmp(publication.beta.data(), results_.coefficients.data(),
                             static_cast<std::size_t>(publication.beta.size()) * sizeof(double)) != 0) ||
                publication.ols_residual_digest != hash_savefe_ols_residuals(abs_cache_key, ols_result.residuals)) {
                throw SavefeCacheMiss{};
            }
            {
                SavefeTimer timer("savefe_cache_expand");
                if (!expand_savefe_effects(publication.effects, fes_use, results_.fe_effects))
                    throw SavefeCacheMiss{};
            }
            publication.effects.clear();
            if (options_.fit_intercept && results_.coefficients.size() > 0) {
                results_.coefficients[results_.coefficients.size() - 1] = publication.intercept;
            }
            results_.residuals = std::move(publication.residuals);
            results_.fe_recovery_converged = true;
            results_.fe_recovery_iterations = publication.recovery_iterations;
            results_.fe_recovery_max_delta = publication.recovery_max_delta;
            results_.abs_residual = publication.abs_residual;
            results_.abs_residual_rel = publication.abs_residual_rel;
            fe_recovery_method = publication.hybrid_recovery ? "hybrid_cached" : "map";
            if (capture_fe_reconstruction) {
                n1_partial = y_use;
                const int slope_cols = static_cast<int>(publication.beta.size()) -
                    (options_.fit_intercept ? 1 : 0);
                if (slope_cols > 0) {
                    n1_partial.noalias() -= X_use * publication.beta.head(slope_cols);
                }
                Eigen::VectorXd fe_total = Eigen::VectorXd::Zero(y_use.size());
                for (const auto& effect : results_.fe_effects) fe_total.noalias() += effect;
                const int ops = 2 * static_cast<int>(publication.beta.size()) +
                    static_cast<int>(results_.fe_effects.size()) + 8;
                const bool with_intercept = options_.fit_intercept;
                const bool recentered = with_intercept && !savefe_projection_published;
                const double shift = publication.intercept - n1_reference_intercept;
                for (Eigen::Index i = 0; i < y_use.size(); ++i) {
                    n1_reconstruction.add(
                        with_intercept ? n1_partial[i] - n1_reference_intercept : n1_partial[i],
                        recentered ? fe_total[i] + shift : fe_total[i], results_.residuals[i],
                        ols_result.residuals[i], w_ptr ? (*w_ptr)[i] : 1.0, ops);
                }
            }
        } else if (options_.retain_fixed_effects && has_fes) {
            if (allow_cache_write && abs_cache_key_ready && abs_cache_key.capture) {
                try {
                    recovery_beta = results_.coefficients;
                } catch (const std::bad_alloc&) {
                    allow_cache_write = false;
                }
            }
            const bool profile_savefe = savefe_profile_enabled();
            const int slope_cols =
                options_.fit_intercept ? static_cast<int>(results_.coefficients.size()) - 1
                                       : static_cast<int>(results_.coefficients.size());
            Eigen::VectorXd partial;
            {
                SavefeTimer timer("savefe_partial");
                partial = y_use;
                if (slope_cols > 0) {
                    partial.noalias() -= X_use * results_.coefficients.head(slope_cols);
                }
            }
            if (!slope_terms.empty()) {
                if (options_.fit_intercept && !drop_intercept) {
                    // A separately estimated constant is not part of the
                    // pure-slope FE projection being recovered here.
                    partial.array() -= results_.coefficients(slope_cols);
                }
                HdfeOptions fe_opts = tuned;
                if (!absorption.sweep_order_used.empty()) {
                    fe_opts.sweep_order_override = absorption.sweep_order_used;
                }
                MixedSavefeRecoveryResult recovered;
                {
                    SavefeTimer timer("savefe_recover_mixed_map");
                    recovered = recover_mixed_savefe_effects(partial, fes_use, slope_terms,
                                                             w_ptr, fe_opts);
                }
                center_mixed_savefe_effects(recovered.contributions, recovered.save_effects,
                                            recovered.save_alpha_slot_by_dim, w_ptr,
                                            options_.fit_intercept);
                results_.fe_effects = std::move(recovered.contributions);
                results_.fe_save_effects = std::move(recovered.save_effects);
                results_.fe_recovery_iterations = recovered.iterations;
                results_.fe_recovery_max_delta = recovered.max_delta;
                results_.fe_recovery_converged = recovered.converged;
                fe_recovery_method = "map_mixed";
                used_mixed_savefe = true;
                if (profile_savefe) {
                    savefe_profile_log("event=fe_recovery_mixed method=map_mixed");
                }
            } else {
            const bool have_group_ids =
                !absorption.fe_group_ids.empty() &&
                absorption.fe_group_ids.size() == fes_use.size();
            bool used_cached = false;
            bool have_cached = false;
            int partial_fe_scale_exponent = 0;
            Eigen::VectorXd cached_residual;
            const bool can_try_hybrid =
                options_.fe_recovery_method == FeRecoveryMethod::Hybrid &&
                have_group_ids &&
                absorption.fe_alpha_y.size() == fes_use.size() &&
                absorption.fe_alpha_X.size() == fes_use.size();
            if (profile_savefe && !can_try_hybrid) {
                if (options_.fe_recovery_method != FeRecoveryMethod::Hybrid) {
                    savefe_profile_log("event=hybrid_skip reason=method");
                }
                if (!have_group_ids) {
                    savefe_profile_log("event=hybrid_skip reason=missing_group_ids");
                }
                if (slope_cols > options_.savefe_fastpath_max_cols) {
                    std::ostringstream oss;
                    oss << "event=hybrid_skip reason=cols_gt_max cols=" << slope_cols
                        << " max=" << options_.savefe_fastpath_max_cols;
                    savefe_profile_log(oss.str());
                }
                if (absorption.fe_alpha_y.size() != fes_use.size() ||
                    absorption.fe_alpha_X.size() != fes_use.size()) {
                    savefe_profile_log("event=hybrid_skip reason=missing_alpha_buffers");
                }
            }
            if (can_try_hybrid) {
                const std::size_t dims = fes_use.size();
                const int nobs = static_cast<int>(partial.size());
                bool sizes_ok = true;
                for (std::size_t dim = 0; dim < dims; ++dim) {
                    if (static_cast<int>(absorption.fe_group_ids[dim].size()) != nobs) {
                        sizes_ok = false;
                        break;
                    }
                    const auto& ay = absorption.fe_alpha_y[dim];
                    const auto& aX = absorption.fe_alpha_X[dim];
                    if (aX.rows() != ay.size() || aX.cols() != slope_cols) {
                        sizes_ok = false;
                        break;
                    }
                }
                if (sizes_ok) {
                    {
                        SavefeTimer timer("savefe_hybrid_map");
                        results_.fe_effects.resize(dims);
                        const Eigen::VectorXd beta =
                            slope_cols > 0 ? results_.coefficients.head(slope_cols)
                                           : Eigen::VectorXd();
                        for (std::size_t dim = 0; dim < dims; ++dim) {
                            const auto& gid = absorption.fe_group_ids[dim];
                            const auto& ay = absorption.fe_alpha_y[dim];
                            const auto& aX = absorption.fe_alpha_X[dim];
                            Eigen::VectorXd alpha_d = ay;
                            if (slope_cols > 0) {
                                alpha_d.noalias() -= aX * beta;
                            }
                            Eigen::VectorXd fe_vec(nobs);
                            for (int i = 0; i < nobs; ++i) {
                                fe_vec[i] = alpha_d[gid[static_cast<std::size_t>(i)]];
                            }
                            results_.fe_effects[dim] = std::move(fe_vec);
                        }
                    }
                    partial_fe_scale_exponent = detail::fe_recovery_scale_exponent(partial);
                    const double fe_tol =
                        std::ldexp(options_.fe_tolerance > 0.0 ? options_.fe_tolerance : options_.tol,
                                   partial_fe_scale_exponent);
                    Eigen::VectorXd residual = partial;
                    for (const auto& fe_vec : results_.fe_effects) {
                        residual.noalias() -= fe_vec;
                    }
                    cached_residual = residual;
                    have_cached = true;
                    double max_delta = 0.0;
                    HdfeOptions fe_check_opts = tuned;
                    if (!absorption.sweep_order_used.empty()) {
                        fe_check_opts.sweep_order_override = absorption.sweep_order_used;
                    }
                    {
                        SavefeTimer timer("savefe_hybrid_check");
                        if (fe_tol > 0.0) {
                            bool checked = false;
                            if (absorption.gpu_used &&
                                absorption.fe_weight_sums.size() == dims &&
                                absorption.fe_group_ids.size() == dims) {
                                std::vector<detail::GpuFeInput> fe_inputs;
                                fe_inputs.reserve(dims);
                                bool inputs_ok = true;
                                for (std::size_t dim = 0; dim < dims; ++dim) {
                                    const auto& gid = absorption.fe_group_ids[dim];
                                    const auto& ws = absorption.fe_weight_sums[dim];
                                    if (static_cast<int>(gid.size()) != nobs || ws.size() == 0) {
                                        inputs_ok = false;
                                        break;
                                    }
                                    detail::GpuFeInput input;
                                    input.group_ids = gid.data();
                                    input.num_groups = static_cast<int>(ws.size());
                                    input.num_levels_present =
                                        dim < absorption.fe_levels.size()
                                            ? absorption.fe_levels[dim]
                                            : input.num_groups;
                                    input.weight_sums = ws.data();
                                    fe_inputs.push_back(input);
                                }
                                if (inputs_ok) {
                                    std::vector<std::size_t> check_order;
                                    check_order.reserve(fe_check_opts.sweep_order_override.size());
                                    for (const int dim : fe_check_opts.sweep_order_override) {
                                        if (dim < 0) {
                                            inputs_ok = false;
                                            break;
                                        }
                                        check_order.push_back(static_cast<std::size_t>(dim));
                                    }
                                    if (inputs_ok) {
                                        checked = detail::fe_recovery_max_delta_cuda_cached(
                                            residual, fe_inputs, w_ptr, check_order, max_delta);
                                        if (!checked) {
                                            checked = detail::fe_recovery_max_delta_cuda(
                                                residual, fe_inputs, w_ptr, check_order,
                                                max_delta);
                                        }
                                    }
                                }
                            }
                            if (!checked) {
                                Eigen::VectorXd residual_check = residual;
                                max_delta =
                                    detail::fe_recovery_max_delta(
                                        residual_check,
                                        absorption.fe_group_ids,
                                        absorption.fe_levels,
                                        w_ptr,
                                        fe_check_opts,
                                        absorption.fe_weight_sums.empty()
                                            ? nullptr
                                            : &absorption.fe_weight_sums);
                            }
                        }
                    }
                    if (fe_tol <= 0.0 || max_delta <= fe_tol) {
                        results_.fe_recovery_iterations = 0;
                        results_.fe_recovery_max_delta = max_delta;
                        results_.fe_recovery_converged = true;
                        fe_recovery_method = "hybrid_cached";
                        used_cached = true;
                        if (profile_savefe) {
                            std::ostringstream oss;
                            oss << "event=hybrid_cached max_delta=" << max_delta
                                << " fe_tol=" << fe_tol;
                            savefe_profile_log(oss.str());
                        }
                    } else if (profile_savefe) {
                        std::ostringstream oss;
                        oss << "event=hybrid_skip reason=max_delta max_delta=" << max_delta
                            << " fe_tol=" << fe_tol;
                        savefe_profile_log(oss.str());
                    }
                } else if (profile_savefe) {
                    savefe_profile_log("event=hybrid_skip reason=size_mismatch");
                }
            }
            if (!used_cached) {
                HdfeOptions fe_opts = tuned;
                if (!absorption.sweep_order_used.empty()) {
                    fe_opts.sweep_order_override = absorption.sweep_order_used;
                }
                const Eigen::VectorXd& fe_partial = have_cached ? cached_residual : partial;
                const double solver_fe_tolerance =
                    fe_opts.fe_tolerance > 0.0 ? fe_opts.fe_tolerance : fe_opts.tol;
                if (have_cached) {
                    // Reuse the original problem's coordinates. The physical
                    // max-update target remains solver_fe_tolerance * 2^scale.
                    fe_opts.fe_tolerance = solver_fe_tolerance;
                }
                detail::FeRecoveryResult recovered;
                {
                    SavefeTimer timer("savefe_recover_map");
                    recovered = have_group_ids
                        ? detail::recover_fixed_effects_group_ids(
                              fe_partial, absorption.fe_group_ids, absorption.fe_levels, w_ptr,
                              fe_opts,
                              absorption.fe_weight_sums.empty()
                                  ? nullptr
                                  : &absorption.fe_weight_sums,
                              solver_fe_tolerance,
                              have_cached ? partial_fe_scale_exponent
                                          : std::numeric_limits<int>::max())
                        : detail::recover_fixed_effects(fe_partial, fes_use, w_ptr, fe_opts,
                                                        solver_fe_tolerance);
                }
                if (have_cached &&
                    recovered.contributions.size() == results_.fe_effects.size()) {
                    for (std::size_t dim = 0; dim < results_.fe_effects.size(); ++dim) {
                        results_.fe_effects[dim].noalias() += recovered.contributions[dim];
                    }
                } else {
                    results_.fe_effects = recovered.contributions;
                }
                results_.fe_recovery_iterations = recovered.iterations;
                results_.fe_recovery_max_delta = recovered.max_delta;
                results_.fe_recovery_converged = recovered.converged;
                fe_recovery_method = "map";
                if (profile_savefe) {
                    savefe_profile_log("event=fe_recovery_fallback method=map");
                }
            }
            }
            if (capture_fe_reconstruction) n1_partial = std::move(partial);
        }

        if (options_.retain_fixed_effects && !results_.fe_recovery_converged) {
            std::ostringstream message;
            message << "Fixed-effect recovery did not converge; iterations="
                    << results_.fe_recovery_iterations << "/" << options_.max_iter
                    << "; final max change=" << std::scientific << results_.fe_recovery_max_delta
                    << "; requested FE tolerance=" << options_.fe_tolerance
                    << ". No estimates or fixed effects returned. Check scaling and the iteration limit.";
            throw std::runtime_error(message.str());
        }
        if (!cached_savefe && !used_mixed_savefe && !results_.fe_effects.empty()) {
            const std::size_t dims = results_.fe_effects.size();
            const FeNormalizeStyle normalize_style =
                resolve_fe_normalize_style(options_.stats_style);
            if (dims == 1) {
                if (options_.fit_intercept) {
                    const double mean = weighted_mean(results_.fe_effects[0], w_ptr);
                    results_.fe_effects[0].array() -= mean;
                }
            } else if (dims >= 2) {
                if (normalize_style == FeNormalizeStyle::Reghdfe) {
                    for (std::size_t d = options_.fit_intercept ? 0 : 1; d < dims; ++d) {
                        const double mean = weighted_mean(results_.fe_effects[d], w_ptr);
                        results_.fe_effects[d].array() -= mean;
                        if (!options_.fit_intercept) results_.fe_effects[0].array() += mean;
                    }
                } else {
                    // Component normalization: center FE2 within each mobility component.
                    const Eigen::VectorXi& fe0 = fes_use[0];
                    const Eigen::VectorXi& fe1 = fes_use[1];
                    const int expected0 =
                        !absorption.fe_levels.empty() ? absorption.fe_levels[0] : -1;
                    const int expected1 =
                        absorption.fe_levels.size() > 1 ? absorption.fe_levels[1] : -1;
                    const FeLookup lookup0 = build_lookup_compact(fe0, expected0);
                    const FeLookup lookup1 = build_lookup_compact(fe1, expected1);
                    Eigen::VectorXi components;
                    const int num_components =
                        count_bipartite_components(fe0, fe1, lookup0, lookup1, &components);
                    if (num_components > 0) {
                        std::vector<double> comp_sum(static_cast<std::size_t>(num_components), 0.0);
                        std::vector<double> comp_w(static_cast<std::size_t>(num_components), 0.0);
                        const double* fe1_ptr = results_.fe_effects[1].data();
                        if (w_ptr) {
                            const double* w = w_ptr->data();
                            for (int i = 0; i < components.size(); ++i) {
                                const int c = components(i) - 1;
                                comp_sum[static_cast<std::size_t>(c)] += fe1_ptr[i] * w[i];
                                comp_w[static_cast<std::size_t>(c)] += w[i];
                            }
                        } else {
                            for (int i = 0; i < components.size(); ++i) {
                                const int c = components(i) - 1;
                                comp_sum[static_cast<std::size_t>(c)] += fe1_ptr[i];
                                comp_w[static_cast<std::size_t>(c)] += 1.0;
                            }
                        }
                        for (int i = 0; i < components.size(); ++i) {
                            const int c = components(i) - 1;
                            const double denom = comp_w[static_cast<std::size_t>(c)];
                            const double shift =
                                denom > 0.0 ? comp_sum[static_cast<std::size_t>(c)] / denom : 0.0;
                            results_.fe_effects[1](i) -= shift;
                            results_.fe_effects[0](i) += shift;
                        }
                    }
                    if (options_.fit_intercept) {
                        const double mean0 = weighted_mean(results_.fe_effects[0], w_ptr);
                        results_.fe_effects[0].array() -= mean0;
                    }
                    for (std::size_t d = 2; d < dims; ++d) {
                        const double mean = weighted_mean(results_.fe_effects[d], w_ptr);
                        results_.fe_effects[d].array() -= mean;
                        if (!options_.fit_intercept) results_.fe_effects[0].array() += mean;
                    }
                }
            }
        }

        if (!cached_savefe && savefe_projection_published && !results_.fe_effects.empty()) {
            // E1: the residuals and the constant stay those of the published
            // projection, that is of the same fit without saved effects; the
            // identity y = Xb + constant + effects + residual then holds to the
            // accuracy of the recovered effects, which the audit evidence checks.
            if (capture_fe_reconstruction) {
                Eigen::VectorXd fe_total = Eigen::VectorXd::Zero(static_cast<int>(y_use.size()));
                for (const auto& fe_vec : results_.fe_effects) {
                    fe_total.noalias() += fe_vec;
                }
                const double gauge = options_.fit_intercept ? n1_reference_intercept : 0.0;
                for (int i = 0; i < y_use.size(); ++i) {
                    n1_reconstruction.add(n1_partial[i] - gauge, fe_total[i], results_.residuals[i],
                        ols_result.residuals[i], w_ptr ? (*w_ptr)[i] : 1.0,
                        2 * static_cast<int>(results_.coefficients.size()) +
                        static_cast<int>(results_.fe_effects.size()) + 8);
                }
            }
        } else if (!cached_savefe && !results_.fe_effects.empty()) {
            Eigen::VectorXd fe_total = Eigen::VectorXd::Zero(static_cast<int>(y_use.size()));
            for (const auto& fe_vec : results_.fe_effects) {
                fe_total.noalias() += fe_vec;
            }
            if (options_.fit_intercept) {
                const int intercept_idx =
                    static_cast<int>(results_.coefficients.size()) - 1;
                const int slope_cols = intercept_idx;
                Eigen::VectorXd linear_predictor =
                    Eigen::VectorXd::Zero(static_cast<int>(y_use.size()));
                if (slope_cols > 0) {
                    linear_predictor.noalias() = X_use * results_.coefficients.head(slope_cols);
                }
                linear_predictor.noalias() += fe_total;
                const double intercept = weighted_mean(y_use - linear_predictor, w_ptr);
                results_.coefficients(intercept_idx) = intercept;
                results_.residuals.resize(y_use.size());
                for (int i = 0; i < y_use.size(); ++i) {
                    results_.residuals[i] = y_use[i] - (linear_predictor[i] + intercept);
                    if (capture_fe_reconstruction) {
                        const double canonical_partial = n1_partial[i] -
                            (used_mixed_savefe && !drop_intercept ? 0.0 : n1_reference_intercept);
                        const double canonical_fe = fe_total[i] + (intercept - n1_reference_intercept);
                        n1_reconstruction.add(canonical_partial, canonical_fe, results_.residuals[i],
                            ols_result.residuals[i], w_ptr ? (*w_ptr)[i] : 1.0,
                            2 * static_cast<int>(results_.coefficients.size()) +
                            static_cast<int>(results_.fe_effects.size()) + 8);
                    }
                }
            } else {
                Eigen::VectorXd fitted_full = X_use * results_.coefficients;
                fitted_full.noalias() += fe_total;
                results_.residuals.resize(y_use.size());
                for (int i = 0; i < y_use.size(); ++i) {
                    results_.residuals[i] = y_use[i] - fitted_full[i];
                    if (capture_fe_reconstruction) {
                        n1_reconstruction.add(n1_partial[i], fe_total[i], results_.residuals[i],
                            ols_result.residuals[i], w_ptr ? (*w_ptr)[i] : 1.0,
                            2 * static_cast<int>(results_.coefficients.size()) +
                            static_cast<int>(results_.fe_effects.size()) + 8);
                    }
                }
            }
        }

        if (options_.retain_fixed_effects && !results_.fe_effects.empty()) {
            maybe_write_fe_diagnostics(y_use, X_use, results_.coefficients, results_.fe_effects,
                                       options_.fit_intercept, w_ptr, results_.residuals,
                                       absorption.iterations, results_.fe_recovery_iterations,
                                       results_.fe_recovery_converged,
                                       results_.fe_recovery_max_delta, fe_recovery_method);
        }

        // P7 (2.31.0): a Stata residuals() request keeps the fit's own residuals
        // (HdfeOptions::stored_residuals_fit_state); refine_stored_residuals keeps
        // its meaning for every other caller and for the opt-in prototypes above.
        // CUDA Strict checks the published fit residual. Preserve the earlier
        // re-absorption on CPU when the caller requests stored residuals.
        const bool stored_residuals_fit_state =
            options_.stored_residuals_fit_state &&
            (options_.tolerance_mode != ToleranceMode::StrictResidual || absorption.gpu_used);
        const bool needs_refined_residuals =
            options_.refine_stored_residuals && !stored_residuals_fit_state &&
            has_fes && !options_.retain_fixed_effects &&
            results_.residuals.size() == y_use.size();
        // Trace only (diagnostic build cand_p3_trace_20261110, P7): with
        // XHDFE_P7_REFINE_TRACE=1 every fit prints whether the stored residuals
        // are refined and, when they are, the refinement's options, route and
        // cost, and aggregates of the fit's own (internal) residuals against the
        // refined (stored) ones of the same fit: norms, their relative distance
        // and the largest |weighted group mean| over the absorbed FEs. With
        // XHDFE_P7_REFINE_DUMP_DIR=<dir> as well, both vectors are written there
        // as raw float64 files, for public fixtures only (never on confidential
        // data). Off (the default), nothing is copied, timed or printed.
        static const bool p7_refine_trace = [] {
            const char* e = std::getenv("XHDFE_P7_REFINE_TRACE");
            return e != nullptr && std::strcmp(e, "1") == 0;
        }();
        static std::atomic<int> p7_refine_sequence{0};
        const int p7_seq = p7_refine_trace ? ++p7_refine_sequence : 0;
        if (p7_refine_trace && !needs_refined_residuals) {
            std::fprintf(stderr,
                         "p7_refine_trace seq=%d refined=0 refine_flag=%d fit_state=%d "
                         "has_fes=%d retain_fes=%d residuals=%lld rows=%lld\n",
                         p7_seq, options_.refine_stored_residuals ? 1 : 0,
                         stored_residuals_fit_state ? 1 : 0, has_fes ? 1 : 0,
                         options_.retain_fixed_effects ? 1 : 0,
                         static_cast<long long>(results_.residuals.size()),
                         static_cast<long long>(y_use.size()));
        }
        if (needs_refined_residuals) {
            const int coef_size = static_cast<int>(results_.coefficients.size());
            const int expected_slope_cols =
                options_.fit_intercept ? std::max(0, coef_size - 1) : coef_size;
            if (expected_slope_cols == static_cast<int>(X_use.cols())) {
                Eigen::VectorXd partial = y_use;
                if (expected_slope_cols > 0) {
                    partial.noalias() -= X_use * results_.coefficients.head(expected_slope_cols);
                }
                if (options_.fit_intercept && coef_size > expected_slope_cols) {
                    partial.array() -= results_.coefficients(coef_size - 1);
                }

                HdfeOptions resid_opts = tuned;
                resid_opts.retain_fixed_effects = false;
                if (!absorption.sweep_order_used.empty()) {
                    resid_opts.sweep_order_override = absorption.sweep_order_used;
                }

                Eigen::MatrixXd empty_design(static_cast<int>(y_use.size()), 0);
                Eigen::VectorXd p7_internal;
                if (p7_refine_trace) {
                    p7_internal = results_.residuals;
                    std::fprintf(stderr, "p7_refine_begin seq=%d\n", p7_seq);
                }
                const auto p7_start = p7_refine_trace ? std::chrono::steady_clock::now()
                                                      : std::chrono::steady_clock::time_point{};
                detail::AbsorptionResult resid_absorption =
                    detail::absorb_fixed_effects_v6(partial,
                                                    empty_design,
                                                    fes_use,
                                                    w_ptr,
                                                    resid_opts,
                                                    method_used_,
                                                    slope_terms);
                const double p7_seconds =
                    p7_refine_trace ? std::chrono::duration<double>(
                                          std::chrono::steady_clock::now() - p7_start).count()
                                    : 0.0;
                const bool p7_applied = p7_refine_trace && resid_absorption.converged &&
                                        resid_absorption.y_tilde.size() == partial.size();
                if (resid_absorption.converged &&
                    resid_absorption.y_tilde.size() == partial.size()) {
                    results_.residuals = std::move(resid_absorption.y_tilde);
                }
                if (p7_refine_trace) {
                    // The refined candidate: the stored vector when it was applied,
                    // otherwise the refinement's own output (not stored).
                    const Eigen::VectorXd& refined =
                        p7_applied ? results_.residuals : resid_absorption.y_tilde;
                    auto max_group_mean = [&](const Eigen::VectorXd& v) {
                        double worst = 0.0;
                        for (const auto& fe : fes_use) {
                            if (fe.size() != v.size()) continue;
                            Eigen::Index levels = 0;
                            for (Eigen::Index i = 0; i < fe.size(); ++i) {
                                levels = std::max<Eigen::Index>(levels, fe[i] + 1);
                            }
                            std::vector<long double> sum(static_cast<std::size_t>(levels), 0.0L);
                            std::vector<long double> wsum(static_cast<std::size_t>(levels), 0.0L);
                            for (Eigen::Index i = 0; i < fe.size(); ++i) {
                                if (fe[i] < 0) continue;
                                const long double wi = w_ptr ? (*w_ptr)[i] : 1.0;
                                sum[static_cast<std::size_t>(fe[i])] += wi * v[i];
                                wsum[static_cast<std::size_t>(fe[i])] += wi;
                            }
                            for (std::size_t g = 0; g < sum.size(); ++g) {
                                if (wsum[g] > 0.0L) {
                                    worst = std::max(worst, std::fabs(static_cast<double>(
                                                                sum[g] / wsum[g])));
                                }
                            }
                        }
                        return worst;
                    };
                    const bool same_size = refined.size() == p7_internal.size();
                    const double norm_internal = p7_internal.norm();
                    const double norm_refined = refined.norm();
                    const double refined_vs_internal_rel =
                        same_size && norm_internal > 0.0
                            ? (refined - p7_internal).norm() / norm_internal
                            : std::numeric_limits<double>::quiet_NaN();
                    std::fprintf(stderr,
                                 "p7_refine_trace seq=%d refined=1 applied=%d method=%d mode=%d "
                                 "criterion=%d tol=%.6e max_iter=%d threads=%d iterations=%d "
                                 "converged=%d certified=%d abs_residual_rel=%.6e "
                                 "gpu_attempted=%d gpu_used=%d gpu_status=%d cuda_tail=%s "
                                 "seconds=%.6f rows=%lld weights=%d slopes=%d "
                                 "norm_internal=%.17g norm_refined=%.17g "
                                 "refined_vs_internal_rel=%.6e D_internal=%.6e D_refined=%.6e\n",
                                 p7_seq, p7_applied ? 1 : 0, static_cast<int>(method_used_),
                                 static_cast<int>(resid_opts.tolerance_mode),
                                 static_cast<int>(resid_opts.convergence_criterion),
                                 resid_opts.tol, resid_opts.max_iter, resid_opts.num_threads,
                                 resid_absorption.iterations, resid_absorption.converged ? 1 : 0,
                                 resid_absorption.precision_certified ? 1 : 0,
                                 resid_absorption.abs_residual_rel,
                                 resid_absorption.gpu_attempted ? 1 : 0,
                                 resid_absorption.gpu_used ? 1 : 0,
                                 resid_absorption.gpu_status_code,
                                 detail::cuda_tail_name(resid_absorption.cuda_tail), p7_seconds,
                                 static_cast<long long>(partial.size()), w_ptr ? 1 : 0,
                                 slope_terms.empty() ? 0 : 1, norm_internal, norm_refined,
                                 refined_vs_internal_rel, max_group_mean(p7_internal),
                                 same_size ? max_group_mean(refined)
                                           : std::numeric_limits<double>::quiet_NaN());
                    const char* dump_dir = std::getenv("XHDFE_P7_REFINE_DUMP_DIR");
                    if (dump_dir != nullptr && *dump_dir != '\0') {
                        const long long stamp = static_cast<long long>(
                            std::chrono::system_clock::now().time_since_epoch().count());
                        auto dump = [&](const Eigen::VectorXd& v, const char* tag) {
                            const std::string path = std::string(dump_dir) + "/p7_" + tag + "_" +
                                                     std::to_string(stamp) + "_" +
                                                     std::to_string(p7_seq) + ".f64";
                            std::FILE* f = std::fopen(path.c_str(), "wb");
                            if (f == nullptr) {
                                std::fprintf(stderr, "p7_refine_dump seq=%d tag=%s error=open path=%s\n",
                                             p7_seq, tag, path.c_str());
                                return;
                            }
                            const std::size_t written = std::fwrite(
                                v.data(), sizeof(double), static_cast<std::size_t>(v.size()), f);
                            std::fclose(f);
                            std::fprintf(stderr, "p7_refine_dump seq=%d tag=%s doubles=%zu path=%s\n",
                                         p7_seq, tag, written, path.c_str());
                        };
                        dump(p7_internal, "internal");
                        dump(refined, "refined");
                    }
                }
            } else if (p7_refine_trace) {
                std::fprintf(stderr,
                             "p7_refine_trace seq=%d refined=0 reason=slope-columns "
                             "expected_slope_cols=%d design_cols=%d\n",
                             p7_seq, expected_slope_cols, static_cast<int>(X_use.cols()));
            }
        }

        const int omit_cols = static_cast<int>(results_.coefficients.size());
        results_.omitted_reason.assign(static_cast<std::size_t>(omit_cols), 0);
        results_.fe_collinear_ss_ratio =
            options_.capture_fe_collinear_ss_ratio
                ? fe_collinear_ss_ratio
                : Eigen::VectorXd();
        for (const int idx : omitted_fe_slope_cols) {
            if (idx >= 0 && idx < omit_cols) {
                results_.omitted_reason[static_cast<std::size_t>(idx)] = 1;
            }
        }
        for (const int idx : omitted_rank_slope_cols) {
            if (idx >= 0 && idx < omit_cols &&
                results_.omitted_reason[static_cast<std::size_t>(idx)] == 0) {
                results_.omitted_reason[static_cast<std::size_t>(idx)] = 2;
            }
        }

        // Degrees-of-freedom adjustments to match reghdfe / fixest SSC.
        const double nobs = results_.nobs_effective;
        const int df_m = df_m_effective;  // excludes constant
        results_.df_m = static_cast<double>(df_m);
        const int df_intercept = (options_.fit_intercept && !drop_intercept) ? 1 : 0;
        const bool use_reghdfe_stats = (options_.stats_style == StatsStyle::Reghdfe);
        // Reghdfe books the ordinary constant as one absorbed degree of freedom
        // only when there are no explicit fixed effects. Pure-slope FEs need not
        // span a constant, so their explicitly estimated intercept still costs
        // one model degree of freedom.
        const int df_intercept_dof =
            (use_reghdfe_stats && !has_fes) ? 0 : df_intercept;

        // E3: the sums of levels and coefficients in 64 bits, to their doubles below.
        std::int64_t df_a_levels = (use_reghdfe_stats && !has_fes) ? df_intercept : 0;
        std::int64_t df_a_exact = df_a_levels;
        std::int64_t nested_dof_levels = 0;  // round 11 (E3): 64 bits, to their doubles
        std::int64_t nested_dof_coefs = 0;
        if (has_fes) {
            post_phase_t0 = std::chrono::steady_clock::now();
            Eigen::VectorXi groupvar;
            Eigen::VectorXi* groupvar_ptr = options_.save_groupvar ? &groupvar : nullptr;
            FeComponentStats* first_pair_stats_ptr =
                options_.capture_first_pair_component_stats
                    ? &first_pair_component_stats_
                    : nullptr;
            const DofAdjustmentMethod mobility_method =
                options_.dof_mobility_groups
                    ? options_.dof_method
                    : DofAdjustmentMethod::None;
            const std::size_t dof_dims = fes_use.size();
            std::vector<uint8_t> nested_flags(dof_dims, 0);
            std::vector<uint8_t> slope_only_flags(dof_dims, 0);
            for (const auto& slope : slope_terms) {
                if (!slope.include_intercept &&
                    slope.fe_index >= 0 &&
                    slope.fe_index < static_cast<int>(dof_dims)) {
                    slope_only_flags[static_cast<std::size_t>(slope.fe_index)] = 1;
                }
            }
            if (options_.dof_adjust_clusters && tuned.se_type == StandardErrorType::Cluster && c_ptr &&
                !c_ptr->empty()) {
                for (const auto& cl : *c_ptr) {
                    for (std::size_t d = 0; d < dof_dims; ++d) {
                        if (nested_flags[d]) {
                            continue;
                        }
                        if (fe_nested_within_cluster(fes_use[d], cl, tuned.num_threads,
                                                     tuned.parallel_observer)) {
                            nested_flags[d] = 1;
                        }
                    }
                }
            }
            bool any_nested = false;
            if (options_.dof_method != DofAdjustmentMethod::None) {
                for (std::size_t d = 0; d < nested_flags.size(); ++d) {
                    if (nested_flags[d]) {
                        any_nested = true;
                        break;
                    }
                }
            }
            cpu_profile_log_elapsed("post_dof_nested", post_phase_t0);

            FeDofInfo dof;
            const bool can_skip_full_dof =
                any_nested && groupvar_ptr == nullptr &&
                first_pair_stats_ptr == nullptr &&
                absorption.fe_levels.size() == dof_dims &&
                options_.dof_method != DofAdjustmentMethod::None;
            if (can_skip_full_dof) {
                dof.levels = absorption.fe_levels;
                dof.redundant.assign(dof_dims, 0);
                dof.num_coefs.assign(dof_dims, 0);
                dof.inexact.assign(dof_dims, 0);

                std::vector<Eigen::VectorXi> fes_nonnested;
                std::vector<int> levels_nonnested;
                std::vector<int> map_nonnested;
                std::vector<uint8_t> slopes_nonnested;
                fes_nonnested.reserve(dof_dims);
                levels_nonnested.reserve(dof_dims);
                map_nonnested.reserve(dof_dims);
                slopes_nonnested.reserve(dof_dims);
                for (std::size_t d = 0; d < dof_dims; ++d) {
                    if (nested_flags[d]) {
                        continue;
                    }
                    fes_nonnested.emplace_back();
                    assign_by_blocks(fes_nonnested.back(), fes_use[d], tuned.num_threads,
                                     *tuned.parallel_observer);
                    levels_nonnested.push_back(dof.levels[d]);
                    map_nonnested.push_back(static_cast<int>(d));
                    slopes_nonnested.push_back(slope_only_flags[d]);
                }
                if (!fes_nonnested.empty()) {
                    const FeDofInfo dof_nonnested =
                        compute_fe_dof_for_intercept_dims(
                            fes_nonnested, levels_nonnested, mobility_method,
                            slopes_nonnested, nullptr, tuned.num_threads,
                            nullptr, nullptr, tuned.num_threads_explicit);
                    for (std::size_t pos = 0; pos < map_nonnested.size(); ++pos) {
                        const int orig = map_nonnested[pos];
                        dof.redundant[static_cast<std::size_t>(orig)] =
                            dof_nonnested.redundant[pos];
                    }
                }
            } else {
                dof = compute_fe_dof_for_intercept_dims(
                    fes_use, absorption.fe_levels, mobility_method,
                    slope_only_flags, groupvar_ptr, tuned.num_threads,
                    first_pair_stats_ptr, w_ptr, tuned.num_threads_explicit);

                // If some fixed effects are nested within the clustering variable, reghdfe does not
                // use them to compute mobility-group redundancies for the remaining dimensions.
                if (any_nested && options_.dof_method != DofAdjustmentMethod::None) {
                    std::vector<Eigen::VectorXi> fes_nonnested;
                    std::vector<int> levels_nonnested;
                    std::vector<int> map_nonnested;
                    std::vector<uint8_t> slopes_nonnested;
                    fes_nonnested.reserve(dof_dims);
                    levels_nonnested.reserve(dof_dims);
                    map_nonnested.reserve(dof_dims);
                    slopes_nonnested.reserve(dof_dims);
                    for (std::size_t d = 0; d < dof_dims; ++d) {
                        if (nested_flags[d]) {
                            continue;
                        }
                        fes_nonnested.emplace_back();
                        assign_by_blocks(fes_nonnested.back(), fes_use[d], tuned.num_threads,
                                         *tuned.parallel_observer);
                        levels_nonnested.push_back(dof.levels[d]);
                        map_nonnested.push_back(static_cast<int>(d));
                        slopes_nonnested.push_back(slope_only_flags[d]);
                    }
                    if (!fes_nonnested.empty()) {
                        const FeDofInfo dof_nonnested =
                            compute_fe_dof_for_intercept_dims(
                                fes_nonnested, levels_nonnested, mobility_method,
                                slopes_nonnested, nullptr, tuned.num_threads,
                                nullptr, nullptr, tuned.num_threads_explicit);
                        for (std::size_t pos = 0; pos < map_nonnested.size(); ++pos) {
                            const int orig = map_nonnested[pos];
                            dof.redundant[static_cast<std::size_t>(orig)] =
                                dof_nonnested.redundant[pos];
                        }
                    }
                }
            }
            std::int64_t nested_total = 0;  // round 11 (E3): a sum of levels, in 64 bits
            if (options_.dof_method != DofAdjustmentMethod::None) {
                for (std::size_t d = 0; d < dof.levels.size(); ++d) {
                    if (nested_flags[d]) {
                        nested_total += dof.levels[d];
                        dof.redundant[d] = dof.levels[d];
                        dof.num_coefs[d] = 0;
                    }
                }
                std::vector<int> intercept_index;
                intercept_index.reserve(dof.levels.size());
                for (std::size_t d = 0; d < dof.levels.size(); ++d) {
                    if (!nested_flags[d] && !slope_only_flags[d]) {
                        intercept_index.push_back(static_cast<int>(d));
                    }
                }
                if (!intercept_index.empty()) {
                    bool skip_next = (nested_total == 0);
                    for (const int idx : intercept_index) {
                        if (dof.redundant[static_cast<std::size_t>(idx)] >=
                            dof.levels[static_cast<std::size_t>(idx)]) {
                            continue;
                        }
                        if (skip_next) {
                            skip_next = false;
                            continue;
                        }
                        if (dof.redundant[static_cast<std::size_t>(idx)] < 1) {
                            dof.redundant[static_cast<std::size_t>(idx)] = 1;
                        }
                    }
                }
                for (std::size_t d = 0; d < dof.levels.size(); ++d) {
                    dof.num_coefs[d] =
                        std::max(0, dof.levels[d] - dof.redundant[d]);
                }
            } else {
                bool skip_first_intercept = true;
                for (std::size_t d = 0; d < dof.levels.size(); ++d) {
                    if (slope_only_flags[d]) {
                        continue;
                    }
                    if (skip_first_intercept) {
                        skip_first_intercept = false;
                        continue;
                    }
                    dof.redundant[d] = std::max(dof.redundant[d], 1);
                }
                for (std::size_t d = 0; d < dof.levels.size(); ++d) {
                    dof.num_coefs[d] =
                        std::max(0, dof.levels[d] - dof.redundant[d]);
                }
            }
            dof.inexact.assign(dof.levels.size(), 0);
            const int exact_intercept_dims = options_.dof_mobility_groups ? 2 : 1;
            int intercept_count = 0;
            for (std::size_t d = 0; d < dof.levels.size(); ++d) {
                if (nested_flags[d] || slope_only_flags[d]) {
                    continue;
                }
                ++intercept_count;
                if (intercept_count > exact_intercept_dims) {
                    dof.inexact[d] = 1;
                }
            }
            const std::vector<int> base_redundant = dof.redundant;
            apply_heterogeneous_slope_dof(
                dof, fes_use, slope_terms, w_ptr, nested_flags,
                options_.dof_adjust_continuous, tuned.num_threads,
                tuned.num_threads_explicit, tuned.parallel_observer);
            df_a_levels = 0;
            df_a_exact = 0;
            for (std::size_t d = 0; d < dof.levels.size(); ++d) {
                df_a_levels += dof.levels[d];
                df_a_exact += dof.num_coefs[d];
            }
            dof.df_a_levels = df_a_levels;
            dof.df_a_exact = df_a_exact;
            dof.df_a = df_a_exact;
            results_.df_a_levels = static_cast<double>(df_a_levels);
            results_.df_a_exact = static_cast<double>(df_a_exact);
            results_.fe_num_levels = dof.levels;
            results_.fe_base_levels = absorption.fe_levels;
            results_.fe_base_redundant = base_redundant;
            results_.fe_redundant = dof.redundant;
            results_.fe_num_coefs = dof.num_coefs;
            results_.fe_inexact = dof.inexact;
            results_.fe_nested.assign(dof.levels.size(), 0);
            if (groupvar_ptr) {
                results_.groupvar = std::move(groupvar);
            }
            if (options_.dof_adjust_clusters && tuned.se_type == StandardErrorType::Cluster && c_ptr &&
                !c_ptr->empty()) {
                nested_dof_coefs += detail::sparse_rank::flagged_sum(nested_flags, [&](std::size_t d) {
                    return nested_coefs_for_heterogeneous_dim(d, slope_terms, dof.num_coefs);
                });
                nested_dof_levels += detail::sparse_rank::flagged_sum(nested_flags, [&](std::size_t d) {
                    return nested_levels_for_heterogeneous_dim(d, slope_terms, absorption.fe_levels, dof.levels);
                });
                for (std::size_t d = 0; d < nested_flags.size(); ++d) {
                    if (nested_flags[d]) {
                        results_.fe_nested[d] = 1;
                    }
                }
            }
            cpu_profile_log_elapsed("post_dof", post_phase_t0);
        } else {
            results_.df_a_levels = static_cast<double>(df_a_levels);
            results_.df_a_exact = static_cast<double>(df_a_exact);
        }

        const std::int64_t df_a_report = df_a_exact;
        const std::int64_t nested_report = nested_dof_levels;
        results_.df_a = static_cast<double>(df_a_report);
        results_.df_a_nested = static_cast<double>(nested_report);

        std::int64_t df_a_used = df_a_report;
        std::int64_t nested_dof_used = nested_dof_levels;
        int nested_adj = (nested_dof_levels > 0) ? 1 : 0;
        if (!use_reghdfe_stats) {
            df_a_used = 0;
            nested_dof_used = 0;
            const std::int64_t df_a_base = tuned.ssc_k_exact ? df_a_exact : df_a_levels;
            const std::int64_t nested_base = tuned.ssc_k_exact ? nested_dof_coefs : nested_dof_levels;
            nested_adj = (nested_base > 0) ? 1 : 0;
            if (tuned.ssc_k_fixef == FixefDofMethod::None) {
                df_a_used = 0;
                nested_dof_used = 0;
            } else {
                if (tuned.ssc_k_fixef == FixefDofMethod::Nonnested &&
                    tuned.se_type == StandardErrorType::Cluster) {
                    df_a_used = std::max<std::int64_t>(0, df_a_base - nested_base);
                    nested_dof_used = 0;
                } else {
                    df_a_used = df_a_base;
                    nested_dof_used = nested_base;
                }
            }
        }

        // Use absorbed DoF (after redundancy) for RMSE/Adj R2 residual df.
        // Keep the raw (possibly non-positive) df_r so the saturated case can
        // be handled reghdfe-style (negative e(df_r), missing inference).
        const double df_r_raw =
            nobs - static_cast<double>(df_m) - static_cast<double>(df_intercept_dof) -
            static_cast<double>(df_a_report);
        const double df_r_unadj = std::max(0.0, df_r_raw);
        results_.df_resid_unadj = df_r_raw;
        const double sigma2_df =
            use_reghdfe_stats ? df_r_raw - static_cast<double>(nested_report)
                              : df_r_unadj;
        if (sigma2_df > 0.0) {
            const double sigma2_old = results_.sigma2;
            const double sigma2_new = results_.rss / sigma2_df;
            results_.sigma2 = sigma2_new;
            if (tuned.se_type == StandardErrorType::Homoskedastic && sigma2_old > 0.0) {
                const double ratio = sigma2_new / sigma2_old;
                results_.covariance *= ratio;
                results_.std_errors *= std::sqrt(ratio);
            }
        } else if (use_reghdfe_stats && sigma2_df == 0.0) {
            results_.sigma2 = results_.rss;
        } else if (use_reghdfe_stats) {
            results_.sigma2 = std::numeric_limits<double>::quiet_NaN();
        } else {
            results_.sigma2 = 0.0;
        }
        const bool saturated_model = !(df_r_raw > 0.0);

        double df_r_model =
            nobs - static_cast<double>(df_m) - static_cast<double>(df_intercept_dof) -
            static_cast<double>(df_a_used);
        df_r_model = std::max(0.0, df_r_model);

        // Cluster diagnostics (counts).
        post_phase_t0 = std::chrono::steady_clock::now();
        if (c_ptr && !c_ptr->empty()) {
            results_.num_clusters = ols_result.num_clusters;
            if (c_ptr->size() == 1) {
                results_.cluster_counts.assign(1, results_.num_clusters);
                results_.cluster_combo_counts.assign(1, results_.num_clusters);
            } else {
                // Phase 5b: the G of every mask from the OLS stage's meats when it
                // published the carrier for this list (mask_counts[mask - 1]; the
                // dimension d at mask 2^d); otherwise today's passes.
                const std::size_t masks = (static_cast<std::size_t>(1) << c_ptr->size()) - 1;
                const bool from_passes = passes && passes->ready && passes->source == c_ptr &&
                                         passes->mask_counts.size() == masks;
                if (from_passes) {
                    std::vector<int> counts(c_ptr->size());
                    for (std::size_t d = 0; d < c_ptr->size(); ++d) {
                        counts[d] = passes->mask_counts[(static_cast<std::size_t>(1) << d) - 1];
                    }
                    results_.cluster_counts = std::move(counts);
                    results_.cluster_combo_counts = passes->mask_counts;
                } else {
                    results_.cluster_counts = compute_cluster_counts(*c_ptr);
                    results_.cluster_combo_counts = compute_cluster_combo_counts(*c_ptr);
                }
                if (cpu_profile_enabled()) {
                    std::cerr << "cpu_profile label=cluster_passes site=counts counts="
                              << (from_passes ? "carrier pair=none" : "recount pair=built") << '\n';
                }
            }
        } else {
            results_.cluster_counts.clear();
            results_.cluster_combo_counts.clear();
            results_.num_clusters = 0;
        }
        cpu_profile_log_elapsed("post_cluster_counts", post_phase_t0);

        double robust_scale = 1.0;
        double cluster_ratio = 1.0;
        if (tuned.se_type == StandardErrorType::Robust && df_r_model > 0.0) {
            if (tuned.ssc_k_adj) {
                robust_scale = nobs / df_r_model;
                const double scale = std::sqrt(robust_scale);
                results_.std_errors *= scale;
                results_.covariance *= robust_scale;
            }
            results_.df_resid = tuned.ssc_t_df > 0.0 ? tuned.ssc_t_df : df_r_model;
        } else if (tuned.se_type == StandardErrorType::Cluster && c_ptr && !c_ptr->empty()) {
            const int G = ols_result.num_clusters;
            if (use_reghdfe_stats) {
                const double df_r_unclust = df_r_model;
                const double df_r_cluster = static_cast<double>(std::max(0, G - 1));
                results_.df_resid = std::min(df_r_unclust, df_r_cluster);
                double ratio = 1.0;
                if (tuned.ssc_k_adj) {
                    const double denom = std::max(
                        0.0, nobs - static_cast<double>(df_m) - static_cast<double>(df_a_report) -
                                 static_cast<double>(nested_adj));
                    if (denom > 0.0) {
                        ratio *= ols_result.df_resid / denom;
                    }
                } else {
                    const double denom = std::max(1.0, nobs - 1.0);
                    ratio *= ols_result.df_resid / denom;
                }
                if (c_ptr->size() == 1 && !tuned.ssc_g_adj && G > 1) {
                    ratio *= static_cast<double>(G - 1) / static_cast<double>(G);
                }
                if (ratio > 0.0 && hdfe::detail::ieee_finite(ratio)) {
                    const double scale = std::sqrt(ratio);
                    results_.std_errors *= scale;
                    results_.covariance *= ratio;
                    cluster_ratio = ratio;
                }
                results_.cluster_scale = ratio;
                if (tuned.ssc_t_df > 0.0) {
                    results_.df_resid = tuned.ssc_t_df;
                }
            } else {
                results_.df_resid = static_cast<double>(std::max(0, G - 1));
                double ratio = 1.0;
                if (tuned.ssc_k_adj) {
                    const double df_denom =
                        std::max(0.0, df_r_model + static_cast<double>(nested_dof_used) -
                                          static_cast<double>(nested_adj));
                    if (df_denom > 0.0) {
                        ratio *= ols_result.df_resid / df_denom;
                    }
                } else {
                    const double denom = std::max(1.0, nobs - 1.0);
                    ratio *= ols_result.df_resid / denom;
                }
                if (c_ptr->size() == 1 && !tuned.ssc_g_adj && G > 1) {
                    ratio *= static_cast<double>(G - 1) / static_cast<double>(G);
                }
                if (ratio > 0.0 && hdfe::detail::ieee_finite(ratio)) {
                    const double scale = std::sqrt(ratio);
                    results_.std_errors *= scale;
                    results_.covariance *= ratio;
                    cluster_ratio = ratio;
                }
                results_.cluster_scale = ratio;
                if (tuned.ssc_t_df > 0.0) {
                    results_.df_resid = tuned.ssc_t_df;
                }
            }
        } else if (df_r_model > 0.0) {
            results_.df_resid = tuned.ssc_t_df > 0.0 ? tuned.ssc_t_df : df_r_model;
        }
        if (saturated_model) {
            results_.df_resid = df_r_raw;
        }

        bool intercept_cov_updated = false;
        bool entered_multiway_intercept_fallback = false;
        bool deferred_network_intercept = false;
        if (drop_intercept && options_.fit_intercept && !saturated_model) {
            post_phase_t0 = std::chrono::steady_clock::now();
            const bool have_wide_intercept = iv_intercept_covariance.size()==
                static_cast<int>(kept_slope_cols.size())+1;
            if(have_wide_intercept) {
                double scale=tuned.se_type==StandardErrorType::Robust ? robust_scale :
                    (tuned.se_type==StandardErrorType::Cluster ? cluster_ratio :
                     (ols_result.sigma2>0 ? results_.sigma2/ols_result.sigma2 : 1.0));
                const int intercept=static_cast<int>(results_.coefficients.size())-1;
                results_.covariance.row(intercept).setZero();
                results_.covariance.col(intercept).setZero();
                for(int pos=0;pos<static_cast<int>(kept_slope_cols.size());++pos) {
                    const int column=kept_slope_cols[static_cast<std::size_t>(pos)];
                    const double value=scale*iv_intercept_covariance[pos];
                    results_.covariance(intercept,column)=value;
                    results_.covariance(column,intercept)=value;
                }
                double variance=scale*iv_intercept_covariance[iv_intercept_covariance.size()-1];
                if(!(tuned.se_type==StandardErrorType::Cluster && c_ptr && c_ptr->size()>1))
                    variance=std::max(0.0,variance);
                results_.covariance(intercept,intercept)=variance;
                results_.std_errors[intercept]=std::sqrt(std::max(0.0,variance));
                intercept_cov_updated=true;
            } else {
                // A cluster that is a union of the levels of an absorbed
                // intercept dimension has an exactly zero weighted residual
                // sum (the normal equations of those level dummies, with the
                // fit weights), so the recovered constant's covariance is
                // xbar'V_bb xbar and -V_bb xbar. Apply the identities on every
                // route and backend instead of inference on the roundoff and
                // iterative error left in those sums; with no regressors, or
                // xbar = 0, that variance is exactly zero. Scope: one cluster
                // dimension (CGM intersections need not vanish), no IV (wide
                // intercept path), not xhdfe-fast (documented approximation),
                // not Driscoll-Kraay (it rebuilds this row). The nested
                // dimension must keep its level dummies: a plain FE or a slope
                // term with include_intercept (i.d##c.z); a slope-only term
                // (i.d#c.z) has none. Nestedness is exact on the estimation
                // sample; the cluster DoF scan is reused when it ran. Saturated
                // fits never reach this call and fewer than two clusters are
                // marked unavailable afterwards, as before.
                bool cluster_residual_sums_zero = false;
                if (tuned.se_type == StandardErrorType::Cluster && c_ptr &&
                    c_ptr->size() == 1 && !wants_iv && tuned.dkraay_bandwidth < 0 &&
                    tuned.tolerance_mode != ToleranceMode::XhdfeFast) {
                    const bool nesting_scanned = options_.dof_adjust_clusters &&
                        results_.fe_nested.size() == fes_use.size();
                    for (std::size_t d = 0; d < fes_use.size() && !cluster_residual_sums_zero; ++d) {
                        const auto slope = std::find_if(slope_terms.begin(), slope_terms.end(),
                            [&](const detail::HeterogeneousSlopeTerm& term) {
                                return term.fe_index == static_cast<int>(d);
                            });
                        const bool level_dummies =
                            slope == slope_terms.end() || slope->include_intercept;
                        if (level_dummies) {
                            cluster_residual_sums_zero = nesting_scanned
                                ? results_.fe_nested[d] != 0
                                : fe_nested_within_cluster(fes_use[d], c_ptr->front());
                        }
                    }
                }
                // With every regressor identified, the augmented sandwich below
                // supersedes the preliminary constant row on success.
                deferred_network_intercept =
                    passes && passes->ready && passes->network && !w_ptr && c_ptr &&
                    c_ptr->size() == 2 &&
                    kept_slope_cols.size() + 1 == static_cast<size_t>(results_.covariance.cols()) &&
                    passes->network->matches(score_X_tilde_used, ols_result.residuals, *c_ptr,
                                             tuned.ssc_g_df, tuned.ssc_g_adj);
                if (!deferred_network_intercept) {
                    intercept_cov_updated = update_intercept_covariance(
                        results_, X_use, score_X_tilde_used, ols_result.residuals, w_ptr,
                        kept_slope_cols, ols_result, tuned.se_type, c_ptr, tuned.ssc_g_df,
                        tuned.ssc_g_adj, results_.sigma2, robust_scale, cluster_ratio,
                        tuned.weights_are_frequencies, cluster_residual_sums_zero,
                        passes && passes->ready ? passes : nullptr,
                        &entered_multiway_intercept_fallback);
                }
            }
            cpu_profile_log_elapsed("post_intercept_cov", post_phase_t0);

            // Multiway clustering: rebuild the whole covariance the way
            // reghdfe does for report_constant — extended partitioned-inverse
            // bread over [X_tilde, 1] and cluster scores on the means-restored
            // regressors. Without a preliminary intercept fallback, the direct
            // intercept meat is the same raw CGM sandwich. Rebuild omitted
            // designs after that fallback; full-width designs retain their
            // existing reconstruction before the final PSD correction.
            if (!have_wide_intercept && tuned.se_type == StandardErrorType::Cluster && c_ptr &&
                c_ptr->size() > 1) {
                const int cov_cols = static_cast<int>(results_.covariance.cols());
                const int slope_cols_aug = static_cast<int>(kept_slope_cols.size());
                const int active_cov_cols = slope_cols_aug + 1;
                if (cpu_profile_enabled()) {
                    std::cerr << "cpu_profile label=multiway_reconstruction_gate scope=fit"
                              << " kept=" << slope_cols_aug << " full=" << cov_cols - 1
                              << " preliminary_fallback=" << entered_multiway_intercept_fallback
                              << " required=" << (active_cov_cols == cov_cols ||
                                                  entered_multiway_intercept_fallback) << '\n';
                }
                if (slope_cols_aug > 0 &&
                    active_cov_cols <= cov_cols &&
                    (active_cov_cols == cov_cols || entered_multiway_intercept_fallback) &&
                    slope_cols_aug == static_cast<int>(score_X_tilde_used.cols()) &&
                    slope_cols_aug == static_cast<int>(ols_result.xtx_inv.cols()) &&
                    slope_cols_aug == static_cast<int>(kept_slope_cols.size())) {
                    const int n_rows = static_cast<int>(score_X_tilde_used.rows());
                    Eigen::RowVectorXd means_x(slope_cols_aug);
                    for (int j = 0; j < slope_cols_aug; ++j) {
                        means_x(j) = weighted_mean(
                            X_use.col(kept_slope_cols[static_cast<std::size_t>(j)]),
                            w_ptr);
                    }
                    // Form the sandwich before restoring means; the equivalent
                    // uncentered bread/scores lose slope precision at large offsets.
                    // L3.1-C, C2: the scores are [score_X_tilde_used | 1]; the sandwich
                    // reads the regressors where they are and takes the ones implicitly.
                    // XHDFE_MULTIWAY_SCORES_COPY=1 builds the n x (p+1) matrix as before.
                    const bool scores_copy = detail::multiway_scores_copy_enabled();
                    Eigen::MatrixXd scores;
                    if (scores_copy) {
                        scores.resize(n_rows, active_cov_cols);
                        scores.leftCols(slope_cols_aug) = score_X_tilde_used;
                        scores.col(slope_cols_aug).setOnes();
                    }
                    // Extended bread (partitioned inverse; reghdfe_extend_b_and_xx).
                    const double n_bread =
                        w_ptr ? w_ptr->sum() : static_cast<double>(n_rows);
                    Eigen::MatrixXd bread = Eigen::MatrixXd::Zero(active_cov_cols, active_cov_cols);
                    bread.topLeftCorner(slope_cols_aug, slope_cols_aug) =
                        ols_result.xtx_inv;
                    bread(slope_cols_aug, slope_cols_aug) = 1.0 / n_bread;
                    if (network_scores_for_pass) network_scores_for_pass->consumed = false;
                    Eigen::MatrixXd cov_aug = scores_copy
                        ? detail::multiway_cluster_sandwich(
                              bread, scores, ols_result.residuals, w_ptr, *c_ptr,
                              tuned.ssc_g_df, tuned.ssc_g_adj, passes && passes->ready ? passes : nullptr)
                        : detail::multiway_cluster_sandwich_with_constant(
                              bread, score_X_tilde_used, ols_result.residuals, w_ptr, *c_ptr,
                              tuned.ssc_g_df, tuned.ssc_g_adj, passes && passes->ready ? passes : nullptr);
                    Eigen::MatrixXd transport = Eigen::MatrixXd::Identity(active_cov_cols, active_cov_cols);
                    transport.block(slope_cols_aug, 0, 1, slope_cols_aug) = -means_x;
                    cov_aug = (transport * cov_aug * transport.transpose()).eval();
                    double rescale = cluster_ratio;
                    if (ols_result.df_resid > 0.0)
                        rescale *= (nobs - 1.0) / ols_result.df_resid;
                    if (tuned.ssc_g_df == ClusterDofMethod::Min && tuned.ssc_g_adj && ols_result.num_clusters > 1)
                        rescale *= static_cast<double>(ols_result.num_clusters) / (ols_result.num_clusters - 1.0);
                    if (rescale > 0.0 && hdfe::detail::ieee_finite(rescale) && hdfe::detail::ieee_all_finite(cov_aug)) {
                        if (active_cov_cols == cov_cols) {
                            results_.covariance = cov_aug * rescale;
                        } else {
                            results_.covariance.setZero();
                            for (int i = 0; i < active_cov_cols; ++i) {
                                const int row = i == slope_cols_aug ? cov_cols - 1
                                    : kept_slope_cols[static_cast<std::size_t>(i)];
                                for (int j = 0; j < active_cov_cols; ++j) {
                                    const int col = j == slope_cols_aug ? cov_cols - 1
                                        : kept_slope_cols[static_cast<std::size_t>(j)];
                                    results_.covariance(row, col) = cov_aug(i, j) * rescale;
                                }
                            }
                        }
                        results_.std_errors =
                            results_.covariance.diagonal().cwiseMax(0.0).cwiseSqrt();
                        intercept_cov_updated = true;
                        covariance_uses_network_scores =
                            network_scores_for_pass && network_scores_for_pass->consumed;
                    }
                }
            }
        }
        if (deferred_network_intercept && !intercept_cov_updated) {
            intercept_cov_updated = update_intercept_covariance(
                results_, X_use, score_X_tilde_used, ols_result.residuals, w_ptr,
                kept_slope_cols, ols_result, tuned.se_type, c_ptr, tuned.ssc_g_df,
                tuned.ssc_g_adj, results_.sigma2, robust_scale, cluster_ratio,
                tuned.weights_are_frequencies, false, passes, &entered_multiway_intercept_fallback);
        }
        // Phase 5b: the pair is freed here whether or not the reconstruction ran,
        // before the inference stage and any N1 re-entry (round 23).
        if (tuned.se_type == StandardErrorType::Cluster && c_ptr && c_ptr->size() >= 2) {
            const long long pair_rows = passes ? static_cast<long long>(passes->pair.size()) : 0;
            if (passes) passes->pair.resize(0);
            if (cpu_profile_enabled()) {
                std::cerr << "cpu_profile label=cluster_passes site=release pair_rows=" << pair_rows << '\n';
            }
        }

        if (tuned.se_type == StandardErrorType::Cluster && c_ptr && c_ptr->size() > 1) {
            const int cov_cols = static_cast<int>(results_.covariance.cols());
            const int slope_cols =
                (options_.fit_intercept && cov_cols > 0) ? (cov_cols - 1) : cov_cols;

            // reghdfe (reghdfe_fix_psd with report_constant): clamp negative
            // eigenvalues on the FULL matrix (including the recovered _cons
            // row/col), then re-fix the slope block separately so slope
            // inference matches the constant-free correction. Repair the
            // intercept's range/Schur condition after replacing that block.
            // reghdfe runs the
            // clamp on STANDARDIZED data (each regressor divided by its raw
            // sample stdev), and the clamp does not commute with per-column
            // rescaling, so the same metric is used here (the congruence
            // preserves the eigenvalue signs, hence whether a fix happens).
            Eigen::VectorXd psd_scale = Eigen::VectorXd::Ones(std::max(cov_cols, 0));
            if (cov_cols > 0) {
                for (const int column : kept_slope_cols) {
                    const auto col = X_use.col(column);
                    const double sd = psd_scale_sample_standard_deviation(
                        col, w_ptr, tuned.weights_are_frequencies);
                    psd_scale(column) = std::max(sd, 1.0e-3);
                }
            }
            auto fix_psd_scaled = [&](Eigen::MatrixXd& V,
                                      const Eigen::Ref<const Eigen::VectorXd>& d) -> bool {
                Eigen::MatrixXd Vs = d.asDiagonal() * V * d.asDiagonal();
                if (!fix_psd(Vs)) {
                    return false;
                }
                V = d.cwiseInverse().asDiagonal() * Vs * d.cwiseInverse().asDiagonal();
                return true;
            };

            const bool full_psd_ready = options_.fit_intercept && cov_cols > 0 &&
                                        intercept_cov_updated &&
                                        hdfe::detail::ieee_all_finite(results_.covariance);
            if (full_psd_ready) {
                // Equal counts for every non-empty cluster intersection prove
                // identical partitions up to relabelling. In IV, their CGM
                // sandwich is a single PSD sandwich: clipping roundoff in an
                // ill-conditioned slope block can corrupt the small constant
                // variance. Preserve the existing slope correction and the
                // already accurate intercept row in this exact special case.
                const auto& combinations = results_.cluster_combo_counts;
                const bool iv_single_partition = wants_iv &&
                    !combinations.empty() && combinations.front() > 1 &&
                    std::all_of(combinations.begin(), combinations.end(),
                        [&](int count) { return count == combinations.front(); });
                // Distinct partitions can also have positive CGM meat. The
                // wide solve classifies its augmented score matrix before the
                // weak-design bread and binary64 rounding. Preserve that
                // accurate intercept row while retaining the slope policy.
                const bool preserve_iv_intercept = iv_single_partition ||
                    (wants_iv && iv_intercept_covariance.size() == cov_cols &&
                     ols_result.augmented_meat_positive_definite);
                // The wide IV solve may have retained the augmented covariance
                // (cluster-influence outer products, no bread*meat*bread
                // cancellation) in OlsWide. Clip and repair that matrix under
                // the same rule before any binary64 rounding: conversion back
                // to wide cannot recover lost bits. Ordinary fits keep the
                // double path.
                const bool have_wide = wants_iv && iv_covariance_wide.values.size() > 0 &&
                    iv_covariance_wide.values.rows() ==
                        static_cast<Eigen::Index>(kept_slope_cols.size()) + 1 &&
                    iv_covariance_wide.values.cols() == iv_covariance_wide.values.rows();
                if (have_wide) {
                    using WideMatrix = detail::OlsWideCovariance::Matrix;
                    const int active = static_cast<int>(kept_slope_cols.size());
                    WideMatrix cov_full = WideMatrix::Zero(cov_cols, cov_cols);
                    for (int i = 0; i <= active; ++i) {
                        const int row = i == active ? cov_cols - 1
                            : kept_slope_cols[static_cast<std::size_t>(i)];
                        for (int j = 0; j <= active; ++j) {
                            const int col = j == active ? cov_cols - 1
                                : kept_slope_cols[static_cast<std::size_t>(j)];
                            cov_full(row, col) = iv_covariance_wide.values(i, j) *
                                                 detail::OlsWide(cluster_ratio);
                        }
                    }
                    const WideMatrix original_slopes =
                        cov_full.topLeftCorner(slope_cols, slope_cols);
                    WideMatrix cov_block = original_slopes;
                    const bool full_fixed = !preserve_iv_intercept &&
                        detail::fix_wide_covariance_psd(cov_full, psd_scale);
                    const bool slopes_fixed = slope_cols > 0 &&
                        detail::fix_wide_covariance_psd(cov_block, psd_scale.head(slope_cols));
                    if (full_fixed || slopes_fixed) {
                        cov_full.topLeftCorner(slope_cols, slope_cols) = cov_block;
                        if (!preserve_iv_intercept)
                            repair_intercept_covariance_wide(cov_full, original_slopes, psd_scale);
                        results_.vcv_psd_fixed = true;
                    }
                    results_.covariance = cov_full.cast<double>();
                    if (!hdfe::detail::ieee_all_finite(results_.covariance))
                        throw std::runtime_error("Multiway covariance exceeded its numerical range; no estimates returned");
                    results_.std_errors = results_.covariance.diagonal().cwiseMax(0.0).cwiseSqrt();
                } else {
                    Eigen::MatrixXd cov_full = results_.covariance;
                    Eigen::MatrixXd cov_block =
                        cov_full.topLeftCorner(slope_cols, slope_cols);
                    const bool full_fixed = !preserve_iv_intercept &&
                        fix_psd_scaled(cov_full, psd_scale);
                    const bool slopes_fixed = slope_cols > 0 &&
                        fix_psd_scaled(cov_block, psd_scale.head(slope_cols));
                    if (full_fixed || slopes_fixed) {
                        cov_full.topLeftCorner(slope_cols, slope_cols) = cov_block;
                        if (!preserve_iv_intercept)
                            repair_intercept_covariance(cov_full,
                                results_.covariance.topLeftCorner(slope_cols, slope_cols), psd_scale);
                        results_.covariance = cov_full;
                        results_.std_errors = cov_full.diagonal().cwiseMax(0.0).cwiseSqrt();
                        results_.vcv_psd_fixed = true;
                    }
                }
            } else if (slope_cols > 0) {
                Eigen::MatrixXd cov_block =
                    results_.covariance.topLeftCorner(slope_cols, slope_cols);
                if (fix_psd_scaled(cov_block, psd_scale.head(slope_cols))) {
                    results_.covariance.topLeftCorner(slope_cols, slope_cols) = cov_block;
                    results_.std_errors.head(slope_cols) =
                        cov_block.diagonal().cwiseMax(0.0).cwiseSqrt();
                    results_.vcv_psd_fixed = true;
                }
            }
        }

        post_phase_t0 = std::chrono::steady_clock::now();
        if (tuned.dkraay_bandwidth >= 0) {
            detail::apply_dkraay_covariance(results_, ols_result, score_X_tilde_used,
                X_use, w_ptr, c_ptr, kept_slope_cols, drop_intercept, tuned,
                wants_iv && iv_score_low_storage.size() ? &iv_score_low_storage : nullptr,
                wants_iv ? &iv_dkraay_influences : nullptr);
        }
        // Full-width covariance rebuilds must preserve the public omitted-column
        // convention: zero covariance, but unavailable standard errors and inference.
        for (const int column : omitted_slope_cols) {
            results_.covariance.row(column).setZero();
            results_.covariance.col(column).setZero();
            results_.std_errors[column] = std::numeric_limits<double>::quiet_NaN();
        }
        recompute_inference(results_.coefficients, results_.std_errors, results_.tvalues,
                            results_.pvalues, results_.conf_int, tuned.level, results_.df_resid,
                            tuned.inference_quantiles);
        normalize_nonfrequency_weighted_fit_stats(
            results_, tuned.weights_are_frequencies, w_ptr, sum_weights_for_stats);
        const bool fewer_than_two_clusters =
            tuned.se_type == StandardErrorType::Cluster && c_ptr &&
            !c_ptr->empty() && results_.num_clusters < 2;
        const bool inference_unavailable =
            saturated_model || fewer_than_two_clusters ||
            !(results_.df_resid > 0.0) ||
            !hdfe::detail::ieee_finite(results_.df_resid);
        if (saturated_model || fewer_than_two_clusters) {
            mark_inference_unavailable(results_);
        }
        enforce_estimation_output_postcondition(
            results_, drop_intercept, inference_unavailable);
        // Package B: a fit in scope runs the checks of the reghdfe-comparable
        // fit of the same inputs (the copy of the options its route used), then
        // D(e); every other fit reads tuned, as before.
        const HdfeOptions& check_options = strict_cuda_scope ? strict_cuda_route : tuned;
        const bool check_strict_cuda_residual = absorption.gpu_used &&
            options_.tolerance_mode == ToleranceMode::StrictResidual && !has_slopes_use;
        bool strict_residual_failed = false;
        if (check_strict_cuda_residual) ++strict_cuda_pass;
        try {
            require_n1_fit(absorption, ols_result, kept_slope_cols,
                           transformed_has_intercept, transformed_full_cols, check_options,
                           have_precomputed ? &xtx_used : nullptr,
                           have_precomputed ? &xty_used : nullptr);
            if (absorption.gpu_used && !wants_iv && !has_slopes_use && w_ptr == nullptr &&
                !tuned.retain_fixed_effects &&
                check_options.tolerance_mode == ToleranceMode::ReghdfeComparable)
                require_original_ols_moments(y_use, X_use, absorption.y_tilde, transformed_X_used,
                                             kept_slope_cols, ols_result, check_options,
                                             n1_budget.used);
            if (detail::n1_capture_active && !results_.fe_effects.empty())
                n1_reconstruction.require(tuned.fe_tolerance > 0.0 ? tuned.fe_tolerance : tuned.tol);
            if (check_strict_cuda_residual) {
                // Measure the exact residual published by the fit, including
                // the reconstruction when the fixed effects are retained.
                const auto check_t0 = std::chrono::steady_clock::now();
                const detail::GroupMeanReading reading = detail::max_abs_group_mean(
                    results_.residuals, fes_use, tuned.num_threads, w_ptr);
                const double check_seconds = std::chrono::duration<double>(
                    std::chrono::steady_clock::now() - check_t0).count();
                const bool accepted = reading.finite &&
                    reading.maximum <= static_cast<long double>(options_.tol);
                if (strict_accept_trace_on()) {
                    strict_cuda_first_effect_host = reading.per_effect;
                    std::ostringstream line;
                    line.precision(17);
                    line << "strict_accept_trace pass=" << strict_cuda_pass
                         << " certified=" << (absorption.precision_certified ? 1 : 0)
                         << " checks=pass D=" << static_cast<double>(reading.maximum)
                         << " limit=" << options_.tol << " finite=" << (reading.finite ? 1 : 0)
                         << " per_effect=";
                    for (std::size_t d = 0; d < reading.per_effect.size(); ++d)
                        line << (d ? "," : "") << static_cast<double>(reading.per_effect[d]);
                    // The per-column readings (largest group mean of y~ and of
                    // each absorbed column), computed only with the trace on.
                    line << " columns=y:" << static_cast<double>(detail::max_abs_group_mean(
                        absorption.y_tilde, fes_use, tuned.num_threads, w_ptr).maximum);
                    for (Eigen::Index j = 0; j < absorption.X_tilde.cols(); ++j)
                        line << ",c" << j + 1 << ':' << static_cast<double>(detail::max_abs_group_mean(
                            absorption.X_tilde.col(j), fes_use, tuned.num_threads, w_ptr).maximum);
                    line << " check_seconds=" << check_seconds
                         << " iterations=" << absorption.iterations << " max_iter=" << tuned.max_iter
                         << " decision=" << (accepted ? "accept"
                                             : (n1_budget.used || absorption.iterations >= tuned.max_iter
                                                    ? "refuse" : "continue")) << '\n';
                    std::cerr << line.str();
                }
                if (!accepted) {
                    strict_residual_failed = true;
                    std::ostringstream message;
                    message.precision(6);
                    message << "the largest absolute group mean of the delivered residual is "
                            << std::scientific << static_cast<double>(reading.maximum)
                            << (reading.finite ? "" : " (not finite)")
                            << ", above the tolerance " << options_.tol;
                    throw detail::N1Failure(message.str());
                }
            }
        } catch (const detail::N1Failure& failure) {
            if (cached_savefe) throw SavefeCacheMiss{};
            int remaining = 0;
            try {
                remaining = n1_budget.remaining(absorption.iterations, failure);
            } catch (const detail::N1Failure& exhausted) {
                if (!strict_cuda_scope && !strict_residual_failed) throw;
                // Package B: a second failure of any check, or no budget left,
                // ends a fit in scope with the mode's non-convergence error.
                if (strict_accept_trace_on()) {
                    std::cerr << "strict_accept_trace pass=" << strict_cuda_pass
                              << " decision=refuse iterations=" << absorption.iterations
                              << " max_iter=" << tuned.max_iter << '\n';
                }
                // Stage 2a': the text names the fit's single refinement (N1 or the
                // continuation), not the N1 budget that both share.
                (void)exhausted;
                std::ostringstream message;
                message << "Requested GPU backend did not converge during the strict-residual "
                           "acceptance: " << failure.what()
                        << (n1_budget.used ? "; the fit's single refinement was exhausted"
                                           : "; no absorption iteration budget remains")
                        << "; iterations="
                        << absorption.iterations << '/' << tuned.max_iter
                        << "; requested tolerance=" << std::scientific << options_.tol
                        << ". No estimates returned.";
                throw detail::N1Failure(message.str());
            }
            Eigen::MatrixXd original_design = drop_intercept ? Eigen::MatrixXd(X_use)
                : maybe_add_intercept(X_use, options_.fit_intercept);
            if (inst_use && inst_use->cols()) original_design = append_matrix(original_design, inst_use);
            if (strict_residual_failed) {
                if (!strict_cuda_scope) {
                    if (!detail::repair_cuda_projection(
                            y_use, original_design, fes_use, w_ptr, tuned, absorption)) {
                        throw detail::N1Failure(std::string(
                            "CUDA strict-residual check failed after device LSMR: ") + failure.what());
                    }
                    method_used_ = krylov_method_used(absorption);
                    savefe_projection_published = tuned.retain_fixed_effects;
                    continue;
                }
                // Package B: the continuation, the single refinement of a fit
                // in scope whose existing checks passed: Gauss-Seidel sweeps of
                // the delivered state on the device (its own entry), within what
                // the budget leaves, at the public tolerance; then the
                // certificate against the original inputs with the comparable
                // view, and the selection, both stages, inference, the checks
                // and D(e) again (the next pass of this loop).
                const auto continuation_t0 = std::chrono::steady_clock::now();
                Eigen::VectorXd combination = Eigen::VectorXd::Zero(absorption.X_tilde.cols());
                for (std::size_t j = 0; j < kept_slope_cols.size(); ++j)
                    combination[kept_slope_cols[j]] = ols_result.coefficients[static_cast<Eigen::Index>(j)];
                if (transformed_has_intercept &&
                    ols_result.coefficients.size() > static_cast<Eigen::Index>(kept_slope_cols.size()))
                    combination[transformed_full_cols - 1] =
                        ols_result.coefficients[static_cast<Eigen::Index>(kept_slope_cols.size())];
                detail::StrictContinuationReport report;
                report.trace_level = strict_accept_trace_level();  // stage 2a'': 2 adds readings
                const int iterations_before = absorption.iterations;
                const bool served = absorption.gpu_used && detail::continue_strict_residual(
                    absorption.y_tilde, absorption.X_tilde, y_use, fes_use,
                    absorption.sweep_order_used, combination, options_.tol, remaining,
                    tuned.num_threads, report);
                if (!served) {
                    std::ostringstream message;
                    message << "Requested GPU backend did not converge during the strict-residual "
                               "acceptance: the device did not serve the continuation; iterations="
                            << iterations_before << '/' << tuned.max_iter
                            << "; requested tolerance=" << std::scientific << options_.tol
                            << ". No estimates returned.";
                    throw detail::N1Failure(message.str());
                }
                absorption.iterations += report.sweeps;
                absorption.gpu_absorption_iterations += report.sweeps;
                const auto recertify_t0 = std::chrono::steady_clock::now();
                // Stage 2a': the raw sums of squares of the same original columns
                // (instruments included) that the last certificate of this result
                // formed are taken over; the comparable normalisation still runs.
                const bool raw_norms_reused = absorption.raw_original_norm_sq.size() ==
                    static_cast<std::size_t>(original_design.cols() + 1);
                absorption.reuse_raw_original_norm_sq = true;
                HdfeOptions certificate_options = strict_cuda_route;
                certificate_options.strict_provenance = true;
                detail::certify_absorption_result(y_use, original_design, fes_use, w_ptr,
                    certificate_options, slope_terms, absorption, nullptr, true);
                const double recertify_seconds = std::chrono::duration<double>(
                    std::chrono::steady_clock::now() - recertify_t0).count();
                if (!absorption.precision_certified || !absorption.cuda_projection_moments_met) {
                    // The mode's non-convergence error at the next pass.
                    absorption.converged = false;
                    absorption.gpu_status_code = 3;
                }
                if (strict_accept_trace_on()) {
                    std::ostringstream line;
                    line.precision(17);
                    const std::size_t first = report.order.empty() ? 0 : static_cast<std::size_t>(report.order[0]);
                    line << "strict_accept_trace refinement=continuation sweeps=" << report.sweeps
                         << " exit=" << report.exit
                         << " confirmations=" << report.confirmations
                         << " confirmed=" << (report.confirmed ? 1 : 0)
                         << " first_effect_in_sweep=" << report.first_effect_in_sweep
                         << " first_effect_host=" << (first < strict_cuda_first_effect_host.size()
                                ? static_cast<double>(strict_cuda_first_effect_host[first]) : -1.0)
                         << " last_in_sweep=" << report.last_in_sweep
                         << " last_fresh=" << report.last_fresh << " order=";
                    for (std::size_t d = 0; d < report.order.size(); ++d)
                        line << (d ? "," : "") << report.order[d];
                    line << " inherited=" << (report.order_inherited ? 1 : 0)
                         << " budget=" << remaining
                         << " seconds_indexers=" << report.seconds_indexers
                         << " seconds_upload=" << report.seconds_upload
                         << " seconds_sweeps=" << report.seconds_sweeps
                         << " seconds_confirmations=" << report.seconds_confirmations
                         << " seconds_download=" << report.seconds_download
                         << " seconds_recertify=" << recertify_seconds
                         << " raw_norms_reused=" << (raw_norms_reused ? 1 : 0)
                         << " seconds_total=" << std::chrono::duration<double>(
                                std::chrono::steady_clock::now() - continuation_t0).count()
                         << " certified=" << (absorption.precision_certified ? 1 : 0)
                         << " abs_residual_rel=" << absorption.abs_residual_rel
                         << " iterations=" << absorption.iterations << '\n';
                    std::cerr << line.str();
                }
                continue;
            }
            const bool standard_gpu_moments = absorption.gpu_used && !wants_iv &&
                !has_slopes_use && w_ptr == nullptr && !tuned.retain_fixed_effects &&
                check_options.tolerance_mode == ToleranceMode::ReghdfeComparable;
            const auto n1_t0 = std::chrono::steady_clock::now();
            absorption = refine_n1_absorption(y_use, original_design, fes_use, w_ptr,
                check_options, method_used_, slope_terms, nullptr, absorption, remaining,
                standard_gpu_moments ? &ols_result.coefficients : nullptr,
                standard_gpu_moments ? &kept_slope_cols : nullptr);
            if (strict_cuda_scope && strict_accept_trace_on()) {
                std::cerr << "strict_accept_trace pass=" << strict_cuda_pass
                          << " checks=fail refinement=n1 reason=\"" << failure.what()
                          << "\" seconds=" << std::chrono::duration<double>(
                                 std::chrono::steady_clock::now() - n1_t0).count()
                          << " iterations=" << absorption.iterations << '\n';
            }
            continue;
        }
        if (detail::ordinary_audit_enabled()) {
            detail::OrdinaryAuditReceipt audit("fit",tuned,absorption,cache_hit,n1_budget.used ? 1 : 0);
            if (tuned.dkraay_bandwidth >= 0) {
                audit.unsupported("driscoll_kraay_covariance_use_offline_battery");
            } else if (has_slopes_use) {
                audit.unsupported("heterogeneous_slopes");
            } else {
                Eigen::MatrixXd audit_design=drop_intercept ? Eigen::MatrixXd(X_use)
                    : maybe_add_intercept(X_use,options_.fit_intercept);
                if (inst_use && inst_use->cols()) audit_design=append_matrix(audit_design,inst_use);
                double rss_scale=1.0;
                if (w_ptr && !tuned.weights_are_frequencies && sum_weights_for_stats>0.0 &&
                    std::abs(sum_weights_for_stats-results_.nobs)>1e-12*std::max(1.0,double(results_.nobs)))
                    rss_scale=results_.nobs/sum_weights_for_stats;
                detail::run_ordinary_post_ols_audit(audit,y_use,audit_design,fes_use,w_ptr,c_ptr,tuned,
                    absorption,transformed_X_used,kept_slope_cols,ols_result,results_,
                    drop_intercept,transformed_has_intercept,sigma2_df,robust_scale,cluster_ratio,
                    rss_scale,inference_unavailable,wants_iv,false);
            }
            audit.emit();
        }
        provisional_cache_hit = false;
        // The published transform is final after the last N1 check.
        krylov_pcg_published_ = tuned.use_krylov && absorption.krylov_pcg_used;
        if (cached_savefe) {
            reduced_pcg_status_ = cached_savefe->tier_status;
            reduced_pcg_reason_ = std::move(cached_savefe->tier_reason);
            reduced_pcg_discarded_iterations_ = cached_savefe->tier_discarded;
            reduced_pcg_fine_ = cached_savefe->tier_fine;
            reduced_pcg_fine_.cache_hit = true;
            if (detail::reduced_pcg_effective(options_)) {
                detail::reduced_pcg_final_line(
                    std::string("status=cache method=") + method_name(absorption_method_used()) +
                    " iterations=" + std::to_string(absorption.iterations));
            }
            if (read_env_bool("XHDFE_DEBUG_SOLVER").value_or(false)) {
                std::cerr << "xhdfe solver: use_krylov=" << (tuned.use_krylov ? 1 : 0)
                          << " use_sparse=" << (tuned.use_sparse_solver ? 1 : 0)
                          << " method=" << static_cast<int>(method_used_)
                          << " iterations=" << absorption.iterations << " cache_hit=1\n";
            }
        }
        slope_solver_diagnostics_.scores_used = covariance_uses_network_scores &&
            !saturated_model && !fewer_than_two_clusters;
        // Package B: the deferred suggestion of a fit in scope, written once it
        // is accepted (the same profile as the write above, which it skipped).
        if (strict_cuda_scope && allow_profile_write && absorption.converged &&
            absorption.precision_certified) {
            MobilityProfile profile = compute_mobility_profile(
                fes_use, nobs_full, singletons_dropped_rows, options_.drop_singletons,
                absorption.sweep_order_used);
            if (options_.absorption_method == AbsorptionMethod::Auto &&
                !options_.symmetric_sweep) {
                profile.suggest_method = method_used_;
                profile.suggest_symmetric =
                    (method_used_ == AbsorptionMethod::SymmetricGaussSeidel);
            }
            profile.suggest_use_sparse = tuned.use_sparse_solver;
            profile.suggest_use_krylov = tuned.use_krylov;
            write_mobility_profile(mobility_cfg.path, profile);
        }
        // Package D: no entry after a transient memory fallback of the tier (the
        // finer blocks not allocated, the repetition on the coarse blocks, a
        // decline for memory), as after an abandoned projection.
        if (allow_cache_write && !cache_hit && absorption.converged &&
            absorption.precision_certified && !cache_path.empty() &&
            !reduced_pcg_transient_fallback_) {
            // The published method: a transform of the tier is stored as
            // reduced-pcg, so that a later hit reports it truthfully; the
            // krylov-pcg label is reported only (cached_method_used).
            try {
                std::optional<SavefeTimer> write_timer;
                if (abs_cache_key.capture) write_timer.emplace("savefe_cache_write");
                std::optional<CachedSavefePublication> publication;
                if (abs_cache_key.capture) {
                    publication.emplace();
                    auto& p = *publication;
                    if (compact_savefe_effects(fes_use, absorption.fe_levels, results_.fe_effects, p.effects)) {
                        p.beta = std::move(recovery_beta);
                        p.kept_columns = kept_slope_cols;
                        p.ols_residual_digest = hash_savefe_ols_residuals(abs_cache_key, ols_result.residuals);
                        if (options_.fit_intercept && results_.coefficients.size() > 0) {
                            p.intercept = results_.coefficients[results_.coefficients.size() - 1];
                        }
                        p.recovery_iterations = results_.fe_recovery_iterations;
                        p.recovery_max_delta = results_.fe_recovery_max_delta;
                        p.hybrid_recovery = std::strcmp(fe_recovery_method, "hybrid_cached") == 0 ? 1 : 0;
                        p.internal_method = static_cast<int>(method_used_);
                        p.tuned_method = static_cast<int>(tuned.absorption_method);
                        p.route_flags = (tuned.symmetric_sweep ? kSavefeSymmetric : 0U) |
                            (tuned.use_sparse_solver ? kSavefeUseSparse : 0U) |
                            (tuned.use_krylov ? kSavefeUseKrylov : 0U) |
                            (tuned.from_auto ? kSavefeFromAuto : 0U) |
                            (absorption.mlsmr_used ? kSavefeMlsmr : 0U) |
                            (absorption.schwarz_used ? kSavefeSchwarz : 0U) |
                            (absorption.krylov_pcg_used ? kSavefeKrylovPcg : 0U);
                        p.tier_status = reduced_pcg_status_;
                        p.tier_reason = reduced_pcg_reason_;
                        p.tier_discarded = reduced_pcg_discarded_iterations_;
                        p.tier_fine = reduced_pcg_fine_;
                        p.abs_residual = results_.abs_residual;
                        p.abs_residual_rel = results_.abs_residual_rel;
                    } else {
                        publication.reset();
                    }
                }
                write_absorption_cache(cache_path, abs_cache_key, absorption.y_tilde,
                    absorption.X_tilde, absorption.fe_levels, absorption.sweep_order_used,
                    design_cols, cached_method_used(), absorption.iterations, absorption.converged,
                    absorption.krylov_internal_tolerance, absorption.krylov_max_final_backward_error,
                    absorption.krylov_max_condition, absorption.krylov_max_condition_times_backward_error,
                    absorption, savefe_projection_published, cpu_projection_refined,
                    publication ? &*publication : nullptr, publication ? &results_.residuals : nullptr);
            } catch (const std::bad_alloc&) {
                // Cache preparation is optional and the result is already final.
            }
        }
        cpu_profile_log_elapsed("post_inference", post_phase_t0);
        cpu_profile_log_elapsed("postprocess", post_t0);
        cpu_profile_log_elapsed("fit_inner_total", fit_t0);
        end_parallel_observation();
        break;
        }
    };

    auto run_fit = [&](const Eigen::Ref<const Eigen::VectorXd>& y_use,
                       const Eigen::Ref<const Eigen::MatrixXd>& X_use,
                       const std::vector<Eigen::VectorXi>& fes_use,
                       const Eigen::VectorXd* w_ptr,
                       const std::vector<Eigen::VectorXi>* c_ptr,
                       const Eigen::MatrixXd* inst_use,
                       const std::vector<detail::HeterogeneousSlopeTerm>* slopes_use) {
        // One snapshot per fit, including a cold restart after a provisional hit.
        const auto slope_request = slope_solver_diagnostics_.request;
        const auto slope_source = slope_solver_diagnostics_.source;
        const bool slope_scores = slope_scores_enabled_;
        const bool slope_csr_owner = slope_csr_owner_enabled_;
        bool provisional_cache_hit = false;
        try {
            run_fit_once(y_use, X_use, fes_use, w_ptr, c_ptr, inst_use, slopes_use,
                         false, provisional_cache_hit);
            return;
        } catch (const SavefeCacheMiss&) {
        } catch (const std::bad_alloc&) {
            if (!provisional_cache_hit) throw;
        }
        clear_consumable_state();
        // Keep configuration, while discarding the provisional fit's outcomes.
        slope_solver_diagnostics_.request = slope_request;
        slope_solver_diagnostics_.source = slope_source;
        slope_solver_diagnostics_.reset_outcome();
        slope_scores_enabled_ = slope_scores;
        slope_csr_owner_enabled_ = slope_csr_owner;
        run_fit_once(y_use, X_use, fes_use, w_ptr, c_ptr, inst_use, slopes_use,
                     true, provisional_cache_hit);
    };

    if (!has_slopes && fe_cache_cfg.mode != "off" && has_fes) {
        const auto fe_cache_read_t0 = std::chrono::steady_clock::now();
        const bool allow_read =
            (fe_cache_cfg.mode == "read" || fe_cache_cfg.mode == "auto");
        if (allow_read) {
            ensure_fe_cache_signature();
            fe_cache_hit =
                read_fe_structure_cache(fe_cache_cfg.path, fe_cache_signature, nobs_full,
                                        options_.drop_singletons,
                                        static_cast<int>(fes.size()), fe_cache,
                                        preprocessing_thread_resolution.effective, parallel_observer_.get());
        }
        cpu_profile_log_elapsed("fe_cache_read", fe_cache_read_t0);
    }

    if (fe_cache_hit) {
        if (options_.drop_singletons && fe_cache.nobs < nobs_full) {
            const auto filter_t0 = std::chrono::steady_clock::now();
            kept_idx = std::move(fe_cache.kept_idx);
            singletons_dropped_rows = nobs_full - fe_cache.nobs;
            y_work = filter_vector(y, kept_idx);
            X_work = filter_rows(X, kept_idx);
            fes_work = std::move(fe_cache.fe_group_ids);

            const Eigen::VectorXd* w_ptr = nullptr;
            if (weights) {
                weights_work = filter_vector(*weights, kept_idx);
                w_ptr = &(*weights_work);
            }

            const std::vector<Eigen::VectorXi>* c_ptr = clusters;
            if (clusters && !clusters->empty()) {
                std::vector<Eigen::VectorXi> clusters_tmp;
                clusters_tmp.reserve(clusters->size());
                for (const auto& c : *clusters) {
                    clusters_tmp.push_back(filter_vector(c, kept_idx));
                }
                clusters_work = std::move(clusters_tmp);
                c_ptr = &(*clusters_work);
            }

            const Eigen::MatrixXd* inst_use = inst_ptr;
            if (inst_ptr) {
                instruments_work = filter_rows(*inst_ptr, kept_idx);
                inst_use = &(*instruments_work);
            }
            const std::vector<detail::HeterogeneousSlopeTerm>* slopes_use = slopes_in;
            if (has_slopes) {
                slopes_work = filter_slope_terms(*slopes_in, kept_idx);
                slopes_use = &(*slopes_work);
            }
            cpu_profile_log_elapsed("singleton_filter_cache", filter_t0);

            run_fit(*y_work, *X_work, *fes_work, w_ptr, c_ptr, inst_use, slopes_use);

            if (options_.weights_are_frequencies && weights_work) {
                std::int64_t kept_weight = 0;
                for (const int row : kept_idx) {
                    kept_weight += integer_frequency_weights[
                        static_cast<std::size_t>(row)];
                }
                singletons_dropped_effective = static_cast<double>(
                    nobs_full_frequency - kept_weight);
            } else {
                singletons_dropped_effective = static_cast<double>(singletons_dropped_rows);
            }
        } else {
            fes_work = std::move(fe_cache.fe_group_ids);
            run_fit(y, X, *fes_work, weights, clusters, inst_ptr, slopes_in);
        }
    } else if (options_.drop_singletons && has_fes) {
        const auto singleton_t0 = std::chrono::steady_clock::now();
        std::vector<uint8_t> keep;
        if (options_.weights_are_frequencies && weights) {
            keep = compute_keep_mask_drop_singletons_fweights(
                fes, *weights, &singletons_dropped_rows,
                &singletons_dropped_effective,
                preprocessing_thread_resolution.effective,
                preprocessing_thread_resolution.capacity,
                options_.num_threads > 0,
                &integer_frequency_weights,
                &preprocessing_observer);
        } else {
            keep = compute_keep_mask_drop_singletons(fes,
                                                     &singletons_dropped_rows,
                                                     preprocessing_thread_resolution.effective,
                                                     preprocessing_thread_resolution.capacity,
                                                     options_.num_threads > 0,
                                                     &preprocessing_observer,
                                                     &singleton_scan_levels);
            singletons_dropped_effective = static_cast<double>(singletons_dropped_rows);
        }
        preprocessing_threads_used =
            std::max(1, preprocessing_observer.max_team_size());
        preprocessing_parallel_workers_active =
            std::max(1, preprocessing_observer.active_workers());
        preprocessing_parallel_observed =
            preprocessing_threads_used > 1 ||
            preprocessing_parallel_workers_active > 1;
        cpu_profile_log_elapsed("singleton_scan", singleton_t0);

        if (singletons_dropped_rows > 0) {
            const auto filter_t0 = std::chrono::steady_clock::now();
            {
                const RowFilterTeam team{preprocessing_thread_resolution.effective,
                                         options_.num_threads > 0};
                ScopedParallelRuntime filter_runtime(
                    team.threads, preprocessing_thread_resolution.capacity);
                kept_idx = build_keep_indices(keep, team);
                y_work = filter_vector(y, kept_idx, team);
                X_work = filter_rows(X, kept_idx, team);

                std::vector<Eigen::VectorXi> fes_tmp;
                fes_tmp.reserve(fes.size());
                for (const auto& fe : fes) {
                    fes_tmp.push_back(filter_vector(fe, kept_idx, team));
                }
                fes_work = std::move(fes_tmp);

                if (weights) {
                    weights_work = filter_vector(*weights, kept_idx, team);
                }
                if (clusters && !clusters->empty()) {
                    std::vector<Eigen::VectorXi> clusters_tmp;
                    clusters_tmp.reserve(clusters->size());
                    for (const auto& c : *clusters) {
                        clusters_tmp.push_back(filter_vector(c, kept_idx, team));
                    }
                    clusters_work = std::move(clusters_tmp);
                }
                if (inst_ptr) {
                    instruments_work = filter_rows(*inst_ptr, kept_idx, team);
                }
                if (has_slopes) {
                    slopes_work = filter_slope_terms(*slopes_in, kept_idx, team);
                }
            }
            const Eigen::VectorXd* w_ptr = weights ? &(*weights_work) : nullptr;
            const std::vector<Eigen::VectorXi>* c_ptr =
                (clusters && !clusters->empty()) ? &(*clusters_work) : clusters;
            const Eigen::MatrixXd* inst_use =
                inst_ptr ? &(*instruments_work) : inst_ptr;
            const std::vector<detail::HeterogeneousSlopeTerm>* slopes_use =
                has_slopes ? &(*slopes_work) : slopes_in;
            cpu_profile_log_elapsed("singleton_filter", filter_t0);

            run_fit(*y_work, *X_work, *fes_work, w_ptr, c_ptr, inst_use, slopes_use);
        } else {
            run_fit(y, X, fes, weights, clusters, inst_ptr, slopes_in);
        }
    } else {
        run_fit(y, X, fes, weights, clusters, inst_ptr, slopes_in);
    }
    if (preprocessing_parallel_observed) {
        if (preprocessing_thread_resolution.effective > threads_effective_) {
            // A registry-limited estimation team keeps its reason (code 6).
            const bool estimation_coordinated =
                thread_limit_code_ == kThreadLimitAutoTeamCoordination;
            threads_effective_ = preprocessing_thread_resolution.effective;
            thread_capacity_ = preprocessing_thread_resolution.capacity;
            openmp_enabled_ = preprocessing_thread_resolution.openmp_enabled;
            thread_limit_code_ = preprocessing_thread_resolution.limit_code;
            thread_limit_reason_ = preprocessing_thread_resolution.limit_reason;
            if (estimation_coordinated) {
                thread_limit_code_ = kThreadLimitAutoTeamCoordination;
                thread_limit_reason_ = kThreadLimitAutoTeamCoordinationReason;
            }
        }
        threads_used_ = std::max(threads_used_, preprocessing_threads_used);
        parallel_workers_active_ =
            std::max(parallel_workers_active_,
                     preprocessing_parallel_workers_active);
    }
    const bool allow_fe_cache_write =
        fe_cache_cfg.mode == "write" ||
        (fe_cache_cfg.mode == "auto" && fe_cache_cfg.allow_auto_write);
    if (!has_slopes && !fe_cache_hit && allow_fe_cache_write && has_fes && !fe_cache_cfg.path.empty()) {
        ensure_fe_cache_signature();
        const std::vector<Eigen::VectorXi>* fes_used =
            fes_work ? &(*fes_work) : &fes;
        if (!fes_used->empty()) {
            std::vector<Eigen::VectorXi> fe_group_ids;
            std::vector<int> num_groups;
            fe_group_ids.reserve(fes_used->size());
            num_groups.reserve(fes_used->size());
            for (const auto& fe : *fes_used) {
                FeIndexerLite idx = build_indexer_lite(fe);
                Eigen::VectorXi ids(static_cast<int>(idx.group_ids.size()));
                for (int i = 0; i < ids.size(); ++i) {
                    ids(i) = idx.group_ids[static_cast<std::size_t>(i)];
                }
                fe_group_ids.push_back(std::move(ids));
                num_groups.push_back(idx.num_groups);
            }
            write_fe_structure_cache(fe_cache_cfg.path, fe_cache_signature, nobs_full,
                                     options_.drop_singletons, kept_idx, num_groups,
                                     fe_group_ids, preprocessing_thread_resolution.effective,
                                     parallel_observer_.get());
        }
    }

    results_.nobs_full = static_cast<int>(y.size());
    results_.num_singletons = singletons_dropped_rows;
    const auto sample_index_t0 = std::chrono::steady_clock::now();
    results_.sample_index.resize(results_.nobs);
    {
        const RowFilterTeam team{preprocessing_thread_resolution.effective,
                                 options_.num_threads > 0};
        ScopedParallelRuntime index_runtime(
            team.threads, preprocessing_thread_resolution.capacity);
        const int rows = results_.nobs;
        int* const sample = results_.sample_index.data();
        const int* const kept = kept_idx.empty() ? nullptr : kept_idx.data();
#ifdef HDFE_USE_OPENMP
#pragma omp parallel for schedule(static) num_threads(team.threads) \
    if(team.shares(static_cast<std::size_t>(std::max(0, rows))))
#endif
        for (int i = 0; i < rows; ++i) {
            sample[i] = kept ? kept[i] : i;
        }
    }
    cpu_profile_log_elapsed("sample_index", sample_index_t0);
    cpu_profile_log_elapsed("fit_total", fit_outer_t0);

    // Package C: the routed call's only difference from the CPU call (an absorption
    // cache hit included): its GPU status code. Every other GPU field stays the CPU's.
    if (weighted_cpu_routed) gpu_status_code_ = detail::kGpuStatusWeightedCpuRoute;
    reduced_pcg_fit_scope.complete();
    attempt.commit(LifecycleState::StandardReady);
}

void HdfeRegressorV11::apply_importance_weights(
    const Eigen::Ref<const Eigen::VectorXd>& weights) {
    try {
        if (!has_estimation_result() || !results_.converged ||
            !results_.precision_certified || options_.weights_are_frequencies ||
            results_.sample_index.size() != results_.nobs || results_.nobs <= 0) {
            throw std::runtime_error(
                "iweights require a successful non-frequency-weight fit with a complete sample map; no estimates returned");
        }
        // regress treats iweights as analytic weights with robust/cluster VCE.
        // Only classical inference uses unnormalized sums and weighted N/df.
        if (options_.se_type != StandardErrorType::Homoskedastic) return;
        long double full_sum = 0.0L, kept_sum = 0.0L;
        for (int row = 0; row < weights.size(); ++row) {
            if (!hdfe::detail::ieee_finite(weights(row)) || weights(row) <= 0.0) {
                throw std::runtime_error("iweights must be finite and positive; no estimates returned");
            }
            full_sum += static_cast<long double>(weights(row));
        }
        for (int row : results_.sample_index) {
            if (row < 0 || row >= weights.size()) {
                throw std::runtime_error("iweight sample index is outside the supplied weights; no estimates returned");
            }
            kept_sum += static_cast<long double>(weights(row));
        }
        const double full_weight = static_cast<double>(full_sum);
        const double kept_weight = static_cast<double>(kept_sum);
        if (!hdfe::detail::ieee_finite(full_weight) || !hdfe::detail::ieee_finite(kept_weight)) {
            throw std::runtime_error("iweight totals exceed the finite result range; no estimates returned");
        }
        // regress truncates classical iweight counts, but keeps the actual
        // unnormalized weights in RSS/TSS and in the normal equations.
        const double full_n = std::floor(full_weight);
        const double kept_n = std::floor(kept_weight);
        const double old_df = results_.df_resid_unadj;
        const double new_df = old_df + kept_weight - results_.nobs;
        const double reported_df = old_df + kept_n - results_.nobs;
        if (options_.se_type == StandardErrorType::Homoskedastic && old_df > 0.0 && new_df > 0.0) {
            const double variance_scale = old_df / new_df;
            if (!hdfe::detail::ieee_finite(variance_scale)) {
                throw std::runtime_error("iweight covariance scaling overflowed; no estimates returned");
            }
            for (int j = 0; j < results_.covariance.size(); ++j) {
                const double value = results_.covariance.data()[j];
                if (hdfe::detail::ieee_finite(value) &&
                    !hdfe::detail::ieee_finite(value * variance_scale)) {
                    throw std::runtime_error("iweight covariance overflowed; no estimates returned");
                }
            }
            results_.covariance *= variance_scale;
            for (int j = 0; j < results_.std_errors.size(); ++j) {
                const double variance = results_.covariance(j,j);
                results_.std_errors(j) = variance >= 0.0 ? std::sqrt(variance)
                    : std::numeric_limits<double>::quiet_NaN();
            }
        }
        const double scale = kept_weight / results_.nobs;
        results_.rss *= scale;
        results_.tss *= scale;
        results_.tss_within *= scale;
        results_.sigma2 = new_df > 0.0 ? results_.rss / new_df
            : std::numeric_limits<double>::quiet_NaN();
        results_.df_resid_unadj = new_df;
        if (options_.se_type != StandardErrorType::Cluster) results_.df_resid = reported_df;
        results_.nobs_effective = kept_n;
        results_.nobs_full_effective = full_n;
        recompute_inference(results_.coefficients, results_.std_errors, results_.tvalues,
                            results_.pvalues, results_.conf_int, options_.level, results_.df_resid,
                            options_.inference_quantiles);
        if (!(new_df > 0.0)) mark_inference_unavailable(results_);
        if (!hdfe::detail::ieee_finite(results_.rss) ||
            !hdfe::detail::ieee_finite(results_.tss) ||
            !hdfe::detail::ieee_finite(results_.tss_within)) {
            throw std::runtime_error("iweight fit statistics overflowed; no estimates returned");
        }
    } catch (...) {
        fail_attempt();
        throw;
    }
}

detail::AbsorptionResult HdfeRegressorV11::partial_out(
    const Eigen::Ref<const Eigen::VectorXd>& y,
    const Eigen::Ref<const Eigen::MatrixXd>& X,
    const std::vector<Eigen::VectorXi>& fes,
    const Eigen::VectorXd* weights,
    const std::vector<Eigen::VectorXi>* clusters,
    const std::vector<detail::HeterogeneousSlopeTerm>* slopes) {
    AttemptTransaction attempt(*this);
    const bool cuda_execution_required = require_cuda_compatible_method(options_, fes.size());
    if (y.size() == 0) {
        throw std::runtime_error("Outcome vector must be non-empty");
    }
    if (X.rows() != y.size()) {
        throw std::runtime_error("X must have the same number of rows as y");
    }
    const int nobs_full = static_cast<int>(y.size());
    // Released on every exit path; a nested partial_out() acts on this record.
    detail::AutoTeamRegistration team_registration;
    const ThreadResolution preprocessing_thread_resolution =
        coordinate_auto_team(
            resolve_threads(nobs_full, static_cast<int>(fes.size())),
            nobs_full, static_cast<int>(fes.size()), team_registration,
            false);
    const int validation_threads = preprocessing_thread_resolution.effective;
    require_finite_vector(y, "y", validation_threads);
    require_finite_matrix(X, "X", validation_threads);
    for (const auto& fe : fes) {
        if (fe.size() != y.size()) {
            throw std::runtime_error(
                "Each fixed-effect vector must have the same length as y");
        }
        require_nonnegative_ids(fe, "fixed-effect IDs", validation_threads);
    }
    if (weights && weights->size() != y.size()) {
        throw std::runtime_error("Weights must have the same length as y");
    }
    int zero_weight_count = 0;
    if (weights && !options_.weights_are_frequencies) {
        // Analytic weights must be IEEE-finite and non-negative (re-audit
        // R-03): one negative or NaN value among many silently corrupts
        // every weighted moment while the only prior guard â a positive
        // total â still passes. Zero remains allowed (a zero-weight row
        // contributes nothing). ieee_finite is bit-level, immune to
        // -ffast-math folding std::isfinite into a constant. Frequency
        // weights keep their stricter positive-integer validation.
        const double* w_chk = weights->data();
        const Eigen::Index n_w = weights->size();
        for (Eigen::Index i = 0; i < n_w; ++i) {
            if (!hdfe::detail::ieee_finite(w_chk[i]) || w_chk[i] < 0.0) {
                throw std::runtime_error(
                    "weights must be finite and non-negative");
            }
            zero_weight_count += (detail::ieee_bits_detail::bits(w_chk[i]) &
                                  UINT64_C(0x7fffffffffffffff)) == 0;
        }
    }
    gpu_used_ = false;
    gpu_status_code_ = 0;
    gpu_attempted_ = false;
    gpu_absorption_converged_ = false;
    gpu_absorption_iterations_ = 0;
    cuda_tail_code_ = 0;
    if (clusters) {
        for (const auto& c : *clusters) {
            if (c.size() != y.size()) {
                throw std::runtime_error("Clusters must have the same length as y");
            }
            require_nonnegative_ids(c, "cluster IDs", validation_threads);
        }
    }
    const std::vector<detail::HeterogeneousSlopeTerm> empty_slopes;
    const std::vector<detail::HeterogeneousSlopeTerm>* slopes_in =
        slopes ? slopes : &empty_slopes;
    const bool has_slopes = slopes_in && !slopes_in->empty();
    if (has_slopes && fes.empty()) {
        throw std::runtime_error("Heterogeneous slopes require at least one absorbed FE");
    }
    if (has_slopes) {
        for (const auto& slope : *slopes_in) {
            if (slope.fe_index < 0 || slope.fe_index >= static_cast<int>(fes.size())) {
                throw std::runtime_error("Heterogeneous slope FE index out of range");
            }
            if (slope.values.size() != y.size()) {
                throw std::runtime_error("Heterogeneous slope variable must have the same length as y");
            }
            require_finite_vector(
                slope.values, "heterogeneous slope values", validation_threads);
        }
    }

    if (zero_weight_count) {
        PositiveWeightInput sample(y, X, fes, *weights, clusters, nullptr, slopes, zero_weight_count);
        auto result = partial_out(sample.y, sample.X, sample.fes, &sample.weights,
            sample.clusters ? &*sample.clusters : nullptr,
            sample.slopes ? &*sample.slopes : nullptr);
        for (int i = 0; i < results_.sample_index.size(); ++i)
            results_.sample_index[i] = sample.rows.at(static_cast<std::size_t>(results_.sample_index[i]));
        attempt.commit(LifecycleState::PartialReady);
        return result;
    }

    const bool has_fes = !fes.empty();
    auto env_option_set = [](const char* name) {
        const char* value = std::getenv(name);
        return value && *value != '\0';
    };
    const bool mobility_config_requested =
        env_option_set("XHDFE_MOBILITY_PROFILE") ||
        env_option_set("XHDFE_MOBILITY_MODE");
    const bool absorption_config_requested =
        env_option_set("XHDFE_ABSORPTION_CACHE") ||
        env_option_set("XHDFE_ABSORPTION_CACHE_MODE");
    MobilityProfileConfig mobility_cfg;
    mobility_cfg.mode = "off";
    if (mobility_config_requested) {
        mobility_cfg = load_mobility_profile_config();
    }
    AbsorptionCacheConfig abs_cache_cfg;
    abs_cache_cfg.mode = "off";
    if (absorption_config_requested) {
        abs_cache_cfg = load_absorption_cache_config();
    }
    const FeStructureCacheConfig fe_cache_cfg = load_fe_structure_cache_config();
    std::vector<std::int64_t> integer_frequency_weights;
    const std::int64_t nobs_full_frequency =
        (options_.weights_are_frequencies && weights)
            ? checked_frequency_weight_sum(
                  *weights,
                  (options_.drop_singletons && has_fes)
                      ? &integer_frequency_weights
                      : nullptr)
            : static_cast<std::int64_t>(nobs_full);
    const double nobs_full_effective =
        static_cast<double>(nobs_full_frequency);
    int singletons_dropped_rows = 0;
    auto current_nobs_effective = [&](Eigen::Index row_count) -> double {
        if (options_.weights_are_frequencies && weights) {
            const std::int64_t kept_frequency =
                nobs_full_frequency -
                static_cast<std::int64_t>(singletons_dropped_rows);
            return static_cast<double>(kept_frequency);
        }
        return static_cast<double>(row_count);
    };

    double singletons_dropped_effective = 0.0;
    detail::ParallelWorkObserver preprocessing_observer;
    int preprocessing_threads_used = 1;
    int preprocessing_parallel_workers_active = 1;
    bool preprocessing_parallel_observed = false;
    std::vector<int> kept_idx;
    std::optional<Eigen::VectorXd> y_work;
    std::optional<Eigen::MatrixXd> X_work;
    std::optional<std::vector<Eigen::VectorXi>> fes_work;
    std::optional<Eigen::VectorXd> weights_work;
    std::optional<std::vector<Eigen::VectorXi>> clusters_work;
    std::optional<std::vector<detail::HeterogeneousSlopeTerm>> slopes_work;

    FeStructureCache fe_cache;
    bool fe_cache_hit = false;
    FeStructureDigest fe_cache_signature{};
    bool fe_cache_signature_ready = false;
    auto ensure_fe_cache_signature = [&]() {
        if (!fe_cache_signature_ready) {
            fe_cache_signature = hash_fe_structure_cache_signature(
                fes, weights, options_.drop_singletons, options_.weights_are_frequencies,
                preprocessing_thread_resolution.effective, parallel_observer_.get());
            fe_cache_signature_ready = true;
        }
    };

    auto choose_method_used = [&](std::size_t dims,
                                  int threads,
                                  const HdfeOptions& tuned) -> AbsorptionMethod {
        if (tuned.absorption_method != AbsorptionMethod::Auto) {
            return tuned.absorption_method;
        }
        if (dims <= 1) {
            return AbsorptionMethod::GaussSeidel;
        }
        if (dims == 2) {
            return AbsorptionMethod::SymmetricGaussSeidel;
        }
        if (threads >= static_cast<int>(2 * dims)) {
            return AbsorptionMethod::Jacobi;
        }
        if (tuned.symmetric_sweep && dims > 1) {
            return AbsorptionMethod::SymmetricGaussSeidel;
        }
        return AbsorptionMethod::GaussSeidel;
    };

    auto run_partial = [&](const Eigen::Ref<const Eigen::VectorXd>& y_use,
                           const Eigen::Ref<const Eigen::MatrixXd>& X_use,
                           const std::vector<Eigen::VectorXi>& fes_use,
                           const Eigen::VectorXd* w_ptr,
                           const std::vector<Eigen::VectorXi>* c_ptr,
                           const std::vector<detail::HeterogeneousSlopeTerm>* slopes_use) -> detail::AbsorptionResult {
        detail::additive_cell_projection::ScopedPublicAutoRequest additive_request(
            options_.absorption_method==AbsorptionMethod::Auto);
        const ThreadResolution thread_resolution = coordinate_auto_team(
            resolve_threads(static_cast<int>(y_use.size()),
                            static_cast<int>(fes_use.size())),
            static_cast<int>(y_use.size()), static_cast<int>(fes_use.size()),
            team_registration, true);
        begin_parallel_observation(thread_resolution);
        const int threads = thread_resolution.effective;
        ScopedParallelRuntime parallel_runtime(
            threads, thread_resolution.capacity);

        HdfeOptions tuned = options_;
        tuned.num_threads_explicit = options_.num_threads > 0;
        tuned.parallel_observer = parallel_observer_.get();
        tuned.num_threads = threads;
        const std::vector<detail::HeterogeneousSlopeTerm>& slope_terms =
            slopes_use ? *slopes_use : empty_slopes;
        tuned.ordinary_krylov_parity_floor =
            options_.ordinary_krylov_parity_floor && slope_terms.empty();
        // partial_out/xfepout is explicitly outside the bounded Auto retry
        // product contract.
        tuned.ordinary_auto_routing_retry = false;
        tuned.ordinary_auto_early_routing = false;
        const bool has_slopes_use = !slope_terms.empty();
        const bool cache_profile_enabled =
            !has_slopes_use &&
            (mobility_cfg.mode != "off" || abs_cache_cfg.mode != "off");
        const bool allow_weighted_repair = options_.partial_out_allow_mlsmr_repair &&
            w_ptr != nullptr && !options_.weights_are_frequencies &&
            (fes_use.size() == 2 || fes_use.size() == 3) && !has_slopes_use &&
            !tuned.retain_fixed_effects && !tuned.save_groupvar &&
            tuned.tolerance_mode == ToleranceMode::ReghdfeComparable &&
            !mobility_gpu_backend_selected();
        AbsorptionMethod partial_out_primary_method = AbsorptionMethod::Auto;

        auto solve_absorption = [&]() {
            partial_out_primary_method = choose_method_used(fes_use.size(), threads, tuned);
            detail::AbsorptionResult solved =
                detail::absorb_fixed_effects_v6(
                    y_use, X_use, fes_use, w_ptr, tuned,
                    AbsorptionMethod::Auto, slope_terms);
            if (!solved.cuda_projection_moments_met) {
                if (options_.partial_out_allow_mlsmr_repair &&
                    detail::repair_cuda_projection(y_use, X_use, fes_use, w_ptr, tuned, solved)) {
                    method_used_ = krylov_method_used(solved);
                    return solved;
                }
                solved.precision_certified = false;
                method_used_ = partial_out_primary_method;
                return solved;
            }
            const double effective_tolerance =
                tuned.tolerance_mode == ToleranceMode::ReghdfeComparable
                    ? std::min(tuned.tol, 1e-9) : tuned.tol;
            const double necessary_limit = std::max(
                8.0 * std::max(0.0, effective_tolerance),
                64.0 * std::numeric_limits<double>::epsilon());
            if (solved.converged && !solved.precision_certified &&
                hdfe::detail::ieee_finite(solved.abs_residual_rel) &&
                solved.abs_residual_rel > necessary_limit && w_ptr == nullptr &&
                slope_terms.empty() && solved.iterations < tuned.max_iter) {
                // One continuation at the caller's unchanged method/target.
                // Only an actual necessary-check failure enters this branch.
                HdfeOptions continuation = tuned;
                continuation.max_iter -= solved.iterations;
                detail::AbsorptionResult refined = detail::absorb_fixed_effects_v6(
                    solved.y_tilde, solved.X_tilde, fes_use, nullptr, continuation,
                    AbsorptionMethod::Auto, slope_terms);
                refined.iterations += solved.iterations;
                refined.gpu_absorption_iterations += solved.gpu_absorption_iterations;
                detail::certify_absorption_result(
                    y_use, X_use, fes_use, nullptr, tuned, slope_terms, refined, nullptr, true);
                solved = std::move(refined);
            }
            if (allow_weighted_repair && !tuned.use_sparse_solver && !tuned.use_krylov &&
                partial_out_primary_method != AbsorptionMethod::Mlsmr && !solved.mlsmr_used &&
                solved.converged && !solved.precision_certified &&
                hdfe::detail::ieee_finite(solved.abs_residual_rel) &&
                solved.abs_residual_rel > necessary_limit && solved.iterations < tuned.max_iter) {
                HdfeOptions repair = tuned;
                repair.absorption_method = AbsorptionMethod::Mlsmr;
                repair.max_iter -= solved.iterations;
                // Reuse the original columns and the weights. The primary
                // transformed columns must not be weighted a second time.
                detail::AbsorptionResult refined = detail::absorb_fixed_effects_v6(
                    y_use, X_use, fes_use, w_ptr, repair, AbsorptionMethod::Mlsmr, slope_terms);
                refined.iterations += solved.iterations;
                if (refined.converged && refined.precision_certified) {
                    method_used_ = AbsorptionMethod::Mlsmr;
                    return refined;
                }
                solved.iterations = refined.iterations;
            }
            method_used_ = solved.mlsmr_used && solved.gpu_used
                ? krylov_method_used(solved) : partial_out_primary_method;
            if (has_slopes_use && method_used_ == AbsorptionMethod::Jacobi) {
                method_used_ = fes_use.size() > 1
                                   ? AbsorptionMethod::SymmetricGaussSeidel
                                   : AbsorptionMethod::GaussSeidel;
            }
            return solved;
        };

        detail::AbsorptionResult absorption;
        bool cache_hit = false;
        if (!cache_profile_enabled) {
            // Preserve the cache-off hot path exactly: no signature, profile,
            // cache allocation, read, or write is attempted.
            absorption = solve_absorption();
        } else {
            MobilityHint mobility_hint;
            bool have_mobility_hint = false;
            bool mobility_profile_match = false;
            MobilityProfile profile;
            bool have_profile = false;
            if (mobility_cfg.mode == "read" || mobility_cfg.mode == "auto") {
                have_profile = load_mobility_profile(mobility_cfg.path, profile);
            }
            if (have_profile && profile.profile_kind == "standard") {
                bool match = false;
                if (profile.signature != 0 || profile.signature_canon != 0) {
                    const std::uint64_t sig =
                        hash_fe_signature(fes_use, options_.drop_singletons);
                    match =
                        (profile.signature != 0 && profile.signature == sig) ||
                        (profile.signature_canon != 0 &&
                         profile.signature_canon == sig);
                }
                if (!match && fe_cache_hit && profile.signature != 0) {
                    const std::vector<int>* kept_ptr =
                        (options_.drop_singletons && !kept_idx.empty())
                            ? &kept_idx
                            : nullptr;
                    const std::uint64_t sig_raw =
                        hash_fe_signature_filtered(
                            fes, kept_ptr, options_.drop_singletons);
                    match = profile.signature == sig_raw;
                }
                if (match) {
                    mobility_hint = build_standard_mobility_hint(profile);
                    have_mobility_hint = true;
                    mobility_profile_match = true;
                }
            }
            if (have_mobility_hint && !mobility_hint.sweep_order.empty()) {
                tuned.sweep_order_override = mobility_hint.sweep_order;
            }
            if (have_mobility_hint && mobility_hint.force_symmetric &&
                options_.absorption_method == AbsorptionMethod::Auto &&
                !options_.symmetric_sweep) {
                tuned.symmetric_sweep = true;
            }
            if (have_mobility_hint && !gpu_backend_env_requested() &&
                options_.absorption_method == AbsorptionMethod::Auto &&
                !options_.use_krylov && !options_.use_sparse_solver) {
                if (mobility_hint.use_krylov) {
                    tuned.use_krylov = true;
                    tuned.use_sparse_solver = false;
                } else if (mobility_hint.use_sparse) {
                    tuned.use_sparse_solver = true;
                    tuned.use_krylov = false;
                }
            }

            bool allow_profile_write =
                mobility_cfg.mode == "write" ||
                (mobility_cfg.mode == "auto" &&
                 mobility_cfg.allow_auto_write && !mobility_profile_match);
            bool allow_cache_read = false;
            bool allow_cache_write = false;
            std::string cache_path;
            if (abs_cache_cfg.mode_set) {
                if (abs_cache_cfg.mode != "off") {
                    if (!abs_cache_cfg.path.empty()) {
                        cache_path = abs_cache_cfg.path;
                    } else if (mobility_cfg.mode != "off") {
                        cache_path = absorption_cache_path(mobility_cfg.path);
                    }
                    allow_cache_read =
                        abs_cache_cfg.mode == "read" ||
                        abs_cache_cfg.mode == "auto";
                    allow_cache_write =
                        abs_cache_cfg.mode == "write" ||
                        (abs_cache_cfg.mode == "auto" &&
                         abs_cache_cfg.allow_auto_write);
                    if (cache_path.empty()) {
                        allow_cache_read = false;
                        allow_cache_write = false;
                    }
                }
            } else if (abs_cache_cfg.mode != "off" &&
                       !abs_cache_cfg.path.empty()) {
                allow_cache_read =
                    abs_cache_cfg.mode == "read" ||
                    abs_cache_cfg.mode == "auto";
                allow_cache_write =
                    abs_cache_cfg.mode == "write" ||
                    (abs_cache_cfg.mode == "auto" &&
                     abs_cache_cfg.allow_auto_write);
                cache_path = abs_cache_cfg.path;
            } else {
                allow_cache_read =
                    mobility_cfg.mode == "read" ||
                    mobility_cfg.mode == "auto";
                allow_cache_write =
                    mobility_cfg.mode == "write" ||
                    (mobility_cfg.mode == "auto" &&
                     mobility_cfg.allow_auto_write);
                cache_path = absorption_cache_path(mobility_cfg.path);
            }

            // The native partial-out result may contain captured alphas.
            // A transform-only entry cannot supply them.
            if (tuned.retain_fixed_effects) {
                allow_cache_read = false;
                allow_cache_write = false;
            }
            AbsorptionCacheKey cache_key;
            bool cache_key_ready = false;
            const HdfeOptions cache_key_options = tuned;
            auto make_cache_key = [&](bool require_cpu_refined) {
                // Structure hits expose canonical group IDs. Hash the same
                // representation on a cold call with arbitrary labels.
                std::vector<Eigen::VectorXi> canonical_fes;
                canonical_fes.reserve(fes_use.size());
                for (const auto& fe : fes_use) {
                    FeIndexerLite indexer = build_indexer_lite(fe);
                    Eigen::VectorXi ids(
                        static_cast<int>(indexer.group_ids.size()));
                    for (int i = 0; i < ids.size(); ++i) {
                        ids(i) = indexer.group_ids[
                            static_cast<std::size_t>(i)];
                    }
                    canonical_fes.push_back(std::move(ids));
                }
                return hash_absorption_signature(
                    y_use, X_use, canonical_fes, w_ptr, cache_key_options,
                    allow_weighted_repair ? kWeightedPartialOutRepairCacheGeneration
                                          : kAbsorptionSolveContractGeneration,
                    nullptr, /*instrumented=*/false, /*capture=*/false,
                    /*e1_enabled=*/false, require_cpu_refined);
            };
            auto ensure_cache_key = [&]() {
                if (!cache_key_ready) {
                    cache_key = make_cache_key(false);
                    cache_key_ready = true;
                }
            };

            if (allow_cache_read && !cache_path.empty() &&
                !mobility_gpu_backend_selected()) {
                ensure_cache_key();
                AbsorptionCacheRecord cached;
                auto decode = [&](const AbsorptionCacheKey& key) {
                    return read_absorption_cache(
                        cache_path, key,
                        static_cast<int>(y_use.size()),
                        static_cast<int>(X_use.cols()),
                        static_cast<int>(X_use.cols()),
                        static_cast<int>(fes_use.size()), cached);
                };
                bool decoded = decode(cache_key);
                if (!decoded && may_read_refined_v5(cache_path, cache_key)) {
                    try {
                        decoded = decode(make_cache_key(true));
                    } catch (const std::bad_alloc&) {
                        // An inability to hash a historical candidate means a miss.
                    }
                }
                if (decoded && cached.converged) {
                    absorption.y_tilde = std::move(cached.y_tilde);
                    absorption.X_tilde = std::move(cached.X_tilde);
                    absorption.fe_levels = std::move(cached.fe_levels);
                    absorption.sweep_order_used =
                        std::move(cached.sweep_order);
                    absorption.iterations = cached.iterations;
                    absorption.converged = cached.converged;
                    absorption.krylov_internal_tolerance =
                        cached.krylov_internal_tolerance;
                    absorption.krylov_max_final_backward_error =
                        cached.krylov_max_final_backward_error;
                    absorption.krylov_max_condition =
                        cached.krylov_max_condition;
                    absorption.krylov_max_condition_times_backward_error =
                        cached.krylov_max_condition_times_backward_error;
                    absorption.auto_routing_retry_policy_enabled =
                        cached.auto_routing_retry_policy_enabled;
                    absorption.auto_routing_retry_eligible =
                        cached.auto_routing_retry_eligible;
                    absorption.auto_routing_retry_fired =
                        cached.auto_routing_retry_fired;
                    absorption.auto_routing_retry_status =
                        cached.auto_routing_retry_status;
                    absorption.auto_routing_retry_primary_method =
                        cached.auto_routing_retry_primary_method;
                    absorption.auto_routing_retry_primary_iterations =
                        cached.auto_routing_retry_primary_iterations;
                    absorption.auto_routing_retry_primary_abs_residual_rel =
                        cached.auto_routing_retry_primary_abs_residual_rel;
                    absorption.auto_routing_retry_iterations =
                        cached.auto_routing_retry_iterations;
                    absorption.auto_routing_retry_abs_residual_rel =
                        cached.auto_routing_retry_abs_residual_rel;
                    absorption.auto_routing_retry_elapsed_seconds =
                        cached.auto_routing_retry_elapsed_seconds;
                    method_used_ = cached.method;
                    detail::certify_absorption_result(
                        y_use, X_use, fes_use, w_ptr, tuned, slope_terms,
                        absorption);
                    if (absorption.precision_certified) {
                        cache_hit = true;
                        reduced_pcg_fine_.cache_hit = true;  // package D
                        allow_profile_write = false;
                        // As in fit(): a transform the tier published keeps its
                        // public name; this call, which never enters the tier,
                        // holds the route solve_absorption() would leave.
                        if (method_used_ == AbsorptionMethod::ReducedPcg) {
                            method_used_ = choose_method_used(fes_use.size(), threads, tuned);
                            if (has_slopes_use && method_used_ == AbsorptionMethod::Jacobi) {
                                method_used_ = fes_use.size() > 1
                                                   ? AbsorptionMethod::SymmetricGaussSeidel
                                                   : AbsorptionMethod::GaussSeidel;
                            }
                            reduced_pcg_status_ = 1;
                        }
                        if (detail::reduced_pcg_effective(options_))
                            reduced_pcg_reason_ = reduced_pcg_status_ == 1 ? "none" : "cache";
                    } else {
                        absorption = detail::AbsorptionResult{};
                    }
                }
            }

            if (!cache_hit) {
                absorption = solve_absorption();
                if (allow_cache_write && !cache_path.empty() &&
                    absorption.converged && absorption.precision_certified) {
                    ensure_cache_key();
                    write_absorption_cache(
                        cache_path, cache_key, absorption.y_tilde,
                        absorption.X_tilde, absorption.fe_levels,
                        absorption.sweep_order_used,
                        static_cast<int>(X_use.cols()), method_used_,
                        absorption.iterations, absorption.converged,
                        absorption.krylov_internal_tolerance,
                        absorption.krylov_max_final_backward_error,
                        absorption.krylov_max_condition,
                        absorption.krylov_max_condition_times_backward_error,
                        absorption);
                }
                if (allow_profile_write && absorption.converged &&
                    absorption.precision_certified) {
                    MobilityProfile written = compute_mobility_profile(
                        fes_use, nobs_full, singletons_dropped_rows,
                        options_.drop_singletons,
                        absorption.sweep_order_used);
                    if (options_.absorption_method == AbsorptionMethod::Auto &&
                        !options_.symmetric_sweep) {
                        // A repair of these columns is not a geometry-based first choice.
                        written.suggest_method = partial_out_primary_method;
                        written.suggest_symmetric =
                            partial_out_primary_method ==
                            AbsorptionMethod::SymmetricGaussSeidel;
                    }
                    written.suggest_use_sparse = tuned.use_sparse_solver;
                    written.suggest_use_krylov = tuned.use_krylov;
                    write_mobility_profile(mobility_cfg.path, written);
                }
            }
        }
        // Point 14: as in fit(), once the published transform is final.
        krylov_pcg_published_ = tuned.use_krylov && absorption.krylov_pcg_used;
        gpu_used_ = absorption.gpu_used;
        gpu_status_code_ = absorption.gpu_status_code;
        gpu_attempted_ = absorption.gpu_attempted;
        gpu_absorption_converged_ = absorption.gpu_absorption_converged;
        gpu_absorption_iterations_ = absorption.gpu_absorption_iterations;
        cuda_tail_code_ = absorption.cuda_tail;

        // Populate a minimal results_ object for Stata/Python consumers that expect e(df_a),
        // singleton counts, and convergence diagnostics.
        if (read_env_bool("XHDFE_DEBUG_SOLVER").value_or(false)) {
            std::cerr << "xhdfe partial_out: cache_hit=" << (cache_hit ? 1 : 0) << "\n";
        }
        results_.coefficients.resize(0);
        results_.std_errors.resize(0);
        results_.tvalues.resize(0);
        results_.pvalues.resize(0);
        results_.conf_int.resize(0, 0);
        results_.covariance.resize(0, 0);
        results_.residuals.resize(0);
        results_.omitted_reason.clear();
        results_.fe_collinear_ss_ratio.resize(0);
        results_.nobs = static_cast<int>(y_use.size());
        results_.nobs_full = results_.nobs;
        results_.num_singletons = 0;
        results_.nobs_effective =
            current_nobs_effective(results_.nobs);
        results_.nobs_full_effective = results_.nobs_effective;
        results_.num_singletons_effective = 0.0;
        results_.sample_index.resize(0);
        results_.df_resid = 0.0;
        results_.df_resid_unadj = 0.0;
        results_.df_m = 0.0;
        results_.df_a = 0.0;
        results_.df_a_levels = 0.0;
        results_.df_a_exact = 0.0;
        results_.df_a_nested = 0.0;
        results_.r2 = 0.0;
        results_.r2_within = 0.0;
        results_.sigma2 = 0.0;
        results_.rss = 0.0;
        results_.tss = 0.0;
        results_.tss_within = 0.0;
        results_.fe_num_levels = absorption.fe_levels;
        results_.fe_base_levels = absorption.fe_levels;
        results_.fe_base_redundant.clear();
        results_.fe_redundant.clear();
        results_.fe_num_coefs.clear();
        results_.fe_inexact.clear();
        results_.fe_nested.clear();
        results_.num_iterations = absorption.iterations;
        results_.groupvar.resize(0);
        results_.fe_effects.clear();
        results_.fe_save_effects.clear();
        results_.fe_recovery_iterations = 0;
        results_.fe_recovery_max_delta = 0.0;
        results_.fe_recovery_converged = true;
        results_.converged = absorption.converged;
        results_.abs_residual = absorption.abs_residual;
        results_.abs_residual_rel = absorption.abs_residual_rel;
        results_.krylov_internal_tolerance =
            absorption.krylov_internal_tolerance;
        results_.krylov_max_final_backward_error =
            absorption.krylov_max_final_backward_error;
        results_.krylov_max_condition = absorption.krylov_max_condition;
        results_.krylov_max_condition_times_backward_error =
            absorption.krylov_max_condition_times_backward_error;
        results_.auto_routing_retry_policy_enabled =
            absorption.auto_routing_retry_policy_enabled;
        results_.auto_routing_retry_eligible =
            absorption.auto_routing_retry_eligible;
        results_.auto_routing_retry_fired =
            absorption.auto_routing_retry_fired;
        results_.auto_routing_retry_status =
            absorption.auto_routing_retry_status;
        results_.auto_routing_retry_primary_method =
            absorption.auto_routing_retry_primary_method;
        results_.auto_routing_retry_primary_iterations =
            absorption.auto_routing_retry_primary_iterations;
        results_.auto_routing_retry_primary_abs_residual_rel =
            absorption.auto_routing_retry_primary_abs_residual_rel;
        results_.auto_routing_retry_iterations =
            absorption.auto_routing_retry_iterations;
        results_.auto_routing_retry_abs_residual_rel =
            absorption.auto_routing_retry_abs_residual_rel;
        results_.auto_routing_retry_elapsed_seconds =
            absorption.auto_routing_retry_elapsed_seconds;
        results_.slope_block_checked = absorption.slope_block_checked;
        results_.slope_block_residual_rel = absorption.slope_block_residual_rel;
        results_.slope_block_frobenius_rel = absorption.slope_block_frobenius_rel;
        results_.slope_block_rms_rel = absorption.slope_block_rms_rel;
        results_.slope_block_max_rel = absorption.slope_block_max_rel;
        results_.slope_block_skipped_max_rel =
            absorption.slope_block_skipped_max_rel;
        results_.slope_certificate_worst_fe =
            absorption.slope_certificate_worst_fe;
        results_.slope_certificate_worst_moment =
            absorption.slope_certificate_worst_moment;
        results_.slope_accuracy_retry_stages =
            absorption.slope_accuracy_retry_stages;
        results_.slope_accuracy_retry_iterations =
            absorption.slope_accuracy_retry_iterations;
        results_.slope_internal_tolerance = absorption.slope_internal_tolerance;
        results_.precision_certified = absorption.precision_certified;
        results_.num_clusters = 0;
        results_.cluster_counts.clear();
        results_.cluster_combo_counts.clear();
        results_.cluster_scale = 1.0;

        // Degrees-of-freedom adjustments (hdfe-style; mirrors the reghdfe logic in fit()).
        std::int64_t df_a_levels = 0;  // E3: 64 bits, as in fit()
        std::int64_t df_a_exact = 0;
        std::int64_t nested_dof_levels = 0;  // round 11 (E3): 64 bits, to their doubles
        std::int64_t nested_dof_coefs = 0;
        if (!fes_use.empty()) {
            Eigen::VectorXi groupvar;
            Eigen::VectorXi* groupvar_ptr = options_.save_groupvar ? &groupvar : nullptr;
            FeComponentStats* first_pair_stats_ptr =
                options_.capture_first_pair_component_stats
                    ? &first_pair_component_stats_
                    : nullptr;
            const DofAdjustmentMethod mobility_method =
                options_.dof_mobility_groups
                    ? options_.dof_method
                    : DofAdjustmentMethod::None;
            std::vector<uint8_t> slope_only_flags(fes_use.size(), 0);
            for (const auto& slope : slope_terms) {
                if (!slope.include_intercept &&
                    slope.fe_index >= 0 &&
                    slope.fe_index < static_cast<int>(slope_only_flags.size())) {
                    slope_only_flags[static_cast<std::size_t>(slope.fe_index)] = 1;
                }
            }
            FeDofInfo dof =
                compute_fe_dof_for_intercept_dims(
                    fes_use, absorption.fe_levels, mobility_method,
                    slope_only_flags, groupvar_ptr, tuned.num_threads,
                    first_pair_stats_ptr, w_ptr, tuned.num_threads_explicit);
            std::vector<uint8_t> nested_flags(dof.levels.size(), 0);
            if (options_.dof_adjust_clusters && tuned.se_type == StandardErrorType::Cluster && c_ptr &&
                !c_ptr->empty()) {
                for (const auto& cl : *c_ptr) {
                    for (std::size_t d = 0; d < fes_use.size(); ++d) {
                        if (nested_flags[d]) {
                            continue;
                        }
                        if (fe_nested_within_cluster(fes_use[d], cl)) {
                            nested_flags[d] = 1;
                        }
                    }
                }
            }

            // If some fixed effects are nested within the clustering variable, reghdfe does not
            // use them to compute mobility-group redundancies for the remaining dimensions.
            if (options_.dof_method != DofAdjustmentMethod::None) {
                bool any_nested = false;
                for (std::size_t d = 0; d < nested_flags.size(); ++d) {
                    if (nested_flags[d]) {
                        any_nested = true;
                        break;
                    }
                }
                if (any_nested) {
                    std::vector<Eigen::VectorXi> fes_nonnested;
                    std::vector<int> levels_nonnested;
                    std::vector<int> map_nonnested;
                    std::vector<uint8_t> slopes_nonnested;
                    fes_nonnested.reserve(fes_use.size());
                    levels_nonnested.reserve(fes_use.size());
                    map_nonnested.reserve(fes_use.size());
                    slopes_nonnested.reserve(fes_use.size());
                    for (std::size_t d = 0; d < fes_use.size(); ++d) {
                        if (nested_flags[d]) {
                            continue;
                        }
                        fes_nonnested.push_back(fes_use[d]);
                        levels_nonnested.push_back(dof.levels[d]);
                        map_nonnested.push_back(static_cast<int>(d));
                        slopes_nonnested.push_back(slope_only_flags[d]);
                    }
                    if (!fes_nonnested.empty()) {
                        const FeDofInfo dof_nonnested =
                            compute_fe_dof_for_intercept_dims(
                                fes_nonnested, levels_nonnested, mobility_method,
                                slopes_nonnested, nullptr, tuned.num_threads,
                                nullptr, nullptr, tuned.num_threads_explicit);
                        for (std::size_t pos = 0; pos < map_nonnested.size(); ++pos) {
                            const int orig = map_nonnested[pos];
                            dof.redundant[static_cast<std::size_t>(orig)] =
                                dof_nonnested.redundant[pos];
                        }
                    }
                }
            }
            std::int64_t nested_total = 0;  // round 11 (E3): a sum of levels, in 64 bits
            if (options_.dof_method != DofAdjustmentMethod::None) {
                for (std::size_t d = 0; d < dof.levels.size(); ++d) {
                    if (nested_flags[d]) {
                        nested_total += dof.levels[d];
                        dof.redundant[d] = dof.levels[d];
                        dof.num_coefs[d] = 0;
                    }
                }
                std::vector<int> intercept_index;
                intercept_index.reserve(dof.levels.size());
                for (std::size_t d = 0; d < dof.levels.size(); ++d) {
                    if (!nested_flags[d] && !slope_only_flags[d]) {
                        intercept_index.push_back(static_cast<int>(d));
                    }
                }
                if (!intercept_index.empty()) {
                    bool skip_next = (nested_total == 0);
                    for (const int idx : intercept_index) {
                        if (skip_next) {
                            skip_next = false;
                            continue;
                        }
                        if (dof.redundant[static_cast<std::size_t>(idx)] < 1) {
                            dof.redundant[static_cast<std::size_t>(idx)] = 1;
                        }
                    }
                }
                for (std::size_t d = 0; d < dof.levels.size(); ++d) {
                    dof.num_coefs[d] =
                        std::max(0, dof.levels[d] - dof.redundant[d]);
                }
            } else {
                bool skip_first_intercept = true;
                for (std::size_t d = 0; d < dof.levels.size(); ++d) {
                    if (slope_only_flags[d]) {
                        continue;
                    }
                    if (skip_first_intercept) {
                        skip_first_intercept = false;
                        continue;
                    }
                    dof.redundant[d] = std::max(dof.redundant[d], 1);
                }
                for (std::size_t d = 0; d < dof.levels.size(); ++d) {
                    dof.num_coefs[d] =
                        std::max(0, dof.levels[d] - dof.redundant[d]);
                }
            }
            dof.inexact.assign(dof.levels.size(), 0);
            const int exact_intercept_dims = options_.dof_mobility_groups ? 2 : 1;
            int intercept_count = 0;
            for (std::size_t d = 0; d < dof.levels.size(); ++d) {
                if (nested_flags[d] || slope_only_flags[d]) {
                    continue;
                }
                ++intercept_count;
                if (intercept_count > exact_intercept_dims) {
                    dof.inexact[d] = 1;
                }
            }
            const std::vector<int> base_redundant = dof.redundant;
            apply_heterogeneous_slope_dof(
                dof, fes_use, slope_terms, w_ptr, nested_flags,
                options_.dof_adjust_continuous, tuned.num_threads,
                tuned.num_threads_explicit, tuned.parallel_observer);

            df_a_levels = 0;
            df_a_exact = 0;
            for (std::size_t d = 0; d < dof.levels.size(); ++d) {
                df_a_levels += dof.levels[d];
                df_a_exact += dof.num_coefs[d];
            }
            dof.df_a_levels = df_a_levels;
            dof.df_a_exact = df_a_exact;
            dof.df_a = df_a_exact;
            results_.df_a_levels = static_cast<double>(df_a_levels);
            results_.df_a_exact = static_cast<double>(df_a_exact);
            results_.fe_num_levels = dof.levels;
            results_.fe_base_levels = absorption.fe_levels;
            results_.fe_base_redundant = base_redundant;
            results_.fe_redundant = dof.redundant;
            results_.fe_num_coefs = dof.num_coefs;
            results_.fe_inexact = dof.inexact;
            results_.fe_nested.assign(dof.levels.size(), 0);
            if (groupvar_ptr) {
                results_.groupvar = std::move(groupvar);
            }
            if (options_.dof_adjust_clusters && tuned.se_type == StandardErrorType::Cluster && c_ptr &&
                !c_ptr->empty()) {
                nested_dof_coefs += detail::sparse_rank::flagged_sum(nested_flags, [&](std::size_t d) {
                    return nested_coefs_for_heterogeneous_dim(d, slope_terms, dof.num_coefs);
                });
                nested_dof_levels += detail::sparse_rank::flagged_sum(nested_flags, [&](std::size_t d) {
                    return nested_levels_for_heterogeneous_dim(d, slope_terms, absorption.fe_levels, dof.levels);
                });
                for (std::size_t d = 0; d < nested_flags.size(); ++d) {
                    if (nested_flags[d]) {
                        results_.fe_nested[d] = 1;
                    }
                }
            }
        }

        const std::int64_t df_a_report = df_a_exact;
        const std::int64_t nested_report = nested_dof_levels;
        results_.df_a = static_cast<double>(df_a_report);
        results_.df_a_nested = static_cast<double>(nested_report);

        if (detail::ordinary_audit_enabled()) {
            detail::OrdinaryAuditReceipt audit("partial_out",tuned,absorption,cache_hit);
            if (has_slopes_use) audit.unsupported("heterogeneous_slopes");
            else {
                audit.families[0]=detail::run_ordinary_n2_audit(y_use,X_use,fes_use,w_ptr,tuned,absorption,c_ptr,false);
                for(int j=1;j<4;++j) audit.families[j]={detail::OrdinaryAuditFinding::Unsupported,"partial_out_no_ols"};
            }
            audit.emit();
        }
        end_parallel_observation();
        return absorption;
    };

    if (!has_slopes && fe_cache_cfg.mode != "off" && has_fes) {
        const bool allow_read =
            (fe_cache_cfg.mode == "read" || fe_cache_cfg.mode == "auto");
        if (allow_read) {
            ensure_fe_cache_signature();
            fe_cache_hit =
                read_fe_structure_cache(fe_cache_cfg.path, fe_cache_signature, nobs_full,
                                        options_.drop_singletons,
                                        static_cast<int>(fes.size()), fe_cache,
                                        preprocessing_thread_resolution.effective, parallel_observer_.get());
        }
    }

    detail::AbsorptionResult absorption;
    if (fe_cache_hit) {
        if (options_.drop_singletons && fe_cache.nobs < nobs_full) {
            kept_idx = std::move(fe_cache.kept_idx);
            singletons_dropped_rows = nobs_full - fe_cache.nobs;
            y_work = filter_vector(y, kept_idx);
            X_work = filter_rows(X, kept_idx);
            fes_work = std::move(fe_cache.fe_group_ids);

            const Eigen::VectorXd* w_ptr = nullptr;
            if (weights) {
                weights_work = filter_vector(*weights, kept_idx);
                w_ptr = &(*weights_work);
            }

            const std::vector<Eigen::VectorXi>* c_ptr = clusters;
            if (clusters && !clusters->empty()) {
                std::vector<Eigen::VectorXi> clusters_tmp;
                clusters_tmp.reserve(clusters->size());
                for (const auto& c : *clusters) {
                    clusters_tmp.push_back(filter_vector(c, kept_idx));
                }
                clusters_work = std::move(clusters_tmp);
                c_ptr = &(*clusters_work);
            }

            const std::vector<detail::HeterogeneousSlopeTerm>* slopes_use = slopes_in;
            if (has_slopes) {
                slopes_work = filter_slope_terms(*slopes_in, kept_idx);
                slopes_use = &(*slopes_work);
            }
            absorption = run_partial(*y_work, *X_work, *fes_work, w_ptr, c_ptr, slopes_use);
            if (options_.weights_are_frequencies && weights_work) {
                std::int64_t kept_weight = 0;
                for (const int row : kept_idx) {
                    kept_weight += integer_frequency_weights[
                        static_cast<std::size_t>(row)];
                }
                singletons_dropped_effective = static_cast<double>(
                    nobs_full_frequency - kept_weight);
            } else {
                singletons_dropped_effective = static_cast<double>(singletons_dropped_rows);
            }
        } else {
            fes_work = std::move(fe_cache.fe_group_ids);
            absorption = run_partial(y, X, *fes_work, weights, clusters, slopes_in);
        }
    } else if (options_.drop_singletons && has_fes) {
        std::vector<uint8_t> keep;
        if (options_.weights_are_frequencies && weights) {
            keep = compute_keep_mask_drop_singletons_fweights(
                fes, *weights, &singletons_dropped_rows,
                &singletons_dropped_effective,
                preprocessing_thread_resolution.effective,
                preprocessing_thread_resolution.capacity,
                options_.num_threads > 0,
                &integer_frequency_weights,
                &preprocessing_observer);
        } else {
            keep = compute_keep_mask_drop_singletons(fes,
                                                     &singletons_dropped_rows,
                                                     preprocessing_thread_resolution.effective,
                                                     preprocessing_thread_resolution.capacity,
                                                     options_.num_threads > 0,
                                                     &preprocessing_observer);
            singletons_dropped_effective = static_cast<double>(singletons_dropped_rows);
        }
        preprocessing_threads_used =
            std::max(1, preprocessing_observer.max_team_size());
        preprocessing_parallel_workers_active =
            std::max(1, preprocessing_observer.active_workers());
        preprocessing_parallel_observed =
            preprocessing_threads_used > 1 ||
            preprocessing_parallel_workers_active > 1;
        if (singletons_dropped_rows > 0) {
            {
                const RowFilterTeam team{preprocessing_thread_resolution.effective,
                                         options_.num_threads > 0};
                ScopedParallelRuntime filter_runtime(
                    team.threads, preprocessing_thread_resolution.capacity);
                kept_idx = build_keep_indices(keep, team);
                y_work = filter_vector(y, kept_idx, team);
                X_work = filter_rows(X, kept_idx, team);

                std::vector<Eigen::VectorXi> fes_tmp;
                fes_tmp.reserve(fes.size());
                for (const auto& fe : fes) {
                    fes_tmp.push_back(filter_vector(fe, kept_idx, team));
                }
                fes_work = std::move(fes_tmp);

                if (weights) {
                    weights_work = filter_vector(*weights, kept_idx, team);
                }
                if (clusters && !clusters->empty()) {
                    std::vector<Eigen::VectorXi> clusters_tmp;
                    clusters_tmp.reserve(clusters->size());
                    for (const auto& c : *clusters) {
                        clusters_tmp.push_back(filter_vector(c, kept_idx, team));
                    }
                    clusters_work = std::move(clusters_tmp);
                }
                if (has_slopes) {
                    slopes_work = filter_slope_terms(*slopes_in, kept_idx, team);
                }
            }
            const Eigen::VectorXd* w_ptr = weights ? &(*weights_work) : nullptr;
            const std::vector<Eigen::VectorXi>* c_ptr =
                (clusters && !clusters->empty()) ? &(*clusters_work) : clusters;
            const std::vector<detail::HeterogeneousSlopeTerm>* slopes_use =
                has_slopes ? &(*slopes_work) : slopes_in;
            absorption = run_partial(*y_work, *X_work, *fes_work, w_ptr, c_ptr, slopes_use);
        } else {
            absorption = run_partial(y, X, fes, weights, clusters, slopes_in);
        }
    } else {
        absorption = run_partial(y, X, fes, weights, clusters, slopes_in);
    }
    require_accepted_absorption(options_, absorption, "HDFE partial-out");
    require_cuda_execution(cuda_execution_required, absorption);
    if (preprocessing_parallel_observed) {
        if (preprocessing_thread_resolution.effective > threads_effective_) {
            // A registry-limited absorption team keeps its reason (code 6).
            const bool absorption_coordinated =
                thread_limit_code_ == kThreadLimitAutoTeamCoordination;
            threads_effective_ = preprocessing_thread_resolution.effective;
            thread_capacity_ = preprocessing_thread_resolution.capacity;
            openmp_enabled_ = preprocessing_thread_resolution.openmp_enabled;
            thread_limit_code_ = preprocessing_thread_resolution.limit_code;
            thread_limit_reason_ = preprocessing_thread_resolution.limit_reason;
            if (absorption_coordinated) {
                thread_limit_code_ = kThreadLimitAutoTeamCoordination;
                thread_limit_reason_ = kThreadLimitAutoTeamCoordinationReason;
            }
        }
        threads_used_ = std::max(threads_used_, preprocessing_threads_used);
        parallel_workers_active_ =
            std::max(parallel_workers_active_,
                     preprocessing_parallel_workers_active);
    }

    const bool allow_fe_cache_write =
        fe_cache_cfg.mode == "write" ||
        (fe_cache_cfg.mode == "auto" && fe_cache_cfg.allow_auto_write);
    if (!has_slopes && !fe_cache_hit && allow_fe_cache_write && has_fes && !fe_cache_cfg.path.empty()) {
        ensure_fe_cache_signature();
        const std::vector<Eigen::VectorXi>* fes_used =
            fes_work ? &(*fes_work) : &fes;
        if (!fes_used->empty()) {
            std::vector<Eigen::VectorXi> fe_group_ids;
            std::vector<int> num_groups;
            fe_group_ids.reserve(fes_used->size());
            num_groups.reserve(fes_used->size());
            for (const auto& fe : *fes_used) {
                FeIndexerLite idx = build_indexer_lite(fe);
                Eigen::VectorXi ids(static_cast<int>(idx.group_ids.size()));
                for (int i = 0; i < ids.size(); ++i) {
                    ids(i) = idx.group_ids[static_cast<std::size_t>(i)];
                }
                fe_group_ids.push_back(std::move(ids));
                num_groups.push_back(idx.num_groups);
            }
            write_fe_structure_cache(fe_cache_cfg.path, fe_cache_signature, nobs_full,
                                     options_.drop_singletons, kept_idx, num_groups,
                                     fe_group_ids, preprocessing_thread_resolution.effective,
                                     parallel_observer_.get());
        }
    }

    results_.nobs_full = nobs_full;
    results_.num_singletons = singletons_dropped_rows;
    const double nobs_effective =
        current_nobs_effective(results_.nobs);
    results_.nobs_effective = nobs_effective;
    results_.nobs_full_effective = nobs_full_effective;
    results_.num_singletons_effective =
        options_.weights_are_frequencies && weights
            ? static_cast<double>(singletons_dropped_rows)
            : singletons_dropped_effective;
    results_.sample_index.resize(results_.nobs);
    if (!kept_idx.empty()) {
        for (int i = 0; i < results_.nobs; ++i) {
            results_.sample_index(i) = kept_idx[static_cast<std::size_t>(i)];
        }
    } else {
        for (int i = 0; i < results_.nobs; ++i) {
            results_.sample_index(i) = i;
        }
    }

    attempt.commit(LifecycleState::PartialReady);
    return absorption;
}

void HdfeRegressorV11::fit_grouped(const Eigen::Ref<const Eigen::VectorXd>& y,
                                  const Eigen::Ref<const Eigen::MatrixXd>& X,
                                  const std::vector<Eigen::VectorXi>& fes,
                                  const Eigen::VectorXi& group_ids,
                                  const Eigen::VectorXi* individual_ids,
                                  GroupAggregation aggregation,
                                  const Eigen::VectorXd* weights,
                                  const std::vector<Eigen::VectorXi>* clusters) {
    AttemptTransaction attempt(*this);
    slope_solver_diagnostics_.reset_outcome("group");
    detail::ReducedPcgFitScope reduced_pcg_fit_scope(detail::reduced_pcg_effective(options_));
    detail::ScopedN1Capture n1_capture(detail::ordinary_audit_enabled());
    const bool exact_group_dof = options_.dof_method == DofAdjustmentMethod::Exact;
    const bool adjust_group_clusters = options_.dof_adjust_clusters && !exact_group_dof;
    const bool cuda_execution_required = require_cuda_compatible_method(options_, fes.size());
    if (!individual_ids) {
        GroupCollapsedData collapsed =
            collapse_group_long_format(
                y, X, fes, group_ids, nullptr, -1, aggregation, weights,
                options_.weights_are_frequencies, clusters);
        const Eigen::VectorXd* w_ptr = collapsed.weights ? &(*collapsed.weights) : nullptr;
        const std::vector<Eigen::VectorXi>* c_ptr = collapsed.clusters ? &(*collapsed.clusters) : nullptr;
        {
            ScopedBoolOverride disable_group_only_parity_floor(
                options_.ordinary_krylov_parity_floor, false);
            ScopedBoolOverride disable_group_only_auto_retry(
                suppress_auto_routing_retry_, true);
            fit(collapsed.y, collapsed.X, collapsed.standard_fes, w_ptr, c_ptr, nullptr, {});
        }
        if (results_.sample_index.size() != results_.nobs) {
            throw std::runtime_error(
                "group(): estimation sample mapping is incomplete; no estimates returned");
        }
        // Compose the post-singleton group selection with original input rows.
        for (int i = 0; i < results_.sample_index.size(); ++i) {
            const int group_row = results_.sample_index(i);
            if (group_row < 0 || group_row >= static_cast<int>(collapsed.rep_row.size())) {
                throw std::runtime_error(
                    "group(): estimation sample index is outside the group map; no estimates returned");
            }
            results_.sample_index(i) = collapsed.rep_row[static_cast<std::size_t>(group_row)];
        }
        attempt.commit(LifecycleState::StandardReady);
        return;
    }

    const MobilityProfileConfig mobility_cfg = load_mobility_profile_config();

    if (fes.empty()) {
        throw std::runtime_error("fes must include the individual_ids when using group/individual");
    }
    const int individual_fe_index = find_identical_fe(*individual_ids, fes);
    if (individual_fe_index < 0) {
        throw std::runtime_error("individual_ids must also be included in fes");
    }

    if (options_.retain_fixed_effects) {
        throw std::runtime_error("retain_fes is not supported with group/individual fixed effects");
    }

    GroupCollapsedData collapsed = collapse_group_long_format(
        y, X, fes, group_ids, individual_ids, individual_fe_index, aggregation,
        weights, options_.weights_are_frequencies, clusters);
    drop_zero_weight_groups(collapsed, aggregation, options_.weights_are_frequencies);
    const int collapsed_full = static_cast<int>(collapsed.y.size());
    const std::int64_t nobs_full_frequency =
        (options_.weights_are_frequencies && collapsed.weights)
            ? checked_frequency_weight_sum(*collapsed.weights)
            : static_cast<std::int64_t>(collapsed_full);
    const double nobs_full_effective =
        static_cast<double>(nobs_full_frequency);
    int group_singletons_dropped = 0;

    if (options_.drop_singletons) {
        const GroupSingletonDropResult dropped =
            drop_singletons_group_individual(
                collapsed.standard_fes, collapsed.gi,
                options_.weights_are_frequencies && collapsed.weights
                    ? &(*collapsed.weights)
                    : nullptr);
        group_singletons_dropped = dropped.dropped_groups;
        if (dropped.dropped_groups > 0) {
            collapsed =
                filter_group_collapsed(collapsed, dropped.keep_groups, dropped.individual_degrees, aggregation);
        }
    }

    const Eigen::VectorXd* w_ptr = collapsed.weights ? &(*collapsed.weights) : nullptr;
    const std::vector<Eigen::VectorXi>* c_ptr = collapsed.clusters ? &(*collapsed.clusters) : nullptr;
    if (collapsed.y.size() == 0) {
        throw std::runtime_error("no observations remain for estimation");
    }
    const std::int64_t nobs_frequency =
        (options_.weights_are_frequencies && w_ptr)
            ? checked_frequency_weight_sum(*w_ptr)
            : static_cast<std::int64_t>(collapsed.y.size());
    const double nobs_effective =
        static_cast<double>(nobs_frequency);

    const bool has_fes = true;
    const bool drop_intercept = options_.fit_intercept && has_fes;

    Eigen::VectorXd y_work = collapsed.y;
    Eigen::MatrixXd X_work = collapsed.X;
    std::vector<Eigen::VectorXi> standard_fes_work = collapsed.standard_fes;
    hdfe::detail::GroupIndividualStructure gi_work = std::move(collapsed.gi);

    Eigen::MatrixXd design =
        drop_intercept ? X_work : maybe_add_intercept(X_work, options_.fit_intercept);
    const int design_cols = static_cast<int>(design.cols());

    // The grouped design never carries an explicit intercept column: an
    // ordinary FE level or mean-aggregated membership columns (rows summing to
    // one) span the constant. Sum aggregation spans it only through a
    // combination of individual columns that is constant across groups:
    // guaranteed for a uniform team size and scale, otherwise a property of
    // the incidence pattern, decided after the absorption by projecting the
    // ones vector as one separate right-hand side (only in that case). A fit
    // whose absorbed effects do not span the constant has no intercept and is
    // reported as such: no recovered constant, uncentered total sum of squares.
    bool constant_in_span =
        !standard_fes_work.empty() || aggregation == GroupAggregation::Mean ||
        gi_work.num_groups <= 0;
    if (!constant_in_span) {
        const int first_size = gi_work.group_ptr[1] - gi_work.group_ptr[0];
        bool uniform_team = true;
        for (int group = 1; group < gi_work.num_groups && uniform_team; ++group) {
            uniform_team =
                gi_work.group_ptr[group + 1] - gi_work.group_ptr[group] == first_size &&
                (gi_work.group_scale.empty() ||
                 gi_work.group_scale[static_cast<std::size_t>(group)] ==
                     gi_work.group_scale[0]);
        }
        constant_in_span = uniform_team;
    }
    const bool probe_constant = !constant_in_span;

    // One resolution on this path: the lease is taken directly and released
    // on every exit path.
    detail::AutoTeamRegistration team_registration;
    const ThreadResolution thread_resolution = coordinate_auto_team(
        resolve_threads(static_cast<int>(y_work.size()),
                        static_cast<int>(standard_fes_work.size() + 1)),
        static_cast<int>(y_work.size()),
        static_cast<int>(standard_fes_work.size() + 1), team_registration,
        true);
    begin_parallel_observation(thread_resolution);
    const int threads = thread_resolution.effective;
    ScopedParallelRuntime parallel_runtime(
        threads, thread_resolution.capacity);

    HdfeOptions tuned = options_;
    tuned.from_auto =
        options_.absorption_method == AbsorptionMethod::Auto &&
        !options_.symmetric_sweep;
    tuned.num_threads_explicit = options_.num_threads > 0;
    tuned.parallel_observer = parallel_observer_.get();
    tuned.num_threads = threads;
    std::optional<HdfeOptions> grouped_profile_context;
    if (mobility_cfg.mode != "off") {
        grouped_profile_context = tuned;
    }
    std::optional<AbsorptionCacheKey> grouped_profile_signature;
    auto ensure_grouped_profile_signature = [&]() -> const AbsorptionCacheKey& {
        if (!grouped_profile_signature) {
            grouped_profile_signature = hash_grouped_mobility_signature(
                y_work, design, standard_fes_work, gi_work,
                aggregation, w_ptr,
                *grouped_profile_context, collapsed_full,
                group_singletons_dropped);
        }
        return *grouped_profile_signature;
    };

    MobilityHint mobility_hint;
    bool have_mobility_hint = false;
    bool mobility_profile_match = false;
    MobilityProfile profile;
    bool have_profile = false;
    if (mobility_cfg.mode == "read" || mobility_cfg.mode == "auto") {
        if (load_mobility_profile(mobility_cfg.path, profile)) {
            have_profile = true;
        }
    }
    if (have_profile && profile.profile_kind == "group_individual") {
        const AbsorptionCacheKey& expected =
            ensure_grouped_profile_signature();
        const bool match =
            profile.signature != 0 && profile.signature_canon != 0 &&
            profile.signature == expected.sig1 &&
            profile.signature_canon == expected.sig2;
        if (match) {
            mobility_hint = build_mobility_hint(profile);
            have_mobility_hint = true;
            mobility_profile_match = true;
        }
    }
    const bool mobility_hint_method_usable =
        have_mobility_hint && mobility_hint.has_method &&
        mobility_hint.preferred_method == AbsorptionMethod::Lsmr &&
        !mobility_gpu_backend_selected();
    if (have_mobility_hint && !mobility_hint.sweep_order.empty()) {
        tuned.sweep_order_override = mobility_hint.sweep_order;
    }
    // Grouped Auto has one safe authority per backend: joint LSMR on CPU and
    // the grouped CUDA solver on GPU. Profiles may confirm CPU LSMR, but a
    // GS/SGS hint can never promote a sweep method into Auto.
    if (mobility_hint_method_usable &&
        options_.absorption_method == AbsorptionMethod::Auto &&
        !options_.symmetric_sweep) {
        tuned.from_auto = false;
    }

    const bool profile_write_requested =
        mobility_cfg.mode == "write" ||
        (mobility_cfg.mode == "auto" && mobility_cfg.allow_auto_write &&
         (!mobility_profile_match || !mobility_hint_method_usable));
    bool allow_profile_write = profile_write_requested;

    AbsorptionMethod preferred_method = AbsorptionMethod::Auto;
    if (mobility_hint_method_usable) {
        preferred_method = mobility_hint.preferred_method;
    }
    AbsorptionMethod selected_method = AbsorptionMethod::Auto;
    if (options_.absorption_method != AbsorptionMethod::Auto) {
        selected_method = options_.absorption_method;
    } else if (options_.symmetric_sweep) {
        selected_method = AbsorptionMethod::SymmetricGaussSeidel;
    } else if (!options_.use_sparse_solver && !options_.use_krylov &&
               !mobility_gpu_backend_selected()) {
        // Make the safe CPU Auto authority explicit. Do not rely on the
        // downstream from_auto flag to override a sweep-method label.
        selected_method = AbsorptionMethod::Lsmr;
    } else if (preferred_method != AbsorptionMethod::Auto) {
        selected_method = preferred_method;
    }
    if (selected_method == AbsorptionMethod::Auto ||
        selected_method == AbsorptionMethod::Jacobi) {
        selected_method = select_method(standard_fes_work.size() + 1);
    }
    method_used_ = selected_method;
    if (tuned.symmetric_sweep && options_.absorption_method == AbsorptionMethod::Auto &&
        method_used_ != AbsorptionMethod::SymmetricGaussSeidel &&
        standard_fes_work.size() + 1 > 1) {
        method_used_ = AbsorptionMethod::SymmetricGaussSeidel;
    }
    tuned.absorption_method = method_used_;

    detail::AbsorptionResult absorption =
        detail::absorb_fixed_effects_group_individual(
            y_work, design, standard_fes_work, gi_work, w_ptr, tuned,
            method_used_);
    if (mobility_hint_method_usable &&
        options_.absorption_method == AbsorptionMethod::Auto &&
        !options_.symmetric_sweep &&
        (!absorption.converged || !absorption.precision_certified)) {
        // The profile is a structural/cost hint and deliberately excludes RHS
        // values. A method that worked for one outcome can therefore fail for
        // another outcome with the same operator. Restore the exact pre-hint
        // Auto context and retry from the original y/design. Certification
        // failure never promotes GS/SGS.
        HdfeOptions auto_options = *grouped_profile_context;
        auto_options.from_auto = true;
        const AbsorptionMethod auto_method =
            select_method(standard_fes_work.size() + 1);
        auto_options.absorption_method = auto_method;
        auto_options.symmetric_sweep = options_.symmetric_sweep;
        absorption = detail::absorb_fixed_effects_group_individual(
            y_work, design, standard_fes_work, gi_work, w_ptr,
            auto_options, auto_method);
        tuned = std::move(auto_options);
        method_used_ = auto_method;
        if (mobility_cfg.mode == "auto" && mobility_cfg.allow_auto_write) {
            allow_profile_write = true;
        }
    }
    if (absorption.mlsmr_used) {
        method_used_ = AbsorptionMethod::Lsmr;
        tuned.absorption_method = method_used_;
    } else if (tuned.from_auto && !absorption.gpu_used) {
        method_used_ = absorption.mlsmr_used
                           ? AbsorptionMethod::Lsmr
                           : (method_used_ == AbsorptionMethod::SymmetricGaussSeidel
                                  ? AbsorptionMethod::SymmetricGaussSeidel
                                  : AbsorptionMethod::GaussSeidel);
        tuned.absorption_method = method_used_;
    }
    detail::N1RefinementBudget n1_budget{tuned.max_iter};
    for (;;) {
    gpu_used_ = absorption.gpu_used;
    gpu_status_code_ = absorption.gpu_status_code;
    gpu_attempted_ = absorption.gpu_attempted;
    gpu_absorption_converged_ = absorption.gpu_absorption_converged;
    gpu_absorption_iterations_ = absorption.gpu_absorption_iterations;
    cuda_tail_code_ = absorption.cuda_tail;
    require_accepted_absorption(tuned, absorption, "group/individual HDFE absorption",
        absorption.converged && absorption.precision_certified ? std::string{} :
        group_failure_criteria(y_work, design, standard_fes_work, gi_work, w_ptr, tuned, absorption));
    require_cuda_execution(cuda_execution_required, absorption);

    if (probe_constant) {
        // Ones vector projected on the absorbed effects by one separate
        // right-hand side (exact direct route when eligible, otherwise the
        // LSMR of the backend that did the absorption), outside the
        // certificate, refinement and retry machinery: appended to the design
        // it made the primary certificate fail on its consistent system and
        // triggered a wasted tighter pass. A residual at the FE-collinearity
        // scale (kFeCollinearTol below) means the constant lies in the span.
        const double residual_rel = detail::group_constant_projection_residual_rel(
            standard_fes_work, gi_work, w_ptr, tuned, absorption.gpu_used);
        constant_in_span = residual_rel <= 1e-9;
    }
    // An explicit nonzero constant regressor centres fit statistics even if
    // the individual FE span alone does not contain the constant. Keep this
    // separate from constant_in_span: that flag also governs FE collinearity
    // and recovery and must not discard the explicit regressor.
    bool constant_in_model = constant_in_span;
    if (!constant_in_model) {
        for (Eigen::Index j = 0; j < X_work.cols(); ++j) {
            const double first = X_work(0, j);
            if (first != 0.0 && (X_work.col(j).array() == first).all()) {
                constant_in_model = true;
                break;
            }
        }
    }
    results_.model_has_constant = constant_in_model;

    double sum_weights_for_stats = static_cast<double>(y_work.size());
    double total_tss = 0.0;
    if (constant_in_model) {
        total_tss = compute_total_sum_of_squares(y_work, w_ptr, &sum_weights_for_stats);
    } else {
        // No constant anywhere in the model: uncentered total sum of squares,
        // as the ordinary path reports noconstant fits without absorbed levels.
        total_tss = weighted_sum_of_squares(y_work, w_ptr);
        sum_weights_for_stats =
            w_ptr ? w_ptr->sum() : static_cast<double>(y_work.size());
    }
    const double within_tss = weighted_sum_of_squares(absorption.y_tilde, w_ptr);

    Eigen::MatrixXd transformed_X = absorption.X_tilde.leftCols(design_cols);
    const int transformed_full_cols = static_cast<int>(transformed_X.cols());
    const bool transformed_has_intercept =
        (options_.fit_intercept && !drop_intercept && transformed_full_cols > 0);
    const int transformed_slope_cols =
        transformed_has_intercept ? (transformed_full_cols - 1) : transformed_full_cols;

    // Drop collinear slopes after partialling-out.
    constexpr double kFeCollinearTol = detail::kFeCollinearTol;
    const double rank_collinear_tol = std::max(1e-6, tuned.tol * 10.0);
    std::vector<int> kept_slope_cols;
    std::vector<int> omitted_slope_cols;
    std::vector<int> omitted_fe_slope_cols;
    std::vector<int> omitted_rank_slope_cols;
    Eigen::VectorXd fe_collinear_ss_ratio;
    if (options_.capture_fe_collinear_ss_ratio) {
        fe_collinear_ss_ratio.resize(transformed_slope_cols);
    }
    kept_slope_cols.reserve(static_cast<std::size_t>(std::max(0, transformed_slope_cols)));
    omitted_slope_cols.reserve(static_cast<std::size_t>(std::max(0, transformed_slope_cols)));
    std::optional<bool> exact_constant_membership_projection;
    for (int j = 0; j < transformed_slope_cols; ++j) {
        const double raw_ss = X_work.col(j).squaredNorm();
        const double tilde_ss = transformed_X.col(j).squaredNorm();
        if (options_.capture_fe_collinear_ss_ratio) {
            fe_collinear_ss_ratio[j] =
                raw_ss > 0.0 ? tilde_ss / raw_ss
                             : (tilde_ss <= kFeCollinearTol
                                    ? 0.0
                                    : std::numeric_limits<double>::infinity());
        }
        const bool finite = hdfe::detail::ieee_finite(raw_ss) && hdfe::detail::ieee_finite(tilde_ss);
        bool collinear =
            finite && (raw_ss <= 0.0 ? (tilde_ss <= kFeCollinearTol)
                                     : (tilde_ss <= kFeCollinearTol * raw_ss));
        const bool grouped_constant_available =
            constant_in_span;
        if (collinear && detail::ordinary_audit_enabled()) {
            // Audit mode: exact redundancy proof or an informative refusal.
            bool verified=false;
            if(standard_fes_work.size()<=1 && raw_ss>0 && tilde_ss>0) {
                if(!exact_constant_membership_projection) {
                    bool same=gi_work.num_individuals>0;
                    for(int g=0;g<gi_work.num_groups && same;++g)
                        same=gi_work.group_ptr[g+1]-gi_work.group_ptr[g]==gi_work.num_individuals &&
                             gi_work.group_scale[g]==gi_work.group_scale[0];
                    Eigen::VectorXi level=standard_fes_work.empty() ? Eigen::VectorXi::Zero(y_work.size()) : standard_fes_work[0];
                    exact_constant_membership_projection=same && detail::exact_level_projection(
                        y_work,X_work,level,w_ptr,absorption.y_tilde,transformed_X.leftCols(X_work.cols()));
                }
                verified=*exact_constant_membership_projection;
            }
            collinear=require_safe_fe_omission(X_work.col(j),raw_ss,tilde_ss,standard_fes_work,
                {},grouped_constant_available,j+1,verified,
                &gi_work,aggregation==GroupAggregation::Mean);
        } else if (collinear && grouped_constant_available && raw_ss > 0.0 && tilde_ss > 0.0) {
            // Centered scale, as in the ordinary path: a level shift is absorbed
            // by the ordinary FE or by mean-aggregated membership columns.
            const double centered_ss = centered_sum_of_squares(X_work.col(j));
            const double rounding_floor =
                16.0 * std::numeric_limits<double>::epsilon() *
                std::numeric_limits<double>::epsilon() * raw_ss;
            collinear = !(centered_ss > 0.0) ||
                        tilde_ss <= kFeCollinearTol * centered_ss ||
                        tilde_ss <= rounding_floor;
        }
        if (collinear) {
            omitted_fe_slope_cols.push_back(j);
            omitted_slope_cols.push_back(j);
        } else {
            kept_slope_cols.push_back(j);
        }
    }

    Eigen::MatrixXd xtx_used;
    Eigen::VectorXd xty_used;
    bool have_precomputed = false;

    const bool use_precomputed = (tuned.se_type != StandardErrorType::Cluster);
    if (use_precomputed) {
        const int k_initial = static_cast<int>(kept_slope_cols.size());
        const int intercept_col = transformed_has_intercept ? (transformed_full_cols - 1) : -1;
        const CrossproductResult cp = compute_crossproducts_selected(
            absorption.y_tilde, transformed_X, kept_slope_cols, intercept_col, w_ptr,
            transformed_has_intercept, tuned.num_threads, tuned.parallel_observer);

        std::vector<int> keep_positions;
        keep_positions.reserve(kept_slope_cols.size());
        if (k_initial > 0) {
            // FP64 triage on the Gram already formed for OLS (2.26.2 rule);
            // the double-double rank runs only for unseparated decisions.
            Eigen::MatrixXd gram = cp.xtx.topLeftCorner(k_initial, k_initial);
            if (transformed_has_intercept) {
                double denom = cp.sum_w;
                if (!(denom > 0.0)) {
                    denom = 1.0;
                }
                gram.noalias() -= (cp.sum_x * cp.sum_x.transpose()) / denom;
            }
            bool rank_separated = true;
            const Eigen::VectorXd uncentered_diagonal =
                cp.xtx.diagonal().head(k_initial);
            std::vector<uint8_t> drop_mask =
                compute_rank_collinearity_mask_from_gram(
                    gram, kept_slope_cols, rank_collinear_tol,
                    options_.collinear_priority, &rank_separated,
                    &uncentered_diagonal);
            if (!rank_separated) {
                drop_mask = detail::precise_ols_rank_mask(
                    transformed_X, kept_slope_cols, w_ptr, transformed_has_intercept,
                    rank_collinear_tol, options_.collinear_priority,
                    tuned.num_threads, tuned.parallel_observer);
            }

            std::vector<int> new_kept;
            std::vector<int> new_omitted;
            new_kept.reserve(kept_slope_cols.size());
            new_omitted.reserve(kept_slope_cols.size());
            for (std::size_t pos = 0; pos < kept_slope_cols.size(); ++pos) {
                const int idx = kept_slope_cols[pos];
                if (drop_mask[static_cast<std::size_t>(pos)]) {
                    new_omitted.push_back(idx);
                } else {
                    new_kept.push_back(idx);
                    keep_positions.push_back(static_cast<int>(pos));
                }
            }
            kept_slope_cols.swap(new_kept);
            omitted_rank_slope_cols.insert(omitted_rank_slope_cols.end(),
                                           new_omitted.begin(), new_omitted.end());
            omitted_slope_cols.insert(omitted_slope_cols.end(),
                                      new_omitted.begin(), new_omitted.end());
        }

        std::vector<int> xtx_cols = keep_positions;
        if (intercept_col >= 0) {
            xtx_cols.push_back(k_initial);
        }
        const int p_used = static_cast<int>(xtx_cols.size());
        xtx_used.resize(p_used, p_used);
        xty_used.resize(p_used);
        for (int i = 0; i < p_used; ++i) {
            const int col_i = xtx_cols[static_cast<std::size_t>(i)];
            xty_used(i) = cp.xty(col_i);
            for (int j = 0; j < p_used; ++j) {
                const int col_j = xtx_cols[static_cast<std::size_t>(j)];
                xtx_used(i, j) = cp.xtx(col_i, col_j);
            }
        }
        have_precomputed = true;
    } else if (!kept_slope_cols.empty()) {
        const std::vector<uint8_t> drop_mask = compute_rank_collinearity_mask(
            transformed_X, kept_slope_cols, transformed_slope_cols, transformed_has_intercept,
            w_ptr, rank_collinear_tol, tuned.num_threads,
            options_.collinear_priority, tuned.parallel_observer);

        std::vector<int> new_kept;
        std::vector<int> new_omitted;
        new_kept.reserve(kept_slope_cols.size());
        new_omitted.reserve(kept_slope_cols.size());
        for (const int idx : kept_slope_cols) {
            if (idx >= 0 && idx < transformed_slope_cols &&
                drop_mask[static_cast<std::size_t>(idx)]) {
                new_omitted.push_back(idx);
            } else {
                new_kept.push_back(idx);
            }
        }
        kept_slope_cols.swap(new_kept);
        omitted_rank_slope_cols.insert(omitted_rank_slope_cols.end(),
                                       new_omitted.begin(), new_omitted.end());
        omitted_slope_cols.insert(omitted_slope_cols.end(),
                                  new_omitted.begin(), new_omitted.end());
    }

    Eigen::MatrixXd transformed_X_used;
    transformed_X_used.resize(transformed_X.rows(),
                              static_cast<int>(kept_slope_cols.size()) +
                                  (transformed_has_intercept ? 1 : 0));
    for (int out_j = 0; out_j < static_cast<int>(kept_slope_cols.size()); ++out_j) {
        transformed_X_used.col(out_j) =
            transformed_X.col(kept_slope_cols[static_cast<std::size_t>(out_j)]);
    }
    if (transformed_has_intercept) {
        transformed_X_used.col(static_cast<int>(kept_slope_cols.size())) =
            transformed_X.col(transformed_full_cols - 1);
    }
    const int df_m_effective = static_cast<int>(kept_slope_cols.size());

    detail::OlsResult ols_result;
    // Phase 5b: as in fit(), one carrier per pass of the N1 loop.
    detail::ClusterPasses cluster_passes;
    detail::ClusterPasses* const passes =
        (detail::cluster_shared_passes_enabled() && tuned.se_type == StandardErrorType::Cluster &&
         c_ptr && c_ptr->size() >= 2) ? &cluster_passes : nullptr;
    if (passes) passes->want_pair = c_ptr->size() == 2 && drop_intercept;
    if (transformed_X_used.cols() == 0) {
        detail::OlsResult empty;
        empty.coefficients.resize(0);
        empty.std_errors.resize(0);
        empty.tvalues.resize(0);
        empty.pvalues.resize(0);
        empty.conf_int.resize(0, 2);
        empty.residuals.resize(absorption.y_tilde.size());
        empty.n1_normal = std::make_shared<detail::N1NormalEvidence>(1, 0);
        for (int i = 0; i < empty.residuals.size(); ++i) {
            const double value = absorption.y_tilde[i];
            empty.residuals[i] = value;
            empty.n1_normal->chunks[0].add(value, value, w_ptr ? (*w_ptr)[i] : 1.0,
                0, [](int) { return 0.0; }, [](int) { return 0.0; }, [](int) { return 0.0; });
        }
        empty.df_resid = nobs_effective;
        if (tuned.se_type == StandardErrorType::Cluster) {
            if (!c_ptr || c_ptr->empty())
                throw std::runtime_error("Cluster-robust errors requested but no cluster variables were provided");
            const auto counts = compute_cluster_counts(*c_ptr);
            empty.num_clusters = *std::min_element(counts.begin(), counts.end());
            if (c_ptr->size() == 1 && empty.num_clusters > 1 && nobs_effective > 0.0)
                empty.cov_scale = static_cast<double>(empty.num_clusters) / (empty.num_clusters-1.0) *
                    (nobs_effective-1.0) / nobs_effective;
        }
        empty.rss = weighted_sum_of_squares(empty.residuals, w_ptr);
        empty.tss = total_tss;
        empty.within_tss = within_tss;
        const double missing_r2 =
            std::numeric_limits<double>::quiet_NaN();
        empty.r2 = (total_tss > 0.0)
                       ? 1.0 - empty.rss / total_tss
                       : missing_r2;
        empty.r2_within = (within_tss > 0.0)
                              ? 1.0 - empty.rss / within_tss
                              : missing_r2;
        empty.sigma2 = 0.0;
        empty.nobs = static_cast<int>(absorption.y_tilde.size());
        ols_result = std::move(empty);
    } else if (tuned.se_type == StandardErrorType::Cluster) {
        if (!c_ptr || c_ptr->empty()) {
            throw std::runtime_error(
                "Cluster-robust errors requested but no cluster variables were provided");
        }
        if (c_ptr->size() == 1) {
            ols_result = detail::run_ols(absorption.y_tilde, transformed_X_used, w_ptr, &(*c_ptr)[0],
                                         tuned.se_type, total_tss, within_tss, nobs_effective,
                                         false, nullptr, tuned.num_threads_explicit,
                                         tuned.parallel_observer);
        } else {
            ols_result = detail::run_ols_multiway(absorption.y_tilde, transformed_X_used, w_ptr, c_ptr,
                                                 tuned.se_type, total_tss, within_tss,
                                                 tuned.ssc_g_df, tuned.ssc_g_adj, nobs_effective,
                                                 nullptr, tuned.num_threads_explicit,
                                                 tuned.parallel_observer, passes);
            log_cluster_passes_ols(passes);
        }
    } else if (have_precomputed &&
               xtx_used.rows() == transformed_X_used.cols() &&
               xty_used.size() == transformed_X_used.cols()) {
        ols_result = detail::run_ols_fast_from_xtx(absorption.y_tilde, transformed_X_used, w_ptr,
                                                   tuned.se_type, total_tss, within_tss,
                                                   xtx_used, xty_used, nobs_effective,
                                                   tuned.weights_are_frequencies,
                                                   tuned.num_threads_explicit,
                                                   tuned.parallel_observer);
    } else {
        ols_result = detail::run_ols(absorption.y_tilde, transformed_X_used, w_ptr, nullptr, tuned.se_type,
                                     total_tss, within_tss, nobs_effective,
                                     tuned.weights_are_frequencies, nullptr,
                                     tuned.num_threads_explicit,
                                     tuned.parallel_observer);
    }

    apply_common_postprocessing(y_work, X_work, w_ptr, absorption.fe_levels, ols_result);
    results_.nobs_effective = nobs_effective;
    results_.nobs_full_effective = nobs_full_effective;
    results_.num_singletons_effective =
        static_cast<double>(nobs_full_frequency - nobs_frequency);
    results_.vcv_psd_fixed = false;
    results_.nobs_full = collapsed_full;
    results_.num_singletons = group_singletons_dropped;
    results_.num_iterations = absorption.iterations;
    results_.converged = absorption.converged;
    results_.abs_residual = absorption.abs_residual;
    results_.abs_residual_rel = absorption.abs_residual_rel;
    results_.krylov_internal_tolerance =
        absorption.krylov_internal_tolerance;
    results_.krylov_max_final_backward_error =
        absorption.krylov_max_final_backward_error;
    results_.krylov_max_condition = absorption.krylov_max_condition;
    results_.krylov_max_condition_times_backward_error =
        absorption.krylov_max_condition_times_backward_error;
    results_.auto_routing_retry_policy_enabled =
        absorption.auto_routing_retry_policy_enabled;
    results_.auto_routing_retry_eligible =
        absorption.auto_routing_retry_eligible;
    results_.auto_routing_retry_fired =
        absorption.auto_routing_retry_fired;
    results_.auto_routing_retry_status = absorption.auto_routing_retry_status;
    results_.auto_routing_retry_primary_method =
        absorption.auto_routing_retry_primary_method;
    results_.auto_routing_retry_primary_iterations =
        absorption.auto_routing_retry_primary_iterations;
    results_.auto_routing_retry_primary_abs_residual_rel =
        absorption.auto_routing_retry_primary_abs_residual_rel;
    results_.auto_routing_retry_iterations =
        absorption.auto_routing_retry_iterations;
    results_.auto_routing_retry_abs_residual_rel =
        absorption.auto_routing_retry_abs_residual_rel;
    results_.auto_routing_retry_elapsed_seconds =
        absorption.auto_routing_retry_elapsed_seconds;
    results_.slope_block_checked = absorption.slope_block_checked;
    results_.slope_block_residual_rel = absorption.slope_block_residual_rel;
    results_.slope_block_frobenius_rel = absorption.slope_block_frobenius_rel;
    results_.slope_block_rms_rel = absorption.slope_block_rms_rel;
    results_.slope_block_max_rel = absorption.slope_block_max_rel;
    results_.slope_block_skipped_max_rel =
        absorption.slope_block_skipped_max_rel;
    results_.slope_certificate_worst_fe =
        absorption.slope_certificate_worst_fe;
    results_.slope_certificate_worst_moment =
        absorption.slope_certificate_worst_moment;
    results_.slope_accuracy_retry_stages =
        absorption.slope_accuracy_retry_stages;
    results_.slope_accuracy_retry_iterations =
        absorption.slope_accuracy_retry_iterations;
    results_.slope_internal_tolerance = absorption.slope_internal_tolerance;
    results_.precision_certified = absorption.precision_certified;
    // For group/individual mode, map each collapsed group observation back to a representative
    // row in the original long-format input.
    if (static_cast<int>(collapsed.rep_row.size()) != results_.nobs) {
        throw std::runtime_error("Unexpected rep_row size in grouped regression");
    }
    results_.sample_index.resize(results_.nobs);
    for (int i = 0; i < results_.nobs; ++i) {
        results_.sample_index(i) = collapsed.rep_row[static_cast<std::size_t>(i)];
    }
    if (allow_profile_write && absorption.converged &&
        absorption.precision_certified) {
        const AbsorptionCacheKey& profile_signature =
            ensure_grouped_profile_signature();
        MobilityProfile profile = compute_mobility_profile(
            standard_fes_work, collapsed_full, group_singletons_dropped,
            options_.drop_singletons, absorption.sweep_order_used);
        profile.profile_kind = "group_individual";
        profile.signature = profile_signature.sig1;
        profile.signature_canon = profile_signature.sig2;
        profile.has_signature_canon = true;
        profile.has_signature_sample = false;
        profile.has_signature_sample_canon = false;
        profile.suggest_method =
            !absorption.gpu_used && absorption.mlsmr_used
                ? AbsorptionMethod::Lsmr
                : AbsorptionMethod::Auto;
        profile.suggest_symmetric = false;
        profile.suggest_use_sparse = false;
        profile.suggest_use_krylov = false;
        write_mobility_profile(mobility_cfg.path, profile);
    }

    if ((!omitted_slope_cols.empty()) &&
        results_.coefficients.size() == static_cast<int>(kept_slope_cols.size()) +
                                             (transformed_has_intercept ? 1 : 0)) {
        const double nan = std::numeric_limits<double>::quiet_NaN();
        const int full_cols = transformed_full_cols;
        Eigen::VectorXd coef_full = Eigen::VectorXd::Zero(full_cols);
        Eigen::VectorXd se_full = Eigen::VectorXd::Constant(full_cols, nan);
        Eigen::VectorXd t_full = Eigen::VectorXd::Constant(full_cols, nan);
        Eigen::VectorXd p_full = Eigen::VectorXd::Constant(full_cols, nan);
        Eigen::MatrixXd ci_full = Eigen::MatrixXd::Constant(full_cols, 2, nan);
        Eigen::MatrixXd cov_full = Eigen::MatrixXd::Zero(full_cols, full_cols);
        Eigen::MatrixXd cov_used = results_.covariance;

        for (int pos = 0; pos < static_cast<int>(kept_slope_cols.size()); ++pos) {
            const int j = kept_slope_cols[static_cast<std::size_t>(pos)];
            coef_full(j) = results_.coefficients(pos);
            se_full(j) = results_.std_errors(pos);
            t_full(j) = results_.tvalues(pos);
            p_full(j) = results_.pvalues(pos);
            ci_full(j, 0) = results_.conf_int(pos, 0);
            ci_full(j, 1) = results_.conf_int(pos, 1);

            for (int pos2 = 0; pos2 < static_cast<int>(kept_slope_cols.size()); ++pos2) {
                const int k = kept_slope_cols[static_cast<std::size_t>(pos2)];
                if (cov_used.rows() > pos && cov_used.cols() > pos2) {
                    cov_full(j, k) = cov_used(pos, pos2);
                }
            }
        }
        if (transformed_has_intercept) {
            const int intercept_full_idx = full_cols - 1;
            const int intercept_pos = static_cast<int>(kept_slope_cols.size());
            coef_full(intercept_full_idx) = results_.coefficients(intercept_pos);
            se_full(intercept_full_idx) = results_.std_errors(intercept_pos);
            t_full(intercept_full_idx) = results_.tvalues(intercept_pos);
            p_full(intercept_full_idx) = results_.pvalues(intercept_pos);
            ci_full(intercept_full_idx, 0) = results_.conf_int(intercept_pos, 0);
            ci_full(intercept_full_idx, 1) = results_.conf_int(intercept_pos, 1);

            if (cov_used.rows() > intercept_pos && cov_used.cols() > intercept_pos) {
                cov_full(intercept_full_idx, intercept_full_idx) =
                    cov_used(intercept_pos, intercept_pos);
            }
            for (int pos = 0; pos < static_cast<int>(kept_slope_cols.size()); ++pos) {
                const int j = kept_slope_cols[static_cast<std::size_t>(pos)];
                if (cov_used.rows() > pos && cov_used.cols() > intercept_pos) {
                    cov_full(j, intercept_full_idx) = cov_used(pos, intercept_pos);
                }
                if (cov_used.rows() > intercept_pos && cov_used.cols() > pos) {
                    cov_full(intercept_full_idx, j) = cov_used(intercept_pos, pos);
                }
            }
        }

        results_.coefficients = std::move(coef_full);
        results_.std_errors = std::move(se_full);
        results_.tvalues = std::move(t_full);
        results_.pvalues = std::move(p_full);
        results_.conf_int = std::move(ci_full);
        results_.covariance = std::move(cov_full);
    }

    if (drop_intercept) {
        const int slope_cols = static_cast<int>(results_.coefficients.size());
        double denom = 0.0;
        const double y_mean =
            fixed_chunk_weighted_mean(y_work, w_ptr, tuned.num_threads, &denom,
                                      tuned.parallel_observer);
        Eigen::VectorXd x_means = Eigen::VectorXd::Zero(slope_cols);
        if (slope_cols > 0 && denom > 0.0) {
            for (int j = 0; j < slope_cols; ++j) {
                x_means(j) =
                    fixed_chunk_weighted_mean(X_work.col(j), w_ptr,
                                              tuned.num_threads, nullptr,
                                              tuned.parallel_observer);
            }
        }
        // Without a constant in the span of the absorbed effects the recovered
        // level is not an intercept (the residuals need not sum to zero): the
        // slot is reported missing and the Stata ado drops the _cons column.
        const double intercept =
            constant_in_span ? y_mean - x_means.dot(results_.coefficients)
                             : std::numeric_limits<double>::quiet_NaN();

        const int out_cols = slope_cols + 1;
        results_.coefficients.conservativeResize(out_cols);
        results_.coefficients(out_cols - 1) = intercept;

        const double nan = std::numeric_limits<double>::quiet_NaN();
        results_.std_errors.conservativeResize(out_cols);
        results_.std_errors(out_cols - 1) = nan;
        results_.tvalues.conservativeResize(out_cols);
        results_.tvalues(out_cols - 1) = nan;
        results_.pvalues.conservativeResize(out_cols);
        results_.pvalues(out_cols - 1) = nan;
        Eigen::MatrixXd conf_new = Eigen::MatrixXd::Constant(out_cols, 2, nan);
        conf_new.topRows(slope_cols) = results_.conf_int;
        results_.conf_int = std::move(conf_new);

        Eigen::MatrixXd cov_new = Eigen::MatrixXd::Constant(out_cols, out_cols, nan);
        cov_new.topLeftCorner(slope_cols, slope_cols) = results_.covariance;
        results_.covariance = std::move(cov_new);
    }

    const int omit_cols = static_cast<int>(results_.coefficients.size());
    results_.omitted_reason.assign(static_cast<std::size_t>(omit_cols), 0);
    results_.fe_collinear_ss_ratio =
        options_.capture_fe_collinear_ss_ratio
            ? fe_collinear_ss_ratio
            : Eigen::VectorXd();
    for (const int idx : omitted_fe_slope_cols) {
        if (idx >= 0 && idx < omit_cols) {
            results_.omitted_reason[static_cast<std::size_t>(idx)] = 1;
        }
    }
    for (const int idx : omitted_rank_slope_cols) {
        if (idx >= 0 && idx < omit_cols &&
            results_.omitted_reason[static_cast<std::size_t>(idx)] == 0) {
            results_.omitted_reason[static_cast<std::size_t>(idx)] = 2;
        }
    }

    // Degrees-of-freedom adjustments (extend the standard FE DoF with the individual FE count).
    const double nobs = results_.nobs_effective;
    const int df_m = df_m_effective;  // excludes constant
    results_.df_m = static_cast<double>(df_m);

    std::int64_t df_a_levels = gi_work.num_individuals;  // E3: 64 bits, as in fit()
    std::int64_t df_a_exact = gi_work.num_individuals;
    std::int64_t nested_dof_levels = 0;  // round 11 (E3): 64 bits, to their doubles
    std::int64_t nested_dof_coefs = 0;
    if (!standard_fes_work.empty()) {
        std::vector<int> standard_levels;
        if (absorption.fe_levels.size() >= 1) {
            standard_levels.assign(absorption.fe_levels.begin(),
                                   absorption.fe_levels.end() - 1);
        }
        Eigen::VectorXi groupvar;
        Eigen::VectorXi* groupvar_ptr = options_.save_groupvar ? &groupvar : nullptr;
        FeComponentStats* first_pair_stats_ptr =
            options_.capture_first_pair_component_stats
                ? &first_pair_component_stats_
                : nullptr;
        const DofAdjustmentMethod mobility_method =
            options_.dof_mobility_groups
                ? options_.dof_method
                : DofAdjustmentMethod::None;
        FeDofInfo dof =
            compute_fe_dof_reghdfe(
                standard_fes_work, standard_levels, mobility_method,
                groupvar_ptr, tuned.num_threads, first_pair_stats_ptr, w_ptr,
                tuned.num_threads_explicit);
        std::vector<uint8_t> nested_flags(dof.levels.size(), 0);
        if (adjust_group_clusters && tuned.se_type == StandardErrorType::Cluster && c_ptr &&
            !c_ptr->empty()) {
            for (const auto& cl : *c_ptr) {
                for (std::size_t d = 0; d < standard_fes_work.size(); ++d) {
                    if (nested_flags[d]) {
                        continue;
                    }
                    if (fe_nested_within_cluster(standard_fes_work[d], cl)) {
                        nested_flags[d] = 1;
                    }
                }
            }
        }

        // If some fixed effects are nested within the clustering variable, reghdfe does not
        // use them to compute mobility-group redundancies for the remaining dimensions.
        if (options_.dof_method != DofAdjustmentMethod::None) {
            bool any_nested = false;
            for (std::size_t d = 0; d < nested_flags.size(); ++d) {
                if (nested_flags[d]) {
                    any_nested = true;
                    break;
                }
            }
            if (any_nested) {
                std::vector<Eigen::VectorXi> fes_nonnested;
                std::vector<int> levels_nonnested;
                std::vector<int> map_nonnested;
                fes_nonnested.reserve(standard_fes_work.size());
                levels_nonnested.reserve(standard_fes_work.size());
                map_nonnested.reserve(standard_fes_work.size());
                for (std::size_t d = 0; d < standard_fes_work.size(); ++d) {
                    if (nested_flags[d]) {
                        continue;
                    }
                    fes_nonnested.push_back(standard_fes_work[d]);
                    levels_nonnested.push_back(dof.levels[d]);
                    map_nonnested.push_back(static_cast<int>(d));
                }
                if (!fes_nonnested.empty()) {
                    const FeDofInfo dof_nonnested =
                        compute_fe_dof_reghdfe(fes_nonnested, levels_nonnested,
                                               mobility_method, nullptr,
                                               tuned.num_threads, nullptr, nullptr,
                                               tuned.num_threads_explicit);
                    for (std::size_t pos = 0; pos < map_nonnested.size(); ++pos) {
                        const int orig = map_nonnested[pos];
                        dof.redundant[static_cast<std::size_t>(orig)] =
                            dof_nonnested.redundant[pos];
                    }
                }
            }
        }
        std::int64_t nested_total = 0;  // round 11 (E3): a sum of levels, in 64 bits
        if (options_.dof_method != DofAdjustmentMethod::None) {
            for (std::size_t d = 0; d < dof.levels.size(); ++d) {
                if (nested_flags[d]) {
                    nested_total += dof.levels[d];
                    dof.redundant[d] = dof.levels[d];
                    dof.num_coefs[d] = 0;
                }
            }
            std::vector<int> intercept_index;
            intercept_index.reserve(dof.levels.size());
            for (std::size_t d = 0; d < dof.levels.size(); ++d) {
                if (!nested_flags[d]) {
                    intercept_index.push_back(static_cast<int>(d));
                }
            }
            if (!intercept_index.empty()) {
                bool skip_next = (nested_total == 0);
                for (const int idx : intercept_index) {
                    if (skip_next) {
                        skip_next = false;
                        continue;
                    }
                    if (dof.redundant[static_cast<std::size_t>(idx)] < 1) {
                        dof.redundant[static_cast<std::size_t>(idx)] = 1;
                    }
                }
            }
            for (std::size_t d = 0; d < dof.levels.size(); ++d) {
                dof.num_coefs[d] =
                    std::max(0, dof.levels[d] - dof.redundant[d]);
            }
        } else {
            bool skip_first_intercept = true;
            for (std::size_t d = 0; d < dof.levels.size(); ++d) {
                if (skip_first_intercept) {
                    skip_first_intercept = false;
                    continue;
                }
                dof.redundant[d] = std::max(dof.redundant[d], 1);
            }
            for (std::size_t d = 0; d < dof.levels.size(); ++d) {
                dof.num_coefs[d] =
                    std::max(0, dof.levels[d] - dof.redundant[d]);
            }
        }
        dof.inexact.assign(dof.levels.size(), 0);
        const int exact_intercept_dims = options_.dof_mobility_groups ? 2 : 1;
        int intercept_count = 0;
        for (std::size_t d = 0; d < dof.levels.size(); ++d) {
            if (nested_flags[d]) {
                continue;
            }
            ++intercept_count;
            if (intercept_count > exact_intercept_dims) {
                dof.inexact[d] = 1;
            }
        }
        dof.df_a_levels = 0;
        dof.df_a_exact = 0;
        for (std::size_t d = 0; d < dof.levels.size(); ++d) {
            dof.df_a_levels += dof.levels[d];
            dof.df_a_exact += dof.num_coefs[d];
        }
        dof.df_a = dof.df_a_exact;
        df_a_levels += dof.df_a_levels;
        df_a_exact += dof.df_a_exact;
        if (groupvar_ptr) {
            results_.groupvar = std::move(groupvar);
        }
        if (adjust_group_clusters && tuned.se_type == StandardErrorType::Cluster && c_ptr &&
            !c_ptr->empty()) {
            nested_dof_coefs += detail::sparse_rank::flagged_sum(
                nested_flags, [&](std::size_t d) { return dof.num_coefs[d]; });
            nested_dof_levels += detail::sparse_rank::flagged_sum(
                nested_flags, [&](std::size_t d) { return dof.levels[d]; });
        }
        results_.fe_num_levels = dof.levels;
        results_.fe_base_levels = dof.levels;
        results_.fe_base_redundant = dof.redundant;
        results_.fe_redundant = dof.redundant;
        results_.fe_num_coefs = dof.num_coefs;
        results_.fe_inexact = dof.inexact;
        results_.fe_nested.assign(dof.levels.size(), 0);
        for (std::size_t d = 0; d < nested_flags.size(); ++d) {
            if (nested_flags[d]) {
                results_.fe_nested[d] = 1;
            }
        }
    } else {
        // No standard FEs: apply_common_postprocessing seeded fe_num_levels
        // with absorption.fe_levels (which includes the individual level count).
        // Reset so we can rebuild with just the individual row below.
        results_.fe_num_levels.clear();
        results_.fe_base_levels.clear();
        results_.fe_base_redundant.clear();
        results_.fe_redundant.clear();
        results_.fe_num_coefs.clear();
        results_.fe_inexact.clear();
        results_.fe_nested.clear();
    }
    // Append the individual FE row so the Stata ado can display it in the
    // "Absorbed degrees of freedom" footnote, matching reghdfe's layout.
    // The individual FE is placed last in absorb_ordered on the ado side.
    int individual_redundant = 0;
    if (!standard_fes_work.empty() && nested_dof_levels == 0) {
        bool constant_team_size = true;
        const int first_size = gi_work.group_ptr[1] - gi_work.group_ptr[0];
        for (int group = 1; group < gi_work.num_groups; ++group) {
            if (gi_work.group_ptr[group + 1] - gi_work.group_ptr[group] != first_size) {
                constant_team_size = false;
                break;
            }
        }
        // Mean membership columns sum to one. Uniform-size sum membership has
        // the same span. An ordinary FE already supplies that intercept.
        if (aggregation == GroupAggregation::Mean || constant_team_size) {
            individual_redundant = 1;
        }
    }
    if (individual_redundant > 0) {
        df_a_exact -= individual_redundant;
    }
    results_.fe_num_levels.push_back(gi_work.num_individuals);
    results_.fe_base_levels.push_back(gi_work.num_individuals);
    results_.fe_base_redundant.push_back(individual_redundant);
    results_.fe_redundant.push_back(individual_redundant);
    results_.fe_num_coefs.push_back(
        std::max(0, gi_work.num_individuals - individual_redundant));
    // Mark as inexact ("?" in the footnote): redundancy is approximate for
    // the individual FE in group/individual mode.
    results_.fe_inexact.push_back(1);
    results_.fe_nested.push_back(0);

    if (exact_group_dof) {
        const FeDofInfo exact = compute_grouped_dof_exact(standard_fes_work, gi_work, aggregation, w_ptr);
        df_a_levels = exact.df_a_levels;
        df_a_exact = exact.df_a_exact;
        results_.fe_num_levels = exact.levels;
        results_.fe_base_levels = exact.levels;
        results_.fe_redundant = exact.redundant;
        results_.fe_base_redundant = exact.redundant;
        results_.fe_num_coefs = exact.num_coefs;
        results_.fe_inexact = exact.inexact;
        results_.fe_nested.assign(exact.levels.size(), 0);
    }

    results_.df_a_levels = static_cast<double>(df_a_levels);
    results_.df_a_exact = static_cast<double>(df_a_exact);

    const std::int64_t df_a_report = df_a_exact;
    const std::int64_t nested_report = nested_dof_levels;
    results_.df_a = static_cast<double>(df_a_report);
    results_.df_a_nested = static_cast<double>(nested_report);
    results_.model_has_constant = constant_in_span;

    const bool use_reghdfe_stats = (options_.stats_style == StatsStyle::Reghdfe);
    std::int64_t df_a_used = df_a_report;
    std::int64_t nested_dof_used = nested_dof_levels;
    int nested_adj = (nested_dof_levels > 0) ? 1 : 0;
    if (!use_reghdfe_stats) {
        df_a_used = 0;
        nested_dof_used = 0;
        const std::int64_t df_a_base = (tuned.ssc_k_exact || exact_group_dof) ? df_a_exact : df_a_levels;
        const std::int64_t nested_base = tuned.ssc_k_exact ? nested_dof_coefs : nested_dof_levels;
        nested_adj = (nested_base > 0) ? 1 : 0;
        if (tuned.ssc_k_fixef == FixefDofMethod::None) {
            df_a_used = 0;
            nested_dof_used = 0;
        } else {
            if (tuned.ssc_k_fixef == FixefDofMethod::Nonnested &&
                tuned.se_type == StandardErrorType::Cluster) {
                df_a_used = std::max<std::int64_t>(0, df_a_base - nested_base);
                nested_dof_used = 0;
            } else {
                df_a_used = df_a_base;
                nested_dof_used = nested_base;
            }
        }
    }

    // Use absorbed DoF (after redundancy) for RMSE/Adj R2 residual df.
    // Preserve the raw (possibly non-positive) df_r for reghdfe-compatible
    // reporting: reghdfe surfaces a negative e(df_r) and missing inference
    // when the model is saturated or over-specified.
    const double df_r_raw =
        nobs - static_cast<double>(df_m) -
        static_cast<double>(df_a_report);
    const double df_r_unadj = std::max(0.0, df_r_raw);
    results_.df_resid_unadj = df_r_raw;
    const double sigma2_df =
        use_reghdfe_stats ? df_r_raw - static_cast<double>(nested_report)
                          : df_r_unadj;
    if (sigma2_df > 0.0) {
        const double sigma2_old = results_.sigma2;
        const double sigma2_new = results_.rss / sigma2_df;
        results_.sigma2 = sigma2_new;
        if (tuned.se_type == StandardErrorType::Homoskedastic && sigma2_old > 0.0) {
            const double ratio = sigma2_new / sigma2_old;
            results_.covariance *= ratio;
            results_.std_errors *= std::sqrt(ratio);
        }
    } else if (use_reghdfe_stats && sigma2_df == 0.0) {
        results_.sigma2 = results_.rss;
    } else if (use_reghdfe_stats) {
        results_.sigma2 = std::numeric_limits<double>::quiet_NaN();
    } else {
        results_.sigma2 = 0.0;
    }
    const bool saturated_model = !(df_r_raw > 0.0);

    double df_r_model =
        nobs - static_cast<double>(df_m) -
        static_cast<double>(df_a_used);
    df_r_model = std::max(0.0, df_r_model);

    if (c_ptr && !c_ptr->empty()) {
        results_.num_clusters = ols_result.num_clusters;
        if (c_ptr->size() == 1) {
            results_.cluster_counts.assign(1, results_.num_clusters);
            results_.cluster_combo_counts.assign(1, results_.num_clusters);
        } else {
            // Phase 5b: as in fit().
            const std::size_t masks = (static_cast<std::size_t>(1) << c_ptr->size()) - 1;
            const bool from_passes = passes && passes->ready && passes->source == c_ptr &&
                                     passes->mask_counts.size() == masks;
            if (from_passes) {
                std::vector<int> counts(c_ptr->size());
                for (std::size_t d = 0; d < c_ptr->size(); ++d) {
                    counts[d] = passes->mask_counts[(static_cast<std::size_t>(1) << d) - 1];
                }
                results_.cluster_counts = std::move(counts);
                results_.cluster_combo_counts = passes->mask_counts;
            } else {
                results_.cluster_counts = compute_cluster_counts(*c_ptr);
                results_.cluster_combo_counts = compute_cluster_combo_counts(*c_ptr);
            }
            if (cpu_profile_enabled()) {
                std::cerr << "cpu_profile label=cluster_passes site=counts counts="
                          << (from_passes ? "carrier pair=none" : "recount pair=built") << '\n';
            }
        }
    } else {
        results_.cluster_counts.clear();
        results_.cluster_combo_counts.clear();
        results_.num_clusters = 0;
    }

    double robust_scale = 1.0;
    double cluster_ratio = 1.0;
    if (tuned.se_type == StandardErrorType::Robust && df_r_model > 0.0) {
        if (tuned.ssc_k_adj) {
            robust_scale = nobs / df_r_model;
            const double scale = std::sqrt(robust_scale);
            results_.std_errors *= scale;
            results_.covariance *= robust_scale;
        }
        results_.df_resid = tuned.ssc_t_df > 0.0 ? tuned.ssc_t_df : df_r_model;
    } else if (tuned.se_type == StandardErrorType::Cluster && c_ptr && !c_ptr->empty()) {
        const int Gc = ols_result.num_clusters;
        if (use_reghdfe_stats) {
            const double df_r_unclust = df_r_model;
            const double df_r_cluster =
                static_cast<double>(std::max(0, Gc - 1));
            results_.df_resid = std::min(df_r_unclust, df_r_cluster);
            double ratio = 1.0;
            if (tuned.ssc_k_adj) {
                const double denom = std::max(
                    0.0, nobs - static_cast<double>(df_m) -
                             static_cast<double>(df_a_report) -
                             static_cast<double>(nested_adj));
                if (denom > 0.0) {
                    ratio *= ols_result.df_resid / denom;
                }
            } else {
                const double denom = std::max(1.0, nobs - 1.0);
                ratio *= ols_result.df_resid / denom;
            }
            if (c_ptr->size() == 1 && !tuned.ssc_g_adj && Gc > 1) {
                ratio *= static_cast<double>(Gc - 1) / static_cast<double>(Gc);
            }
            if (ratio > 0.0 && hdfe::detail::ieee_finite(ratio)) {
                const double scale = std::sqrt(ratio);
                results_.std_errors *= scale;
                results_.covariance *= ratio;
                cluster_ratio = ratio;
            }
            results_.cluster_scale = ratio;
            if (tuned.ssc_t_df > 0.0) {
                results_.df_resid = tuned.ssc_t_df;
            }
        } else {
            results_.df_resid = static_cast<double>(std::max(0, Gc - 1));
            double ratio = 1.0;
            if (tuned.ssc_k_adj) {
                const double df_denom = std::max(
                    0.0, df_r_model +
                             static_cast<double>(nested_dof_used) -
                             static_cast<double>(nested_adj));
                if (df_denom > 0.0) {
                    ratio *= ols_result.df_resid / df_denom;
                }
            } else {
                const double denom = std::max(1.0, nobs - 1.0);
                ratio *= ols_result.df_resid / denom;
            }
            if (c_ptr->size() == 1 && !tuned.ssc_g_adj && Gc > 1) {
                ratio *= static_cast<double>(Gc - 1) / static_cast<double>(Gc);
            }
            if (ratio > 0.0 && hdfe::detail::ieee_finite(ratio)) {
                const double scale = std::sqrt(ratio);
                results_.std_errors *= scale;
                results_.covariance *= ratio;
                cluster_ratio = ratio;
            }
            results_.cluster_scale = ratio;
            if (tuned.ssc_t_df > 0.0) {
                results_.df_resid = tuned.ssc_t_df;
            }
        }
    } else if (df_r_model > 0.0) {
        results_.df_resid = tuned.ssc_t_df > 0.0 ? tuned.ssc_t_df : df_r_model;
    }
    if (saturated_model) {
        // Report the raw (possibly negative) residual df_r, matching reghdfe.
        results_.df_resid = df_r_raw;
    }

    bool intercept_cov_updated = false;
    bool entered_multiway_intercept_fallback = false;
    if (drop_intercept && options_.fit_intercept && !saturated_model) {
        intercept_cov_updated = update_intercept_covariance(
            results_, X_work, transformed_X_used, ols_result.residuals, w_ptr,
            kept_slope_cols, ols_result, tuned.se_type, c_ptr, tuned.ssc_g_df,
            tuned.ssc_g_adj, results_.sigma2, robust_scale, cluster_ratio,
                tuned.weights_are_frequencies, false, passes && passes->ready ? passes : nullptr,
            &entered_multiway_intercept_fallback);

        // Multiway clustering: rebuild from the extended bread and means-
        // restored scores (see the standard path; reghdfe semantics).
        if (tuned.se_type == StandardErrorType::Cluster && c_ptr &&
            c_ptr->size() > 1) {
            const int cov_cols = static_cast<int>(results_.covariance.cols());
            const int slope_cols_aug = static_cast<int>(kept_slope_cols.size());
            const int active_cov_cols = slope_cols_aug + 1;
            if (cpu_profile_enabled()) {
                std::cerr << "cpu_profile label=multiway_reconstruction_gate scope=grouped"
                          << " kept=" << slope_cols_aug << " full=" << cov_cols - 1
                          << " preliminary_fallback=" << entered_multiway_intercept_fallback
                          << " required=" << (active_cov_cols == cov_cols ||
                                              entered_multiway_intercept_fallback) << '\n';
            }
            if (slope_cols_aug > 0 &&
                active_cov_cols <= cov_cols &&
                (active_cov_cols == cov_cols || entered_multiway_intercept_fallback) &&
                slope_cols_aug == static_cast<int>(transformed_X_used.cols()) &&
                slope_cols_aug == static_cast<int>(ols_result.xtx_inv.cols()) &&
                slope_cols_aug == static_cast<int>(kept_slope_cols.size())) {
                const int n_rows = static_cast<int>(transformed_X_used.rows());
                Eigen::RowVectorXd means_x(slope_cols_aug);
                for (int j = 0; j < slope_cols_aug; ++j) {
                    means_x(j) = weighted_mean(
                        X_work.col(kept_slope_cols[static_cast<std::size_t>(j)]),
                        w_ptr);
                }
                // L3.1-C, C2: as in fit(), the ones are implicit unless
                // XHDFE_MULTIWAY_SCORES_COPY=1.
                const bool scores_copy = detail::multiway_scores_copy_enabled();
                Eigen::MatrixXd scores;
                if (scores_copy) {
                    scores.resize(n_rows, active_cov_cols);
                    scores.leftCols(slope_cols_aug) = transformed_X_used;
                    scores.col(slope_cols_aug).setOnes();
                }
                const double n_bread =
                    w_ptr ? w_ptr->sum() : static_cast<double>(n_rows);
                Eigen::MatrixXd bread = Eigen::MatrixXd::Zero(active_cov_cols, active_cov_cols);
                bread.topLeftCorner(slope_cols_aug, slope_cols_aug) =
                    ols_result.xtx_inv;
                bread(slope_cols_aug, slope_cols_aug) = 1.0 / n_bread;
                Eigen::MatrixXd cov_aug = scores_copy
                    ? detail::multiway_cluster_sandwich(
                          bread, scores, ols_result.residuals, w_ptr, *c_ptr,
                          tuned.ssc_g_df, tuned.ssc_g_adj, passes && passes->ready ? passes : nullptr)
                    : detail::multiway_cluster_sandwich_with_constant(
                          bread, transformed_X_used, ols_result.residuals, w_ptr, *c_ptr,
                          tuned.ssc_g_df, tuned.ssc_g_adj, passes && passes->ready ? passes : nullptr);
                Eigen::MatrixXd transport = Eigen::MatrixXd::Identity(active_cov_cols, active_cov_cols);
                transport.block(slope_cols_aug, 0, 1, slope_cols_aug) = -means_x;
                cov_aug = (transport * cov_aug * transport.transpose()).eval();
                double rescale = cluster_ratio;
                if (ols_result.df_resid > 0.0)
                    rescale *= (nobs - 1.0) / ols_result.df_resid;
                if (tuned.ssc_g_df == ClusterDofMethod::Min && tuned.ssc_g_adj && ols_result.num_clusters > 1)
                    rescale *= static_cast<double>(ols_result.num_clusters) / (ols_result.num_clusters - 1.0);
                if (rescale > 0.0 && hdfe::detail::ieee_finite(rescale) && hdfe::detail::ieee_all_finite(cov_aug)) {
                    if (active_cov_cols == cov_cols) {
                        results_.covariance = cov_aug * rescale;
                    } else {
                        results_.covariance.setZero();
                        for (int i = 0; i < active_cov_cols; ++i) {
                            const int row = i == slope_cols_aug ? cov_cols - 1
                                : kept_slope_cols[static_cast<std::size_t>(i)];
                            for (int j = 0; j < active_cov_cols; ++j) {
                                const int col = j == slope_cols_aug ? cov_cols - 1
                                    : kept_slope_cols[static_cast<std::size_t>(j)];
                                results_.covariance(row, col) = cov_aug(i, j) * rescale;
                            }
                        }
                    }
                    results_.std_errors =
                        results_.covariance.diagonal().cwiseMax(0.0).cwiseSqrt();
                    intercept_cov_updated = true;
                }
            }
        }
    }
    // Phase 5b: as in fit(), the pair is freed here, before any N1 re-entry.
    if (tuned.se_type == StandardErrorType::Cluster && c_ptr && c_ptr->size() >= 2) {
        const long long pair_rows = passes ? static_cast<long long>(passes->pair.size()) : 0;
        if (passes) passes->pair.resize(0);
        if (cpu_profile_enabled()) {
            std::cerr << "cpu_profile label=cluster_passes site=release pair_rows=" << pair_rows << '\n';
        }
    }

    if (tuned.se_type == StandardErrorType::Cluster && c_ptr && c_ptr->size() > 1) {
        const int cov_cols = static_cast<int>(results_.covariance.cols());
        const int slope_cols =
            (options_.fit_intercept && cov_cols > 0) ? (cov_cols - 1) : cov_cols;

        // Same Cameron-Gelbach-Miller PSD handling as the standard path (see
        // reghdfe_fix_psd): full-matrix clamp plus slope-block override and
        // the intercept range/Schur repair, in
        // reghdfe's standardized metric.
        Eigen::VectorXd psd_scale = Eigen::VectorXd::Ones(std::max(cov_cols, 0));
        if (cov_cols > 0) {
            for (const int column : kept_slope_cols) {
                const auto col = X_work.col(column);
                const double sd = psd_scale_sample_standard_deviation(
                    col, w_ptr, tuned.weights_are_frequencies);
                psd_scale(column) = std::max(sd, 1.0e-3);
            }
        }
        auto fix_psd_scaled = [&](Eigen::MatrixXd& V,
                                  const Eigen::Ref<const Eigen::VectorXd>& d) -> bool {
            Eigen::MatrixXd Vs = d.asDiagonal() * V * d.asDiagonal();
            if (!fix_psd(Vs)) {
                return false;
            }
            V = d.cwiseInverse().asDiagonal() * Vs * d.cwiseInverse().asDiagonal();
            return true;
        };

        const bool full_psd_ready = options_.fit_intercept && cov_cols > 0 &&
                                    intercept_cov_updated &&
                                    hdfe::detail::ieee_all_finite(results_.covariance);
        if (full_psd_ready) {
            Eigen::MatrixXd cov_full = results_.covariance;
            Eigen::MatrixXd cov_block =
                cov_full.topLeftCorner(slope_cols, slope_cols);
            const bool full_fixed = fix_psd_scaled(cov_full, psd_scale);
            const bool slopes_fixed = slope_cols > 0 &&
                fix_psd_scaled(cov_block, psd_scale.head(slope_cols));
            if (full_fixed || slopes_fixed) {
                cov_full.topLeftCorner(slope_cols, slope_cols) = cov_block;
                repair_intercept_covariance(cov_full,
                    results_.covariance.topLeftCorner(slope_cols, slope_cols), psd_scale);
                results_.covariance = cov_full;
                results_.std_errors = cov_full.diagonal().cwiseMax(0.0).cwiseSqrt();
                results_.vcv_psd_fixed = true;
            }
        } else if (slope_cols > 0) {
            Eigen::MatrixXd cov_block =
                results_.covariance.topLeftCorner(slope_cols, slope_cols);
            if (fix_psd_scaled(cov_block, psd_scale.head(slope_cols))) {
                results_.covariance.topLeftCorner(slope_cols, slope_cols) = cov_block;
                results_.std_errors.head(slope_cols) =
                    cov_block.diagonal().cwiseMax(0.0).cwiseSqrt();
                results_.vcv_psd_fixed = true;
            }
        }
    }

    if (tuned.dkraay_bandwidth >= 0) {
        detail::apply_dkraay_covariance(results_, ols_result, transformed_X_used,
            X_work, w_ptr, c_ptr, kept_slope_cols, drop_intercept, tuned);
    }
    for (const int column : omitted_slope_cols) {
        results_.covariance.row(column).setZero();
        results_.covariance.col(column).setZero();
        results_.std_errors[column] = std::numeric_limits<double>::quiet_NaN();
    }
    recompute_inference(results_.coefficients, results_.std_errors, results_.tvalues,
                        results_.pvalues, results_.conf_int, tuned.level, results_.df_resid,
                        tuned.inference_quantiles);
    normalize_nonfrequency_weighted_fit_stats(
        results_, tuned.weights_are_frequencies, w_ptr, sum_weights_for_stats);
    const bool fewer_than_two_clusters =
        tuned.se_type == StandardErrorType::Cluster && c_ptr &&
        !c_ptr->empty() && results_.num_clusters < 2;
    const bool inference_unavailable =
        saturated_model || fewer_than_two_clusters ||
        !(results_.df_resid > 0.0) ||
        !hdfe::detail::ieee_finite(results_.df_resid);
    if (saturated_model || fewer_than_two_clusters) {
        mark_inference_unavailable(results_);
    }
    enforce_estimation_output_postcondition(
        results_, drop_intercept, inference_unavailable);

    try {
        require_n1_fit(absorption, ols_result, kept_slope_cols,
                       transformed_has_intercept, transformed_full_cols, tuned,
                       have_precomputed ? &xtx_used : nullptr,
                       have_precomputed ? &xty_used : nullptr);
    } catch (const detail::N1Failure& failure) {
        const int remaining = n1_budget.remaining(absorption.iterations, failure);
        absorption = refine_n1_absorption(y_work, design, standard_fes_work, w_ptr,
            tuned, method_used_, {}, &gi_work, absorption, remaining);
        continue;
    }

    if (detail::ordinary_audit_enabled()) {
        detail::OrdinaryAuditReceipt audit("group_fit",tuned,absorption,false,n1_budget.used ? 1 : 0);
        audit.unsupported("group_individual");
        audit.emit();
    }
    // Point 14: as in fit(); the group/individual absorber never runs the
    // Krylov-PCG absorber, so this stays false on this path.
    krylov_pcg_published_ = tuned.use_krylov && absorption.krylov_pcg_used;
    end_parallel_observation();
    break;
    }
    const AbsorptionCacheKey grouped_signature = hash_grouped_fit_signature(
        y, X, fes, group_ids, *individual_ids, aggregation, weights, options_);
    grouped_signature_1_ = grouped_signature.sig1;
    grouped_signature_2_ = grouped_signature.sig2;
    grouped_signature_valid_ = true;
    attempt.commit(LifecycleState::GroupedReady);
}

GroupIndividualFeEstimates HdfeRegressorV11::extract_group_individual_fes(
    const Eigen::Ref<const Eigen::VectorXd>& y,
    const Eigen::Ref<const Eigen::MatrixXd>& X,
    const std::vector<Eigen::VectorXi>& fes,
    const Eigen::VectorXi& group_ids,
    const Eigen::VectorXi& individual_ids,
    GroupAggregation aggregation,
    const Eigen::VectorXd* weights,
    const GroupIndividualFeOptions& options) const {
    if (options.max_iter_main <= 0 || options.max_iter_solver <= 0) {
        throw std::runtime_error("Group/individual FE recovery iteration limits must be positive");
    }
    if (lifecycle_state_ != LifecycleState::GroupedReady ||
        !results_.converged ||
        !results_.precision_certified) {
        throw std::runtime_error(
            "extract_group_individual_fes requires a successful, "
            "precision-certified fit() first");
    }
    if (y.size() == 0) {
        throw std::runtime_error("Outcome vector must be non-empty");
    }
    const int n = static_cast<int>(y.size());
    if (X.rows() != n) {
        throw std::runtime_error("X must have the same number of rows as y");
    }
    require_finite_vector(y, "y");
    require_finite_matrix(X, "X");
    if (group_ids.size() != n) {
        throw std::runtime_error("group_ids must have the same length as y");
    }
    require_nonnegative_ids(group_ids, "group IDs");
    if (individual_ids.size() != n) {
        throw std::runtime_error("individual_ids must have the same length as y");
    }
    require_nonnegative_ids(individual_ids, "individual IDs");
    if (weights && weights->size() != n) {
        throw std::runtime_error("weights must have the same length as y");
    }
    if (fes.empty()) {
        throw std::runtime_error("fes must include individual_ids when extracting group/individual effects");
    }
    for (const auto& fe : fes) {
        if (fe.size() != n) {
            throw std::runtime_error("Each fixed-effect vector must be length n");
        }
        require_nonnegative_ids(fe, "fixed-effect IDs");
    }

    const int individual_fe_index = find_identical_fe(individual_ids, fes);
    if (individual_fe_index < 0) {
        throw std::runtime_error("individual_ids must also be included in fes");
    }

    const AbsorptionCacheKey supplied_signature = hash_grouped_fit_signature(
        y, X, fes, group_ids, individual_ids, aggregation, weights, options_);
    if (!grouped_signature_valid_ ||
        supplied_signature.sig1 != grouped_signature_1_ ||
        supplied_signature.sig2 != grouped_signature_2_) {
        throw std::runtime_error(
            "extract_group_individual_fes inputs and fit semantics must "
            "exactly match the last successful grouped fit");
    }

    GroupCollapsedData collapsed =
        collapse_group_long_format(y, X, fes, group_ids, &individual_ids, individual_fe_index,
                                   aggregation, weights,
                                   options_.weights_are_frequencies, nullptr);
    drop_zero_weight_groups(collapsed, aggregation, options_.weights_are_frequencies);

    if (options_.drop_singletons) {
        if (options_.weights_are_frequencies && collapsed.weights) {
            // Validate the collapsed total even when this extraction call is
            // reached independently of the preceding fit.
            (void)checked_frequency_weight_sum(*collapsed.weights);
        }
        const GroupSingletonDropResult dropped =
            drop_singletons_group_individual(
                collapsed.standard_fes, collapsed.gi,
                options_.weights_are_frequencies && collapsed.weights
                    ? &(*collapsed.weights)
                    : nullptr);
        if (dropped.dropped_groups > 0) {
            collapsed = filter_group_collapsed(collapsed, dropped.keep_groups,
                                               dropped.individual_degrees, aggregation);
        }
    }

    const Eigen::VectorXd* w_ptr = collapsed.weights ? &(*collapsed.weights) : nullptr;
    // One resolution on this path: the lease is taken directly and released
    // on every exit path.
    detail::AutoTeamRegistration team_registration;
    const ThreadResolution extraction_thread_resolution = coordinate_auto_team(
        resolve_threads(static_cast<int>(collapsed.y.size()),
                        static_cast<int>(collapsed.standard_fes.size() + 1)),
        static_cast<int>(collapsed.y.size()),
        static_cast<int>(collapsed.standard_fes.size() + 1), team_registration,
        true);
    const int extraction_threads = extraction_thread_resolution.effective;
    ScopedParallelRuntime parallel_runtime(
        extraction_threads, extraction_thread_resolution.capacity);
    detail::ParallelWorkObserver extraction_observer;
    extraction_observer.reset();

    const int coef_size = static_cast<int>(results_.coefficients.size());
    const int x_cols = static_cast<int>(collapsed.X.cols());
    const int slope_cols = options_.fit_intercept ? (coef_size - 1) : coef_size;
    if (slope_cols != x_cols) {
        throw std::runtime_error("Coefficient dimension mismatch: X columns differ from last fit()");
    }

    Eigen::VectorXd linear = Eigen::VectorXd::Zero(collapsed.y.size());
    if (slope_cols > 0) {
        linear.noalias() = collapsed.X * results_.coefficients.head(slope_cols);
    }
    // Match reghdfe's predict, d convention: remove only the slope component (exclude _cons),
    // then project onto the FE space.
    const Eigen::VectorXd y_minus_xb = collapsed.y - linear;
    // Stata's predict, d returns the fitted fixed-effect component (excluding the regression residual).
    // Compute it as (y - Xb) - M(y - Xb), where M is the within transformation that partials out
    // the group/individual and standard fixed effects.
    HdfeOptions tuned = options_;
    tuned.num_threads = extraction_threads;
    tuned.num_threads_explicit =
        extraction_thread_resolution.requested > 0;
    tuned.parallel_observer = &extraction_observer;
    tuned.max_iter = std::max(tuned.max_iter, 20000);
    tuned.tol = std::min(tuned.tol, 1e-15);
    AbsorptionMethod extraction_method = method_used_;
    if (options_.absorption_method == AbsorptionMethod::Auto) {
        // Re-enter through the internal Auto context used by the successful
        // fit. In particular, CUDA Auto may have reported LSMR as the method
        // actually used, but that must not be reinterpreted as a public
        // absorptionmethod(lsmr) request, which remains CPU-only.
        tuned.absorption_method = AbsorptionMethod::Auto;
        tuned.from_auto = !options_.symmetric_sweep;
        extraction_method = AbsorptionMethod::Auto;
    }
    Eigen::MatrixXd empty_X(static_cast<int>(y_minus_xb.size()), 0);
    const detail::AbsorptionResult absorbed =
        detail::absorb_fixed_effects_group_individual(y_minus_xb, empty_X, collapsed.standard_fes,
                                                      collapsed.gi, w_ptr, tuned,
                                                      extraction_method);
    if (!absorbed.converged || !absorbed.precision_certified) {
        throw std::runtime_error(
            "Group/individual FE extraction absorption did not converge "
            "and pass the independent precision certificate");
    }
    Eigen::VectorXd d = y_minus_xb - absorbed.y_tilde;
    const int recovery_scale_exponent = detail::fe_recovery_scale_exponent(d);
    if (recovery_scale_exponent < 0)
        detail::scale_fe_recovery_vector(d, -recovery_scale_exponent);

    const int G = collapsed.gi.num_groups;
    const int I = collapsed.gi.num_individuals;
    if (G != d.size()) {
        throw std::runtime_error("Internal error: group count mismatch");
    }
    if (I <= 0) {
        throw std::runtime_error("Group/individual structure must have at least one individual");
    }

    const int K = static_cast<int>(collapsed.standard_fes.size());
    if (K > 3) {
        throw std::runtime_error("extract_group_individual_fes supports up to 3 standard fixed effects (Stata extractfes limit)");
    }

    std::vector<FeIndexMap> maps;
    maps.reserve(static_cast<std::size_t>(K));
    std::vector<Eigen::VectorXd> fe_level_values;
    std::vector<Eigen::VectorXd> fe_group_values;
    fe_level_values.reserve(static_cast<std::size_t>(K));
    fe_group_values.reserve(static_cast<std::size_t>(K));
    for (int k = 0; k < K; ++k) {
        maps.push_back(build_fe_index_map(collapsed.standard_fes[static_cast<std::size_t>(k)]));
        fe_level_values.emplace_back(Eigen::VectorXd::Zero(maps.back().raw_values.size()));
        fe_group_values.emplace_back(Eigen::VectorXd::Zero(G));
    }

    Eigen::VectorXd a = Eigen::VectorXd::Zero(I);
    Eigen::VectorXd a_prev1 = Eigen::VectorXd::Zero(I);
    Eigen::VectorXd a_prev2 = Eigen::VectorXd::Zero(I);
    Eigen::VectorXd a_long(G);

    const Eigen::VectorXd precond =
        gi_preconditioner(collapsed.gi, w_ptr, tuned.num_threads,
                          &extraction_observer);

    double tols = options.tol_start;
    double mse = options.tol_main + 1.0;
    int iter = 0;
    bool converged = false;
    double constant = 0.0;

    while (mse > options.tol_main) {
        gi_group_sum(collapsed.gi, a, a_long, tuned.num_threads,
                     &extraction_observer);

        if (K == 0) {
            Eigen::VectorXd resid = d - a_long;
            constant = weighted_mean(resid, w_ptr);
        } else {
            for (int k = 0; k < K; ++k) {
                Eigen::VectorXd resid = d - a_long;
                for (int j = 0; j < K; ++j) {
                    if (j == k) {
                        continue;
                    }
                    resid.noalias() -= fe_group_values[static_cast<std::size_t>(j)];
                }
                update_standard_fe(resid,
                                   maps[static_cast<std::size_t>(k)],
                                   w_ptr,
                                   fe_level_values[static_cast<std::size_t>(k)],
                                   fe_group_values[static_cast<std::size_t>(k)],
                                   tuned.num_threads, &extraction_observer);
            }
        }

        Eigen::VectorXd dd = d;
        if (K == 0) {
            dd.array() -= constant;
        } else {
            for (int k = 0; k < K; ++k) {
                dd.noalias() -= fe_group_values[static_cast<std::size_t>(k)];
            }
        }

        a_prev2 = a_prev1;
        a_prev1 = a;
        a = solve_a1(std::move(a), collapsed.gi, dd, w_ptr, precond,
                     options.max_iter_solver, tols, options.verbose,
                     tuned.num_threads, &extraction_observer);

        if (mse < options.factor * tols) {
            tols = std::max(tols / 10.0, options.tol_final);
        }

        if (iter > options.start_accel && options.accel > 0 && options.every_accel > 0 &&
            (iter % options.every_accel) == 0) {
            a = accel_a1(a, a_prev1, a_prev2, options.accel, options.a1p1, options.a2p1,
                         options.a2p2);
        }

        gi_group_sum(collapsed.gi, a, a_long, tuned.num_threads,
                     &extraction_observer);

        Eigen::VectorXd resid = d - a_long;
        if (K == 0) {
            resid.array() -= constant;
        } else {
            for (int k = 0; k < K; ++k) {
                resid.noalias() -= fe_group_values[static_cast<std::size_t>(k)];
            }
        }
        mse = weighted_mse(resid, w_ptr);
        ++iter;
        if (options.verbose > 0) {
            std::cout << "iter: " << iter << " mse=" << mse << "\n";
        }
        if (iter >= options.max_iter_main) {
            break;
        }
    }
    converged = (mse <= options.tol_main);
    if (!converged || !hdfe::detail::ieee_finite(mse)) {
        std::ostringstream message;
        message << "Group/individual fixed-effect recovery did not converge; iterations="
                << iter << "/" << options.max_iter_main
                << "; mse=" << std::scientific << mse
                << "; requested tolerance=" << options.tol_main
                << ". No fixed-effect estimates returned. Check scaling and the iteration limits.";
        throw std::runtime_error(message.str());
    }

    GroupIndividualFeEstimates out;
    out.individual_ids = collapsed.individual_values;
    if (recovery_scale_exponent < 0) {
        detail::scale_fe_recovery_vector(a, recovery_scale_exponent);
        for (auto& values : fe_level_values)
            detail::scale_fe_recovery_vector(values, recovery_scale_exponent);
        mse = std::ldexp(mse, 2 * recovery_scale_exponent);
    }
    out.individual_effects = std::move(a);
    out.fe_level_ids.reserve(static_cast<std::size_t>(K));
    out.fe_level_effects.reserve(static_cast<std::size_t>(K));
    for (int k = 0; k < K; ++k) {
        out.fe_level_ids.push_back(maps[static_cast<std::size_t>(k)].raw_values);
        out.fe_level_effects.push_back(fe_level_values[static_cast<std::size_t>(k)]);
    }
    out.iterations = iter;
    out.converged = converged;
    out.mse = mse;
    out.threads_requested = extraction_thread_resolution.requested;
    out.threads_effective = extraction_thread_resolution.effective;
    out.threads_used = std::max(1, extraction_observer.max_team_size());
    out.parallel_workers_active =
        std::max(1, extraction_observer.active_workers());
    out.thread_capacity = extraction_thread_resolution.capacity;
    out.openmp_enabled = extraction_thread_resolution.openmp_enabled;
    out.thread_limit_code = extraction_thread_resolution.limit_code;
    out.thread_limit_reason = extraction_thread_resolution.limit_reason;
    return out;
}

}  // namespace v11
}  // namespace hdfe
