# xhdfe / xfepout --- offline source distribution (version 2.28.0.20260924)

Self-contained sources to build every native component for CPU and GPU with
**no internet access**. Native package dependencies are vendored (Eigen,
pybind11, the official Rcpp 1.1.2 CRAN source archive, and Stata `stplugin`
inputs). Python runtime dependencies must be present in the local environment.

## System requirements (not bundled)

- A C++17 compiler (GCC/Clang; MSVC on Windows).
- For GPU: the NVIDIA CUDA toolkit (`nvcc`) and a compatible driver.
- Python builds: Python >= 3.9 with development headers, CMake >= 3.18, and
  NumPy >= 1.23 already installed.
- Optional Python formula interface: Formulaic >= 1.2.1,<2 and its pandas/SciPy
  dependencies already installed; these optional runtime packages are not
  vendored in this archive.
- R builds: R >= 4.0, its source-package build toolchain, and OpenMP support.
  Rcpp itself is bundled and does not need to be downloaded or preinstalled.
  `XHDFE_ALLOW_SERIAL_BUILD=1` is reserved for explicit diagnostic builds and
  is forbidden for releases.
- Stata builds: none beyond the C++ (and CUDA) toolchain.
- macOS Stata release builds: CMake >= 3.20, Python 3, the native Apple build
  tools, and the pinned LLVM OpenMP source archive in
  `third_party/LLVM-OpenMP-20.1.8-source.tar.gz` on a native macOS build host.

## Stata plugin

```bash
# CPU (OpenMP required for production)
bash stata/tools/build-plugin.sh     --linux --openmp
bash stata/tools/build-xfepout-plugin.sh --linux --openmp
# GPU (auto-detect the local NVIDIA architecture)
XHDFE_ENABLE_CUDA=auto bash stata/tools/build-plugin.sh     --linux --openmp
XHDFE_ENABLE_CUDA=auto bash stata/tools/build-xfepout-plugin.sh --linux --openmp
```

Produces `stata/xhdfe.plugin` and `stata/xfepout.plugin`. Put them on the Stata
adopath (next to `xhdfe.ado`). The `xhdfegpu` command automates the GPU case.

On a native macOS host, extract the bundled source, build the SDK for that
host's architecture, and build both plugins against its absolute SDK path:

```bash
mkdir llvm-openmp-20.1.8-source
tar -xzf third_party/LLVM-OpenMP-20.1.8-source.tar.gz \
  -C llvm-openmp-20.1.8-source
sdk_root="$PWD/macos-openmp-sdk"
arch="$(uname -m)"
bash tools/build_macos_openmp_runtime.sh \
  "$PWD/llvm-openmp-20.1.8-source" "$sdk_root" "$arch"
XHDFE_MACOS_ARCHS="$arch" XHDFE_OPENMP_ROOT="$sdk_root" \
  bash stata/tools/build-plugin.sh --openmp
XHDFE_MACOS_ARCHS="$arch" XHDFE_OPENMP_ROOT="$sdk_root" \
  bash stata/tools/build-xfepout-plugin.sh --openmp
```

The builders run `validate_macos_openmp.py inspect` on each native file. A
universal release requires separate native arm64 and x86_64 SDKs, followed by
the release manifest assembly and native validation on both architectures;
the SDK directory alone is not an input to the final `verify` command.

## Python package

```bash
python -m pip install .                      # CPU
XHDFE_ENABLE_CUDA=auto python -m pip install .   # GPU
# Formula frontend, when its optional dependencies are available locally:
python -m pip install --no-index --no-deps --no-build-isolation '.[formula]'
```

## R package

```bash
mkdir -p r/Rlib

# Install the pinned dependency locally, with user/site startup files disabled.
R_PROFILE_USER=/dev/null R_ENVIRON_USER=/dev/null \
  R_LIBS_USER="$PWD/r/Rlib" \
  R CMD INSTALL --library="$PWD/r/Rlib" third_party/Rcpp_1.1.2.tar.gz

# CPU
R_PROFILE_USER=/dev/null R_ENVIRON_USER=/dev/null \
  R_LIBS_USER="$PWD/r/Rlib" XHDFE_ENABLE_CUDA=OFF \
  R CMD INSTALL --library="$PWD/r/Rlib" r/xhdfe

# GPU (optional; install into a separate local library if both builds are kept)
mkdir -p r/Rlib_cuda
R_PROFILE_USER=/dev/null R_ENVIRON_USER=/dev/null \
  R_LIBS_USER="$PWD/r/Rlib_cuda" \
  R CMD INSTALL --library="$PWD/r/Rlib_cuda" third_party/Rcpp_1.1.2.tar.gz
R_PROFILE_USER=/dev/null R_ENVIRON_USER=/dev/null \
  R_LIBS_USER="$PWD/r/Rlib_cuda" XHDFE_ENABLE_CUDA=auto \
  R CMD INSTALL --library="$PWD/r/Rlib_cuda" r/xhdfe
```

The unmodified Rcpp archive's URL, license, version, and SHA-256 are recorded
in `third_party/RCPP_SOURCE_PROVENANCE.md`.

CPU is the reference backend. GPU builds auto-detect the local compute
capability via `nvidia-smi`; set `XHDFE_CUDA_ARCH=90` to force a target.
