"""Gelbach (2016) coefficient-movement decomposition, HDFE-aware (M9B).

This module provides specification accounting, not causal mediation. A causal
interpretation requires a separately justified research design; block names
and the decision to add a control or fixed effect are supplied by the user and
are not validated by the command.

Decomposes the change in the base-specification coefficients when covariate
groups (and/or absorbed fixed-effect blocks) are added:

    base:  y = X1*b_base + common FEs C + e_base
    full:  y = X1*b_full + sum_g X2_g*G_g + C + added FEs A + e

    b_base - b_full = sum_g delta_g,
    delta_g = (X1_C'X1_C)^{-1} X1_C'H_g,C

with H_g = X2_g @ G_g for observed groups and H_d = the observation-level
fixed-effect contribution for added absorbed dimensions (recovered by the
xhdfe core). The C subscript denotes partialling out ``common_fes``. Those
dimensions condition base, full and every auxiliary projection; they are not
contribution blocks. Without common FEs, X1_C = [X1, 1] and the historical
b1x2-compatible intercept contract is unchanged. With common FEs, the slope
identity and inference remain available, while the intercept allocation is
normalization-dependent and its public point/covariance entries are missing.

The default is the standard Gelbach estimand and remains fail-closed when an
X1 column is not identified in the full model. ``absorbed_targets=`` activates
a separate constrained estimand for a focal X1 column that belongs to the span
of an added FE (for example, a worker-invariant group indicator with worker
FEs). The backend must classify every declared target specifically as
FE-collinear; its full-model coefficient is imposed at zero and labelled
``imposed_zero``. It is not an estimated within-FE coefficient. Undeclared
omissions and generic rank dependencies still raise an error.

Inference reproduces b1x2 (validated to machine precision in
tests/validation/VALIDATE_GELBACH.py):

The reported covariance is the random-design/stacked-moment variance used by
``b1x2``: it includes sampling variation in the auxiliary projections. It is
not the smaller variance conditional on the realised covariate matrix. For an
absorbed target, the target-target block of ``total_cov`` is anchored to the
same base-model VCE because ``total_j`` and ``b_base_j`` are one estimator.

- vce='unadjusted' (default): V[d_g,d_h] = Omega[v_g,v_h]*(X1~'X1~)^{-1}
  (auxregV) + Gamma_g' V(G) Gamma_h (v2upart), Omega = centred residual
  cross-products / df_full. The stacked cross terms are identically zero
  (e is orthogonal to X2 in sample), so b1x2's cov0 coincides with its
  default here.
- vce='robust' / vce='cluster' (with `cluster` ids): b1x2's stacked-system
  sandwich. Bread = blockdiag(S, I_G x P) with S the full-design
  (X'X)^{-1} — in the absorbed case the within-transformed representation,
  obtained by absorbing the fixed effects out of each [x1, x2] column;
  scores = (X_i e_i ; X1~_i v_gi). Multipliers match b1x2/_robust:
  stacked n/(n-1) (G_c/(G_c-1) clustered), full-model n/df_full
  ((n-1)/df_full * G_c/(G_c-1) clustered). The total-change variance is the
  sum over all block pairs (equals b1x2's reported __TC).

Options: gamma0=True -> auxregV only (b1x2 gamma0); cov0=True -> drop the
robust cross terms (no-op for vce='unadjusted'). Absorbed FE blocks always
receive the gamma0 treatment (the sampling variance of absorbed
coefficients is unavailable by construction); observed groups get the full
formula, including robust cross terms via the within representation.
Accordingly, ``total_se_type`` is labelled ``mixed_*_conditional_fe`` when a
total combines fully modelled observed blocks with conditional FE blocks.

For every observed-block contribution row, the backend also evaluates the
product gradient ``[beta2_g, Gamma_rg]``. Ordinary first-order delta-method
inference is marked valid only when the requested-VCE joint Wald test rejects
``beta2_g = 0`` or, if it does not, a Bonferroni rowwise test rejects
``Gamma_rg = 0``. Each component test uses half of
``regularity_test_alpha=0.05`` so that the exposed value is the family-wise
level for their union. Failure to reject is not proof that the population
gradient is zero: it is reported conservatively as
``nonregular_not_ruled_out``. Numerical SEs are preserved for diagnosis, while
``notes``, runtime warnings, tidy rows and contrasts label the corresponding
normal confidence intervals as diagnostic only. ``auxiliary_loadings`` are the
true projection loadings; the legacy ``gamma`` field remains the padded
full-model X2 coefficients for backward compatibility.

Per the brief, NO KSS-style correction is applied: the contributions are
linear functionals of the fixed effects and largely escape the quadratic
limited-mobility bias. Stata-style aweights and fweights are supported
(weights=, fweights=True), matching b1x2's weighted estimators exactly.

Fast/legacy paths (compiled core): the default fast path resolves the
per-FE-dimension split via an MLSMR exact-normal-equations solve with a
fail-closed convergence gate — it is the MORE-converged path. The env
kill-switches XHDFE_GELBACH_FAST_FIT=0 / XHDFE_GELBACH_WARM_RECOVERY=0 /
XHDFE_GELBACH_WITHIN_BATCH=0 exist for bitwise A/B reproduction of the
pre-2.14.1 legacy output only; on ill-conditioned FE graphs the legacy
retained path's per-dimension FE split can be materially wrong (its GS
recovery certificate is blind to slow graph modes — adversarial audit
09jul2026, finding G1) and is now cross-checked and flagged via
`converged`/`notes`. Do NOT treat FAST_FIT=0 as a safety fallback.

Severely near-collinear columns inside an observed x2 block are detected with
a bounded-cost normalized-Gram diagnostic. The decomposition values are left
unchanged, but ``notes`` and a ``RuntimeWarning`` flag that the block SE split
can be tolerance/rounding sensitive. For clustered VCE, the streamed meat may
use FMA and differ from the former materialized path by one last-place unit in
well-conditioned cells; coefficients and deltas remain bit-identical.

Separately, each focal X1 column reports its FE-residual squared-norm ratio.
The backend classifies it as absorbed at a ratio no larger than 1e-9; the
diagnostic-only band immediately above that boundary through 1e-4 emits a
``RuntimeWarning`` and sets ``x1_near_collinear_mask`` without changing any
estimate, covariance, or rank decision.

Note on interpretation: component diagnostics are computed on the retained
sample for the pair selected by ``connectivity_fes`` among the added
dimensions in ``fes`` (the first two added FEs by default). With no common FEs
and exactly two added FE dimensions, one component certifies the x1-row split;
two or more components make the per-dimension split normalization-dependent.
``connected='require'`` turns that certificate into a fail-closed gate. With
common FEs, the selected pair remains informative but cannot certify the
larger common-plus-added FE normalization, so the result reports
``fe_split_status='not_certified_with_common_fes'``. With three or more added
FE dimensions, it reports ``not_certified_multiway``. In every case the total
across added FE dimensions and b_base - b_full are normalization-invariant.
"""

from __future__ import annotations

from statistics import NormalDist

import numpy as np


__all__ = [
    "decompose",
    "bootstrap",
    "tidy",
    "contrast",
    "etable",
    "waterfall_data",
    "coefplot",
]


def _core():
    import sys

    core = sys.modules.get("py_hdfe_v11")
    if core is None:
        core = sys.modules.get("xhdfe.py_hdfe_v11")
    if core is None:
        from . import py_hdfe_v11 as core
    return core


def _cluster_meat(Z, codes):
    if codes is None:
        return Z.T @ Z
    G = int(codes.max()) + 1
    sums = np.zeros((G, Z.shape[1]))
    np.add.at(sums, codes, Z)
    return sums.T @ sums


def _x1_labels(p, x1_names=None):
    if x1_names is None:
        return [f"x1_{v + 1}" for v in range(p)]
    labels = list(x1_names)
    if len(labels) != p:
        raise ValueError("x1_names must have one entry per x1 column")
    if any(not isinstance(label, str) or not label.strip() for label in labels):
        raise ValueError("x1_names must contain non-empty strings")
    labels = [label.strip() for label in labels]
    if len(set(labels)) != len(labels):
        raise ValueError("x1_names must be unique")
    if "_cons" in labels:
        raise ValueError("x1_names may not use the reserved name '_cons'")
    return labels


def _focal_indices(focal, p, labels):
    """Normalize a reporting-only focal selector to zero-based indices."""
    if focal is None:
        return list(range(p))
    values = np.asarray(focal if np.ndim(focal) else [focal], dtype=object)
    if values.ndim != 1:
        raise ValueError("focal must be a one-dimensional name/index selector")
    if values.size == p and all(isinstance(v, (bool, np.bool_)) for v in values):
        indices = np.flatnonzero(values.astype(bool)).astype(int).tolist()
    elif all(isinstance(v, str) for v in values):
        unknown = [v for v in values if v not in labels]
        if unknown:
            raise ValueError(f"focal contains unknown x1 name(s): {unknown}")
        indices = [labels.index(v) for v in values]
    else:
        indices = []
        for value in values:
            if isinstance(value, (bool, np.bool_)) or not isinstance(
                    value, (int, np.integer)):
                raise ValueError("focal must contain x1 names, zero-based indices, or a boolean mask")
            indices.append(int(value))
        if any(value < 0 or value >= p for value in indices):
            raise ValueError("focal index is outside the x1 column range")
    if not indices:
        raise ValueError("focal must select at least one x1 column")
    if len(set(indices)) != len(indices):
        raise ValueError("focal entries must be unique")
    return indices


def _connectivity_fe_indices(connectivity_fes, fe_names):
    """Normalize an FE-pair selector to zero-based indices."""
    if connectivity_fes is None:
        return []
    if isinstance(connectivity_fes, (str, int, np.integer)):
        values = [connectivity_fes]
    else:
        try:
            values = list(connectivity_fes)
        except TypeError as exc:
            raise ValueError(
                "connectivity_fes must contain exactly two FE names or "
                "zero-based indices"
            ) from exc
    if len(values) != 2:
        raise ValueError(
            "connectivity_fes must contain exactly two FE names or "
            "zero-based indices"
        )
    if all(isinstance(value, str) for value in values):
        unknown = [value for value in values if value not in fe_names]
        if unknown:
            raise ValueError(
                f"connectivity_fes contains unknown FE name(s): {unknown}"
            )
        indices = [fe_names.index(value) for value in values]
    elif any(isinstance(value, str) for value in values):
        raise ValueError(
            "connectivity_fes must use either FE names or zero-based "
            "indices, not a mixture"
        )
    else:
        indices = []
        for value in values:
            if isinstance(value, (bool, np.bool_)) or not isinstance(
                    value, (int, np.integer)):
                raise ValueError(
                    "connectivity_fes indices must be integers"
                )
            indices.append(int(value))
        if any(value < 0 or value >= len(fe_names) for value in indices):
            raise ValueError(
                "connectivity_fes index is outside the FE dimension range"
            )
    if indices[0] == indices[1]:
        raise ValueError("connectivity_fes entries must be distinct")
    return indices


def decompose(y, x1, x2_groups=None, fes=None, vce="unadjusted", cluster=None,
              gamma0=False, cov0=False, tol=1e-8, num_threads=0,
              weights=None, fweights=False, absorbed_targets=None,
              x1_names=None, focal=None, gpu=False, connected="diagnose",
              connectivity_fes=None, common_fes=None, sample_info=False,
              fe_variance_ratio_min=0.35):
    """Gelbach decomposition of the coefficient movement b_base - b_full.

    The result is an accounting identity for the declared base and full
    specifications. It does not identify a causal mechanism or mediated
    effect.

    Parameters
    ----------
    y : (n,) outcome.
    x1 : (n, p) base covariates (no constant column; one is implicit).
    x2_groups : dict name -> (n,) or (n, q_g) observed covariate group(s).
    fes : dict name -> (n,) integer ids of fixed-effect dimensions added only
        to the full model and reported as decomposable contribution blocks.
    common_fes : optional dict name -> (n,) integer ids of fixed-effect
        dimensions absorbed in both the base and full specifications. They
        condition the decomposition and are not themselves reported as
        contribution blocks. Slope rows retain the full point/inference
        contract; the ``_cons`` row is returned missing because its allocation
        depends on common-FE normalization.
    vce : 'unadjusted' (b1x2 default), 'robust', or 'cluster' (requires
        `cluster` ids). Matches b1x2's estimators exactly (see module doc).
    cluster : optional length-n one-way cluster ids. Required exactly when
        ``vce='cluster'``; at least two clusters are required.
    gamma0 : bool — aux-regression variance only (b1x2's gamma0).
    cov0 : bool — drop the robust cross terms (b1x2's cov0; no-op for
        vce='unadjusted').
    tol : positive float — fixed-effect absorption tolerance. The default
        1e-8 preserves the historical effective tolerance of this wrapper.
        It controls iterative absorption, not the separate FE-collinearity
        classification. The latter uses the documented squared-norm rule
        ``||M_D x||^2 / ||x||^2 <= 1e-9`` (relative norm about 3.16e-5),
        returned as metadata.
    num_threads : nonnegative OpenMP thread request; zero uses the library
        automatic policy. A positive request bypasses automatic workload
        heuristics and is limited only by the processor/OpenMP capacity
        visible to the running process. The returned ``threads_*`` fields
        distinguish the request, the effective capacity-limited budget, and
        workers actually observed doing useful work.
    gpu : bool — request CUDA for the full-model absorption phase. This is
        opt-in; CPU remains the reference and any fallback is reported in the
        returned GPU diagnostics.
    weights : optional positive analytic or frequency weights.
    fweights : interpret ``weights`` as positive integer frequency weights.
    absorbed_targets : optional X1 names, zero-based column indices, or a
        length-p boolean mask. This activates a distinct, constrained estimand
        for targets that are fully absorbed by ``fes``. Every declared target
        must be classified by the backend as collinear with the absorbed FEs;
        its full-model coefficient is imposed at zero, not estimated. The
        standard rank guard is unchanged when this argument is omitted.
    x1_names : optional sequence of unique names for the X1 columns. Names are
        reporting metadata only and do not alter the design matrix.
    focal : optional X1 names, zero-based indices, or length-p boolean mask.
        This selects the coefficients to report in :func:`tidy`; all X1
        columns remain in both the base and full specifications. It is useful
        when X1 contains one focal regressor plus common controls. The
        decomposition and returned full-precision matrices are unchanged.
    connected : ``'diagnose'`` (default) or ``'require'``. Require mode fails
        closed unless there are no common FEs and exactly two added FE
        dimensions form one mobility component in the retained sample.
        Common-FE and three-or-more-added-FE splits are not yet
        connectivity-certified and therefore cannot pass require mode.
    connectivity_fes : optional pair of FE names or zero-based indices.
        Selects the retained-sample pair diagnostic among the added dimensions
        in ``fes``. Common FEs cannot be selected. The default is the first two
        added FE dimensions. With common FEs or three or more added FEs the
        selected pair remains a diagnostic, never a global identification
        certificate.
    sample_info : bool, default False.
        Opt in to retained-sample provenance. The result then contains the
        zero-based positions into the supplied arrays (``sample_index``), a
        length-n Boolean ``sample_mask``, and a stable non-cryptographic
        ``sample_hash`` together with its declared algorithm and scope.
        Leaving this false avoids the extra O(n) hash and output allocation.
    fe_variance_ratio_min : nonnegative float, default 0.35.
        Diagnostic threshold for the residual-to-total X1 squared-norm ratio.
        With added FEs, ratios at or below this value mark conditional FE-block
        and mixed-total normal intervals as diagnostic only; no estimate or
        covariance is changed.

    Returns
    -------
    dict with 'b_base', 'b_full', per-group 'delta' (contribution over
    [x1..., _cons] with 'se'), 'total' (with SE), 'cov', 'identity_gap',
    full-model observed-block 'gamma', sample sizes and notes. The total
    covariance is available both as ``total['cov']`` and the cross-language
    top-level alias ``total_cov``. ``base_cov``, ``cov_delta_bbase`` and
    ``cov_total_bbase`` support joint base-share inference. ``beta2``,
    ``beta2_cov``, ``auxiliary_loadings`` and the per-block ``regularity``
    dictionary expose the product-gradient diagnostic.
    ``regular_inference_valid`` and ``regular_inference_status`` are keyed by
    observed block and contain one entry per [x1..., _cons] row. ``fe_total``
    is the normalization-safe aggregate of added FEs. Common-FE metadata and
    the intercept boundary are exposed through ``common_fe_names``,
    ``n_common_fes``, ``common_fes_applied``,
    ``intercept_inference_available`` and ``intercept_status``. Always inspect
    ``converged``, ``notes``, ``regular_inference_valid``,
    ``fe_split_status``, ``total_se_type``, the GPU diagnostics
    when ``gpu=True`` and, in absorbed-target mode,
    ``absorbed_target_inference_valid``. With ``sample_info=True``, the
    zero-based ``sample_index``, Boolean ``sample_mask``, and declared
    non-cryptographic ``sample_hash`` make the retained sample auditable.

    See Also
    --------
    ``xhdfe.help_text('gelbach')`` documents every field, share convention,
    inference qualifier, example and deliberate limitation.
    """
    y = np.ascontiguousarray(y, dtype=float)
    if y.ndim != 1:
        raise ValueError("y must be one-dimensional")
    x1 = np.asarray(x1, dtype=float)
    if x1.ndim == 1:
        x1 = x1[:, None]
    n, p = x1.shape
    if p == 0:
        raise ValueError("x1 must contain at least one focal column")
    x1_labels = _x1_labels(p, x1_names)
    focal_x1 = _focal_indices(focal, p, x1_labels)
    if y.shape[0] != n:
        raise ValueError("y and x1 must have the same number of rows")
    if not np.all(np.isfinite(y)) or not np.all(np.isfinite(x1)):
        raise ValueError("y and x1 must contain only finite values")
    if not np.isfinite(tol) or tol <= 0:
        raise ValueError("tol must be finite and strictly positive")
    if (
        isinstance(num_threads, (bool, np.bool_))
        or not isinstance(num_threads, (int, np.integer))
    ):
        raise TypeError("num_threads must be a nonnegative integer")
    if num_threads < 0:
        raise ValueError("num_threads must be a nonnegative integer")
    if not isinstance(gpu, (bool, np.bool_)):
        raise TypeError("gpu must be True or False")
    if not isinstance(sample_info, (bool, np.bool_)):
        raise TypeError("sample_info must be True or False")
    if (
        not np.isfinite(fe_variance_ratio_min)
        or fe_variance_ratio_min < 0
    ):
        raise ValueError(
            "fe_variance_ratio_min must be finite and nonnegative"
        )
    if vce not in ("unadjusted", "robust", "cluster"):
        raise ValueError("vce must be 'unadjusted', 'robust' or 'cluster'")
    if vce == "cluster":
        if cluster is None:
            raise ValueError("vce='cluster' requires cluster ids")
        cluster = np.asarray(cluster)
        if cluster.ndim != 1 or cluster.shape[0] != n:
            raise ValueError("cluster ids must be one-dimensional with length n")
        if np.issubdtype(cluster.dtype, np.number) and not np.all(np.isfinite(cluster)):
            raise ValueError("cluster ids must not contain missing or non-finite values")
        _, ccodes = np.unique(cluster, return_inverse=True)
        if np.unique(ccodes).size < 2:
            raise ValueError("vce='cluster' requires at least two clusters")
    else:
        # Single source of truth: cluster ids with a non-cluster vce would
        # otherwise be silently dropped and the user would get robust/
        # unadjusted SEs labelled as such — match the Stata and R front-ends,
        # which reject this combination rather than ignore it.
        if cluster is not None:
            raise ValueError("cluster ids supplied but vce != 'cluster'")
        ccodes = None
    x2_groups = dict(x2_groups or {})
    fes = dict(fes or {})
    common_fes = dict(common_fes or {})
    if not x2_groups and not fes:
        raise ValueError(
            "provide at least one x2 group or added fixed-effect dimension"
        )
    all_names = list(x2_groups) + list(common_fes) + list(fes)
    if any(not isinstance(name, str) or not name.strip() for name in all_names):
        raise ValueError("every x2/FE block must have a non-empty string name")
    if len(set(all_names)) != len(all_names):
        raise ValueError("x2, common-FE and added-FE names must be unique")
    if not isinstance(connected, str):
        raise TypeError("connected must be 'diagnose' or 'require'")
    connected_mode = connected.strip().lower()
    if connected_mode not in ("diagnose", "require"):
        raise ValueError("connected must be 'diagnose' or 'require'")
    fe_names = list(fes)
    connectivity_fe_pair = _connectivity_fe_indices(
        connectivity_fes, fe_names
    )
    if connected_mode == "require" and (
            len(fe_names) != 2 or common_fes):
        raise ValueError(
            "connected='require' requires exactly two FE dimensions, both "
            "added, and no common FEs; this split is not yet certified with "
            "common FEs or a multiway added-FE design"
        )

    if absorbed_targets is None:
        absorbed_x1 = []
    else:
        target_arr = np.asarray(absorbed_targets)
        if target_arr.ndim == 0:
            target_arr = target_arr.reshape(1)
        if target_arr.ndim != 1:
            raise ValueError(
                "absorbed_targets must be a one-dimensional name/index "
                "selector or boolean mask"
            )
        target_values = target_arr.tolist()
        if all(isinstance(value, str) for value in target_values):
            unknown = [value for value in target_values
                       if value not in x1_labels]
            if unknown:
                raise ValueError(
                    f"absorbed_targets contains unknown x1 name(s): {unknown}"
                )
            absorbed_x1 = [x1_labels.index(value) for value in target_values]
            if len(set(absorbed_x1)) != len(absorbed_x1):
                raise ValueError("absorbed_targets names must be unique")
        elif any(isinstance(value, str) for value in target_values):
            raise ValueError(
                "absorbed_targets must contain names, indices, or a boolean "
                "mask, not a mixture"
            )
        elif np.issubdtype(target_arr.dtype, np.bool_):
            if target_arr.size != p:
                raise ValueError("an absorbed_targets boolean mask must have length p")
            absorbed_x1 = np.flatnonzero(target_arr).astype(int).tolist()
        else:
            if not np.issubdtype(target_arr.dtype, np.integer):
                if (np.issubdtype(target_arr.dtype, np.floating) and
                        np.all(np.isfinite(target_arr)) and
                        np.all(target_arr == np.rint(target_arr))):
                    target_arr = np.rint(target_arr).astype(np.int64)
                else:
                    raise ValueError("absorbed_targets indices must be integers")
            absorbed_x1 = target_arr.astype(int).tolist()
            if any(c < 0 or c >= p for c in absorbed_x1):
                raise ValueError("absorbed_targets index is outside the x1 column range")
            if len(set(absorbed_x1)) != len(absorbed_x1):
                raise ValueError("absorbed_targets indices must be unique")
        if absorbed_x1 and not fes:
            raise ValueError("absorbed_targets requires at least one absorbed FE dimension")

    groups = []  # (name, kind, payload)
    x2_cols = []
    for name, arr in x2_groups.items():
        arr = np.asarray(arr, dtype=float)
        if arr.ndim == 1:
            arr = arr[:, None]
        if arr.shape[0] != n:
            raise ValueError(f"x2 group {name!r} has wrong length")
        if arr.shape[1] == 0:
            raise ValueError(f"x2 group {name!r} must contain at least one column")
        if not np.all(np.isfinite(arr)):
            raise ValueError(f"x2 group {name!r} must contain only finite values")
        groups.append((name, "x2", arr))
        x2_cols.append(arr)
    common_fe_lists = []
    for name, ids in common_fes.items():
        ids = np.asarray(ids)
        if ids.ndim != 1 or ids.shape[0] != n:
            raise ValueError(
                f"common fe {name!r} must be one-dimensional with length n"
            )
        if not np.issubdtype(ids.dtype, np.integer):
            if (np.issubdtype(ids.dtype, np.floating) and
                    np.all(np.isfinite(ids)) and
                    np.all(ids == np.rint(ids))):
                ids = np.rint(ids).astype(np.int64)
            else:
                raise ValueError(
                    f"common fe {name!r} ids must be finite integers"
                )
        common_fe_lists.append(ids)
    fe_lists = []
    for name, ids in fes.items():
        ids = np.asarray(ids)
        if ids.ndim != 1 or ids.shape[0] != n:
            raise ValueError(f"fe {name!r} must be one-dimensional with length n")
        if not np.issubdtype(ids.dtype, np.integer):
            if (np.issubdtype(ids.dtype, np.floating) and
                    np.all(np.isfinite(ids)) and np.all(ids == np.rint(ids))):
                ids = np.rint(ids).astype(np.int64)
            else:
                raise ValueError(f"fe {name!r} ids must be finite integers")
        groups.append((name, "fe", len(fe_lists)))
        fe_lists.append(ids)

    w = None
    if weights is not None:
        w = np.ascontiguousarray(weights, dtype=float)
        if w.ndim != 1 or w.shape[0] != n:
            raise ValueError("weights must be one-dimensional with length n")
        if not np.all(np.isfinite(w)) or np.any(w <= 0):
            raise ValueError("weights must be finite and strictly positive")
        if fweights and not np.all(w == np.rint(w)):
            raise ValueError("frequency weights must be integers")
    elif fweights:
        raise ValueError("fweights=True requires weights")

    core = _core()
    if not hasattr(core, "gelbach_decompose"):
        raise ImportError("the compiled xhdfe extension predates the Gelbach "
                          "module; rebuild the package")

    x2_sizes = [np.asarray(d).shape[1] for _, k, d in groups if k == "x2"]
    X2 = (np.hstack([np.asarray(d, dtype=float) for _, k, d in groups
                     if k == "x2"]) if x2_sizes else None)
    union_fe_lists = common_fe_lists + fe_lists
    r = core.gelbach_decompose(y, x1, x2=X2, x2_group_sizes=x2_sizes,
                               fes=union_fe_lists if union_fe_lists else None,
                               cluster=(np.ascontiguousarray(ccodes, dtype=np.int64)
                                        if ccodes is not None else None),
                               vce=vce, gamma0=bool(gamma0), cov0=bool(cov0),
                               tol=float(tol), num_threads=num_threads,
                               weights=w,
                               fweights=bool(fweights),
                               absorbed_x1=absorbed_x1,
                               gpu=bool(gpu),
                               connectivity_fe_pair=connectivity_fe_pair,
                               require_connected=(
                                   connected_mode == "require"
                               ),
                               n_common_fes=len(common_fe_lists),
                               sample_info=bool(sample_info))

    p_ = x1.shape[1]
    k1 = p_ + 1
    delta = np.asarray(r["delta"])
    fullcov = np.asarray(r["cov"])
    # group order in the compiled core: x2 groups first, then FE dims — match
    # the caller's insertion order of `groups`.
    order = [g for g, (_, kind, _d) in enumerate(groups) if kind == "x2"] + \
            [g for g, (_, kind, _d) in enumerate(groups) if kind == "fe"]
    names = [groups[g][0] for g in order]
    kinds = [groups[g][1] for g in order]
    gamma_raw = np.asarray(r["gamma"], dtype=float)
    gamma = {
        names[g]: gamma_raw[:width, g].copy()
        for g, width in enumerate(x2_sizes)
    }
    labels = x1_labels + ["_cons"]
    beta2 = np.asarray(r["beta2"], dtype=float)
    beta2_cov = np.asarray(r["beta2_cov"], dtype=float)
    auxiliary_loadings = np.asarray(r["auxiliary_loadings"], dtype=float)
    loading_ss_ratio = np.asarray(
        r["auxiliary_loading_ss_ratio"], dtype=float
    )
    loading_rank = np.asarray(r["auxiliary_loading_rank"], dtype=int)
    loading_condition = np.asarray(
        r["auxiliary_loading_condition_number"], dtype=float
    )
    loading_max_abs_z = np.asarray(
        r["auxiliary_loading_max_abs_z"], dtype=float
    )
    loading_pvalue = np.asarray(
        r["auxiliary_loading_pvalue"], dtype=float
    )
    loading_test_evaluated = np.asarray(
        r["auxiliary_loading_test_evaluated"], dtype=bool
    )
    beta2_wald_stat = np.asarray(r["beta2_wald_stat"], dtype=float)
    beta2_wald_df = np.asarray(r["beta2_wald_df"], dtype=int)
    beta2_wald_pvalue = np.asarray(r["beta2_wald_pvalue"], dtype=float)
    gradient_norm = np.asarray(
        r["contribution_gradient_norm"], dtype=float
    )
    regular_valid_raw = np.asarray(
        r["regular_inference_valid"], dtype=bool
    )
    regular_status_raw = np.asarray(
        list(r["regular_inference_status"]), dtype=object
    ).reshape(len(x2_sizes), k1).T
    regularity = {}
    x2_cursor = 0
    for g, width in enumerate(x2_sizes):
        name = names[g]
        block_slice = slice(x2_cursor, x2_cursor + width)
        regularity[name] = {
            "beta2": beta2[block_slice].copy(),
            "beta2_cov": beta2_cov[block_slice, block_slice].copy(),
            "auxiliary_loadings": auxiliary_loadings[:, block_slice].copy(),
            "auxiliary_loading_ss_ratio": float(loading_ss_ratio[g]),
            "auxiliary_loading_rank": int(loading_rank[g]),
            "auxiliary_loading_condition_number": float(
                loading_condition[g]
            ),
            "auxiliary_loading_max_abs_z": loading_max_abs_z[:, g].copy(),
            "auxiliary_loading_pvalue": loading_pvalue[:, g].copy(),
            "auxiliary_loading_test_evaluated":
                loading_test_evaluated[:, g].copy(),
            "beta2_wald_stat": float(beta2_wald_stat[g]),
            "beta2_wald_df": int(beta2_wald_df[g]),
            "beta2_wald_pvalue": float(beta2_wald_pvalue[g]),
            "contribution_gradient_norm": gradient_norm[:, g].copy(),
            "regular_inference_valid": regular_valid_raw[:, g].copy(),
            "regular_inference_status":
                regular_status_raw[:, g].astype(str).tolist(),
        }
        x2_cursor += width
    observed_se_type = (
        "gamma0" if gamma0 else
        ("cov0" if cov0 and vce != "unadjusted" else "full")
    )
    se_type = {
        name: ("conditional_gamma0" if kind == "fe" else
               observed_se_type)
        for name, kind in zip(names, kinds)
    }
    absorbed_mask = np.asarray(r["x1_absorbed"], dtype=bool)
    absorbed_mode = bool(np.any(absorbed_mask))
    b_full_status = ["imposed_zero" if value else "estimated"
                     for value in absorbed_mask]
    focal_status = ["absorbed" if value else "identified"
                    for value in absorbed_mask]
    has_fe_groups = any(kind == "fe" for kind in kinds)
    has_observed_groups = any(kind == "x2" for kind in kinds)
    x1_fe_collinear_ratio = np.asarray(
        r["x1_fe_collinear_ratio"], dtype=float
    )
    fe_variance_status = [
        (
            "conditional_only_between_fe_dominant"
            if (
                has_fe_groups
                and (
                    not np.isfinite(x1_fe_collinear_ratio[row])
                    or x1_fe_collinear_ratio[row] <= fe_variance_ratio_min
                )
            )
            else "valid_first_order"
        )
        for row in range(p)
    ]
    fe_variance_failed = any(
        status == "conditional_only_between_fe_dominant"
        for status in fe_variance_status
    )
    total_cov = np.asarray(r["total_cov"])
    if has_fe_groups:
        total_se_type = (
            "conditional_gamma0" if gamma0 or not has_observed_groups else
            ("mixed_cov0_observed_conditional_fe"
             if cov0 and vce != "unadjusted" else
             "mixed_full_observed_conditional_fe")
        )
    else:
        total_se_type = observed_se_type
    if absorbed_mode:
        total_se_type = "target_exact_base_vce_mixed_components"
    fe_diagnostic_suffix = "_conditional_only_diagnostic"
    if fe_variance_failed and has_fe_groups:
        total_se_type += fe_diagnostic_suffix
        for name, kind in zip(names, kinds):
            if kind == "fe":
                se_type[name] += fe_diagnostic_suffix
    inference_status = "not_applicable"
    if absorbed_mode:
        inference_status = (
            "clustered_at_absorbing_fe"
            if bool(r["absorbed_target_inference_valid"])
            else "warning_unsupported_vce_or_cluster"
        )
    connectivity_indices = [
        int(r["connectivity_fe_index1"]),
        int(r["connectivity_fe_index2"]),
    ]
    connectivity_indices = [
        value for value in connectivity_indices if value >= 0
    ]
    connectivity_names = [
        fe_names[value] for value in connectivity_indices
    ]
    sample_index = None
    sample_mask = None
    sample_hash = None
    sample_hash_algorithm = None
    sample_index_scope = None
    if sample_info:
        sample_index = np.asarray(r["sample_index"], dtype=np.int64)
        if sample_index.ndim != 1 or sample_index.size != int(r["n_obs"]):
            raise RuntimeError(
                "Gelbach backend returned an invalid retained-sample index"
            )
        if (sample_index.size and
                (sample_index[0] < 0 or sample_index[-1] >= n or
                 np.any(np.diff(sample_index) <= 0))):
            raise RuntimeError(
                "Gelbach backend returned unordered, duplicate, or "
                "out-of-range retained-sample positions"
            )
        sample_mask = np.zeros(n, dtype=bool)
        sample_mask[sample_index] = True
        sample_hash = str(r["sample_hash"])
        sample_hash_algorithm = str(r["sample_hash_algorithm"])
        sample_index_scope = str(r["sample_index_scope"])
        if (not sample_hash or
                sample_hash_algorithm != "fnv1a64-le-v1" or
                sample_index_scope != "input_rows_zero_based"):
            raise RuntimeError(
                "Gelbach backend returned incomplete sample provenance"
            )
    out = {
        "names": names,
        "group_kinds": dict(zip(names, kinds)),
        "labels": labels,
        "x1_names": x1_labels,
        "focal_indices": focal_x1,
        "focal_names": [x1_labels[c] for c in focal_x1],
        "common_fe_names": list(common_fes),
        "n_common_fes": int(r["n_common_fes"]),
        "common_fes_applied": bool(r["common_fes_applied"]),
        "intercept_inference_available": bool(
            r["intercept_inference_available"]
        ),
        "intercept_status": str(r["intercept_status"]),
        "b_base": np.asarray(r["b_base"]),
        "b_full": np.asarray(r["b_full"]),
        "b_full_status": b_full_status,
        "gamma": gamma,
        "beta2": beta2,
        "beta2_cov": beta2_cov,
        "auxiliary_loadings": auxiliary_loadings,
        "regularity": regularity,
        "regular_inference_valid": {
            name: regularity[name]["regular_inference_valid"]
            for name in names[:len(x2_sizes)]
        },
        "regular_inference_status": {
            name: regularity[name]["regular_inference_status"]
            for name in names[:len(x2_sizes)]
        },
        "regular_inference_all_valid": bool(
            r["regular_inference_all_valid"]
        ),
        "regularity_test_alpha": float(r["regularity_test_alpha"]),
        "focal_status": focal_status,
        "absorbed_mask": absorbed_mask.astype(bool).tolist(),
        "absorbed_targets": np.flatnonzero(absorbed_mask).astype(int).tolist(),
        "absorbed_target_names": [labels[c] for c in np.flatnonzero(absorbed_mask)],
        "delta": {
            name: {"coef": delta[:, g],
                   "se": np.sqrt(np.diag(
                       fullcov[g * k1:(g + 1) * k1, g * k1:(g + 1) * k1])),
                   "se_type": se_type[name]}
            for g, name in enumerate(names)
        },
        "total": {"coef": np.asarray(r["total"]),
                  "cov": total_cov,
                  "se": np.sqrt(np.diag(total_cov)),
                  "se_type": total_se_type},
        "total_cov": total_cov,
        "cov": fullcov,
        "base_cov": np.asarray(r["base_cov"]),
        "cov_delta_bbase": np.asarray(r["cov_delta_bbase"]),
        "cov_total_bbase": np.asarray(r["cov_total_bbase"]),
        "identity_gap": float(r["identity_gap"]),
        "n_obs_input": int(r["n_obs_input"]),
        "n_obs": int(r["n_obs"]),
        "n_obs_effective": int(r["n_obs_effective"]),
        "n_singletons_dropped": int(r["n_singletons_dropped"]),
        "sample_info_requested": bool(sample_info),
        "sample_index": sample_index,
        "sample_mask": sample_mask,
        "sample_hash": sample_hash,
        "sample_hash_algorithm": sample_hash_algorithm,
        "sample_index_scope": sample_index_scope,
        "n_mobility_components": int(r["n_mobility_components"]),
        "largest_mobility_component_n_obs": int(
            r["largest_mobility_component_n_obs"]
        ),
        "largest_mobility_component_share": float(
            r["largest_mobility_component_share"]
        ),
        "largest_mobility_component_weight_share": float(
            r["largest_mobility_component_weight_share"]
        ),
        "fe_split_identified": bool(r["fe_split_identified"]),
        "fe_split_status": str(r["fe_split_status"]),
        "connectivity_fe_index1": int(
            r["connectivity_fe_index1"]
        ),
        "connectivity_fe_index2": int(
            r["connectivity_fe_index2"]
        ),
        "connectivity_fe_indices": connectivity_indices,
        "connectivity_fe_names": connectivity_names,
        "connectivity_pair_explicit": bool(
            r["connectivity_pair_explicit"]
        ),
        "connectivity_pair_status": str(
            r["connectivity_pair_status"]
        ),
        "connected_mode": str(r["connected_mode"]),
        "mobility_component_scope": str(
            r["mobility_component_scope"]
        ),
        "df_full": float(r["df_full"]),
        "df_base": float(r["df_base"]),
        "n_clusters": int(r["n_clusters"]),
        "x1_fe_collinear_ratio": x1_fe_collinear_ratio,
        "fe_variance_status": fe_variance_status,
        "fe_variance_ratio_min": float(fe_variance_ratio_min),
        "x1_near_collinear_mask": np.asarray(
            r["x1_near_collinear_mask"], dtype=bool
        ).tolist(),
        "fe_collinear_ss_ratio_tol": float(r["fe_collinear_ss_ratio_tol"]),
        "near_fe_collinear_ss_ratio_warn_upper": float(
            r["near_fe_collinear_ss_ratio_warn_upper"]
        ),
        "few_cluster_warning_threshold": int(
            r["few_cluster_warning_threshold"]
        ),
        "fe_collinear_relative_norm_tol": float(
            np.sqrt(r["fe_collinear_ss_ratio_tol"])
        ),
        "absorbed_target_inference_valid": bool(
            r["absorbed_target_inference_valid"]
        ),
        "absorbing_fe_index": int(r["absorbing_fe_index"]),
        "inference_status": inference_status,
        "vce": vce,
        "gamma0": bool(gamma0),
        "cov0": bool(cov0),
        "tol": float(tol),
        "threads_requested": int(r["threads_requested"]),
        "threads_effective": int(r["threads_effective"]),
        "recovery_threads_effective": int(
            r["recovery_threads_effective"]
        ),
        "fullfit_threads_used": int(r["fullfit_threads_used"]),
        "fullfit_parallel_workers_active": int(
            r["fullfit_parallel_workers_active"]
        ),
        "recovery_threads_used": int(r["recovery_threads_used"]),
        "recovery_parallel_workers_active": int(
            r["recovery_parallel_workers_active"]
        ),
        "covariance_threads_used": int(
            r["covariance_threads_used"]
        ),
        "covariance_parallel_workers_active": int(
            r["covariance_parallel_workers_active"]
        ),
        "threads_used": int(r["threads_used"]),
        "parallel_workers_active": int(
            r["parallel_workers_active"]
        ),
        "thread_capacity": int(r["thread_capacity"]),
        "openmp_enabled": bool(r["openmp_enabled"]),
        "thread_limit_code": int(r["thread_limit_code"]),
        "thread_limit_reason": str(r["thread_limit_reason"]),
        "gpu_requested": bool(r["gpu_requested"]),
        "gpu_used": bool(r["gpu_used"]),
        "gpu_status_code": int(r["gpu_status_code"]),
        "gpu_backend": str(r["gpu_backend"]),
        "gpu_status": str(r["gpu_status"]),
        "gpu_attempted": bool(r["gpu_attempted"]),
        "gpu_absorption_converged": bool(
            r["gpu_absorption_converged"]
        ),
        "gpu_absorption_iterations": int(
            r["gpu_absorption_iterations"]
        ),
        "estimand": ("absorbed_target_allocation" if absorbed_mode else
                     "coefficient_movement"),
        "identity_status": (
            "exact_ols_conditional_common_fes"
            if common_fes else
            ("exact_ols_constrained" if absorbed_mode else "exact_ols")
        ),
        "total_se_type": total_se_type,
        "causal_interpretation": False,
        "notes": r["notes"],
        "converged": bool(r["converged"]),
    }
    for name in names:
        if out["group_kinds"][name] == "x2":
            out["delta"][name].update({
                "regular_inference_valid":
                    regularity[name]["regular_inference_valid"],
                "regular_inference_status":
                    regularity[name]["regular_inference_status"],
                "contribution_gradient_norm":
                    regularity[name]["contribution_gradient_norm"],
            })
        else:
            out["delta"][name].update({
                "regular_inference_valid": None,
                "regular_inference_status":
                    ["not_applicable_conditional_fe"] * k1,
                "contribution_gradient_norm":
                    np.full(k1, np.nan, dtype=float),
            })
    fe_groups = [g for g, kind in enumerate(kinds) if kind == "fe"]
    if fe_groups:
        fe_coef = delta[:, fe_groups].sum(axis=1)
        fe_cov = np.zeros((k1, k1), dtype=float)
        for g in fe_groups:
            for h in fe_groups:
                fe_cov += fullcov[g * k1:(g + 1) * k1,
                                  h * k1:(h + 1) * k1]
        out["fe_total"] = {
            "members": [names[g] for g in fe_groups],
            "coef": fe_coef,
            "cov": fe_cov,
            "se": np.sqrt(np.diag(fe_cov)),
            "se_type": se_type[names[fe_groups[0]]],
            "fe_variance_status": fe_variance_status,
        }
    else:
        out["fe_total"] = None
    if fe_variance_failed:
        failed_names = [
            x1_labels[row]
            for row, status in enumerate(fe_variance_status)
            if status == "conditional_only_between_fe_dominant"
        ]
        fe_note = (
            "WARNING: conditional FE-block and mixed-total normal intervals "
            "are diagnostic only because x1_fe_collinear_ratio is at or below "
            f"fe_variance_ratio_min={fe_variance_ratio_min:g} for "
            f"{','.join(failed_names)}. Use xhdfe.gelbach.bootstrap with the "
            "pairs method for the calibrated alternative."
        )
        out["notes"] = f"{out['notes'].strip()} {fe_note}".strip()
    if not r["converged"]:
        out["notes"] += " (not converged)"
        import warnings

        warnings.warn(
            "xhdfe.gelbach.decompose: the decomposition did not converge or "
            "failed a convergence cross-check — results are unreliable. "
            f"notes: {out['notes'].strip()}",
            RuntimeWarning,
            stacklevel=2,
        )
    elif "warning:" in out["notes"].lower():
        import warnings

        warnings.warn(
            "xhdfe.gelbach.decompose: inferential diagnostic. "
            f"notes: {out['notes'].strip()}",
            RuntimeWarning,
            stacklevel=2,
        )
    return out


def _result_focal_indices(result, focal=None, include_intercept=False):
    labels = list(result["labels"])
    p = len(result["b_base"])
    selected = _focal_indices(
        result.get("focal_indices") if focal is None else focal,
        p,
        labels[:p],
    )
    if include_intercept:
        selected.append(p)
    return selected


def _row_group_covariance(result, row):
    names = list(result["names"])
    k1 = len(result["labels"])
    positions = [g * k1 + row for g in range(len(names))]
    return np.asarray(result["cov"])[np.ix_(positions, positions)]


def _share_rows(result, denominator, share_tol, share_t_min):
    if denominator not in ("base", "base_fixed", "movement"):
        raise ValueError("share must be None, 'base', 'base_fixed' or 'movement'")
    if not np.isfinite(share_tol) or share_tol < 0:
        raise ValueError("share_tol must be finite and nonnegative")
    if not np.isfinite(share_t_min) or share_t_min < 0:
        raise ValueError("share_t_min must be finite and nonnegative")

    names = list(result["names"])
    k1 = len(result["labels"])
    p = len(result["b_base"])
    G = len(names)
    coef = np.column_stack([result["delta"][name]["coef"] for name in names])
    share = np.full((k1, G), np.nan)
    se = np.full((k1, G), np.nan)
    defined = np.zeros(k1, dtype=bool)
    denominator_t = np.full(k1, np.nan)
    interval_status = np.full(
        k1,
        "weak_denominator_delta_method_unreliable",
        dtype=object,
    )

    for row in range(k1):
        if denominator in ("base", "base_fixed"):
            if row >= p:
                continue
            denom = float(result["b_base"][row])
            denom_var = float(np.asarray(result["base_cov"])[row, row])
        else:
            denom = float(result["total"]["coef"][row])
            denom_var = float(np.asarray(result["total_cov"])[row, row])
        if not np.isfinite(denom) or abs(denom) <= share_tol:
            continue
        denom_se = np.sqrt(max(0.0, denom_var))
        denominator_t[row] = (
            abs(denom) / denom_se if denom_se > 0.0 else np.inf
        )
        if denominator_t[row] >= share_t_min:
            interval_status[row] = "valid_first_order"
        defined[row] = True
        d = coef[row, :]
        share[row, :] = d / denom
        V = _row_group_covariance(result, row)
        if denominator == "base_fixed":
            # This is the reporting convention used in several applications:
            # scale Gelbach's component SE by the reported base coefficient.
            # Deliberately hold the denominator fixed even though the joint
            # covariance is now public, and label that convention explicitly.
            se[row, :] = np.sqrt(np.maximum(0.0, np.diag(V))) / abs(denom)
        elif denominator == "base":
            base_cov = np.asarray(result["base_cov"])
            cross = np.asarray(result["cov_delta_bbase"])
            var_base = float(base_cov[row, row])
            for g in range(G):
                cov_delta_base = float(cross[g * k1 + row, row])
                variance = (
                    float(V[g, g]) / (denom * denom)
                    + d[g] * d[g] * var_base / (denom ** 4)
                    - 2.0 * d[g] * cov_delta_base / (denom ** 3)
                )
                se[row, g] = (
                    np.sqrt(max(0.0, variance))
                    if np.isfinite(variance) else np.nan
                )
        elif denominator == "movement":
            # The movement is exactly sum_g delta_g, so the joint covariance
            # already contains everything needed for the ratio delta method.
            for g in range(G):
                grad = -d[g] * np.ones(G) / (denom * denom)
                grad[g] += 1.0 / denom
                se[row, g] = np.sqrt(max(0.0, float(grad @ V @ grad)))
    return {
        "coef": share,
        "se": se,
        "defined": defined,
        "denominator_t": denominator_t,
        "interval_status": interval_status.astype(str).tolist(),
        "denominator": denominator,
        "se_type": ("joint_base_covariance_delta_method" if denominator == "base"
                    else ("fixed_base_denominator_scaling"
                          if denominator == "base_fixed" else
                          "joint_covariance_delta_method")),
        "units": "fraction",
        "tol": float(share_tol),
        "t_min": float(share_t_min),
    }


def tidy(result, *, focal=None, include_intercept=False, include_total=True,
         include_full=True, conf_level=0.95, share=None, share_tol=1e-12,
         share_t_min=3.0):
    """Return publication-ready Gelbach rows without changing the estimator.

    The result is a list of dictionaries, so it can be passed directly to
    pandas, Polars or a CSV writer without adding a package dependency.
    ``share='base'`` reports the common ``delta / b_base`` convention and
    obtains full ratio inference from ``base_cov`` and
    ``cov_delta_bbase``. ``share='base_fixed'`` preserves the widespread
    fixed-denominator scaling convention, labelled as such.
    ``share='movement'`` uses the full joint covariance and the delta method
    for ``delta / sum(delta)``.
    Signed shares are never truncated or renormalized.

    Parameters
    ----------
    result : dictionary returned by :func:`decompose`.
    focal : optional X1 names, zero-based indices, or Boolean mask. If omitted,
        use the selector stored by :func:`decompose`.
    include_intercept : include the implicit ``_cons`` row.
    include_total : add a ``total_movement`` row.
    include_full : add a ``full_model_residual`` row; its SE is unavailable.
    conf_level : normal-approximation confidence level in (0, 1).
    share : None, ``'movement'``, ``'base'``, or ``'base_fixed'``.
    share_tol : nonnegative absolute threshold below which ratios are missing.
    share_t_min : nonnegative minimum absolute denominator t-statistic for
        first-order delta-method share inference. Point shares and SEs are
        retained below this diagnostic threshold.

    Returns
    -------
    list of dictionaries with coefficient/component labels, estimates, SEs,
    confidence intervals and inference type; share fields are added only when
    requested. See ``xhdfe.help_text('gelbach')`` for the complete schema.
    """
    if not 0 < conf_level < 1:
        raise ValueError("conf_level must lie strictly between zero and one")
    rows = _result_focal_indices(result, focal, include_intercept)
    zcrit = NormalDist().inv_cdf(0.5 + conf_level / 2.0)
    share_stats = (
        None if share is None
        else _share_rows(result, share, share_tol, share_t_min)
    )
    if share_stats is not None:
        undefined = [
            result["labels"][row]
            for row in rows
            if not share_stats["defined"][row]
        ]
        if undefined:
            import warnings

            warnings.warn(
                "xhdfe.gelbach.tidy: requested share denominator is "
                "undefined at the selected share_tol for "
                f"{', '.join(undefined)}; share fields are NaN.",
                RuntimeWarning,
                stacklevel=2,
            )
        weak = [
            result["labels"][row]
            for row in rows
            if (
                share_stats["defined"][row]
                and share_stats["interval_status"][row]
                == "weak_denominator_delta_method_unreliable"
            )
        ]
        if weak:
            import warnings

            warnings.warn(
                "xhdfe.gelbach.tidy: the requested share denominator has "
                f"|t| < share_t_min for {', '.join(weak)}; first-order "
                "delta-method share intervals are diagnostic only. Use "
                "xhdfe.gelbach.bootstrap with the pairs method for the "
                "calibrated alternative.",
                RuntimeWarning,
                stacklevel=2,
            )
    output = []
    p = len(result["b_base"])

    for row in rows:
        label = result["labels"][row]
        fe_variance_status = (
            result["fe_variance_status"][row]
            if row < p else "valid_first_order"
        )
        fe_variance_failed = (
            fe_variance_status
            == "conditional_only_between_fe_dominant"
        )
        for g, name in enumerate(result["names"]):
            estimate = float(result["delta"][name]["coef"][row])
            std_error = float(result["delta"][name]["se"][row])
            component_kind = result["group_kinds"][name]
            if component_kind == "x2":
                regular_valid = bool(
                    result["delta"][name]["regular_inference_valid"][row]
                )
                regular_status = str(
                    result["delta"][name]["regular_inference_status"][row]
                )
                interval_status = (
                    "valid_first_order"
                    if regular_valid
                    else "diagnostic_only_nonregular_not_ruled_out"
                )
                row_se_type = result["delta"][name]["se_type"]
                if not regular_valid:
                    row_se_type += "_nonregular_diagnostic_only"
            else:
                regular_valid = None
                regular_status = "not_applicable_conditional_fe"
                interval_status = (
                    "diagnostic_only_between_fe_dominant"
                    if fe_variance_failed
                    else "conditional_fe_not_covered"
                )
                row_se_type = result["delta"][name]["se_type"]
                diagnostic_suffix = "_conditional_only_diagnostic"
                if (
                    fe_variance_failed
                    and not row_se_type.endswith(diagnostic_suffix)
                ):
                    row_se_type += "_conditional_only_diagnostic"
                elif (
                    not fe_variance_failed
                    and row_se_type.endswith(diagnostic_suffix)
                ):
                    row_se_type = row_se_type[:-len(diagnostic_suffix)]
            item = {
                "coefficient": label,
                "component": name,
                "component_kind": component_kind,
                "estimate": estimate,
                "std_error": std_error,
                "conf_low": estimate - zcrit * std_error,
                "conf_high": estimate + zcrit * std_error,
                "conf_level": float(conf_level),
                "se_type": row_se_type,
                "regular_inference_valid": regular_valid,
                "regular_inference_status": regular_status,
                "confidence_interval_status": interval_status,
                "fe_variance_status": fe_variance_status,
                "fe_variance_ratio_min":
                    result["fe_variance_ratio_min"],
            }
            if share_stats is not None:
                s = float(share_stats["coef"][row, g])
                sse = float(share_stats["se"][row, g])
                share_interval_status = share_stats["interval_status"][row]
                share_se_type = share_stats["se_type"]
                if (
                    share_stats["defined"][row]
                    and share_interval_status
                    == "weak_denominator_delta_method_unreliable"
                ):
                    share_se_type += "_weak_denominator_diagnostic_only"
                item.update({
                    "share": s,
                    "share_std_error": sse,
                    "share_conf_low": s - zcrit * sse,
                    "share_conf_high": s + zcrit * sse,
                    "share_defined": bool(share_stats["defined"][row]),
                    "share_denominator_t":
                        float(share_stats["denominator_t"][row]),
                    "share_interval_status": share_interval_status,
                    "share_denominator": share_stats["denominator"],
                    "share_se_type": share_se_type,
                    "share_units": share_stats["units"],
                    "share_tol": share_stats["tol"],
                    "share_t_min": share_stats["t_min"],
                })
            output.append(item)

        if include_total:
            estimate = float(result["total"]["coef"][row])
            std_error = float(result["total"]["se"][row])
            total_has_fe = any(
                kind == "fe" for kind in result["group_kinds"].values()
            )
            total_se_type = result["total"]["se_type"]
            total_interval_status = "linear_total_not_product_gate"
            if total_has_fe and fe_variance_failed:
                diagnostic_suffix = "_conditional_only_diagnostic"
                if not total_se_type.endswith(diagnostic_suffix):
                    total_se_type += diagnostic_suffix
                total_interval_status = (
                    "diagnostic_only_between_fe_dominant"
                )
            elif total_has_fe:
                diagnostic_suffix = "_conditional_only_diagnostic"
                if total_se_type.endswith(diagnostic_suffix):
                    total_se_type = total_se_type[:-len(diagnostic_suffix)]
            item = {
                "coefficient": label,
                "component": "total_movement",
                "component_kind": "total",
                "estimate": estimate,
                "std_error": std_error,
                "conf_low": estimate - zcrit * std_error,
                "conf_high": estimate + zcrit * std_error,
                "conf_level": float(conf_level),
                "se_type": total_se_type,
                "regular_inference_valid": None,
                "regular_inference_status":
                    "not_applicable_linear_total",
                "confidence_interval_status": total_interval_status,
                "fe_variance_status": fe_variance_status,
                "fe_variance_ratio_min":
                    result["fe_variance_ratio_min"],
            }
            if share_stats is not None:
                share_interval_status = share_stats["interval_status"][row]
                share_se_type = share_stats["se_type"]
                if (
                    share_stats["defined"][row]
                    and share_interval_status
                    == "weak_denominator_delta_method_unreliable"
                ):
                    share_se_type += "_weak_denominator_diagnostic_only"
                if share == "movement" and share_stats["defined"][row]:
                    sval, sse = 1.0, 0.0
                elif share in ("base", "base_fixed") and row < p and share_stats["defined"][row]:
                    denom = float(result["b_base"][row])
                    sval = estimate / denom
                    if share == "base_fixed":
                        sse = std_error / abs(denom)
                    elif row in result["absorbed_targets"]:
                        # A declared absorbed target has total == b_base as
                        # an estimator.  Preserve the already-published point
                        # value (which can differ by last-bit summation noise)
                        # while imposing its exact ratio-variance identity.
                        sse = 0.0
                    else:
                        base_cov = np.asarray(result["base_cov"])
                        total_cross = np.asarray(result["cov_total_bbase"])
                        variance = (
                            float(result["total"]["cov"][row, row])
                            / (denom * denom)
                            + estimate * estimate *
                            float(base_cov[row, row]) / (denom ** 4)
                            - 2.0 * estimate *
                            float(total_cross[row, row]) / (denom ** 3)
                        )
                        sse = (
                            np.sqrt(max(0.0, variance))
                            if np.isfinite(variance) else float("nan")
                        )
                else:
                    sval = sse = float("nan")
                item.update({
                    "share": sval,
                    "share_std_error": sse,
                    "share_conf_low": sval - zcrit * sse,
                    "share_conf_high": sval + zcrit * sse,
                    "share_defined": bool(share_stats["defined"][row]),
                    "share_denominator_t":
                        float(share_stats["denominator_t"][row]),
                    "share_interval_status": share_interval_status,
                    "share_denominator": share_stats["denominator"],
                    "share_se_type": share_se_type,
                    "share_units": share_stats["units"],
                    "share_tol": share_stats["tol"],
                    "share_t_min": share_stats["t_min"],
                })
            output.append(item)

        if include_full and row < p:
            item = {
                "coefficient": label,
                "component": "full_model_residual",
                "component_kind": "full_model",
                "estimate": float(result["b_full"][row]),
                "std_error": float("nan"),
                "conf_low": float("nan"),
                "conf_high": float("nan"),
                "conf_level": float(conf_level),
                "se_type": "not_available_in_public_contract",
                "regular_inference_valid": None,
                "regular_inference_status":
                    "not_applicable_full_model_coefficient",
                "confidence_interval_status": "not_available",
                "fe_variance_status": fe_variance_status,
                "fe_variance_ratio_min":
                    result["fe_variance_ratio_min"],
            }
            if share_stats is not None:
                if share in ("base", "base_fixed") and share_stats["defined"][row]:
                    sval = float(result["b_full"][row] / result["b_base"][row])
                else:
                    sval = float("nan")
                item.update({
                    "share": sval,
                    "share_std_error": float("nan"),
                    "share_conf_low": float("nan"),
                    "share_conf_high": float("nan"),
                    "share_defined": bool(share_stats["defined"][row]),
                    "share_denominator_t":
                        float(share_stats["denominator_t"][row]),
                    "share_interval_status":
                        share_stats["interval_status"][row],
                    "share_denominator": share_stats["denominator"],
                    "share_se_type": "not_available_for_full_model_residual",
                    "share_units": share_stats["units"],
                    "share_tol": share_stats["tol"],
                    "share_t_min": share_stats["t_min"],
                })
            output.append(item)
    return output


def contrast(result, focal, groups, *, conf_level=0.95):
    """Estimate a linear contrast of Gelbach blocks from the joint covariance.

    ``groups`` may be a mapping ``{group_name: weight}``, a sequence of group
    names (all weights one), or a numeric sequence in ``result['names']``
    order. No model is re-estimated.

    ``focal`` must select exactly one X1 coefficient. The returned dictionary
    contains the complete weight mapping, estimate, joint-covariance SE,
    confidence interval and inference qualifier. Contrasts containing an FE
    component retain the conditional-FE label. See
    ``xhdfe.help_text('gelbach')`` for examples and limitations.
    """
    if not 0 < conf_level < 1:
        raise ValueError("conf_level must lie strictly between zero and one")
    rows = _result_focal_indices(result, focal, False)
    if len(rows) != 1:
        raise ValueError("contrast requires exactly one focal coefficient")
    names = list(result["names"])
    if isinstance(groups, dict):
        unknown = [name for name in groups if name not in names]
        if unknown:
            raise ValueError(f"contrast contains unknown group(s): {unknown}")
        weights = np.asarray([float(groups.get(name, 0.0)) for name in names])
    else:
        values = list(groups)
        if values and all(isinstance(value, str) for value in values):
            unknown = [name for name in values if name not in names]
            if unknown:
                raise ValueError(f"contrast contains unknown group(s): {unknown}")
            if len(set(values)) != len(values):
                raise ValueError("contrast group names must be unique")
            weights = np.asarray([1.0 if name in values else 0.0 for name in names])
        else:
            weights = np.asarray(values, dtype=float)
            if weights.ndim != 1 or weights.size != len(names):
                raise ValueError("numeric contrast must have one weight per group")
    if not np.all(np.isfinite(weights)) or not np.any(weights):
        raise ValueError("contrast weights must be finite and not all zero")
    row = rows[0]
    d = np.asarray([result["delta"][name]["coef"][row] for name in names])
    V = _row_group_covariance(result, row)
    estimate = float(weights @ d)
    variance = float(weights @ V @ weights)
    std_error = np.sqrt(max(0.0, variance))
    zcrit = NormalDist().inv_cdf(0.5 + conf_level / 2.0)
    included = [name for name, weight in zip(names, weights) if weight != 0]
    has_fe = any(result["group_kinds"][name] == "fe" for name in included)
    observed_included = [
        name for name in included
        if result["group_kinds"][name] == "x2"
    ]
    invalid_regular = [
        name for name in observed_included
        if not bool(result["delta"][name]["regular_inference_valid"][row])
    ]
    if invalid_regular:
        import warnings

        warnings.warn(
            "xhdfe.gelbach.contrast: first-order regular inference is not "
            "established for included observed block(s) "
            f"{', '.join(invalid_regular)}; the normal-theory interval is "
            "diagnostic only.",
            RuntimeWarning,
            stacklevel=2,
        )
    if invalid_regular:
        regular_valid = False
        regular_status = "contains_nonregular_not_ruled_out"
    elif observed_included:
        regular_valid = True
        regular_status = "regular_observed_components"
    else:
        regular_valid = None
        regular_status = "not_applicable_no_observed_x2"
    se_type = (
        "joint_covariance_including_conditional_fe" if has_fe else
        "joint_covariance"
    )
    if invalid_regular:
        se_type += "_nonregular_diagnostic_only"
    return {
        "coefficient": result["labels"][row],
        "weights": dict(zip(names, weights.tolist())),
        "estimate": estimate,
        "std_error": float(std_error),
        "conf_low": estimate - zcrit * std_error,
        "conf_high": estimate + zcrit * std_error,
        "conf_level": float(conf_level),
        "se_type": se_type,
        "regular_inference_valid": regular_valid,
        "regular_inference_status": regular_status,
        "confidence_interval_status": (
            "diagnostic_only_nonregular_not_ruled_out"
            if invalid_regular else
            "valid_first_order_or_not_applicable"
        ),
    }


def bootstrap(y, x1, x2_groups=None, fes=None, *, method="pairs",
              bootstrap_cluster=None, reps=999, seed=0, conf_level=0.95,
              ci_method="percentile", min_valid_reps=None,
              store_draws=True, require_gpu_used=False, share_tol=1e-12,
              **decompose_kwargs):
    """Fit a Gelbach decomposition and fully re-estimate a pairs bootstrap.

    Parameters specific to resampling are keyword-only. All remaining keyword
    arguments are forwarded to :func:`decompose`, including ``common_fes``,
    VCE, weights, absorbed targets, connectivity controls and GPU selection.

    ``method='pairs'`` samples observations. ``method='cluster_pairs'``
    requires ``bootstrap_cluster`` and samples those blocks; the resampling
    unit is deliberately not inferred from ``vce='cluster'``. Each replication
    receives an independent deterministic RNG stream derived from ``seed``.
    Both methods resample the retained point-estimation sample, after singleton
    and connectivity exclusions; excluded rows cannot re-enter a replication.
    Failed fits are retained in an auditable ledger and the procedure fails
    closed below ``min_valid_reps``.

    Frequency-weight bootstrap is deliberately rejected because resampling
    compressed records is not equivalent to resampling the expanded empirical
    distribution. Analytic weights are retained on every sampled pair.

    Returns
    -------
    The ordinary :func:`decompose` result with a ``bootstrap`` member
    containing full draws (unless ``store_draws=False``), percentile or basic
    intervals, bootstrap standard errors, replication ledger, failure counts
    and resampling metadata.
    """
    from ._gelbach_features import bootstrap as _bootstrap

    return _bootstrap(
        decompose,
        y,
        x1,
        x2_groups=x2_groups,
        fes=fes,
        method=method,
        bootstrap_cluster=bootstrap_cluster,
        reps=reps,
        seed=seed,
        conf_level=conf_level,
        ci_method=ci_method,
        min_valid_reps=min_valid_reps,
        store_draws=store_draws,
        require_gpu_used=require_gpu_used,
        share_tol=share_tol,
        **decompose_kwargs,
    )


def etable(result, *, panels="all", format="dataframe", type=None,
           focal=None, keep=None, drop=None, exact_match=False, labels=None,
           include_other=True, digits=3, caption=None, notes=None, conf_level=0.95,
           interval="auto", share_tol=1e-12, share_t_min=3.0):
    """Render Gelbach results as records, DataFrame, Markdown, LaTeX, HTML or GT.

    Bootstrap intervals are selected automatically when ``result`` was
    produced by :func:`bootstrap`; pass ``interval='normal'`` to request the
    analytic interval explicitly. ``type=`` is accepted as a PyFixest-style
    alias for ``format=``.
    """
    from ._gelbach_features import etable as _etable

    return _etable(
        result,
        tidy,
        panels=panels,
        format=format,
        type=type,
        focal=focal,
        keep=keep,
        drop=drop,
        exact_match=exact_match,
        labels=labels,
        include_other=include_other,
        digits=digits,
        caption=caption,
        notes=notes,
        conf_level=conf_level,
        interval=interval,
        share_tol=share_tol,
        share_t_min=share_t_min,
    )


def waterfall_data(result, *, focal=None, keep=None, drop=None,
                   exact_match=False, labels=None, include_other=True,
                   share_tol=1e-12):
    """Return a dependency-free specification for a Gelbach waterfall chart."""
    from ._gelbach_features import waterfall_data as _waterfall_data

    return _waterfall_data(
        result,
        focal=focal,
        keep=keep,
        drop=drop,
        exact_match=exact_match,
        labels=labels,
        include_other=include_other,
        share_tol=share_tol,
    )


def coefplot(result, *, focal=None, annotate_shares=True, title=None,
             figsize=None, keep=None, drop=None, exact_match=False,
             labels=None, notes=None, include_other=True, share_tol=1e-12,
             ax=None, save=None, show=False):
    """Draw an identity-preserving Gelbach waterfall chart.

    Matplotlib is an optional dependency. For dependency-free reporting use
    :func:`waterfall_data`.
    """
    from ._gelbach_features import coefplot as _coefplot

    return _coefplot(
        result,
        focal=focal,
        annotate_shares=annotate_shares,
        title=title,
        figsize=figsize,
        keep=keep,
        drop=drop,
        exact_match=exact_match,
        labels=labels,
        notes=notes,
        include_other=include_other,
        share_tol=share_tol,
        ax=ax,
        save=save,
        show=show,
    )
